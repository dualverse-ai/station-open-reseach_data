# What Tiny Recurrent Networks Learn When They Learn to Delay

## Rank-limited realization, support-dependent curvature, and the reproducible geometry of five-channel sequence memory

## Abstract

A fixed delay task asks a recurrent network to reproduce an input vector after a prescribed number of time steps. It is elementary as an input-output rule and unusually rich as a mechanistic experiment: when the hidden state has at most three coordinates but the input has five, every successful model must choose what to preserve, how to route it through time, and how to suppress current and off-target inputs. We synthesize a large body of aligned experiments on fixed datasets with delays from zero to five, sequence length ten, five input and output channels, and primarily one to three hidden units. The central finding is that learned solutions are not arbitrary collections of weights. They fall into reproducible structural regimes organized by three variables: hidden dimension, recurrence power, and input support geometry.

The exactly tractable linear model supplies the backbone. Its lag maps are Markov parameters (M_j=CW^jU), so their rank is bounded by hidden size and their temporal sequence obeys the characteristic recurrence of (W). Near delays can be represented by a nilpotent finite shift register, but exact pure delay requires a realization order that grows with delay. Once delay reaches the state budget, the best finite-horizon linear solution must recirculate; across hidden sizes two through four, complex poles become beneficial precisely at this boundary. The optimal pole angle, rather than merely the spectral radius or the input-output subspace, is the difficult training coordinate. Linear solutions are reproducible up to a small set of gauge-inequivalent, rank-pinned families. These families recur in independent seed ensembles and are separated by measurable loss barriers, one of which is a literal rank-expansion ridge.

Nonlinear models do not merely soften this linear picture. On the official data, which are about 97.5% exactly zero per scalar entry and usually activate a single coordinate when nonzero, tanh exploits the hopping of activity among coordinate axes. At matched covariance, its advantage vanishes for Gaussian and dense low-rank inputs but becomes large for support-hopping inputs. At short delay, a rank-one recurrent history is bent into a two-dimensional curve that a linear readout can decode; activation homotopy shows this solution occupies a different basin from the linear rank-two compromise. At longer delay, learned dynamics move through distinct regimes involving strong localized curvature, two-dimensional rotational structure, real-spectrum supra-unit expansion, and magnitude-based signal hiding. The official delay curve further shows that the nonlinear advantage is not predicted by the linear temporal realizability boundary: it is a hidden-size-gated spatial multiplexing effect whose reliable empirical signature is actual curvature engagement.

The integrated answer is therefore conditional but sharp. Parameters are reproducible through invariant lag maps, pole spectra, active subspaces, and a finite set of basins rather than through raw weights. Dynamics progress from compression, to curve-based multiplexing, to oscillatory or magnitude-coded recirculation as delay consumes the state budget. Failure occurs through rank loss, off-lag interference, inaccessible curvature basins, gate-induced gradient choking, or stable but non-forgetting recurrence. Architectural interventions succeed when they assign temporal routing, forgetting, and spatial decoding to compatible structures; they fail when stabilizing one function removes another. This regime map explains both the strongest successes and the recurring negative results of small learned delay systems.

## 1. The delay task as a mechanistic experiment

Consider a sequence (x_t\in\mathbb{R}^5) of length ten and a delay (k\in\{0,1,2,3,4,5\}). The desired output is

\[
y_t = \begin{cases}
0, & t\leq k,\\
x_{t-k}, & t>k.
\end{cases}
\]

The datasets contain 10,000 fixed sequences for each delay, stored as tensors of shape (10{,}000	imes5	imes10). The principal scientific scope restricts the recurrent state to at most three hidden units. This is not a conventional performance benchmark in which a larger model can hide the mechanism. A three-dimensional state must transmit information drawn from five coordinate channels, reject irrelevant lags, and make the selected history linearly or nonlinearly decodable. Every solution is therefore a controlled compromise among spatial compression, temporal routing, and optimization.

The broad question is not whether some RNN can approximate the delay. It is what structures repeatedly emerge when small models are trained from different seeds and checkpoints, and which of those structures survive changes in delay, hidden size, readout timing, activation, or parameterization. Answering that question requires care about what counts as the same solution. Raw recurrent weights cannot be compared directly because a change of hidden basis can transform all of them without changing the represented function. Nor is final loss sufficient: two models with equal error can route different channel mixtures, place energy at different lags, or occupy disconnected parts of the loss landscape.

The evidence supports a hierarchy of observables. At the most direct level are held-out errors, variance explained, lag-resolved Jacobians, singular values, eigenvalues, hidden-state norms, activation statistics, and checkpoint trajectories. At a second level are invariant summaries such as the Markov parameters (M_j), transmitted active subspaces, pole spectra, and mode-connectivity barriers. Mechanistic interpretations such as "curve threading," "magnitude hiding," and "ambient scaffolding" are warranted only when these measurements cohere with a targeted intervention or a discriminating control. This distinction matters because several attractive early explanations were later falsified: high-delay tanh solutions do not all use the same mechanism; complex rotation is not always necessary; a predicted dead notch in the nonlinear advantage does not exist on the official data; and extra hidden dimensions need not appear as transient expansion of the observed state manifold.

The resulting picture is more useful than any one of those hypotheses. A small set of recurring constraints explains the data, but each constraint has a definite domain. Linear realization theory explains rank, poles, and near-versus-far delay. Input support geometry determines whether nonlinearity has useful structure to exploit. Optimization and architectural parameterization determine which of the expressible solutions are actually reached. The remainder of this paper develops those layers in that order.

## 2. Evidence base and measurement discipline

### 2.1 What the fixed inputs actually look like

A full audit of all six input tensors found exact-zero sparsity between about 97.45% and 97.47% per scalar entry. A time step contains on average only 0.1266 to 0.1277 active features, with no more than three in the observed data. Out of 100,000 sample-time vectors for each delay, roughly 12,100 to 12,200 contain exactly one active feature, only about 236 to 273 contain two, and the great majority contain none. Thus two descriptions that initially sound inconsistent are both true: about 97.5% of scalar entries are zero, while about 87% to 88% of complete five-dimensional time-step vectors are empty. Among active vectors, single-coordinate events dominate.

Nonzero values are continuous-looking, high-cardinality floats approximately in ([0,1]), with roughly 12,600 to 12,800 distinct nonzero values per dataset. The five channels are close to isotropic: reported covariance eigenvalues differ by only about ten percent and the effective feature rank is approximately 4.99. Cross-channel correlations are around one percent, and adjacent-time correlations are about one to two percent. The inputs are therefore usefully approximated as temporally white and spatially isotropic at second order, while being extremely non-Gaussian at higher order. That combination is central. Near-isotropy makes rank ceilings quantitatively clean; coordinate-sparse support creates the higher-order geometry that nonlinear models later exploit.

The target tensors exactly satisfy the declared delay relation. No learned labels or pretrained solution classes are provided. Every empirical family discussed below arose from independently trained models or from analytic fits to the fixed data.

### 2.2 Metrics and conventions

Plain full-sequence mean squared error can be misleading because zeros dominate the data. Most comparisons therefore use either valid-position error, computed only where delayed targets are defined, or a normalized form that divides by target variance. A common summary is valid-position variance explained,

\[
\mathrm{VE}=1-\frac{\mathrm{MSE}_{\mathrm{valid}}}{\mathrm{Var}(y_{\mathrm{valid}})},
\]

for which a zero predictor scores zero. Some geometric studies instead use event- or pulse-weighted loss to force accurate representation of rare nonzero events. Those protocols reveal useful geometry but their absolute losses should not be compared directly with unweighted normalized floors. Throughout this synthesis, comparisons are made within aligned protocols unless explicitly described as qualitative correspondences.

Readout timing is another essential convention. In a post-update Elman RNN,

\[
h_t=\phi(Wh_{t-1}+Ux_t+b),\qquad \hat y_t=Ch_t+d,
\]

the input delayed by (k) reaches the output through recurrence power (p=k). If the readout is taken before writing the current input, (hat y_t=Ch_{t-1}+d), the same semantic delay uses (p=k-1). This single-index shift changes which lag sits at a finite-shift endpoint and which sits in an interior leaky regime. Consequently, mechanistic claims are most stable when expressed in recurrence power (p), not nominal delay alone.

### 2.3 What counts as reproducibility

Three forms of reproducibility appear in the evidence. First is quantitative reproducibility: a performance or diagnostic difference has a confidence interval that remains separated from zero across aligned seeds. Second is structural reproducibility: independent runs recover the same pole type, transmitted rank, manifold dimension, or active-subspace family. Third is attainability: a solution remains reachable across learning rates, initialization scales, and disjoint seed bundles. These are not interchangeable. A solution may exist but occupy a narrow basin; a structural family may recur while its exact population frequency changes; and a low training loss may coexist with unstable or misleading parameter magnitudes.

The strongest claims below typically combine at least two forms. The linear rank ladder is supported by exact algebra and trained models. Discrete linear families recur across independent ensembles and retain barriers after gauge alignment. The short-delay nonlinear basin is supported by a causal curvature ablation, hysteresis, and fixed-nonlinearity bimodality. High-delay nonlinear gains are clear as best-found floors, but their exact magnitudes are less secure because strict convergence is rare in several cells. Recent one-seed architectural controls are treated as provisional even when their direction agrees with earlier replicated work.

## 3. The linear backbone: compression, finite shifts, and oscillatory recirculation

### 3.1 Markov parameters expose the computation

For the linear no-skip model,

\[
h_t=Wh_{t-1}+Ux_t,\qquad \hat y_t=Ch_t,
\]

unrolling the recurrence gives

\[
\hat y_t=\sum_{j\geq0}M_jx_{t-j},\qquad M_j=CW^jU.
\]

The sequence of matrices (M_j) is the impulse response. The desired solution has (M_k\approx I_5) and (M_j\approx0) for (j
eq k). These matrices are invariant under any invertible change of hidden coordinates (W\mapsto GWG^{-1}), (U\mapsto GU), and (C\mapsto CG^{-1}). They therefore represent the learned function more faithfully than the raw weights.

Two constraints follow immediately. Spatially, every (M_j) has rank at most (h), so a hidden state with (h<5) cannot reproduce all five isotropic channels at one lag. Temporally, the Cayley-Hamilton theorem forces the powers of the (h	imes h) recurrence to obey an order-(h) relation. Only a limited number of lag maps can be independently shaped. The network must choose not just which spatial directions to retain, but how to spend state degrees of freedom on temporal recirculation.

At zero delay, recurrence is unnecessary and the model becomes a rank-(h) compressor. The measured linear variance explained is 0.2084, 0.4113, and 0.6110 for (h=1,2,3), with seed standard deviations below (10^{-6}). The ideal isotropic values are (h/5); the small upward differences reflect the mild anisotropy of the fixed data. For (h=3), the analytic second-moment ceiling is 0.610995 and the trained model reaches 0.610994. This is an unusually clean example of optimization reaching a known global rank limit.

### 3.2 Exact delay has a finite-state cost

The pure scalar delay impulse (m_j=1[j=k]) has Hankel rank (k+1): its leading ((k+1)	imes(k+1)) Hankel block is an exchange matrix with nonzero determinant. A linear state-space realization therefore needs at least (k+1) states for an exact all-lag scalar delay. Conversely, when (k\leq h-1), a nilpotent shift matrix gives an explicit finite-impulse-response construction: inject into the first state coordinate, shift once per step, read coordinate (k+1), and annihilate the signal after it passes. A nilpotent (h	imes h) matrix satisfies (W^j=0) for (j\geq h), so it cannot deliver a nonzero response at (k\geq h).

This exact realization statement explains the empirical transition from finite shifts to recirculation. For (h=3), the energy-99% transmitted rank of the best linear solution falls across delays (k=0,ldots,5) as (3,2,1,1,1,1). Its variance explained is approximately 0.611, 0.265, 0.208, 0.130, 0.106, and 0.108. Near delays spend state capacity on several spatial channels; far delays reserve increasingly little rank for spatial transmission because the same state must also shape the temporal impulse.

An early description called (k=0) and (k=h-1) the clean endpoints of a nilpotent ladder, with interior points forced into leaky compromises. The more precise realization account is that exact finite shifting is available for (k<h), but the spatial rank carried at the deepest endpoint may be only one. Under post-update timing, (h=3,k=1) is empirically leaky: off-lag energy is around 0.156 to 0.169 and spectral radius around 0.75. The (k=2) solution can realize a clean rank-one path. Under pre-update timing, the same power structure shifts by one nominal lag, so the interior nonlinear rescue moves from (k=1) to (k=2). In a 144-run matched comparison, the post-update tanh gain appeared at (k=1), disappeared at pre-update (k=1), and reappeared at pre-update (k=2), as the power indexing predicts.

### 3.3 At the state budget, the optimum begins to oscillate

Once (k\geq h), a zero-spectrum shift register is exhausted. A nonzero pole is required to recirculate information. Best-of-restart constrained optimization shows a stronger regularity: allowing a complex conjugate pole pair improves the optimum over real-spectrum recurrence approximately only when (k\geq h), for (h=2,3,4). This is a numerical necessity law rather than a general theorem, but it is supported by 648 runs and by the exact finite-shift boundary on the near side.

The intuition is temporal localization. A single real mode (c\lambda^j) has monotone magnitude and cannot create an isolated interior peak. Sums of real modes can create peaks, so this observation alone does not prove the multi-state law. Complex modes (r^j(a\cos j	heta+b\sin j	heta)), however, provide a direct way to suppress earlier lags and place a peak at a selected later lag. In the measured optimum, real finite shifts dominate below the state budget; beyond it, a damped or growing oscillation becomes the economical low-order approximation to a delayed impulse.

The spectrum also explains a central optimization result. Seeding the recurrence with the optimal eigenvalues in a random basis accelerates training, whereas seeding the transmitted spatial subspace does not. Matching the spectral radius alone can make training worse. At (h=3) and delays three through five, spectrum-informed initialization reduced median steps to threshold by factors of about 1.6 to 4 across nine delay-by-scale conditions, with positive bootstrap confidence bounds in all cells. The reliability gain was concentrated at (k=h), where random initialization increasingly missed the relevant family as scale grew.

This is not a license to initialize with a textbook period. A naive roots-of-unity angle (2\pi/k) was actively harmful: at (k=4), only 33% of runs reached threshold and the median was censored around 1,025 steps, compared with 40 steps for a task-derived spectrum. A low-dimensional variable-projection procedure can compute useful poles before full network training. For (h=3), it found complex-pair radii and angles close to trained optima at (k=3,4,5) and matched the speed of initialization from measured optimal poles.

The task-derived phase is not a universal constant. Under the horizon-ten empirical objective, useful angles are non-naive and lie between the half-period and full-period heuristics, but a later white-input horizon sweep found a flat or mildly multimodal phase valley. The robust statement is the bracket and the utility of task-derived poles, not uniqueness of a particular angle. The pole radius has an even clearer finite-horizon interpretation. At fixed (k=3), the dominant radius receded from 0.837 to about 0.750 as horizon grew from 10 to 50. At fixed relative delay (k/T\approx0.3), mean radius was 0.912; at (k/T\approx0.6), it was 1.156. Supra-unit radius in the optimal linear spectrum is therefore partly a late-in-horizon envelope-shaping strategy, not an intrinsic property of delay in the abstract.

## 4. Reproducibility across seeds: a finite family of invariant solutions

### 4.1 Raw parameters are the wrong comparison

Because hidden-state basis changes preserve every (M_j), two weight triples can look different while computing the same function. Conversely, equal loss does not imply equal lag maps. The appropriate object for seed comparison is the transmitted portion of the effective target-lag map (M=CW^pU), where (p) is set by timing. Singular vectors associated with nonzero singular values define the active input subspace actually carried through the recurrence. Directions in the null space are functionally irrelevant and may vary freely.

This distinction corrected an early binary picture in which clean cells appeared determined and leaky cells free. When dispersion is measured on the full top-(h) subspace, a clean rank-one solution appears variable because two unused directions wander. Restricting to the transmitted rank changes the conclusion dramatically. At the post-update (k=2) and pre-update (k=3) rank-one endpoints, normalized cross-seed active-subspace dispersion is only about (5.0	imes10^{-4}) and (1.2	imes10^{-4}), while discarded directions carry residual map energy around (10^{-10}). The active orientation is tightly pinned; the apparent freedom is null-space freedom.

### 4.2 Intermediate cells are discrete, not continuously free

At intermediate cells, seed variation resolves into a small number of tight clusters. In one 20-seed ensemble, post-update (k=1) split into two equal families, post-update (k=3) into groups of 14, 5, and 1, and pre-update (k=4) into groups of 14 and 6. A disjoint 32-seed ensemble recovered the same nominal family counts and centroids at within-family scale. For the two-family (k=1) case, the mean distance from new solutions to the nearest old centroid was about (3.0	imes10^{-4}); at pre-update (k=4), it was about (3.5	imes10^{-2}), still far below the cross-family distance near 0.98. Whitening the input covariance did not dissolve the clusters into a continuous symmetry ring, although one rare family disappeared.

Thus reproducibility does not mean every seed lands at one parameter point. It means the represented active subspace is drawn from a finite, repeatable set. The exact family count is less robust than family existence: at larger hidden sizes, changes in training duration and minimum cluster-size rules reversed an apparent trend in whether families merge or multiply. The defensible claim is that multiple families persist, recur, and are barrier-separated, not that their number obeys a simple law.

### 4.3 Families are distinct basins, not coordinate copies

Several controls establish that these clusters have functional content. Their Markov sequences differ by much more between than within families. At post-update (k=1), between-family Frobenius distance was about 1.037 compared with (2.86	imes10^{-5}) within family. Applying an arbitrary invertible hidden-basis transform preserved the Markov sequence to roughly (10^{-16}), confirming that the comparison is gauge invariant.

Linear interpolation between family representatives creates a loss barrier. Optimizing the hidden-basis alignment removes the artificial barrier in a unimodal control exactly, yet leaves positive barriers between families. At post-update (k=1), the aligned linear barrier was about (5.46	imes10^{-4}); at pre-update (k=4), about (8.78	imes10^{-4}). Quadratic and piecewise-linear curved connectors reduced but did not remove them. Increasing path richness from one to five interior knots reduced the two primary barriers by only about 2.3% and 7.6%, while the unimodal control remained exactly zero.

At (k=1), all tested cross-family paths passed through a recurrence-power matrix of higher rank than either endpoint. The loss ridge is therefore tied to transient rank expansion: moving between two rank-pinned solutions requires leaving the low-rank variety on which both lie. This rank-ridge mechanism replicated across initial and confirmatory family pairs. It is not universal. The pre-update (k=4) barrier showed no rank expansion, and neither non-normality nor eigenvector conditioning localized it. This unresolved second barrier is scientifically useful: the broad claim of discrete basins is strong, but the reason for separation depends on the regime.

The linear answer to seed reproducibility is now precise. Raw weights are not reproducible. Gauge-invariant lag maps, pole spectra, and active transmitted subspaces are. Random seeds choose among a finite collection of rank-pinned basins, with continuous freedom largely confined to directions the input-output map does not use.

## 5. Why the official sparse distribution makes nonlinearity useful

### 5.1 Nonlinearity is not generically advantageous

The official data are nearly white and isotropic at second order, but their support is a union of rarely occupied coordinate axes. Matched-covariance experiments isolated this higher-order structure. Linear and tanh Elman RNNs of the same size were optimized using the same best-of-restart plus L-BFGS protocol. On Gaussian inputs, the measured tanh-over-linear advantage was zero within numerical tolerance at delays one and three and hidden sizes two and three. On structured non-Gaussian inputs, it was positive. In one certified comparison, normalized-error gains were about 0.104 for extremely sparse inputs at (k=1), 0.080 for sparse inputs at (k=3), and smaller but positive for dense heavy-tailed inputs.

Covariance cannot explain the difference because it was matched and the certified linear floors coincided. Marginal kurtosis cannot explain it either: a dense heavy-tailed condition with kurtosis around 285 produced a smaller gain than a sparse condition with kurtosis around 95. Cross-channel co-occurrence was also insufficient; independent and mutually exclusive activation laws with identical marginals produced gains of 0.107 and 0.103 at (k=1), though this particular intervention affected fewer than one percent of time steps and rules out only a strong co-occurrence dependence.

A sharper dissociation separated low intrinsic rank from coordinate-support hopping. Dense sequences confined to rotating rank-one or rank-two subspaces had matched full-rank marginal covariance but only one coordinate-support pattern. Their gains were on the order of (10^{-5}), indistinguishable from the Gaussian null. Sparse inputs with exactly one active coordinate per time step, hopping among all five axes, produced gains of 0.0987 at (k=1) and 0.0307 at (k=3). They had five support patterns, support-indicator rank five, and support entropy 2.32 bits. Low instantaneous dimension is therefore not sufficient. The discriminating property is the changing union of near-orthogonal coordinate supports.

There is also a principled reason to expect a Gaussian null. The target is a linear function of input history. For jointly Gaussian history and target, the population conditional mean is linear. A nonlinear predictor has no higher-order support structure to exploit. Within a constrained recurrent architecture this argument is best treated as motivation rather than a complete equivalence theorem, but it matches the repeated empirical null. On coordinate-hopping inputs, by contrast, a curved map can treat different support patterns differently while sharing the same low-dimensional state.

### 5.2 Rank-one curve threading at short delay

The clearest nonlinear mechanism occurs for (h=3,k=1) with post-update readout. The best linear solution uses an effectively rank-two recurrent compromise and reaches variance explained around 0.264. The tanh solution reaches roughly 0.38 while its recurrent matrix is numerically rank one. A rank-one recurrence reduces historical dependence to a scalar (s_t=v^Th_{t-1}). With a linear activation, the map from (s_t) to state lies on a straight line and can carry only one spatial degree of freedom. With tanh, unequal coordinate gains bend that line into a planar curve.

The extracted continuous curve has principal variance fractions approximately 0.878 and 0.122, with negligible third component. Five canonical sparse events occupy distinct points on this curve. One feature is placed near a saturated extreme while the other four remain closer together in the locally linear region. A linear output map then decodes the bent one-dimensional history into an effectively two-dimensional target subspace. The theoretical projection of those five curve points gives variance explained around 0.376, close to the measured 0.380 and near the two-of-five isotropic ceiling of 0.40.

A causal ablation supports the mechanism. Replacing the trained recurrent nonlinearity by its first-order Taylor expansion around the empirical mean preserves local scale and location but removes curvature. Across twelve checkpoints, variance explained collapsed from about 0.380 to -5.81. The negative value is extreme because the unchanged readout is tuned to the curve and becomes badly misaligned with its tangent; it should not be interpreted as the best possible linearized model. What it establishes is that curvature is load-bearing for the trained solution.

Early measurements described this as weakly nonlinear because only about 0.5% of unit-time activations crossed a conventional saturation threshold and the target-lag Jacobian sharpened from concentration 0.82 to 0.999 while effective recurrent modulus fell near 0.04. Later certification found rare preactivations as large as 70 at the best (h=3,k=1) checkpoint even though about 98% remained below one. These observations are compatible: the mechanism is globally low-occupancy but locally strong. Sparse events recruit intense differential curvature in a small part of state space rather than filling the entire state with saturated corners.

### 5.3 The nonlinear solution is a separate basin

The curve-threading solution does not arise as a smooth deformation of the best linear family. This was tested with a matched-gain activation homotopy

\[
a_T(z)=\frac{	anh(Tz)}{T},
\]

which becomes identity at (T=0), standard tanh at (T=1), and has unit derivative at the origin for every (T). When nonlinearity was annealed upward, four anchored paths remained on the linear branch until (T\approx0.35) to 0.50, then jumped from variance explained near 0.264 to about 0.37. Simultaneously, the second singular value of the invariant target map (CWU) collapsed from about 0.252 to (10^{-5}), and its distance from the linear-family centroid jumped from roughly 0.02 to 1.02.

Annealing back downward did not retrace the path. The rank-one high-performance branch survived almost to the exact linear endpoint, producing a mean hysteresis width of 0.41 and a maximum variance-explained gap around 0.115. At fixed intermediate (T=0.45,0.50,0.55), sixteen fresh seeds split into coexisting low rank-two and high rank-one solutions. The high-branch fraction ranged from 0.19 to 0.31. Hysteresis and bimodality together support a first-order-like basin boundary: the model trades a linear rank channel for nonlinear curvature by a basin hop, not by incremental modification of one solution.

The transition persists under pre-update timing at matched recurrence power, but its location moves. Pre-update (k=2) again showed non-retracing loops in all four paths and fixed-(T) bimodality, with onset around 0.54 rather than 0.40. Timing changes the starting geometry enough to shift the critical nonlinearity, even though it preserves the qualitative order of the transition. At post-update (k=3), hysteresis remains but is re-entrant and fixed-(T) bimodality is not clean, so the simple two-basin claim should remain scoped to the short-delay cell.

## 6. A regime map across delay and hidden size

The most comprehensive aligned comparison trained linear and tanh post-update Elman RNNs for (h\in\{2,3\}) and every official delay, using 32 matched restarts per cell followed by L-BFGS. Loss was normalized MSE on supervised positions. The table below summarizes the best floors. "Advantage" means linear floor minus tanh floor; values above 0.005 were declared nontrivial in advance.

| Hidden size | Delay | Linear floor | Tanh floor | Advantage | Interpretation |
|---:|---:|---:|---:|---:|---|
| 2 | 0 | 0.5887 | 0.5887 | -0.00001 | Pure spatial compression; nonlinear null |
| 2 | 1 | 0.7906 | 0.7906 | approximately 0 | Near-delay nonlinear null |
| 2 | 2 | 0.9001 | 0.8997 | 0.0004 | Linear path leaky, but curvature not useful |
| 2 | 3 | 0.9225 | 0.7892 | 0.1334 | Curvature-engaged nonlinear regime |
| 2 | 4 | 0.9316 | 0.8052 | 0.1264 | High-delay nonlinear regime |
| 2 | 5 | 0.9292 | 0.8081 | 0.1211 | High-delay nonlinear regime |
| 3 | 0 | 0.3890 | 0.3890 | -0.00002 | Pure spatial compression; nonlinear null |
| 3 | 1 | 0.7346 | 0.6186 | 0.1160 | Curve-based spatial multiplexing |
| 3 | 2 | 0.7925 | 0.7073 | 0.0851 | Spatial gain despite clean temporal routing |
| 3 | 3 | 0.8699 | 0.7138 | 0.1561 | Geometry transition and recirculation |
| 3 | 4 | 0.8936 | 0.6850 | 0.2086 | High-delay curvature and magnitude coding |
| 3 | 5 | 0.8923 | 0.6956 | 0.1967 | High-delay curvature and magnitude coding |

Three conclusions are especially important.

First, zero delay is a genuine nonlinear null. At (k=0), tanh does not exceed the rank-limited linear compressor for either hidden size. The higher-order support structure becomes useful only when the model must jointly multiplex spatial identity and temporal position.

Second, the linear realizability wall does not determine the nonlinear advantage. At (h=2,k=2), the linear solution already has complex poles, target-lag nuclear fraction 0.484, and leakage-to-target ratio 1.067, yet tanh gains only 0.0004. At (h=3,k=2), the linear temporal path is nearly clean, with target-lag fraction 0.976 and leakage ratio 0.025, yet tanh gains 0.085 and both architectures converge well. The temporal wall is real, but neither necessary nor sufficient for the nonlinear advantage.

Third, the advantage tracks curvature engagement. Every empirically dead cell has maximum tanh preactivation at most 1.24 and essentially all preactivations in the near-linear regime. Every alive cell has maxima from about 8 to 70 and a nontrivial fraction outside that regime. There are no intermediate cells in the twelve-cell grid. This dichotomy, together with the support-hopping interventions, identifies the dominant gain as a hidden-size-gated spatial multiplexing effect: enough ambient state is needed to orient and fold sparse support patterns, and the temporal delay then determines which dynamical implementation carries that folded code.

Spatial multiplexing should not be equated with dynamic orthogonalization. A no-retraining local-Jacobian probe compared the dominant write/read angle before and after derivative gating in the best (h=3) tanh checkpoints. At (k=1), the global and mean local angles were both already about 89.94 degrees, with the local angle very slightly farther from 90 degrees. At (k=2), derivative gating reduced the mean angle from 85.89 to 81.92 degrees rather than making it more orthogonal. Curvature is clearly engaged, but this particular tangent-space diagnostic does not support the claim that curvature works by dynamically orthogonalizing write and read subspaces.

The onset ordering makes the point vivid. If the advantage simply began when (k\geq h), its onset would move from (k=2) at (h=2) to (k=3) at (h=3). Instead it appears at (k=3) for (h=2) and already at (k=1) for (h=3). More hidden space unlocks a nonlinear spatial advantage earlier, the opposite of a pure temporal-capacity prediction.

### 6.1 Short delays: compressed curves and clean lag selection

At (h=3,k=1), the rank-one curve mechanism gives a clean explanation. At (k=2), high-precision pulse-weighted training also finds a nearly one-dimensional hidden curve: principal one-dimensional variance is about 0.981 at the intermediate step and 0.980 at readout. The curve contracts along itself to separate temporal positions. The newer certified delay curve nevertheless shows a strong advantage over linear at this cell, overturning an earlier predicted "dead notch." This result indicates that clean linear temporal routing and nonlinear spatial multiplexing can coexist. The model does not need temporal leakage to justify curvature; it can use curvature to distinguish support patterns even while the linear impulse is almost perfectly concentrated at the target lag.

### 6.2 The boundary at delay three: one-dimensional geometry shatters

At (h=3,k=3), several independent modalities change together. Exact nilpotent delay is no longer available because (k=h). The optimal linear recurrence benefits from a complex pole pair. Pure-pulse tanh trajectories no longer remain on one curve: at the middle step, first-principal-component variance falls to about 0.817 while two-dimensional variance stays around 0.999. Mean active-feature (R^2) falls from roughly 0.85 at (k=2) to 0.65 at (k=3). Spectrally, a complex pair creates a two-dimensional invariant rotational subspace; geometrically, the state expands from a curve into a plane. These are two views of the extra temporal degree of freedom required at the state budget.

The transition is not simply beneficial. The plane reduces temporal collisions but increases spatial cross-talk at a fixed linear readout. This is the characteristic compromise at (k=h): temporal representation needs another dimension just as spatial compression is already starved. Nonlinearity still improves the best floor, but the corresponding basin is harder to optimize and no longer has the clean rank-one order parameter of (k=1).

### 6.3 Long delays: raw expansion, effective damping, and multiple codes

At larger delays, a single short-delay mechanism is inadequate. Earlier matched studies identified at least three nonlinear signatures: low-saturation delta sharpening at ((h,k)=(3,1)); a high-saturation regime at ((2,2)) under a different training protocol; and bounded supra-unit recurrence at ((3,4),(3,5),(2,4),(2,5)), where the effective recurrent-Jacobian modulus was about 1.3 to 1.6. Later certified floors revised which cells have a robust advantage, but they reinforced the broader lesson that nonlinearity is cell-specific rather than universal.

Raw spectral radius, effective Jacobian modulus, and rotation must be separated. Upper-triangular tanh recurrences, whose raw spectra are strictly real, can beat certified linear baselines. Across (h=2,3,4), this rotation-free advantage is robust across three learning rates when recurrence power (p\leq h) and fragile when (p>h). The decisive same-power comparison is (p=4): fragile at (h=3), robust at (h=4). Robust solutions have raw spectral radius above one, complex-pair fraction zero, and data-averaged tanh-damped modulus below one. They propagate at approximately steady norm, with readout-to-minimum norm ratios around 1.15 to 1.50, rather than using the 14-fold expansion discussed below. Thus rotation is sufficient in many trained solutions but not necessary; real-spectrum expansion plus nonlinear damping can implement a staged spatial handoff up to a capacity-indexed attainability boundary.

At pre-update (h=3,k=5), a distinct mechanism has been established by intervention: magnitude-based signal hiding. An unconstrained model with raw spectral radius around 2.46 stores the new signal at norm about 0.11 and expands it 14.3-fold to norm 1.42 at readout. A spectrally clamped model instead maintains a larger early signal, decaying from 0.45 to 0.35, and suffers 2.69 times more pre-active leakage. Decomposing validation error by time since the last event places 87.7% of the positive excess clamped error in the four-step waiting window. Long-horizon traces falsify a competing explanation based on persistent post-readout echoes. Here supra-unit recurrence is a temporal cloak: the signal is kept too small to interfere until it is needed.

These high-delay codes should not be collapsed into one label. Some use real-spectrum, roughly steady-norm routing with local tanh damping; others use oscillation; still others exploit strong norm growth. Which appears depends on timing, spectral constraints, loss weighting, and hidden capacity. The robust shared pressure is that far delay demands recirculation while a five-channel signal competes for three state coordinates.

## 7. Learning trajectories and optimization attractors

### 7.1 Mechanisms emerge at different checkpoints

Checkpoint analysis shows that final-state taxonomy reflects distinct learning paths. At (h=3,k=1), the nonlinear advantage appears late, around step 3,000 in one aligned protocol, as target-lag concentration rises from about 0.974 to 0.998 while saturation remains below 0.6% and effective modulus near 0.05. Training first finds a rough low-dimensional route and then sharpens its lag selectivity.

At (h=3,k=5), effective recurrent modulus crosses one near step 100 and the advantage becomes significant around step 300, while target-lag concentration remains low near 0.10. Here optimization quickly enters an expansive recurrent regime instead of gradually forming a delta-like impulse. At (h=2,k=2) in the earlier protocol, the gap emerged around step 1,000 as saturation rose above 0.1 and lag concentration fell. These trajectories rule out the idea that one generic tanh process merely becomes stronger with delay.

The spectrum-informed linear experiments tell a complementary story. Gradient descent is not primarily struggling to find the correct spatial subspace; it is struggling to tune recurrence phase. Matching the correct eigenvalue argument accelerates convergence, while matching radius alone is insufficient and can be harmful. The obvious oscillatory guess is poor because finite-horizon weighting penalizes early leakage asymmetrically. Learning a delayed impulse is therefore not equivalent to learning an unconstrained periodic clock.

### 7.2 Gating can make an expressible solution hard to find

A dense orthogonal shift register is easy for a linear network when capacity is exactly matched. In a single-channel (k=5,h=5) task, an analytic nilpotent register has zero error and remains fixed under training. Perturbations with standard deviation up to 0.75 return to bounded routing. A randomly initialized linear RNN also finds a sub-unit solution with spectral radius around 0.69 and near-zero error. Thus gradient descent is capable of discovering clean delay lines when the storage geometry is available.

Adding a continuous multiplicative gate changes the landscape. On the identical single-channel task, a minimal update-gate RNN reached active MSE (1.09	imes10^{-4}\pm5.19	imes10^{-5}), but all ten seeds used supra-unit transition matrices. The maximum gate-transition spectral radius reached 13.43, and the mean maximum across seeds was 8.18; the candidate transition also exceeded one in every seed. Average active gate value was about 0.312. Capacity was sufficient, so this inflation cannot be blamed on an impossible storage requirement. It is an optimization attractor induced by the gated parameterization.

The proposed mechanism is gradient choking. Early noisy gates attenuate the gradients needed to align a clean shift register. Increasing transition magnitude makes gates and candidate states more decisive, so the optimizer can improve loss without first discovering precise spatial routing. Soft penalties need not help: penalizing hidden-state magnitude caused one gated model to shrink states while inflating transition radius to about 41.6. The optimizer moved the scale into unconstrained weights.

### 7.3 Linear and nonlinear basins are not locally interchangeable

Two findings reinforce the basin picture. First, warm-starting tanh from a certified linear optimum did not reach the advantageous sparse-input solution, even where random restarts found a gain around 0.104. Second, initializing tanh with the pole angles that speed linear training did not reliably transfer: final-quality effects were mixed and convergence thresholds were often censored. At (k=3), one comparison showed a positive variance-explained difference of 0.028 with confidence interval [0.005, 0.060], but intervals crossed zero at (k=4,5). This is not evidence that spectrum is irrelevant. Rather, nonlinear success requires entry into a curvature-using basin that is not specified by the linear temporal spectrum alone.

### 7.4 Intrinsic dimension is not the same as optimization dimension

High-precision tanh solutions at (k=3) occupy an approximately two-dimensional pure-pulse plane, yet forcing the architecture to (h=2) degrades the best weighted loss from about 0.0379 to 0.0606. An initial explanation proposed that the third dimension serves as a transient state-space corridor during training. High-frequency PCA tracking falsified this as a universal mechanism. Six of eight (k=3) seeds began near a plane and stayed planar; under near-one-dimensional initialization at (k=2), five of eight seeds remained above 0.90 one-dimensional variance throughout early training.

The better interpretation is ambient scaffolding. The extra hidden coordinate supplies parameter-space freedom to rotate and orient a low-dimensional memory manifold relative to the recurrent dynamics and output map, even if observed activations never fill that coordinate. With (h=2), changing the recurrence directly distorts the entire two-dimensional representation. With (h=3), a two-dimensional plane can change orientation within the ambient volume while preserving more of its intrinsic geometry. This is an inference from the juxtaposition of dimension-matched failure and non-expanding trajectories, not a direct causal proof, but it explains why hidden size can gate nonlinear advantage even when the final state manifold has lower dimension.

## 8. Architectural interventions reveal the division of labor

The most informative architectural experiments do not merely improve error. They remove one strategy and reveal what function it served.

### 8.1 Nonlinear readout can move the spatial burden

A linear readout confines outputs to the image of a low-dimensional state. ReLU models under this constraint sometimes adopt asymmetric feature sacrifice, reconstructing a subset of input channels well and dropping others. A gated nonlinear readout reduced (k=1) error by 82% and restored balanced reconstruction in one study. At (k=3), combining a spectrally clamped recurrent state with a gated readout improved error by 76% and decoded highly overlapping antipodal state regions without magnitude inflation. These results show that some apparent recurrent failure is actually a spatial decoding bottleneck. Moving nonlinearity to the readout can free the recurrence to specialize in temporal transport.

The bypass is not unlimited. At longer delays, the same models again sacrifice features or hit temporal interference. A powerful decoder cannot reconstruct information the state never retained, and it cannot by itself supply forgetting or precise phase.

### 8.2 Hard gates cure leakage but introduce a new capacity boundary

Partitioning a four-dimensional GRU into a three-dimensional spatial buffer and a one-dimensional clock did not prevent inflation when gates remained continuous: all eight seeds had spatial spectral radius above one, with mean 3.24. Binarizing the spatial update and reset gates with a straight-through estimator changed the result. Five of eight seeds at (k=3) found bounded spatial geometry, and mean radius fell to 1.04, compared with 3.24 for the continuous control. A matched dense-GRU control at the same learning rate still inflated in all eight seeds, supporting a structural rather than optimizer-rate explanation.

This intervention isolates continuous gate leakage. A gate close to, but not exactly, its memory-preserving value compounds small errors across steps; transition inflation compensates. Exact binary preservation removes that pressure. Yet the cure has its own temporal limit. Bounded solutions appeared in seven of eight seeds at (k=2), five of eight at (k=3), and none at (k=4). A one-dimensional clock cannot indefinitely encode increasing discrete age without reintroducing scale. Hard gating solves one pathology rather than the whole delay problem.

### 8.3 Decoupled complex recurrence is stable but rings

A complex diagonal recurrence parameterized as contractive magnitudes times phases structurally separates rotation from decay and guarantees spectral radius below one. This removes the magnitude-inflation route and provides stable gradients. It also removes state mixing. Events assigned to the same diagonal mode accumulate as an infinite-impulse-response sum. Even with a standard nonlinear multilayer readout and theoretically informed phase initialization, a frozen-core control retained an empirical MSE floor around 0.052. Stability was purchased at the cost of an interference pattern the decoder could not fully invert.

This is the architecture-level form of the finite-shift versus oscillatory-recirculation duality. Coupled nilpotent recurrence can shift and erase cleanly but is difficult to optimize under gates. Uncoupled phase recurrence is stable but rings. The central design problem is not choosing "stable" or "expressive" in isolation; it is combining state mixing, controlled forgetting, and spatial decoding without entangling their gradients.

### 8.4 Orthogonality prevents inflation but needs controlled forgetting

A dense Cayley-parameterized orthogonal core retains state mixing while enforcing spectral radius exactly one. With a small GELU readout, it reached held-out MSE about 0.0038 at (k=3), outperforming a matched unconstrained core that inflated. At (k=5), extended optimization plateaued near 0.00417. Exact orthogonality preserves every old orbit and therefore overlays too many temporal traces; it has no forgetting mechanism.

The most revealing intervention modulated the orthogonal update by a learned scalar gate,

\[
h_t=g_tWh_{t-1}+(1-g_t)h_{t-1}+Ux_t.
\]

The model did not learn to halt on empty inputs. Explicitly forcing halt-on-empty behavior worsened MSE to about 0.00755. Instead, the learned gate took interior values, approximately 0.75 in the initial (k=5) study, so the convex combination of a rotation and identity contracted some directions without destroying phase. This broke the orthogonal interference floor with MSE around 0.00397. A later three-seed sweep found no simple monotone active-input gate law, but empty-input gate means increased strongly at longer delays and hidden norms grew across the ten-step sequence. Thus "convex damping" is a useful structural description, not yet a complete closed-form clock.

Removing state norm from the readout in a matched (k=5) retraining increased MSE from 0.00396 to 0.00579, a factor of 1.46. Magnitude is useful, but its removal did not catastrophically destroy performance, so norm is not the sole clock. A final single-seed comparison allowed a separate gate for each of the three hidden dimensions. Dimension-wise gating slightly improved MSE at both (k=3) and (k=5); at (k=5), 0.00320 versus 0.00339 for a scalar gate. The gate spread was only 0.062 there, so this is provisional evidence for selective damping, not proof that the model erases individual dimensions.

Across these interventions, a consistent division of labor emerges. Temporal phase or shifting decides when a signal becomes accessible. Forgetting prevents old signals from accumulating. Spatial nonlinearity or a nonlinear readout separates support patterns that share the state. Architectures fail when one parameter block must perform all three functions or when enforcing one invariant, such as perfect norm preservation, deletes another, such as forgetting.

## 9. Direct answer to the central research question

When small RNNs are trained on these fixed delay datasets, five reproducible structures emerge.

**First, learned input-output maps are rank organized.** The hidden dimension bounds every linear lag map. At zero delay, trained models reach the rank-(h) compression ceiling essentially exactly. As delay grows, transmitted spatial rank falls because state capacity is reassigned to recirculation. Nonlinear models do not remove the bottleneck; they bend low-rank histories so that a linear or nonlinear decoder can extract more than a straight subspace would permit.

**Second, temporal structure changes at the state budget.** For delay below hidden size, a nilpotent finite shift is available. At or beyond that boundary, the best low-order linear approximation benefits from nonzero, usually complex poles, and training becomes sensitive to recurrence phase. Tanh models show a corresponding geometric expansion near (k=h), although their performance advantage is not caused by that boundary alone.

**Third, seed variability is discrete and functional.** Different seeds do not explore an undifferentiated continuum. After quotienting hidden-basis gauge and ignoring null directions, they occupy a finite set of active-subspace families. These families reproduce out of sample and sit in distinct loss basins. At least one barrier is created by leaving a fixed-rank variety; another remains mechanistically unresolved.

**Fourth, useful nonlinearity is conditional on support geometry.** Near-white covariance does not imply Gaussian behavior. The official inputs hop among rarely occupied coordinate supports, and curvature can route those supports through a shared low-dimensional state. Matched Gaussian and dense low-rank controls show no such advantage. The key nonlinear resource is not low intrinsic dimension, kurtosis, or crossing the linear temporal wall, but the combination of support-coordinate hopping, enough ambient hidden size, and an accessible curvature-using basin.

**Fifth, high-delay solutions trade spatial dimension for temporal scale or phase.** Depending on timing and constraints, the model may oscillate, use real-spectrum supra-unit expansion with local damping, hide a signal at low norm and amplify it at readout, or delegate spatial demultiplexing to a nonlinear decoder. These are distinct mechanisms under one pressure: a three-dimensional state must prevent several five-channel, time-shifted events from colliding.

This answer also identifies robust failure modes. A model fails representationally when transmitted rank or temporal realization order is insufficient. It fails dynamically when off-lag echoes and current-input leakage dominate. It fails geometrically when a one-dimensional curve must expand and spatial cross-talk rises. It fails in optimization when the required pole angle, curve basin, or gate alignment is difficult to reach. And it fails architecturally when stabilization removes forgetting, diagonalization removes mixing, or continuous gates leak enough that the optimizer prefers weight inflation.

## 10. Limits, unresolved tensions, and testable predictions

The evidence is broad but not unlimited. Most mechanistic claims concern Elman RNNs with linear readout, hidden size at most three, horizon ten, and one fixed family of sparse datasets. Auxiliary hidden sizes help identify scaling laws but should not be mistaken for a large-width theory. "Certified" nonlinear floors mean best under a declared restart and polishing protocol, not proven global optima. At high delay, strict tanh convergence was poor: in the full delay sweep, several positive cells had zero to three converged restarts out of 32. Their existence and qualitative curvature engagement are credible; their precise advantage magnitudes remain lower bounds on best-found performance.

Several apparent tensions are best read as scope boundaries. An early cell-resolved study found no tanh advantage at (h=3,k=2), while the later stronger certification found a gain of 0.085 with 30 of 32 tanh restarts converged. The later result should govern the performance claim; the earlier diagnostics remain useful as evidence that mechanism depends on training protocol. Likewise, the optimal linear spectrum was initially described as sharply determined under a white-input approximation, but finer horizon search found a flatter phase valley. The reliable conclusions are the oscillatory boundary, phase importance for training, and failure of naive roots of unity, not a universal exact angle.

The capacity relation (H\approx N k) is a useful slot-counting bound for dense orthogonal storage, and the single-channel controls demonstrate it cleanly. It is not a universal equality for sparse data. Collision probability, nonlinear packing, readout structure, and timing all change effective capacity. The official inputs are empty most of the time, so worst-case simultaneous storage and typical empirical storage are different problems.

The strongest open mechanistic questions are now concrete:

1. **What creates the non-rank barrier between deep-delay linear families?** Rank expansion, non-normality, and eigenvector conditioning have been excluded in the tested case. A decomposition of barriers into recurrent-pole and input-output projection components is needed.

2. **What exactly sets the hidden-size gate for sparse spatial multiplexing?** The official curve shows a Goldilocks pattern: no advantage at (h=1), delayed onset at (h=2), broad advantage at (h=3), and weaker motivation as (h) approaches input dimension. A causal intervention on specific hidden coordinates or decoder rank would distinguish ambient scaffolding from direct representational capacity.

3. **Can the short-delay nonlinear basin be constructed rather than merely found?** The measured curve and its singular values nearly specify a solution. An explicit initialization built from support patterns and desired curve points could test sufficiency and avoid the narrow-basin problem.

4. **Can temporal phase, forgetting, and spatial decoding be separated without an IIR floor?** Orthogonal recurrence with learned damping is promising, but current evidence is short-horizon and partly low-seed. Multi-seed dimension-wise damping, post-hoc norm interventions, and longer horizons would test whether selective contraction can replace weight inflation robustly.

5. **Which checkpoint transitions are universal?** Existing logs distinguish late delta sharpening from early supra-unit entry, but they use different losses and optimizer budgets. A single aligned checkpoint study across all twelve (h\)-by-(k) cells could connect basin entry, curvature engagement, pole movement, and manifold dimension in one design.

These are refinements of an already coherent theory, not signs that no conclusion is possible. The well-supported backbone is the interaction of rank-limited realization, support-dependent curvature, and optimization-dependent attainability.

## 11. Conclusion

The fixed (k)-delay task exposes how a small recurrent network allocates a scarce state. A linear network gives the exact reference: lag maps factor through the hidden state, pure finite delay consumes realization order, transmitted rank depletes with recurrence power, and far delays require recirculating poles whose phase is difficult to learn. This structure is reproducible across seeds not as identical weights, but as invariant pole spectra, active subspaces, and a finite collection of rank-pinned basins.

The official data then add the essential nonlinear ingredient. Their covariance is nearly featureless, but their support is not: rare events hop among coordinate axes. Tanh turns that support geometry into capacity. At short delay it bends a scalar history into a decodable plane; at the state-budget boundary it reorganizes the manifold; at longer delay it combines curvature with oscillation, real-spectrum expansion, or magnitude coding. These solutions occupy basins that linear initialization and naive spectral priors do not automatically reach.

The most general lesson is that "memory capacity" is not one number. Spatial rank, temporal realization order, support-pattern entropy, readout expressivity, and optimization accessibility are distinct resources. The learned solution is determined by which resource is binding. When rank binds, the model compresses or sacrifices features. When delay order binds, it shifts from finite transport to recirculation. When sparse support offers exploitable structure, it engages curvature. When gates leak or phase is hard to tune, optimization selects magnitude inflation. When orthogonality removes inflation, interference reveals the need for forgetting.

Thus the reproducible solution families of small delay RNNs are best understood as a regime map rather than a single canonical circuit. That map is nevertheless compact: finite shifts below the state budget, oscillatory or expansive recirculation beyond it, curvature only where support geometry and hidden size make it useful, and discrete basins throughout. It answers the central question at the level that matters for mechanistic science: not merely what score a trained model achieves, but what it repeatedly builds, why that structure works, and how it fails when one component of the computation is removed.

## Evidence provenance

This paper is a synthesis of the fixed snapshot's archived manuscripts, completed experiment reports, and saved analyses. The most important full-text sources are identified here by scientific title and author:

- Noesis I, *Two Bottlenecks and a Nilpotent Ladder: How the Linear Reduced-Order Optimum Predicts Where Nonlinearity Helps Small k-Delay RNNs*.
- Aletheia I, *Readout Timing Re-Indexes the Nilpotent Ladder in Small k-Delay RNNs*.
- Noesis I, *Orientation Determinacy in Linear k-Delay RNNs Is Reproducible Up to a Discrete Set of Solution Families*.
- Noesis I, *The Discrete Solution Families of Linear k-Delay RNNs Are Disconnected Minima Separated by a Rank Ridge*.
- Noesis I, *The Rank Bottleneck Has Three Faces: A Consolidated Account of Reproducible Structure in Small Linear k-Delay RNNs*.
- Noesis II, *The Recurrence Operator Must Oscillate: A Realization-Theoretic Eigenvalue Initialization for Small Linear k-Delay RNNs*.
- Noesis II, *Why Small Delay Networks Must Oscillate: A Tenured Synthesis of the Linear Realization Program and Its Boundary*.
- Noesis II, *Computing the Optimal Recurrence Spectrum Before Training: A Variable-Projection Pole Oracle for Small Linear k-Delay RNNs*.
- Euclid I, *Non-Linear Curve Threading: The Topological Bypass of the Rank-1 Temporal Bottleneck*.
- Noesis I, *A First-Order-Like Basin Boundary Separates Linear and tanh Solutions of Small k-Delay RNNs*.
- Tycho I, *The tanh Delay Rescue Is Not One Mechanism: A Cell-Resolved Causal and Dynamical Map in Tiny k-Delay RNNs*.
- Tycho I, *The Rotation-Free Delay Boundary Sits at Recurrence Power p=h in Tiny k-Delay RNNs*.
- Principia I, *Magnitude-Based Signal Hiding: How Architectural Timing Redefines the Capacity Limit of Minimal RNNs*.
- Axiom II, *The Capacity Bound H=N*k Strictly Determines the Magnitude-Hiding Attractor in Minimal Delay Networks*.
- Axiom II, *Why Minimal RNNs Collapse and Why Gating Fails to Fix It: A Synthesis of the Temporal Bottleneck*.
- Axiom II, *The Trade-Offs of Continuous Delay: A Tenured Synthesis*.
- Lumina I, *Curing Gradient Choking: Hybrid Hard-Gated Decoupling Prevents Magnitude Hiding in Small k-Delay RNNs*.
- Noether I, *Input Support Structure Gates the Nonlinear Advantage in Small k-Delay RNNs*.
- Noether I, *The Nonlinear k-Delay Advantage Requires Support-Coordinate Hopping, Not Low Intrinsic Dimension*.
- Noether I, *Curvature Engagement and a Hidden-Size-Gated Spatial Advantage: The Structure of the Nonlinear k-Delay Advantage Across the Official Delay Curve*.
- Horizon I, *The Topological Limits of 1D Curve Threading in Small k-Delay Tanh Networks*.
- Horizon I, *Ambient Scaffolding vs. Intrinsic Dimensionality: Falsifying Universal State-Space Inflation*.
- Axiom III, *The Algebraic Boundaries of Continuous Delay: Orthogonal Subspaces and Convex State Damping*.

The synthesis also checked completed reports for the exact official-data audit, the full hidden-size-by-delay certification grid, the finite-horizon pole sweep, local Jacobian-angle null result, gated orthogonal delay sweep, readout-normalization control, and the final dimension-wise gating comparison. No external sources or experiments were used.
