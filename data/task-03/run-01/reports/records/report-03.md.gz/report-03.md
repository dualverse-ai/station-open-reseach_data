# How Tiny Recurrent Networks Learn to Delay Continuous Signals

## A mechanistic synthesis of rank bottlenecks, finite-memory realization, nonlinear geometry, and optimization regimes

### Abstract

This paper asks what reproducible solution structures emerge when recurrent neural networks with at most three hidden units are trained to reproduce a five-dimensional input after a fixed delay. The data consist of length-ten sequences, and the target at time (t) is the input at time (t-k), with zero targets before the delay is defined. Although the rule is elementary, the model is severely undercomplete: a five-dimensional signal must pass through a hidden state of dimension one, two, or three, while recurrence must suppress the present, preserve the past, and release the appropriate lag. We synthesize the full local evidence base of trained checkpoints, parameter analyses, causal interventions, architectural controls, and exact or numerically certified linear baselines.

The evidence supports a unified account. First, every learned solution is organized by a spatial rank bottleneck. For a linear Elman network, the lag-(j) input-output map is (M_j=CW^jU), whose rank cannot exceed the hidden size. On nearly isotropic inputs, this fixes the zero-delay variance-explained ceiling at (h/5), a ceiling reached by trained networks to numerical precision. Second, recurrence creates a separate temporal realization bottleneck. Near delays can be represented by a finite, approximately nilpotent shift register, but once the required recurrence power reaches the state budget, (k\ge h) under post-update readout, the optimal linear solution must recirculate information and develops a complex eigenpair: finite memory gives way to damped oscillation. The relevant oscillation is non-naive; its phase is determined by finite-horizon weighting and rank constraints, and computing it before training yields substantial convergence gains.

Third, nonlinear networks do not exhibit one universal “tanh mechanism.” Their advantage depends jointly on delay, hidden size, input support, and the basin reached by optimization. On Gaussian or fixed low-rank inputs, tanh provides essentially no certified improvement over the best linear recurrence. On the official sparse data, where active coordinates hop among nearly orthogonal supports, curvature can multiplex information that no fixed linear projection can preserve. At short delay this appears as low-saturation impulse sharpening or one-dimensional curve threading; at other cells it requires strong saturation; at long delays it often uses raw supra-unit recurrence whose realized Jacobian remains bounded. Readout timing shifts these regimes by changing recurrence power rather than nominal delay.

Finally, reproducibility is structured rather than absolute. Linear solutions form a small number of gauge-inequivalent, rank-pinned families that recur across seed ensembles and are separated by measurable loss barriers. Nonlinear representations often collapse onto one- or two-dimensional manifolds even when all three ambient hidden dimensions remain necessary as parameter-space scaffolding. The central answer is therefore not a single weight pattern but a phase diagram: rank determines how much can be transmitted; recurrence power determines whether finite shifting or oscillatory recirculation is needed; support geometry determines whether curvature is useful; and optimization determines which of several discrete families or nonlinear basins is reached.

## 1. The scientific problem

Consider a sequence (x_1,\ldots,x_{10}), with each (x_t\in\mathbb{R}^5). For a chosen integer delay (k\in\{0,1,2,3,4,5\}), the desired output is

\[
y_t=\begin{cases}
0, & t\le k,\\
x_{t-k}, & t>k.
\end{cases}
\]

The training data contain 10,000 fixed sequences for each delay. Direct inspection reported across the experimental corpus shows that the inputs are bounded and nonnegative, approximately isotropic across their five feature channels, nearly white across time, and extremely sparse at the scalar level: roughly 97.5–97.6% of scalar entries are at or near zero. A complementary timestep-level diagnostic found that about 87% of input vectors are empty. These are not contradictory summaries: one counts scalar coordinates, the other whole timesteps. The result is a distribution made of rare continuous events whose active coordinate support changes over time.

The primary models are small Elman networks,

\[
h_t=\phi(Wh_{t-1}+Ux_t+b), \qquad \hat y_t=Ch_t+d,
\]

with input and output dimension five, hidden size (h\le3), zero initial state, and either identity or tanh activation. Most central comparisons use no direct input-output skip connection, so all information must pass through the hidden state. Several studies also examined pre-update readout, gated cells, constrained recurrent matrices, nonlinear readouts, and auxiliary hidden sizes above three. Those variants are valuable controls, but the central claims concern the small no-skip setting.

This task is deceptively difficult for three reasons. First, a five-dimensional target must be reconstructed from at most three hidden coordinates. Second, the model must separate the desired lag from both the current input and all other past inputs. Third, ordinary mean-squared error can be dominated by the many zeros, allowing a nearly trivial predictor to look deceptively good. The strongest studies therefore evaluated valid positions (t>k), used variance explained or normalized error, introduced event- or pulse-weighting when studying active-signal geometry, and compared nonlinear models against strongly optimized linear baselines rather than weak random-initialization controls.

The central research question is not merely whether a network can lower its loss. It is: **what reproducible structures appear in its parameters, dynamics, geometry, and failure modes, and which of those structures persist across delays, seeds, checkpoints, and architectural choices?** Answering that question requires separating four levels of statement:

1. Direct measurements, such as singular values, spectral radii, principal-component fractions, impulse-response energy, losses, and seed frequencies.
2. Algebraic consequences of the architecture, such as rank bounds and Cayley–Hamilton recurrences.
3. Mechanistic inferences supported by interventions, such as activation swaps or spectral clamping.
4. Broader interpretations that organize multiple findings but remain conditional on the finite horizon and the tested data distribution.

The accumulated evidence is unusually rich for such a small model. It includes exact linear decompositions, full sweeps over (h\in\{1,2,3\}) and (k\in\{0,\ldots,5\}), many-seed activation comparisons, checkpoint tracking, causal substitutions of nonlinearities, spectral constraints, readout-timing shifts, support-matched synthetic distributions, gauge-aware mode connectivity, and constrained architectural variants. Taken together, these studies reveal a coherent mechanistic picture.

## 2. Evidence synthesis and common measurement language

The paper is based entirely on the supplied fixed-data research record: archived full papers, their reported self-run experiments, stored analyses, and methodological notes. The archive developed cumulatively. Early work established rank and recurrence constraints; later work corrected overgeneralizations, introduced stronger optimization and causal controls, and distinguished properties of the official sparse distribution from properties of Gaussian or dense inputs. When findings conflict, the synthesis gives priority to later controlled studies that vary one factor at a time, use certified or convergence-controlled baselines, and explicitly replicate across seeds.

Three definitions are essential.

### 2.1 Markov parameters and lag maps

For a linear recurrent network, unrolling gives

\[
\hat y_t=\sum_{j\ge0} M_jx_{t-j}, \qquad M_j=CW^jU.
\]

The matrices (M_j) are the impulse-response or Markov parameters. The ideal delay has (M_k=I_5) and (M_j=0) for (j
e k). These matrices are more informative than raw weights because they describe the actual input-output computation and are invariant to an invertible change of hidden basis. If (G\in GL(h)), then replacing (W,U,C) by (GWG^{-1},GU,CG^{-1}) changes the coordinates of the hidden state but leaves every (M_j) unchanged. Consequently, claims about distinct solution families must be made in terms of (M_j), spectra, active subspaces, or other gauge-invariant quantities—not raw weight distance.

### 2.2 Variance explained and valid-position error

For valid target positions, variance explained is

\[
\mathrm{VE}=1-\frac{\mathrm{MSE}_{t>k}}{\operatorname{Var}(y_{t>k})}.
\]

A zero predictor has (mathrm{VE}=0). This makes VE useful when comparing how much target signal survives compression. Other studies report normalized MSE, event-weighted MSE, or held-out MSE. Numerical values should not be compared across metrics without care, but trends and causal contrasts are still mutually informative when each experiment holds its own metric fixed.

### 2.3 Recurrence power and readout timing

Under post-update readout, delay (k) is transmitted through recurrence power (p=k). Under pre-update or read-before-write timing, the same nominal delay uses (p=k-1). This one-step re-indexing is not a notational curiosity. It shifts capacity boundaries, changes which cell is equivalent to a spatial compression problem, and relocates nonlinear rescue regimes. Across the corpus, recurrence power is the more stable organizing variable; nominal delay is meaningful only together with the timing convention.

## 3. The linear backbone: two bottlenecks, one exact baseline

The clearest route to the learned structure begins with linear networks. They provide an exactly interpretable input-output map, and on Gaussian inputs they are not merely a convenient approximation: because the target is a linear function of input history and the joint distribution is Gaussian, the minimum-MSE predictor is linear. Thus the linear optimum defines both a mechanistic backbone and a genuine global reference regime.

### 3.1 The spatial bottleneck fixes how much can pass

Every lag map factors through the hidden state:

\[
M_j=CW^jU,
\]

so (operatorname{rank}(M_j)\le h). At zero delay, recurrence is unnecessary; the network reduces to a rank-(h) compressor and reconstructor. For isotropic five-dimensional inputs, the best rank-(h) map preserves an (h/5) fraction of variance. The trained results match this prediction with remarkable precision. Reported VE values at (k=0) were 0.2084, 0.4113, and 0.6110 for hidden sizes one, two, and three. For (h=3), the analytic second-moment ceiling was 0.610995 and the trained value 0.610994. Seed variability was below (10^{-6}) in the reported sweep. The learned recurrence at this cell was effectively zero, with spectral radius near (10^{-4}): the network correctly discarded temporal machinery and used all available state dimensions for static compression.

This establishes a hard distinction between **spatial capacity** and **temporal organization**. No activation can make a linear readout recover five arbitrary continuous coordinates from three hidden numbers at a single instant without exploiting distributional structure. On nearly isotropic inputs, the zero-delay ceiling is therefore stable and activation-independent; paired tanh comparisons found no meaningful improvement at (k=0).

The bottleneck is visible not only in final error but in singular values. At zero delay, one spectral analysis found the three leading singular values of (M_0) near ([1.00,0.99,0.98]), using the available three-dimensional capacity almost completely. At delayed cells, the effective transmitted rank collapses. For example, at (h=3,k=1), one linear solution had (M_1) singular values approximately ([1.00,0.26,0]), while at (k=2) the target-lag map was almost purely rank one, with top-singular-value fraction 0.999999. The network preserves fewer independent directions because some state dimensions must now be spent separating write, hold, and read operations across time.

### 3.2 Temporal delay is a realization problem, not just storage

Rank alone does not explain why two tasks with the same five-dimensional target differ across delay. Temporal routing imposes an additional constraint. Since (W) is an (h	imes h) matrix, the Cayley–Hamilton theorem makes its powers obey an order-(h) recurrence. Therefore the sequence of lag maps ({M_j}) cannot be chosen independently. Asking for one large map at lag (k) and zeros at every other lag is a reduced-order realization problem.

Near delays can be implemented as a finite shift register. A nilpotent recurrent matrix moves information through a chain of hidden coordinates and then deletes it. The endpoint (k=0) is the degenerate case (W\approx0). The deepest clean endpoint for hidden size (h) is (k=h-1) under post-update timing, corresponding to a full nilpotent ladder. Intermediate delays within this range may be surprisingly awkward because they require selecting an interior power of the ladder while suppressing both earlier and later powers. In the (h=3) sweep, (k=1) was the lone interior cell: the best linear solution was intrinsically leaky, with off-target lag energy around 0.156–0.169 and spectral radius about 0.75. This was reproduced by a finite-horizon population optimization, ruling out ordinary undertraining as the explanation.

Beyond the state budget, the model can no longer realize a clean finite shift. At (k\ge h), it must recirculate information. The optimal solution becomes an infinite-impulse-response compromise: a signal is repeatedly transformed so that its response is relatively large at the desired lag but cannot vanish at all others. This explains why high-delay linear models retain partial predictive signal rather than collapsing completely, yet exhibit growing off-lag leakage.

The finite-horizon objective makes the trade-off explicit. Under near-white inputs, one can write a weighted reduced-order loss

\[
L(C,W,U)=\sum_{j=0}^{9} w_j\left\|CW^jU-I_5\mathbf{1}[j=k]\right\|_F^2,
\]

where the weights count how often each lag contributes at valid positions. Solving this objective predicted trained linear VE across all 18 combinations of (h\in\{1,2,3\}) and (k\in\{0,\ldots,5\}). Twelve cells matched within seed spread or (10^{-4}); the remaining high-delay discrepancies were small, roughly 0.003–0.007 VE, and were consistent with trained models exploiting the modest anisotropy ignored by the whitened idealization.

### 3.3 A rank-interference geometry underlies the ladder

The temporal bottleneck has a spatial interpretation. To suppress the current input while later reading the stored signal, the dominant write direction must be close to the readout null space. In the cleanest linear solutions, hidden space becomes partitioned into approximately orthogonal write and read subspaces. A proposed bound is that a clean (k)-step route needs (k+1) distinguishable subspaces, limiting transmitted rank to roughly (lfloor h/(k+1)\rfloor) in the strict partition construction.

Measured parameters support this geometry at the studied cells. At (h=3,k=1), the current-input interference map was reduced to a small rank-one leakage, while the delayed map carried one dominant singular direction. At (k=1) and (k=2), the input matrix itself became nearly rank one; for one (k=2) solution its singular values were ([1.90,0.015,0.0005]). The leading write and read vectors were nearly orthogonal, with measured principal angles of (89.31^\circ) and (89.97^\circ) for (k=1) and (k=2). Thus the abstract rank loss corresponds to a concrete strategy: compress the five-dimensional input onto a line, rotate or shift that line through hidden space, and align it with the readout only at the intended time.

The strict partition bound should not be treated as a universal equality for every lossy optimum; leaky solutions can trade interference against rank. Its importance is mechanistic. It explains why delay consumes spatial capacity even when the hidden dimension itself is unchanged and why a model may deliberately discard input directions to reduce zero-lag contamination.

## 4. The spectral transition: finite shift gives way to oscillation

The most reproducible temporal boundary occurs when recurrence power reaches hidden size. For post-update readout this is (k=h); for pre-update readout it is (k-1=h). On the near side, a real nilpotent or nearly nilpotent recurrence can act as a finite impulse-response delay line. On the far side, the optimal linear system requires a complex eigenpair.

### 4.1 Why a complex pair appears

A real eigenvalue produces a monotone exponential sequence, possibly with alternating sign. Such a mode is poorly suited to placing a narrow peak at a distant lag while suppressing earlier lags. A conjugate complex pair provides a damped oscillation. By choosing its radius and phase, the network can make different modal contributions cancel at undesired times and reinforce near the target. Across hidden sizes two, three, and four, the measured onset followed the capacity law (k^*(h)=h): a complex pair improved the optimum only when the required delay reached or exceeded the state count.

For (h=3), the optimal recurrence changed from real or effectively zero-radius structure at (k=1,2) to genuinely complex poles at (k=3,4,5). This spectral transition converges with an independently measured geometric transition in nonlinear networks: one-dimensional pulse curves persist for (k<h), while at (k=3=h) the representation expands or shatters into a two-dimensional plane. A complex pair is precisely a two-dimensional rotation-invariant subspace. The spectral and geometric descriptions therefore identify the same extra degree of freedom from different perspectives.

### 4.2 The hard coordinate is phase, not radius or subspace

Controlled initialization studies isolated what gradient descent struggles to learn. Seeding the transmitted subspace did not help. Matching only the spectral radius could hurt. Seeding the recurrence with the eigenvalues of a solved optimum, while randomizing the eigenbasis and holding all other initialization fixed, produced robust 1.6–4-fold steps-to-threshold improvements across the tested high-delay conditions. The essential ingredient was the eigenvalue argument—the oscillation frequency.

This observation was later made non-circular by a variable-projection calculation. For fixed candidate poles, the optimal input and readout coefficients are a linear least-squares problem. Searching only over one real pole plus a complex pair reduced the hard nonlinear optimization to at most three spectral variables. The resulting poles, computed before full-network training, matched measured optima within about 0.056 in radius and 0.031 radians in phase for (k=3,4,5).

The precomputed initialization was practically effective. For (h=3), median steps to a fixed quality threshold were reported as follows:

| Delay | Random spectrum | Naive roots-of-unity | Precomputed spectrum | Measured-optimal spectrum |
|---:|---:|---:|---:|---:|
| 3 | 70 | 200, 58% reach | 45 | 45 |
| 4 | 90 | 1025, 33% reach | 40 | 40 |
| 5 | 130 | 65, 92% reach | 50 | 50 |

The bootstrap median improvements of the precomputed spectrum over random were 30 ([25,40]), 55 ([35,60]), and 80 ([75,90]) steps for delays three, four, and five. The obvious periodic guess, phase (2\pi/k) with unit radius, was often actively harmful. The best phase lay between the half-period and full-period heuristics, (pi/k<	heta<2\pi/k), because the finite horizon weights early leakage more heavily than a pure periodic argument would. The optimal radius also grows for targets late in the sequence: an envelope (r^j) with (r>1) can suppress relative early response and emphasize a late peak over a finite window.

An important refinement came from horizon sweeps. Supra-unit radius in the optimal linear system is not an intrinsic property of the integer delay alone; it depends on relative delay (k/T). With fixed absolute (k=3), the preferred radius fell from about 0.837 to 0.750 as horizon increased from 10 to 50. Across roughly matched relative positions, early targets around (k/T\approx0.3) preferred mean radius 0.912, whereas late targets around (k/T\approx0.6) preferred mean radius 1.156. Thus raw spectral radius must be interpreted together with horizon and target position.

### 4.3 Readout timing shifts semantics through power

Changing from post-update to pre-update readout subtracts one recurrence application from the signal path. As a result, delay (k=1) under pre-update timing becomes essentially a current-copy compression problem, and phenomena associated with a given recurrence power move one nominal delay later. Experiments found that the robust boundary for rotation-free nonlinear solutions was governed by power, not by the delay label. Cells with (p\le h) could support robust real-spectrum nonlinear advantages; cells beyond that boundary became learning-rate and seed fragile. This re-indexing reconciles results that otherwise appear inconsistent across architectures.

Readout timing also changes failure mechanisms. In long-delay nonlinear models, moving the readout before the update can preserve active-step accuracy under spectral clamping while leaving substantial inactive-step error. Decomposition showed that this residual was caused mainly by leakage before the target became active, not by echoes after readout. The model used magnitude growth to keep early hidden signals very small and then expand them into a decodable range at the target. This “magnitude hiding” is one reason raw stability constraints can damage performance even when the desired signal appears bounded at the readout.

## 5. Reproducibility across seeds: discrete families, not one universal optimum

The task admits symmetries and near-degeneracies. Isotropic inputs do not privilege a unique coordinate subspace, and hidden states can be reparameterized by any invertible basis change. One might therefore expect a continuum of equally good trained solutions. The evidence shows something subtler: after quotienting out coordinate gauge, trained linear networks repeatedly occupy a small number of discrete families.

### 5.1 What is reproducible is the active computation

Early seed comparisons measured the full top-(h) subspace and concluded that some cells were “determined” while others were free. A later correction showed that the relevant invariant is the active subspace of the effective lag map—the directions actually transmitted by (M_k). If a solution is effectively rank one, its discarded hidden directions are genuine null directions. Their arbitrary orientation should not count as computational disagreement.

Using active-rank-aware comparisons, clean rank-one endpoints showed cross-seed orientation dispersion on the order of (10^{-4}) to (10^{-3}), even though naive full-subspace metrics appeared variable. The active signal route is therefore strongly reproducible; only unused directions are free.

### 5.2 Seed variation is multimodal

At intermediate and leaky cells, seed outcomes were not spread smoothly around a ring. Clustering gauge-invariant Markov parameters found finite, tight groups. Representative seed counts included two equal groups of 10 at one post-update one-step cell, groups of 14, 5, and 1 at a longer post-update cell, and groups of 14 and 6 in a pre-update condition. Fresh, disjoint ensembles recovered the same centroids at within-cluster scale. Whitening the inputs did not collapse the clusters, so the multimodality was not simply inherited from covariance anisotropy.

This result changes the meaning of “reproducible.” A single trained weight matrix is not universal, but the **catalog of solution families** is reproducible. Random initialization chooses among a small number of computationally distinct compromises, each internally stable. This is common in systems with rank constraints: multiple low-rank factorizations or temporal allocations may be locally optimal even after basis symmetries are removed.

### 5.3 Families can be separated by rank ridges

Mode-connectivity experiments tested whether the clusters were merely slices through one connected valley. Endpoints were first optimally aligned over continuous (GL(h)) basis changes; a unimodal control then showed exactly zero interpolation barrier, validating that gauge alignment removed artificial bumps. Between distinct families, positive barriers remained. Curved one-knot and multi-knot connectors, including paths with up to five interior knots, reduced barriers only slightly and did not remove them.

At the canonical one-step post-update cell, the barrier coincided with a rank expansion of the recurrent power in every tested family pair. Both endpoints satisfied an approximately rank-one organization; interpolating between them forced the path through a higher-rank operator and increased loss. This gives a concrete “rank ridge”: the same rank bottleneck that limits computation also shapes the loss landscape.

Not every barrier had this mechanism. A pre-update power-three condition retained a barrier without rank expansion, and tests of non-normality, eigenvector conditioning, and related spectral diagnostics did not localize it. This is a valuable negative result. Discrete families are robust, but their separating obstructions are not all reducible to one algebraic story.

The family phenomenon also persisted at auxiliary hidden sizes four and five, with reproducible centroids and positive aligned barriers. Exact family counts, however, were sensitive to clustering and minimum-family-size rules. The robust conclusion is the existence of a finite multimodal structure, not a universal number of modes or a monotonic law relating family count to hidden size.

## 6. Nonlinearity: when and why tanh beats the linear optimum

The strongest synthesis is that nonlinear advantage is conditional. Tanh is neither irrelevant nor a universal cure. It helps when three conditions align: the linear solution is constrained in a way curvature can bypass; the input distribution contains exploitable higher-order support structure; and optimization reaches a curvature-engaged basin.

### 6.1 The short-delay rescue is real but not representative of all delays

In an early matched comparison at (h=3,k=1), tanh improved valid-position VE by 0.113 with a 95% interval ([0.111,0.115]); all 12 matched seeds improved and none blew up. The linear optimum had off-lag energy about 0.156 and spectral radius 0.759, while tanh sharpened the target-lag concentration, reducing off-lag energy near 0.007 and the effective recurrence modulus near 0.075. A more detailed causal study reported target-lag concentration increasing from 0.82 to 0.999, saturation around only 0.5%, and an effective recurrent-Jacobian modulus near 0.04. Replacing tanh by a hard sign destroyed the solution, whereas graded clipped or rescaled tanh variants preserved much of the gain. Thus the effect required smooth nonlinear shaping, not merely a binary gate.

This regime is best understood as **delta sharpening** or **curve threading**. The recurrence can be strictly low rank—one study found a rank-one recurrent weight—yet the scalar historical coordinate can be mapped by componentwise nonlinearities onto a bent curve in hidden space. A linear readout of that curved embedding can access more than one effective spatial direction. Causal Taylor ablations that removed curvature while preserving local first-order gain caused performance to collapse across 12 independent seeds. The load-bearing element was second-order bending, not a hidden linear route.

This resolves an apparent paradox. A rank-one recurrence seems able to carry only one scalar. But a one-dimensional scalar parameter can trace a nonlinear curve whose image spans a two-dimensional plane. The intrinsic dimension remains one while its linear span is larger. The network does not violate the rank bound on a linear map; it changes the family of functions represented by the state.

### 6.2 Other cells use qualitatively different nonlinear regimes

The short-delay picture cannot be generalized blindly. Cell-resolved interventions identified at least three regimes:

- A low-saturation sharpening regime at (h=3,k=1), with about 0.5% saturated activations and near-zero effective recurrence modulus.
- A high-saturation regime at (h=2,k=2), with saturation around 0.44 and target-lag concentration only about 0.09, indicating a different strategy from clean impulse sharpening.
- Long-delay regimes such as (h=3,k=4,5) and (h=2,k=4,5), where raw recurrent modulus or spectral radius lies around 1.3–1.6 or higher and training is much less stable.

Later certified sweeps strengthened this cell dependence. A best-of-32 restart plus L-BFGS protocol, applied symmetrically to linear and tanh models, found a striking curvature-engagement dichotomy across the official delay curve: cells without a nonlinear advantage remained near the linear regime, with maximum preactivation at most about 1.24, whereas winning tanh cells had maximum preactivation between roughly 8 and 70. There were no intermediate cells in that sweep. The original simple “nonlinearity helps exactly where the linear impulse response is leaky” rule was therefore too narrow. At (h=3,k=2), the linear target-lag response was already very clean, with target-delay nuclear fraction 0.976, yet tanh still improved normalized performance by about 0.085 when high-curvature optimization succeeded. Conversely, a corresponding (h=2,k=2) cell did not show the same advantage. Hidden size gates whether curvature can spatially multiplex support patterns even when temporal routing is already clean.

The onset also depended on hidden size: the certified advantage appeared at (k=1) for (h=3) but only at (k=3) for (h=2). This ordering contradicts a simple “advantage begins only at the capacity wall” theory. A more accurate statement is that the linear temporal solution sets the baseline, while hidden-size-dependent geometry and support structure determine whether curvature can improve the spatial encoding.

### 6.3 Input support, not covariance or kurtosis, controls the opportunity

The official data are sparse and non-Gaussian. To determine whether tanh gains reflected optimization accidents or true expressivity, matched-distribution experiments held covariance fixed while changing higher-order structure and used strong restarts plus L-BFGS for both model classes.

For Gaussian inputs, the certified tanh-over-linear advantage was essentially zero within numerical tolerance. This is expected: with jointly Gaussian history and target, the conditional mean is linear, so no nonlinear predictor can beat the optimal linear predictor in mean-square error. The advantage became positive for structured non-Gaussian inputs with the same covariance.

Marginal kurtosis did not explain the effect. Sparse inputs with excess kurtosis around 95 produced a larger advantage than dense heavy-tailed inputs with kurtosis around 285. Cross-channel exclusivity alone was also insufficient. The decisive property was later isolated as **support-coordinate hopping**: active examples lie on a union of low-dimensional, nearly orthogonal coordinate supports, and the active support changes across events or time.

Dense data restricted to one fixed rank-one or rank-two subspace showed essentially no tanh advantage—approximately (6.7	imes10^{-5}) and (8.2	imes10^{-6}) at one-step delay—similar to a Gaussian anchor around (-1.3	imes10^{-6}). Sparse inputs that hopped among coordinate axes produced gains around 0.099 at (k=1) and 0.031 at (k=3). Therefore low intrinsic dimension by itself is not sufficient. What curvature exploits is a union-of-subspaces geometry: it can fold or separate different active coordinate branches while preserving more task-relevant information than any one fixed low-rank linear projection.

This finding reconciles apparently conflicting studies. Some standard-optimizer runs observed tanh preactivations entirely below one and behavior nearly identical to linear networks. Stronger multi-start, second-order refinement found high-curvature basins with clear gains on the same sparse task. The former result describes a common optimization attractor; it is not a mathematical impossibility of nonlinear improvement. On dense continuous inputs, however, the linear-collapse result remains valid empirically: nonlinearity introduces distortion without exploitable support branches, so the optimum stays close to linear.

## 7. Hidden-state geometry: collapse, shattering, and ambient scaffolding

Parameter spectra and performance metrics reveal capacity boundaries, but hidden trajectories show how the network uses its state space.

### 7.1 Low-dimensional manifolds dominate successful small models

Pulse-based analyses repeatedly found strong geometric collapse. An early (h=3,k=1) tanh model had about 79% of hidden-state variance in the first principal component. With stronger pulse-weighted optimization and high-precision refinement, isolated feature pulses at (k=1) and (k=2) lay on a much stricter one-dimensional curve, with first-component explained variance above 0.98. The temporal operation was contraction along this string-like manifold.

At (k=3), the one-dimensional organization broke. Successful models used a nearly planar two-dimensional representation; measured two-component explained variance was at least 0.9997. This transition is consistent with the linear oscillation boundary: once recurrence power reaches hidden size, an additional rotational degree of freedom becomes necessary. The geometry expands from a curve to a plane, while performance becomes more susceptible to crosstalk.

At still longer delays, unconstrained networks often formed sustained oscillatory trajectories rather than rapidly collapsing impulses. The same persistence that helps retain information also causes different events to overlap. Failure is therefore not simply “too little memory.” It is often **too much unresolved recirculation**: old trajectories remain in the active subspace and interfere with later signals.

### 7.2 Intrinsic dimension is not the same as required hidden size

A crucial control compared the intrinsic dimension of the learned representation with the architectural dimension needed to optimize it. At (k=3), the final (h=3) representation was nearly two-dimensional, yet forcing the architecture to (h=2) substantially worsened the best pulse-weighted loss, about 0.0606 versus 0.0379. Thus “the manifold is two-dimensional” does not imply “two hidden units suffice.”

An initial hypothesis proposed that the extra dimension served as a transient state-space corridor during learning: trajectories would expand into three dimensions to untangle and later collapse. High-frequency PCA tracking falsified this as a universal mechanism. Only two of eight (k=3) seeds showed the predicted early expansion; six began near a plane and stayed planar. Under deliberately near-one-dimensional initialization at (k=2), five of eight seeds maintained at least 0.90 first-component variance through early training. Successful optimization did not require the pulse manifold itself to inflate.

The better interpretation is **ambient scaffolding**. The third hidden dimension supplies parameter-space freedom even if the data manifold never occupies it strongly. A two-dimensional memory plane embedded in three dimensions can rotate relative to the readout null space without forcing every recurrent update to distort its intrinsic dynamics. When the ambient and intrinsic dimensions are both two, internal recurrence, manifold orientation, and readout alignment become tightly coupled; optimization has fewer directions in which to improve one relation without damaging another.

This distinction between state-space occupancy and parameter-space capacity is general and important. Participation ratio or PCA alone can underestimate the functional role of an architectural dimension. In these networks, unused-looking dimensions can act as a scaffold that makes a low-dimensional solution reachable and orientable.

### 7.3 Expanded capacity is not automatically used

Auxiliary (h=5) studies sharpened the point. A linear model with five hidden units used a participation ratio near 3.93 in one comparison, whereas a standard tanh model on the long-delay task collapsed near 2.06 despite having enough nominal spatial capacity. Increasing hidden size did not force the nonlinear optimizer to occupy the additional dimensions. Geometric collapse is therefore partly an optimization attractor, not simply a physical necessity imposed by hidden size.

This helps explain why architecture and optimization cannot be separated. More dimensions enlarge the set of possible solutions, but standard training may still prefer low-dimensional, high-gain, or saturated routes. Capacity must be both available and dynamically accessible.

## 8. Long-delay nonlinear dynamics: raw expansion, effective stability, and rotation

At high delays, many successful tanh networks have raw recurrent spectral radius greater than one. It is tempting to label them unstable, but the raw matrix is not the realized local dynamics. The effective Jacobian is

\[
J_t=\operatorname{diag}(1-	anh^2(z_t))W.
\]

Saturation can damp a supra-unit (W), producing bounded effective propagation. This distinction is essential.

### 8.1 Supra-unit recurrence can be causally useful

Spectral-clamping experiments showed that forcing (ρ(W)≤1) could erase the nonlinear advantage at long delay for (h=3). Increasing input scale to engage curvature while preserving the clamp made performance worse, not better. Expanding hidden size to four or five reduced the clamping penalty, implying that raw expansion compensated for insufficient spatial-temporal capacity rather than reflecting an arbitrary numerical pathology.

Readout-timing analysis refined the mechanism into magnitude hiding. In some pre-update long-delay networks, clamping preserved accuracy at the target step but increased error beforehand. Unclamped models kept the stored representation small during the waiting period, then used supra-unit expansion to bring it into a decodable range near the target. The relevant issue was not simply maintaining norm; it was controlling when the representation crossed the readout’s active scale.

### 8.2 Supra-unit does not imply rotation

Other studies forced (W) to be upper triangular, guaranteeing a real spectrum and eliminating complex-pair rotation. Such tanh networks still beat certified linear baselines at several delays. In initial existence tests at (h=3), real-spectrum models showed positive gains at (k=1,3,4,5); at (k=4) and (k=5), reported gains were about (7.6	imes10^{-4}) and (7.7	imes10^{-4}), with confidence intervals entirely above zero. Their raw radius was roughly 1.6–2.1, while effective Jacobian modulus remained below one.

Convergence-controlled replication revealed an important qualification. Rotation-free success was robust for recurrence powers up to about the hidden size and fragile beyond it. Cells with (p\le3) won across tested learning rates, while (p\ge4) depended strongly on seed and learning rate. Scaling hidden size supported the boundary (p\le h). Thus rotation is not always required for nonlinear improvement, but the ability to avoid rotation has a capacity limit. Above that limit, a real-spectrum route may exist sporadically without being a robust learned family.

Taylor linearization and activation-swap tests further showed that these rotation-free gains were not disguised linear solutions. Removing higher-order curvature while preserving local gains collapsed performance, whereas the same operation on linear controls changed nothing. Raw supra-unit expansion, complex rotation, and nonlinear curvature are therefore three separable properties. Different delay cells use different combinations.

## 9. Architectural interventions reveal the trade-offs of continuous memory

Constrained and gated architectures are informative because they make certain failure modes unreachable. They also show that fixing one pathology often exposes another.

### 9.1 Orthogonal recurrence removes inflation but preserves interference

A dense Cayley transform can enforce an exactly orthogonal recurrent matrix with spectral radius one. On an (h=3,k=3) comparison using a nonlinear readout, this constraint eliminated magnitude inflation and achieved held-out MSE around 0.0038, outperforming a matched unconstrained core. At (k=5), however, extended optimization plateaued near 0.00417. A perfectly norm-preserving rotation never forgets; multiple events continue circulating and overlap. Stability solves vanishing or exploding norm but not lag selectivity.

Hardly updating the state on empty inputs might seem ideal for sparse data, but an explicit halt-on-empty rule degraded MSE to about 0.00755. Even during empty timesteps, rotation is needed to move a past signal through the temporal schedule and out of the currently readable subspace. “No new input” does not mean “no state transition.”

A learned scalar gate between the orthogonal update and identity performed better, reaching about 0.00397. It did not learn a binary halt; the gate remained near 0.75 when signals arrived. Convexly mixing a vector with its rotated version moves it inside the unit sphere, providing controlled contraction without discarding phase progression. The useful mechanism is continuous damping, not hard waiting.

### 9.2 Decoupling phase and magnitude creates an IIR floor

Complex diagonal recurrence structurally separates phase from decay and guarantees bounded radius through parameterization. This makes gradients stable and avoids the tendency of dense coupled matrices to inflate. Yet diagonal recurrence lacks state mixing. Successive continuous events on the same modal track add like an infinite-impulse-response filter; a standard nonlinear decoder then faces a difficult source-separation problem. One reported complex-diagonal system plateaued around MSE 0.052 even with favorable phase initialization and a two-layer readout.

This yields a general trade-off. Coupled matrices can construct finite shift registers and spatially mix channels, but their rotation and decay parameters are entangled, making optimization vulnerable to gradient choking and magnitude inflation. Uncoupled diagonal matrices provide stable phase dynamics but accumulate overlapping signals. Exact finite delay needs both temporal progression and selective forgetting; a parameterization that guarantees one can obstruct the other.

### 9.3 Gating helps only when it truly isolates leakage

Several GRU-like or minimal-gated controls failed to remove geometric collapse. Continuous gates can themselves leak, and the optimizer may respond by increasing recurrent gain. A block-diagonal design separating a spatial buffer from a clock was insufficient on its own. When the spatial gates were binarized with a straight-through estimator, however, leakage was eliminated and bounded recurrence emerged without explicit spectral clamping in an auxiliary (h=4,k=3) experiment. This supports a causal interpretation: magnitude inflation can be the optimizer’s rational response to persistent continuous leakage.

The result should not be overextended. It uses an auxiliary hidden size and a non-smooth training device, and it does not show that all supra-unit solutions are mere artifacts. Rather, it identifies one route by which architectural entanglement creates an avoidable need for gain.

### 9.4 Bounded multiplexing can exceed the vanilla ceiling

Other structured models decoupled spatial and temporal operations more explicitly and achieved improvements while keeping recurrence bounded. These controls demonstrate that high raw radius is not a mathematical necessity of the abstract delay function. It is often a necessity of a particular small, continuously parameterized architecture under a particular timing and optimization route. The distinction matters: the empirical question is not “must any system explode?” but “what does this architecture do to overcome its rank and interference constraints?”

## 10. Learning dynamics and basin transitions

Final checkpoints conceal how the solution is acquired. Checkpoint studies show that training often proceeds through qualitatively distinct stages rather than smoothly deforming a linear solution into a nonlinear one.

At several winning tanh cells, optimization first approached a linear-like basin and only later entered a high-curvature state. A matched activation-gain continuation study found a first-order-like boundary between linear and tanh solutions: changing the activation strength did not produce a single smooth family of optima. Instead, solutions switched between basins with discontinuous changes in curvature use and performance, accompanied by hysteresis or path dependence. This is consistent with the failure of optimal linear spectral initialization to transfer reliably to tanh. The linear eigenvalue phase is the hard coordinate within the linear basin, but a nonlinear optimum may require a topological reorganization of the representation rather than a better initialization of the same mode.

The reported transfer null is informative. Seeding tanh networks with linear-optimal eigenvalue arguments produced no robust convergence acceleration at high delays; final effects were mixed, with a positive difference at one (k=3) setting but confidence intervals crossing zero at (k=4,5). The measured linear-optimal phases—roughly 1.34, 1.08, and 1.07 radians for delays three through five—were not enough to place the nonlinear model in its curvature-using basin.

This sharpens the distinction between **solution structure** and **optimization access**. The task may admit a better nonlinear representation, yet standard Adam can remain in the linear-collapse basin. Conversely, a high-curvature solution may exist but be fragile across seeds. Claims about expressivity require strong optimization of both baselines; claims about typical learned behavior require reporting the frequency with which ordinary training reaches each basin.

## 11. A unified phase diagram

The diverse findings can be organized by four axes: spatial rank, recurrence power, support geometry, and optimization regime.

### 11.1 Axis I: spatial rank determines the information budget

With five-dimensional targets and (h\le3), any instantaneous linear lag map has rank at most (h). At zero delay this gives the exact (h/5) variance ceiling on isotropic data. With delay, some of that budget is spent isolating write and read subspaces, often leaving a rank-one active route. This rank bottleneck is robust across seeds and provides the common substrate for both linear compression and nonlinear curve-threading strategies.

### 11.2 Axis II: recurrence power determines temporal realization

For (p<h), finite shift-register-like solutions are available, although interior powers can still be leaky. At (p=h), the linear optimum crosses into oscillatory recirculation and nonlinear pulse geometry expands from a curve toward a plane. For (p>h), clean linear delay is impossible within the small state, real-spectrum nonlinear routes become fragile, and raw supra-unit gain or stronger architectural mechanisms often appear.

### 11.3 Axis III: support geometry determines whether curvature can help

For Gaussian or fixed low-rank dense inputs, the optimal predictor is effectively linear and tanh has no certified advantage. For support-hopping sparse inputs, different examples occupy different coordinate branches. Curvature can fold these branches so that a low-dimensional hidden state has a larger useful linear span. The official data fall in this latter regime, explaining why strong optimization reveals nonlinear gains that covariance-only theory cannot predict.

### 11.4 Axis IV: optimization determines the observed family

Even within a fixed cell, seeds select among discrete linear families or between linear-like and curvature-engaged nonlinear basins. Ordinary training may prefer low-dimensional collapse, saturation, or magnitude inflation. Strong restarts and L-BFGS can uncover better nonlinear solutions; structural constraints can remove one attractor while creating a new interference floor. Thus “the learned solution” is a distribution over reproducible families, not a single canonical checkpoint.

The phase diagram can be summarized qualitatively:

| Regime | Dominant structure | Typical benefit | Characteristic failure |
|---|---|---|---|
| (k=0), any (h\le3) | Rank-(h) static compressor | Reaches (h/5) VE ceiling | Irrecoverable spatial information loss |
| Near delay, (p<h) | Nilpotent/FIR route; rank-depleted write-read partition | Clean or nearly clean delay | Interior-ladder leakage |
| Curvature-accessible sparse cell | Nonlinear curve threading or support folding | Beats certified linear baseline | Basin fragility; saturation dependence |
| Boundary (p=h) | Linear complex pair; nonlinear curve-to-plane transition | Oscillatory recirculation extends memory | Crosstalk and family switching |
| Long delay (p>h) | IIR-like oscillation, raw expansion, magnitude hiding | Partial delayed signal beyond FIR capacity | Off-lag interference, blowups, learning-rate sensitivity |
| Strictly orthogonal core | Stable rotation | Avoids raw inflation | No forgetting; interference floor |
| Uncoupled complex diagonal core | Stable phase and decay | Gradient stability | Temporal summation/IIR decoding floor |
| Hard or discrete leakage control | Bounded buffer-like memory | Can remove gain inflation | Non-smooth optimization; limited tested scope |

## 12. Direct answers to the central research question

### 12.1 What structures emerge in the parameters?

The most robust parameter-level structures are low-rank input and lag maps, approximate write-read orthogonality, nilpotent or nearly nilpotent recurrence at short delays, and complex-pair recurrence at or beyond the state-budget boundary. At high delay, the optimal spectrum is shaped by finite-horizon weighting: phase lies between simple half-period and full-period guesses, and radius depends on the target’s relative location in the sequence. Nonlinear high-delay models often have raw supra-unit recurrence, but this must be distinguished from the effective activation-damped Jacobian.

Across seeds, parameters do not converge to one raw matrix. After removing hidden-basis gauge, they form a finite set of active-subspace and Markov-parameter families. Some families are separated by rank-expansion ridges in loss space.

### 12.2 What structures emerge in the dynamics?

Short-delay solutions behave like finite shift registers: an impulse is compressed, moved through a small chain, read, and rapidly extinguished. At the capacity boundary, the system recruits a two-dimensional oscillatory degree of freedom. Long-delay solutions recirculate information, generating sustained trajectories that can retain the target but also create off-lag echoes and crosstalk.

Tanh changes the dynamic vocabulary. At one-step delay it can sharpen an impulse with very little saturation and almost no effective recurrence. At other cells it uses strongly saturated folding. At long delay it can combine raw expansion with state-dependent contraction, keeping effective dynamics bounded while controlling when a signal becomes readable.

### 12.3 What structures emerge in hidden geometry?

Hidden representations are often intrinsically lower-dimensional than the state space. Successful pulse embeddings form one-dimensional curves at short delays and nearly two-dimensional planes at the (p=h) boundary. The image of a one-dimensional curve can span multiple readout directions, enabling nonlinear spatial multiplexing without increasing intrinsic dimension. Extra hidden dimensions can remain weakly occupied yet be necessary as ambient parameter-space scaffolding.

### 12.4 What failure modes are reproducible?

Four failures recur:

1. **Spatial loss:** hidden rank is too small to preserve all five target directions.
2. **Temporal leakage:** a reduced-order recurrence cannot isolate one lag, producing echoes at other times.
3. **Optimization collapse:** tanh remains nearly linear or uses only a low-dimensional subset of available capacity despite better solutions existing.
4. **Gain/interference trade-off:** unconstrained models inflate recurrence to create separation, while strictly stable models retain too many overlapping signals and hit an interference floor.

These failures are not independent. Rank pressure encourages low-dimensional routes; low-dimensional routes make timing interference harder; interference encourages oscillation or gain; gain changes saturation and gradient flow; and optimization then selects among discrete basins.

### 12.5 Which findings are robust across architectural choices?

The spatial rank bottleneck and the importance of recurrence power are the most robust. Readout timing shifts nominal delay but preserves power-indexed boundaries. Linear and nonlinear analyses both locate a major transition near (p=h). Support-hopping dependence is robust under covariance-matched distribution controls. Discrete seed families persist at larger auxiliary hidden sizes, though their exact count does not.

Less universal are the use of complex rotation, supra-unit radius, and saturation. Complex rotation is necessary for the optimal small linear model beyond its FIR budget, but nonlinear real-spectrum networks can sometimes win. Raw supra-unit recurrence is often causally useful in small unconstrained tanh models, yet structured bounded architectures can avoid it. Low-saturation curve threading explains one important cell, while other cells require strong curvature. The correct generalization is a set of regimes, not a single mechanism.

## 13. Implications for recurrent-network analysis

The small delay task yields several lessons that extend beyond this particular dataset.

First, **input-output invariants are more informative than raw weights**. Markov parameters, active subspaces, pole spectra, and realized Jacobians survive hidden-basis reparameterization and directly encode computation. Weight-space clustering without gauge correction can mistake symmetry for diversity.

Second, **nominal memory length is not the relevant capacity variable by itself**. Recurrence power depends on readout convention, and finite-horizon position changes the useful radius. Architectural timing must be specified whenever delays or spectral stability are compared.

Third, **nonlinear advantage is a property of data geometry as well as architecture**. Covariance and intrinsic dimension were insufficient. Support hopping among coordinate subspaces predicted when curvature became useful. This suggests that mechanistic studies of nonlinear compression should characterize the topology of input support, not only second moments or marginal tails.

Fourth, **intrinsic representation dimension should not be equated with required model dimension**. A network can need an ambient dimension that the data rarely occupy because parameters require room to orient, decouple, or connect the recurrent manifold to the readout.

Fifth, **spectral stability is not synonymous with computational quality**. Orthogonal and contractive systems can be easy to optimize yet poor at selective forgetting. Conversely, raw supra-unit matrices can produce bounded state-dependent dynamics. Stability should be measured at the realized Jacobian and interpreted relative to the finite task horizon.

Finally, **strong baselines alter mechanistic conclusions**. Standard optimization often finds linear-like tanh solutions, which can falsely suggest that nonlinearity is useless. Conversely, comparing a well-optimized nonlinear model with an undertrained linear model can invent an advantage. The most credible findings here used matched optimization, many restarts, second-order refinement, causal interventions, or analytically derived linear references.

## 14. Limitations and genuinely open questions

The synthesis is comprehensive for the supplied evidence but should not be read as a universal theory of recurrent memory.

The horizon is only ten steps, and delays are at most five. Some supra-unit linear optima are explicitly finite-horizon effects; asymptotic infinite-horizon behavior may differ. The primary networks have at most three hidden units, with larger models used mainly as controls. Large overparameterized RNNs may organize memory differently.

The official distribution is unusually sparse, bounded, and support-structured. The demonstrated tanh advantage does not transfer to Gaussian or fixed low-rank dense distributions at matched covariance. Conclusions about nonlinear multiplexing should therefore be stated conditionally on support geometry.

Several studies use different losses—valid-position MSE, normalized MSE, event-weighted MSE, or pulse-weighted objectives—to expose different mechanisms. These experiments are individually controlled, but their absolute scores are not interchangeable. Pulse-weighted geometry, for example, emphasizes active events and may select a different optimum from ordinary average MSE.

Some architectural interventions use auxiliary hidden sizes, nonlinear readouts, straight-through estimators, or custom constraints. They are causal probes of mechanisms, not direct replacements for the primary (h\le3) Elman comparison.

The exact multiplicity of linear solution families remains unresolved because it depends on clustering rules and rare small groups. A second type of mode-connectivity barrier has been measured but not explained. The detailed local geometry of high-curvature tanh solutions—especially the alignment of their Jacobian-defined write and read subspaces—has not yet been mapped as completely as the linear case.

The relationship between raw supra-unit recurrence and nonlinear optimization also remains partly open. Some gain is clearly load-bearing under clamping interventions, some disappears with better leakage control, and some is predicted even by finite-horizon linear theory. These are distinct causes that future work should separate with matched horizon, timing, architecture, and effective-Jacobian measurements.

## 15. Conclusion

Small (k)-delay RNNs learn a surprisingly orderly set of solutions. Their behavior is not best described by one attractor, one spectrum, or one nonlinear trick. It is governed by the interaction of four constraints.

The first is spatial: five-dimensional signals must pass through at most three hidden coordinates, fixing an exact linear variance ceiling and forcing rank-depleted active routes. The second is temporal: recurrence powers are coupled by finite-dimensional realization theory. Near delays can use nilpotent finite shift registers; once recurrence power reaches the hidden-state budget, the optimal linear system must oscillate and accept leakage. The third is distributional: nonlinear curvature becomes useful only when input support hops among branches that a fixed low-rank projection cannot jointly preserve. The fourth is algorithmic: training selects among discrete gauge-inequivalent families and between linear-like, curve-threading, saturated, oscillatory, and magnitude-hiding basins.

These constraints explain the major empirical regularities. Linear zero-delay models hit (h/5) variance explained. Short-delay networks compress into nearly orthogonal write and read directions. At the boundary (p=h), complex poles and two-dimensional trajectory geometry appear together. Tanh can turn a rank-one temporal coordinate into a multi-directional readout curve, but only on appropriate support geometry and only when optimization engages curvature. Long-delay models recirculate signals and confront a trade-off between gain-driven separation and stable but interfering memory. Extra dimensions may remain geometrically quiet while serving as essential ambient scaffolding.

The most important scientific conclusion is therefore a phase-diagram answer to the task’s central question. **Reproducible learned structure emerges at the level of invariants and regimes, not at the level of one canonical set of weights.** Rank determines the amount of information that can pass; recurrence power determines the form of temporal transport; support geometry determines whether nonlinearity can bypass linear compression; and optimization determines which family is realized. This integrated account explains both successful solutions and their characteristic failures, and it turns a toy delay problem into a precise laboratory for how recurrent networks allocate scarce state across space, time, and nonlinear geometry.

## Evidence base

The synthesis draws on the complete supplied research record, with particular reliance on the following full papers and milestone syntheses. Titles are given so that the evidence trail remains readable to an external researcher without exposing internal filing handles:

- *Two Bottlenecks and a Nilpotent Ladder: How the Linear Reduced-Order Optimum Predicts Where Nonlinearity Helps Small k-Delay RNNs*.
- *Readout Timing Re-Indexes the Nilpotent Ladder in Small k-Delay RNNs*.
- *The tanh Delay Rescue Is Not One Mechanism: A Cell-Resolved Causal and Dynamical Map in Tiny k-Delay RNNs*.
- *Rank Quantization and Regime-Dependent Determinacy in Linear k-Delay RNNs*.
- *The Causal Necessity of Supra-Unit Recurrence: Why Stable Unitary Rotations Fail at High Delays*.
- *Supra-Unit Is Not Rotation: A Real-Spectrum tanh Recurrence Beats the Linear Delay Ceiling in Tiny RNNs*.
- *Orientation Determinacy in Linear k-Delay RNNs Is Reproducible up to a Discrete Set of Solution Families*.
- *Magnitude-Based Signal Hiding: How Architectural Timing Redefines the Capacity Limit of Minimal RNNs*.
- *The Discrete Solution Families of Linear k-Delay RNNs Are Disconnected Minima Separated by a Rank Ridge*.
- *Non-Linear Curve Threading: The Topological Bypass of the Rank-1 Temporal Bottleneck*.
- *The Rank Bottleneck Has Three Faces: A Consolidated Account of Reproducible Structure in Small Linear k-Delay RNNs*.
- *The Rotation-Free k-Delay Advantage Is Load-Bearing Nonlinearity, Not a Linearizable Route*.
- *The Trade-Offs of Continuous Delay: A Tenured Synthesis*.
- *Input Support Structure Gates the Nonlinear Advantage in Small k-Delay RNNs*.
- *The Recurrence Operator Must Oscillate: A Realization-Theoretic Eigenvalue Initialization for Small Linear k-Delay RNNs*.
- *The Topological Limits of 1D Curve Threading in Small k-Delay Tanh Networks*.
- *The Nonlinear k-Delay Advantage Requires Support-Coordinate Hopping, Not Low Intrinsic Dimension*.
- *Why Small Delay Networks Must Oscillate: A Tenured Synthesis of the Linear Realization Program and Its Boundary*.
- *Transient Topological Corridors: The Role of Extraneous Dimensions in Small Continuous RNNs*.
- *Curvature Engagement and a Hidden-Size-Gated Spatial Advantage: The Structure of the Nonlinear k-Delay Advantage across the Official Delay Curve*.
- *Computing the Optimal Recurrence Spectrum before Training: A Variable-Projection Pole Oracle for Small Linear k-Delay RNNs*.
- *Spectral Geometry of the Rank-Interference Compromise and Linear Collapse in Small k-Delay RNNs*.
- *The Algebraic Boundaries of Continuous Delay: Orthogonal Subspaces and Convex State Damping*.
- *Ambient Scaffolding vs. Intrinsic Dimensionality: Falsifying Universal State-Space Inflation*.
