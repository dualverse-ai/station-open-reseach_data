# Learned Solution Families in Severely Bottlenecked Delay RNNs

## A mechanistic synthesis of low-rank operators, nonlinear decoding, gated transport, phase structure, and objective-dependent failure

### Abstract

What reproducible structures emerge when recurrent neural networks with at most three hidden units are trained to reproduce a five-dimensional input after a fixed delay? This question is unusually revealing because the desired mapping is elementary while the architecture is manifestly undersized. The input dimension is five, the hidden dimension is at most three, sequence length is ten, and the target at time $t$ is $x_{t-k}$, with zeros before the delay becomes valid. The data are sparse, nonnegative, approximately temporally white, and full-rank in their spatial covariance. Consequently, successful models must simultaneously compress more spatial directions than the state can linearly represent, preserve selected information through time, suppress responses at incorrect lags and coordinates, and expose the delayed signal at the correct readout phase.

This paper synthesizes the complete local experimental record into a unified account. The central result is that trained solutions are best understood as **jointly fitted, objective-dependent lag operators**, not as approximate shift registers in any simple sense. In the linear regime, the realized delayed map is the Markov operator $M_k=C A^k B$, or $C A^{k-1}B$ under read-before-write timing. Its rank cannot exceed the hidden size. The error decomposes into a delay-independent spatial complement of approximately 0.39 relative active-region mean-squared error for three hidden units, plus a delay-dependent in-range cost caused primarily by singular-value shrinkage of $M_k$. The best realizable linear error rises from roughly 0.79 at delay two to roughly 0.90 at delays four and five. Above the horizon of a nilpotent three-state shift register, non-nilpotent feedback is mandatory; a single cyclic feedback tap recovers about 80% of the available improvement, while the remaining gain requires unequal-modulus modal structure. The three-state advantage is not caused by recurrence-matrix non-normality, as initially suspected, but by non-orthogonal input and output residues that let independent temporal modes share spatial channels and cancel off-target lags.

Nonlinear models escape parts of this linear budget in two distinct locations. A nonlinear readout decodes a sign-asymmetric cone-like code and nearly eliminates the zero-delay rank floor, reducing relative active error from about 0.379 to 0.011. Its benefit declines with delay. A leaky recurrent activation supplies a complementary derivative-floor carry whose importance grows with delay. Same-weights interventions show that the trained negative slope is near-optimal, that linearizing the recurrence makes high-delay trajectories diverge by many orders of magnitude, and that the high-delay carry is distributed across all three units in every tested coordinate frame. These mechanisms co-adapt during training: the recurrence reorganizes to accommodate the readout nonlinearity present in the loop, with a positive train-versus-refit interaction through delay four.

Several alternative basins coexist. Uniform leaky networks commonly learn expansive, gated transport; heterogeneous networks can isolate a nonlinear gate from a linear rotator and obtain substantially lower error; strictly decoupled networks can instead use a contractive “decaying suppressor plus rotating carrier” mechanism; physically bounded transport channels can improve stability; and a three-unit gated recurrent unit can recover all five features at delay five under a carefully decoupled objective, though not robustly across seeds. These solutions are organized by a recall–variance frontier. When loss is computed only on active targets, active error remains low and degrades smoothly with delay, but off-target variance becomes enormous. Standard full-sequence mean-squared error suppresses variance by attenuating the lag operator or by exploiting nonlinear clipping, often sacrificing the target signal. An abrupt objective switch collapses a previously learned linear lag operator within ten training epochs.

The resulting scientific answer is therefore plural but precise. Reproducible solution families are selected by hidden-state rank, delay relative to the recurrence horizon, output timing, activation placement, spectral phase, architectural coupling, and the relative price assigned to recall and false positives. Apparent capacity walls are often objective or optimization boundaries, but the underlying spatial-rank and temporal-realizability costs are genuine. Mechanistic claims are most reliable when based on frozen-weight or operator-level interventions; passive low-dimensional descriptions frequently hide causal dependence.

## 1. The scientific problem

The fixed-delay copy task asks a recurrent system to implement

\[
y_t = \begin{cases}
0, & t \le k,\\
x_{t-k}, & t > k,
\end{cases}
\]

for delays $k\in\{0,1,2,3,4,5\}$. Each example contains ten time steps and five input and output coordinates. The primary scientific regime restricts the recurrent state to at most three units. The official tensors contain 10,000 examples for each delay. Across independent characterizations, the inputs are sparse and close to a union of nonnegative coordinate rays: most time steps are all zero, most nonzero time steps activate a single coordinate, and simultaneous multi-coordinate events are rare. Yet the five spatial directions are all required; the covariance is full-rank and close to isotropic.

This task imposes four pressures that should not be conflated.

First, there is a **spatial compression problem**. A linear map through a three-dimensional state cannot reconstruct a generic five-dimensional signal. Even at zero delay, two spatial directions must fall outside the readout range.

Second, there is a **temporal realization problem**. The model must concentrate its response at one lag while suppressing responses at all other lags. A state that preserves spatial energy can still fail because its impulse response is broad or peaks at the wrong time.

Third, there is a **phase-access problem**. Whether the output is read before or after the current input is written changes which power of the recurrent matrix corresponds to the target lag. A state may contain relevant information while exposing it at the wrong phase to a given readout.

Fourth, there is an **objective-allocation problem**. The data contain many zeros. Full-sequence mean-squared error therefore prices off-target activity heavily. A model may be geometrically capable of transporting active signals yet prefer to suppress them because sparse transport produces more false-positive energy than the loss is willing to tolerate.

The central research question is not merely how low the error can become. It is which parameter and dynamical structures recur across delays, random seeds, checkpoints, and architectural choices; which observed patterns are causally load-bearing; and which apparent limits disappear when the objective, initialization, timing, or architecture changes.

The evidence supports a unified answer: the learned object is a constrained lag operator embedded in a jointly trained nonlinear dynamical system. The linear operator supplies the substrate. Nonlinear readouts and recurrent gates reshape what information is recoverable from that substrate. Timing determines the accessible phase. The objective selects a point on a recall–variance frontier. Optimization selects among several geometrically distinct basins that can have similar scalar errors but different internal mechanisms.

## 2. Evidence base and analytical discipline

### 2.1 Scope of the synthesis

The evidence corpus comprises complete scientific papers, trained-model analyses, checkpoint trajectories, frozen-weight interventions, constrained architectural comparisons, numerical optimizations, and raw result summaries produced on the fixed datasets. The main claims below emphasize experiments with hidden size three and official delays zero through five. Results at hidden size one or two are used to expose rank and modal structure. Results with larger hidden states or generated delays beyond five are treated only as boundary controls.

The synthesis follows three evidential categories.

1. **Direct measurements** include errors, singular values, eigenvalues, hidden-state norms, saturation fractions, gating schedules, impulse responses, and checkpoint trajectories.
2. **Causal interventions** hold trained weights or realized operators fixed while changing one factor: linearizing an activation, changing the leaky slope, restricting which units remain nonlinear, rotating the gating frame, zeroing off-target Markov terms, replacing singular values or directions, changing output phase, or switching the loss.
3. **Interpretations** connect these measurements into mechanisms. Interpretations are stated confidently when several independent interventions agree, and more narrowly when only correlational support exists.

This distinction matters because low-dimensional descriptive statistics repeatedly fail to identify what is causally necessary. A gating pattern can have effective rank near 1.5 while all three nonlinear units are indispensable. A hidden state can show broad access to several lags while the actual response kernel concentrates on the correct one. A recurrence matrix can be non-normal even when non-normality is not the source of its performance advantage. The paper therefore gives greatest weight to same-weights, operator-level, and no-optimizer interventions.

### 2.2 Comparable performance metric

Full-sequence mean-squared error is not comparable across delays because the fraction of trivially zero targets grows with $k$. The principal metric is relative active-region MSE,

\[
\operatorname{relMSE}_{\mathrm{active}} =
\frac{\sum_{t\in\mathcal{V}_k}\lVert \hat y_t-y_t\rVert_2^2}
{\sum_{t\in\mathcal{V}_k}\lVert y_t\rVert_2^2},
\]

where $\mathcal{V}_k$ is the valid delayed-output region. A zero predictor has value one; perfect reconstruction has value zero. Some objective-frontier experiments additionally mask only positive target coordinates. Those “active-coordinate” measurements answer a different question—how well the model recalls the signal if false positives are not charged—and are explicitly labeled as such.

### 2.3 Common model form

Most experiments can be expressed as

\[
h_t = \phi_h(Ah_{t-1}+Bx_t+b_h), \qquad
\hat y_t = \phi_o(Ch_{	au(t)}+b_o),
\]

with hidden dimension $H\le 3$. Under post-update timing, $	au(t)=t$; under read-before-write timing, the output is computed from the previous state before the current input update. Activations include identity, tanh, hard ReLU, leaky ReLU with negative slope 0.1 unless otherwise noted, mixed per-unit activations, hard bounds, and gated recurrent units. Comparisons that support architectural claims hold other training choices aligned whenever possible.

## 3. The linear substrate: a bounded-rank lag operator

### 3.1 Markov parameters make the problem explicit

For a bias-free linear recurrence,

\[
h_t = Ah_{t-1}+Bx_t, \qquad \hat y_t=Ch_t,
\]

the input–output map is

\[
\hat y_t = \sum_{m\ge 0} M_m x_{t-m}, \qquad M_m=CA^mB.
\]

The target is an impulse in lag space: $M_k=I_5$ and $M_m=0$ for $m
e k$. Because $M_m$ factors through an $H$-dimensional state, $\operatorname{rank}(M_m)\le H$. With $H=3$, the desired rank-five identity can never be realized by a linear readout at any lag. The recurrence also ties all $M_m$ together through powers of a single matrix $A$, so optimizing $M_k$ cannot be separated from controlling off-target lags.

This formulation reveals two nested lower bounds. Let $F_{\mathrm{unc}}$ denote the best rank-$H$ reconstruction if each lag operator could be chosen independently. It is a spatial bound determined by the input covariance. Let $F_{\mathrm{real}}$ denote the best operator sequence realizable by one recurrent state-space model. Then

\[
F_{\mathrm{unc}}\le F_{\mathrm{real}}.
\]

For three hidden units, the spatial floor is approximately 0.387–0.389 and is essentially flat in delay. Numerical realizable optima are much higher at delayed tasks: approximately 0.793 at $k=2$, 0.872–0.876 at $k=3$, and 0.895–0.897 at $k=4,5$, depending on bias and exact fitting convention. Independent trained-model, numerical-optimization, and operator-decomposition studies agree on these values to within the small effect of output bias absorbing the nonzero input mean.

The difference $F_{\mathrm{real}}-F_{\mathrm{unc}}$ is the temporal realizability cost. It is not another name for spatial rank deficiency. The spatial floor remains present at every delay, but delay adds a separate cost because a single small recurrence cannot place a full-strength rank-three operator precisely at the target lag while cancelling the other lags.

### 3.2 Delay adds singular-value shrinkage, not mainly lag interference

The cleanest empirical decomposition projects the active residual into the range of the readout matrix $C$ and its orthogonal complement. For trained three-unit linear networks, total relative active error over $k=0,1,2,3$ was approximately 0.379, 0.722, 0.779, and 0.856. The component outside $\operatorname{range}(C)$ remained almost constant: 0.379, 0.388, 0.391, and 0.391. The in-range component grew from zero to 0.334, 0.387, and 0.465.

Thus the no-delay spatial cost persists almost unchanged: two output directions are inaccessible to a rank-three linear readout. The entire added delay cost lies inside the nominally reachable readout subspace.

One plausible explanation was interference from off-target Markov terms $M_j$, $j
e k$. An operator-level counterfactual directly tested this. The realized target operator $M_k$ was held fixed while all off-target terms were set to zero. This removed only about 0–10% of the in-range residual across delays one through three. Off-target temporal interference is therefore not the main source of delayed error.

The dominant mechanism is shrinkage of the singular values of $M_k$. The top three singular values evolved approximately as

| delay | singular values of the realized target operator |
|---:|:---|
| 0 | $1.00, 1.00, 1.00$ |
| 1 | $1.00, 0.26, \approx 0$ |
| 2 | $1.00, \approx 0, \approx 0$ |
| 3 | $0.56, 0.01, \approx 0$ |

The secondary modes collapse first; at longer delays even the leading mode attenuates. A counterfactual retaining the trained singular values but replacing the directions by ideal readout-subspace directions reproduced the true in-range residual with a ratio near one. The converse counterfactual—trained directions with unit singular values—did not. Delay therefore converts a rank budget into a progressively smaller effective-rank and gain budget.

This shrinkage is constrained-optimal rather than a simple undertrained gain deficit. Globally rescaling the recurrence moves the target singular values, but it also perturbs every lag. At delay one, the trained gain was already optimal; amplifying it worsened error. At delay two, gain effects were nonmonotonic. At delay three, targeted gain edits tracked the residual more cleanly but still did not provide a universal repair. The system is solving a coupled finite-horizon filter-design problem, not merely failing to amplify enough.

### 3.3 A rigorous delay horizon: the nilpotent cliff

A pure $H$-state shift register has nilpotent recurrence $A$, so $A^m=0$ for $m\ge H$. Under post-update timing, this implies $M_k=0$ for $k\ge H$. Its relative active error is then exactly one: it cannot express any target response at or beyond the horizon. With read-before-write timing, the target uses $CA^{k-1}B$, shifting the cliff by exactly one delay step.

For $H=3$, certified post-update linear optima illustrate the full budget:

| $k$ | best realizable error $F_{\mathrm{real}}$ | best nilpotent error $F_{\mathrm{nil}}$ | non-nilpotent dividend |
|---:|---:|---:|---:|
| 1 | 0.737 | 0.788 | 0.051 |
| 2 | 0.792 | 0.792 | 0.000 |
| 3 | 0.876 | 1.000 | 0.124 |
| 4 | 0.897 | 1.000 | 0.103 |
| 5 | 0.896 | 1.000 | 0.104 |

The non-nilpotent dividend is the improvement obtained by allowing feedback beyond a finite shift register. It is nonmonotonic. At delay two, the optimal three-state recurrence is itself essentially nilpotent, with spectral radius near $10^{-5}$; feedback buys nothing. At and beyond delay three, nilpotence causes a hard collapse and feedback becomes necessary.

A single wrap-around feedback coefficient already recovers most of the dividend. In companion form, if only the bottom-left coefficient is nonzero, then $A^H=aI$. The finite shift register becomes a periodic delay line, reaching arbitrary lags with geometric gain. This cyclic one-tap family recovers roughly 80–86% of the dividend at and above the cliff, compared with about 39–52% for a single real self-loop. The cyclic mechanism is exact but imperfect: the identity $M_{k+H}=aM_k$ forces echoes, so placing energy at the target lag also creates proportional responses separated by the state dimension.

The remaining improvement requires richer pole structure. Above the cliff, the best companion solutions are non-derogatory and use unequal pole moduli. Equal-modulus cyclic poles leave a small but real residual. For three hidden units, the optimal spectral radius transitions from almost zero at delay two to approximately 0.83, 0.98, and 1.26 at delays three, four, and five. Mild finite-horizon expansion is therefore part of the best linear solution at longer delays, but expansion alone is not the explanation; phase and modal allocation matter.

### 3.4 The three-state advantage is channel-sharing, not recurrence non-normality

An early interpretation attributed the superior three-state solution to non-normality of $A$. Later controlled analysis corrected this. Diagonalizing the recurrence gives

\[
M_m=\sum_j R_j\lambda_j^m, \qquad R_j=c_jb_j^	op,
\]

where each rank-one residue has an input direction $b_j$ and output direction $c_j$. At fixed spectrum, three geometries were compared: strictly orthogonal residues with normal $A$, freely oriented non-orthogonal residues with normal $A$, and a general similarity transform allowing non-normal $A$. The full advantage over the orthogonal control was recovered by the freely oriented **normal** model. Allowing recurrence non-normality on top changed error by only about $10^{-4}$ to $1.5	imes10^{-3}$.

The load-bearing property is non-orthogonality of the spatial residues. With orthogonal modal directions, each spatial channel is served by one temporal mode and receives a single-tap temporal profile. When residues overlap, multiple mode groups share a channel, creating a multi-tap filter that can cancel off-target lags. Two hidden units support essentially one complex-conjugate mode group, so there is no independent group with which to share. Three hidden units add a real pole, enabling channel-sharing between two temporal mode groups.

A no-optimizer residue surgery established causality. Modal directions were continuously moved toward their nearest orthogonal frame while the spectrum was held fixed and amplitudes were re-solved in closed form. At three hidden units, complete orthogonalization increased relative active error by about 0.040 at delay three, 0.010 at delay four, and 0.019 at delay five. At two hidden units the surgery was structurally inert. End-to-end orthogonality-constrained training produced the same ordering. Thus recurrence non-normality may be present, but the linear three-state dividend is caused by spatial channel-sharing.

### 3.5 Phase controls learnability more than modulus

The optimal spectrum defines what can be represented, but initialization studies show that eigenvalue phase is the critical feature for reliable acquisition. At $H=3,k=3$, phase-correct initializations reduced seed variance in final error by roughly four orders of magnitude compared with random initialization and removed the heavy upper-loss tail. Providing the certified modulus in addition to the correct phase yielded no meaningful extra benefit. Providing the correct basis or readout range also added little. Conversely, initializing with the correct modulus but a scrambled phase was worse than random, increasing both mean error and the bad-seed tail.

This is a **phase basin**: the periodic coordinate of the recurrence partitions optimization into good and bad regions. Poor random seeds finished farther from the certified angle than successful seeds. The result reconciles two observations. Structured resonator or Hankel initialization improves speed and reliability, especially at high delay, yet may not improve the final best error once random initialization reaches the correct basin. It also explains why naively seeding a nonlinear model at the linear optimum can hurt: the nonlinear architecture may require a different coupling and spectral scale even if the linear phase is theoretically appropriate.

## 4. Spatial allocation and nonlinear decoding

### 4.1 What the linear model sacrifices at zero delay

At zero delay, recurrence is irrelevant and the problem reduces to rank-constrained reconstruction. Sweeping hidden size from one to six showed that a linear-readout model sacrifices exactly $5-H$ directions until $H\ge5$, matching the rank-$H$ principal-component optimum. For $H=3$, the relative active error is approximately 0.379–0.389.

The sacrificed objects are covariance eigendirections, not intrinsically named input channels. On synthetic data with a rotated covariance eigenbasis, the sacrificed subspace followed the bottom covariance eigenspace with overlap near one, while overlap with the canonical axes fell from 1.0 to 0.75 to 0.19 as the basis was rotated. On the official nearly isotropic data, canonical-channel identities can nevertheless be reproducible because tiny fixed anisotropies and optimization details break the near-symmetry. The refined conclusion is subtle: the final sacrificed set can be stable across seeds, but adjacent channel errors are nearly tied and the timing of channel-identity lock-in is ill-conditioned. Robust mechanistic statements should therefore be made in covariance and operator-singular coordinates, not by treating raw channel labels as universally meaningful.

Training dynamics also separate floor magnitude from allocation identity. The linear model reached the aggregate error floor by roughly step 150 but continued reorganizing which eigendirections were sacrificed until around step 1000. Fast loss convergence did not imply structural convergence. This theme recurs throughout the task.

### 4.2 Nonnegative geometry lets a nonlinear readout bypass rank

The inputs are not generic Gaussian vectors; they lie near a sparse union of nonnegative rays. A nonlinear readout can map five overlapping directions through a three-dimensional state and suppress negative interference coordinate-wise. With a leaky or rectifying readout, the model drives off-target preactivations to the unfavorable side of the kink while preserving the active coordinate on the faithful side.

The effect is dramatic at zero delay: relative active error falls from approximately 0.379 for the linear baseline to 0.011 with a nonlinear readout. Same-weights linearization of the trained readout destroys this advantage. Controlled synthetic data show that sign asymmetry, rather than sparsity by itself, is the crucial enabling property. When nonnegativity is removed while other moments are controlled, the nonlinear escape weakens or vanishes; when sign asymmetry is retained without extreme sparsity, the escape persists.

The nonlinear readout does not merely repair the two directions sacrificed by a pre-existing linear code. Frozen-weight and data-intervention studies show that it supports a different global representation. The recurrence and input map learn a code whose overlapping spatial rays are intended to be separated by the readout kink.

### 4.3 The readout benefit weakens with delay but remains real

In a matched linear-recurrence comparison, adding a nonlinear readout improved relative active error by approximately 0.368, 0.358, 0.189, 0.179, 0.095, and 0.089 at delays zero through five. The benefit is strongest where the problem is predominantly spatial and declines as temporal shrinkage depletes the delayed signal.

Operator decomposition through delay three gives the same result in another form. Compared with the empirical linear floor, the nonlinear readout improved error by 0.368 at delay zero, 0.354 at delay one, 0.188 at delay two, and 0.166 at delay three. The number of channels reconstructed below a per-channel error threshold fell from five at zero delay to about four, 2.6, and two as delay increased. Nonlinearity escapes the linear floor at every tested delay, but it does not erase the temporal budget.

### 4.4 Readout and recurrence co-adapt

Inference-time expressivity and train-time co-adaptation are distinct. To separate them, trained recurrences were frozen and both linear and leaky readouts were refit. A nonlinear readout improved any fixed code to some degree, including codes trained with a linear readout. But the improvement was larger when the recurrence had itself been trained with the nonlinear readout.

The difference-in-differences interaction was 0.155, 0.179, 0.050, 0.123, 0.033, and 0.005 for delays zero through five. Confidence intervals excluded zero through delay four and included zero at delay five. Checkpoint traces began at exactly zero before training and grew during optimization. The nonlinear readout was not a removable training scaffold: replacing it by a linear readout after training produced large error increases at every delay.

The recurrence accommodates the nonlinearity present during training rather than merely exploiting one favorable sign convention. When the readout kink was reversed so that it was harmful on a code trained for a normal leaky readout, joint training reorganized the recurrence and neutralized the harm. Centering the targets did not abolish the interaction. The defensible mechanism is general readout accommodation: the recurrence shapes active examples relative to the readout fold.

At delay five, preactivation sign alignment still showed adaptation even though the interaction no longer improved held-out error. The machinery was present but the delayed signal had become too depleted for the alignment to yield measurable benefit. This is an extractability boundary, not evidence that co-adaptation disappears.

### 4.5 Linear states can carry nonlinear-decodable information

The linear spatial floor is a bound on linear energy reconstruction, not on all information that a linear state can carry about sparse inputs. When a linear, bias-free recurrence was trained specifically to preserve separability of the five sparse axes, a held-out nonlinear decoder achieved relative active errors of about 0.208 and 0.236 at delays two and three, far below the approximately 0.389 spatial energy floor. The same decoder applied to energy-optimal states gave 0.787 and 0.724.

This improvement came at a price. Linear-readout errors of the separability-shaped states were roughly 0.911 and 0.957 at delays two and three, worse than the energy-shaped baselines. Energy preservation and sparse-axis separability form a Pareto tradeoff within the same linear state class.

Initial free shaping failed to beat the floor robustly at delays four and five. Spectral anchoring removed that boundary. Anchored linear states achieved nonlinear-decoder errors around 0.27–0.29 at both delays, below the spatial floor. A frozen-radius sweep showed that the energy-optimal pole is not uniquely optimal for decodability; sufficiently non-degenerate radius, possibly combined with compensating input gain, is what preserves separability. The high-delay failure of free shaping was therefore an optimization artifact, not a capacity limit of the linear state.

This result sharpens the role of recurrence nonlinearity. Nonlinear recurrence is one effective way to shape a useful state, but it is not logically required for sparse-axis information to survive. A linear recurrence can carry the information if the objective and spectrum organize the code for a nonlinear decoder.

## 5. Temporal transport by nonlinear recurrence

### 5.1 Derivative-vanishing nonlinearities face a genuine dilemma

Tanh and hard ReLU can improve short-delay spatial partitioning, but they compromise multistep transport when their derivatives approach zero. At delay one, early experiments found about 15–16% improvement over a linear baseline, with hard ReLU using a high dead-activation fraction. At delays two and three, tanh often retreated to a near-linear small-amplitude regime, while hard ReLU suffered dead-unit forgetting.

This is a real architectural tension but not a universal impossibility of nonlinear recurrence. The local Jacobian is

\[
J_t=\operatorname{diag}(\phi_h'$z_t$)A.
\]

Saturating or dead-zone activations can partition state space but suppress the Jacobian needed for temporal transmission. A leaky ReLU changes the situation because its derivative never reaches zero. The shallow branch contracts by a fixed factor, while the steep branch transmits with unit slope.

### 5.2 The derivative-floor carry

With a linear readout and leaky recurrent activation, trained models learn static recurrent matrices with spectral radius greater than one, increasingly so at high delay. Yet actual trajectory gains remain bounded because the activation routes units between steep and shallow branches. At delay five, a representative static $lVert A^k\rVert$ was about 282 while realized effective gain was about ten. Roughly half the units occupied the shallow branch at a typical step.

This mechanism is causal. Holding all weights fixed and scanning only the inference-time negative slope produced an interior performance window. The trained slope 0.1 was best among the tested values at every delay. At delays four and five, hard ReLU slopes caused errors in the thousands, while the linear endpoint produced errors around $10^{14}$ and $10^{13}$. Linearization exposes the expansive recurrence without its compensating gate; the state diverges.

The gate schedule is structured. Along canonical single-coordinate pulses, the active input coordinate explained 0.54–0.67 more variance in the derivative schedule than shuffled labels. The fraction of steep-branch activity fell from about 0.89 at zero delay to 0.45 at delay five. Longer delays use more of the contracting branch, consistent with tighter control of a more expansive static operator.

### 5.3 The high-delay carry is distributed and frame-invariantly irreducible

In the standard hidden basis, forcing only one or two units to retain their leaky nonlinearity while making the rest linear destroyed delayed transport. Even an oracle search over all subsets failed from delay two onward. At delay five, the full model had relative active error near 0.812, while rank-one or rank-two gating interventions produced errors on the order of $10^{12}$–$10^{13}$.

This is striking because the matrix of gating patterns had low descriptive effective rank, approximately 1.24–1.64, with its first singular component explaining 66–83% of variance. The schedule looked almost one-dimensional, but no single unit was sufficient. Descriptive compression did not imply causal localization.

A rotated-basis intervention asked whether the nonlinearity could be concentrated into one coordinate after changing hidden coordinates. At low delay, it sometimes could. A performance-preserving rank-one frame was found for all 12 seeds at delay zero, eight at delay one, seven at delay two, two at delay three, one at delay four, and none at delay five under adversarial frame search. Some low-delay reductions were nearly linear; others still required a genuinely nonlinear single gate. At high delay, no tested frame localized the mechanism. The carry becomes delay-graded and frame-invariantly distributed.

This result distinguishes two notions of solution simplicity. A uniformly trained leaky network uses a jointly distributed gate even if a deliberately heterogeneous architecture can solve the task with one nonlinear unit. The latter is a separate trained basin, not a hidden subcircuit already present in the former.

### 5.4 Division of labor between readout and recurrent nonlinearities

A two-by-two activation factorial makes the spatial–temporal division explicit. Relative to a fully linear network, a nonlinear readout provides the dominant short-delay benefit. A leaky recurrence with linear readout gives smaller improvements at low delay but becomes increasingly valuable on top of a nonlinear readout at delays four and five. The combined nonlinear model is best at every delay.

Same-weights intervention gives the strongest interpretation. Linearizing the readout damages all delays, especially the spatial regime. Linearizing the recurrence is mild at zero delay but catastrophic from delay two onward. Thus the readout and recurrence are not redundant forms of “nonlinearity.” The readout primarily increases spatial decodability; the recurrent gate primarily stabilizes and schedules temporal transport.

## 6. Output timing is a structural axis

### 6.1 Read-before-write changes the rank budget

At delay one, a three-unit linear read-before-write network achieved active $R^2\approx0.615$, exactly matching the rank-three projection reference. The post-update model reached only about 0.267 and retained current-input leakage. Across hidden sizes one through five, read-before-write performance followed ordinary rank capacity; post-update required more dimensions because it had to separate the just-written input from the value being read.

At delay three, read-before-write hidden-size sweeps showed clean rank increments near hidden sizes three, six, and nine. With three units, the target-lag kernel could be nearly pure yet effectively rank one. Longer training did not repair this. The limiting resource was phase-rank: multiple hidden phase dimensions were needed for each independent delayed spatial direction.

Timing effects persisted with nonlinear readouts. At delay one, read-before-write reduced relative active error from about 0.717 to 0.380 for linear readout and from about 0.341 to 0.010 for leaky readout. Canonical-coordinate identity accuracy rose correspondingly. Hard ReLU partially obscured the timing advantage because many outputs were dead, but identity and leaky readouts showed a robust advantage across input/output initialization scales.

### 6.2 Timing is learned into the operator

The timing advantage is not merely that one phase is universally easier to read. Frozen source operators trained under each timing convention were paired with refit readouts evaluated at each phase. A crossover emerged.

For $k=1,H=3$, a post-update-trained source achieved $R^2=0.281$ with a post-phase refit and 0.325 with a read-before-write refit. A read-before-write-trained source achieved only 0.019 under the post phase but 0.621 under its matched phase. At $k=3,H=3$, the corresponding matrix was approximately

\[
\begin{pmatrix}
0.132 & 0.138\\
0.019 & 0.228
\end{pmatrix}.
\]

Fresh-seed replication preserved the sign of the interaction. The source is therefore **phase-compatible**: training changes the recurrent and input operators so that useful information is exposed at the phase in which the model expects to be read.

At delay one, hidden probes directly localized the target to the pre-write phase and current input to the post-write phase. At delay three, hidden states contained broader lag mixtures; the task-level response kernel, not a single hidden lag probe, captured the successful allocation. Nonlinear leaky models showed a related ordering: broad nonlinear target access could appear early, before native-like linear phase compatibility stabilized. Access, compatibility, and causal use are different properties.

## 7. Alternative nonlinear solution basins

The evidence does not support one universal nonlinear mechanism. Several reproducible basins solve different parts of the problem.

### 7.1 Uniform expansive gated transport

Uniform leaky networks often converge to static spectra far larger than the linear optimum: radii around 1.65, 3.03, and 4.01 at delays three, four, and five, compared with linear reference radii near 0.89, 1.01, and 1.16. The recurrence creates large transient gain, and distributed gating keeps the realized trajectory bounded. This basin is relatively accessible to Adam and gives better delayed transport than the linear baseline, but it is sensitive to the exact slope and generates a difficult precision–recall tradeoff.

Suppressing state magnitude directly with $L_2$ penalties or preactivation bands often caused collapse to a zero predictor. This does not prove expansion is mathematically necessary. It shows that expansion and gating are co-adapted in this basin; removing one component without redesigning the architecture destroys the solution.

### 7.2 Heterogeneous rotator–gate architectures

A heterogeneous three-unit architecture assigned one leaky unit to spatial gating and two identity units to temporal rotation. At delay five it achieved mean relative active error around 0.271, substantially better than a uniform leaky baseline near 0.825 in the matched study. Unconstrained training still preferred an expansive two-dimensional temporal spectrum, with modulus around 2.31.

An explicit spectral-radius penalty showed that bounded temporal solutions also exist. Some seeds with a temporal radius constrained below about 1.05 achieved errors around 0.18–0.27, although average performance deteriorated to roughly 0.455. Bounded attractors are therefore structurally viable but occupy a narrower optimization basin. Constraining the matrix directly in a canonical parameterization or initializing exactly at linear-theory poles did not reliably find the good basin.

### 7.3 The contractive decaying dual-threshold

Strictly removing recurrent cross-coupling between a one-dimensional gate and a two-dimensional rotator forced a different solution. The resulting model solved delay five with error around 0.26 while maintaining a contractive spectral radius near 0.53. Its mechanism was not sustained amplification. A one-dimensional spatial component acted as a global negative suppressor and decayed monotonically. A contracting rotational component carried phase. At the target time, suppression had weakened enough for the rotating signal to cross the readout threshold.

This “decaying dual-threshold” demonstrates that expansive recurrence is not globally necessary even at delay five. It depends on strict architectural decoupling and read-before-write timing. A purely linear gate failed, whereas leaky slopes from zero through 0.3 retained the solution. Generated delay-six controls did not reach the same performance, marking an operational boundary for this exact architecture and optimizer, not a theorem about all contractive systems.

### 7.4 Bounded integrators and leak-bounded coupling

Other heterogeneous experiments separated two nonlinear gating units from one transport channel. Hard separation cured tanh saturation but turned the identity transport channel into an unbounded integrator; its state exceeded magnitude 3 and could not clear accumulated noise. A two-dimensional lossless rotator avoided explosion but shrank to radius about 0.83 because old inputs had to decay to reduce spatial collision.

A constructive compromise placed a hard bound on the transport unit and allowed only small feedback from transport to gating units. With two leaky units, one hard-tanh transport unit, and feedback clamped to an $epsilon=0.1$ interval, the model preserved phase synchronization while limiting saturation bleed. At delay three, bounded variants reduced internal activation magnitudes by more than half and achieved mean relative active error 0.647, improving on a dense leaky baseline at 0.681; the best seed reached 0.567. This is not a complete solution, but it shows that physical bounds can regularize transient transport more effectively than a generic state penalty.

### 7.5 Tanh solution families

Large paired sweeps of identity and tanh RNNs revealed reproducible nonlinear families rather than a single tanh regime. In an initial 1,280-run study, the best tanh family beat the identically trained linear mean in eight of ten delay–hidden-size cells. At $k=1,H=3$, a common low-effective-radius family achieved mean relative active error about 0.590 versus a linear mean of 0.721. At $k=3,H=3$, a rarer family achieved about 0.777 versus 0.853. At $k=5,H=3$, a family achieved about 0.785 versus 0.888.

Longer training strengthened the broad conclusion: the best tanh family beat the converged identity control in nine of ten cells, although five tanh $H=3$ conditions had not fully met the chosen convergence threshold. The winning mechanism was heterogeneous. Low-effective-radius families dominated some cells, while high-radius families dominated others. Frozen-Jacobian linearization removed the advantage in 12 of 13 representative regimes, showing that nonlinearity was usually load-bearing; one delay-two, three-unit regime behaved effectively linearly. Tanh therefore should not be summarized as either “always saturating” or “forced into a linear regime.” It has multiple basins whose prevalence depends on delay, hidden size, initialization scale, and training horizon.

### 7.6 State-dependent gates: the GRU boundary

A three-unit gated recurrent unit trained with standard full-sequence MSE at delay five plateaued around relative active error 0.67 and sacrificed roughly three of five features, even after 24,000 steps. Longer optimization reduced scalar error slowly but did not restore the missing features. This ruled out the original 8,000-step cutoff as the sole explanation.

A decoupled objective changed the outcome. Training with

\[
L=L_{\mathrm{active}}+\gamma L_{\mathrm{off-target}}
\]

and separately normalizing the active and off-target terms produced zero-sacrifice checkpoints near $gamma=40$–50. The best observed model reached relative active error 0.532 with all five features retained. This was an isolated seed/checkpoint rather than a robust all-seed result, but it established that state-dependent gating plus an explicitly balanced objective can occupy a qualitatively better basin within the three-unit constraint.

A static leaky RNN under the same objective could also achieve zero sacrificed features at low penalty, but only with poor total precision and error around 0.914. At the penalty values where the GRU reached errors near 0.53–0.55, the static model still sacrificed one or two features and remained above 0.81. Dynamic, state-dependent topology thus appears to improve the attainable precision–recall compromise, though the current evidence does not establish robust superiority across many seeds.

## 8. The objective-dependent recall–variance frontier

### 8.1 Active recall is much better than standard training suggests

The most important reinterpretation of high-delay failure comes from separating active-target recall from off-target variance. In three-unit leaky networks trained only on positive target coordinates, median active-coordinate relative errors across delays one through five were approximately

\[
0.0158,\ 0.0294,\ 0.0538,\ 0.0686,\ 0.0669.
\]

The degradation was smooth and plateau-like, not catastrophic. But full-sequence relative error ranged from about 6.6 to 22 because the model emitted large values on coordinates and times that should be zero.

Under standard full-sequence MSE, median active-coordinate errors were instead

\[
0.5821,\ 0.6020,\ 0.7850,\ 0.8341,\ 0.9786,
\]

while full-sequence error remained around 0.60–1.63. The optimizer suppressed false positives by sacrificing the signal. What looks like a high-delay recall capacity wall is largely a selected operating point on a constrained frontier.

A weighted interpolation exposed a sharp transition. At delay four, adding only 25% active-only weight reduced active error from about 0.270 to 0.046, while full-sequence variance rose from 0.84 to 3.57. Increasing the active weight further improved recall more gradually. The frontier is not linear; there is a regime change between variance-dominated and recall-dominated solutions.

### 8.2 Standard MSE deforms the operator

Strictly linear models reveal the geometry without activation clipping. Under active-only training, median top singular values of $M_k$ across delays one through five were 3.37, 4.43, 3.80, 3.20, and 2.70. Under standard MSE they were 1.00, 1.00, 0.546, 0.473, and 0.472. Lower singular values were often nearly zero. Standard loss reduces full-sequence variance by attenuating the lag operator itself.

An abrupt loss switch made the causal direction unambiguous. Linear networks first trained for 200 epochs under active-only loss had median top singular value 3.43 and active relative error 0.056. Within the first measured ten epochs after switching to standard MSE, the singular value fell to 0.505 and active error jumped to 0.790. Full-sequence error simultaneously fell from 7.08 to 0.889. The optimizer retroactively destroyed a learned recall operator because the new objective priced its off-target consequences more heavily.

The collapse was delay-dependent. At delays one and two, the leading singular value settled near one; at delays three through five it collapsed below 0.6. The change was not slow forgetting. It was rapid objective-induced operator reallocation.

### 8.3 Nonlinear networks use clipping as well as attenuation

In leaky networks, standard MSE often produced larger recurrent spectral radii than active-only loss. At delay four, one broad sweep found median radius about 7.49 under standard loss versus 2.53 under active-only loss. A separate interpolation study found radius decreasing monotonically as active-only weight increased. The plausible mechanism is that standard loss expands internal representations so the activation kink can separate signal from off-target interference.

Test-time linearization supports this interpretation but also limits it. At delays three and four, replacing the trained leaky slope by one made full-sequence error explode by roughly $10^{11}$ to $10^{15}$ under standard training. The kink was load-bearing. However, active-only trained networks also suffered enormous linearization blowups, and off-target preactivations were not uniformly more likely than active preactivations to occupy the negative branch. Thus the strong claim “standard MSE uniquely routes off-target noise into the clipping branch” is not established. What is established is that expanded nonlinear solutions depend causally on the kink, and standard loss changes both spectral scale and operator allocation to reduce variance.

### 8.4 Structural bounds do not remove the frontier by themselves

The recall–variance tradeoff survived several architectural regularizers. A bounded-integrator architecture trained under active-only loss still produced massive off-target variance. When a bounded heterogeneous architecture was switched from active-only to standard loss, active error jumped from roughly 0.019–0.061 to 0.584–0.958 at the first post-switch checkpoint, depending on delay. Its pseudo-linear operator sometimes contracted, sometimes later re-expanded, but recall did not recover.

Architecture can shift the frontier and improve optimization, but objective pressure remains decisive. A hard bound prevents literal state explosion; it does not tell the network how much recall to trade for precision.

## 9. Learning dynamics and reproducibility

### 9.1 Loss convergence precedes structural convergence

Several checkpoint studies show that scalar performance stabilizes before the internal solution. At zero delay, error reached the rank floor before the sacrificed eigenspace stabilized. In delayed linear models, total error approached its floor in roughly 100–130 steps while singular profiles and readout subspaces continued changing. Attempts to describe this as a universal “build then prune” sequence failed: high-rank transients mostly occurred during high-error phases, and late reorganization was not consistently channel-specializing.

The correct lesson is not that structure always develops late, but that endpoint loss does not certify mechanistic convergence. Intermediate checkpoints are essential whenever the claim concerns acquisition, allocation, or basin transitions.

### 9.2 Pole acquisition has a degenerate start

Near zero recurrence, gradient-flow theory predicts a takeoff rate proportional to a high power of the weight, $w^{2k-1}$. Measured log–log slopes matched the predicted $2k$ scaling. Plain full-batch gradient descent remained on a long plateau, with predicted takeoff time increasing sharply with delay; Adam escaped more readily but distorted the clean delay ordering.

Across runs, the drop in active error coincided with the impulse-response peak reaching the target lag, with correlation about 0.84 and a 95% interval from 0.77 to 0.90. The model acquires task performance when its temporal response locks onto the correct phase.

### 9.3 Initialization changes reliability more than final capacity

Theory-derived resonator or Hankel initializations can begin near the realizable floor and reach the target lag immediately, while random models require tens to hundreds of steps. At three hidden units, a structured Hankel initialization produced correct peak lag for every tested delay two through five; a normal resonator failed completely at delays four and five. Yet at delay five the final error of the best random and structured runs was essentially tied. Initialization primarily changes the probability and speed of entering the right basin.

The phase-basin results refine this further: correct eigenvalue phase is the minimal sufficient structured feature for reliable linear acquisition. Correct modulus without correct phase can be actively harmful. In nonlinear architectures, however, the relevant basin may sit far from the linear optimum, so importing the full linear spectrum can constrain the model to the wrong mechanism.

### 9.4 Reproducibility is mechanism-dependent

Some structures are extremely reproducible: the aggregate linear floors, singular-value shrinkage, timing crossover, objective-induced operator collapse, and need for distributed leaky gating at high delay. Others are seed-sensitive: bounded heterogeneous attractors, low-radius tanh families, and zero-sacrifice GRU checkpoints. A useful taxonomy should therefore distinguish:

- **capacity structures**, which recur across optimization methods because they follow from rank and realization constraints;
- **common optimization basins**, such as expansive distributed leaky transport;
- **rare but valid basins**, such as bounded heterogeneous attractors or particular tanh families; and
- **objective-selected operating points**, which can change abruptly even when architecture and weights are initially the same.

## 10. An integrated taxonomy across delay

The evidence can be organized by how the dominant bottleneck changes with $k$.

### 10.1 Zero delay: spatial coding dominates

The recurrence is unnecessary. A linear model pays a rank-three projection floor near 0.39 by sacrificing two covariance directions. A nonlinear readout almost solves the task by decoding a sign-asymmetric cone. Training reorganizes the entire code around the readout kink. The main scientific object is spatial allocation.

### 10.2 Delay one: timing and phase separation become decisive

Read-before-write timing lets a three-unit linear model reach ordinary rank capacity, while post-update timing spends dimensions separating current input from delayed content. Nonlinear readouts still provide large gains. Tanh and ReLU can exploit short-horizon partitioning without yet paying the full multistep Jacobian cost. Several low-effective-radius nonlinear families are accessible.

### 10.3 Delay two: a special linear boundary

For a post-update three-state linear system, the optimal recurrence is nearly nilpotent and the non-nilpotent dividend is essentially zero. Yet the target operator has already collapsed to roughly one strong singular mode. Nonlinear readouts and separability-shaped states recover information far below the linear energy floor. Uniform leaky carry becomes causally important, though some rotated one-gate reductions still exist.

### 10.4 Delay three: the recurrence horizon opens

The nilpotent shift register reaches its cliff. Cyclic feedback becomes useful, the optimal linear spectrum becomes nonzero, channel-sharing between mode groups matters, and the leading target singular value falls to roughly 0.56. Timing requires multiple phase dimensions per spatial rank. Uniform leaky networks use distributed gating; heterogeneous and bounded-integrator designs offer alternative compromises. Tanh families can beat the linear baseline but may be rare.

### 10.5 Delays four and five: temporal depletion and objective pressure dominate

The best linear recurrence becomes mildly expansive but remains near relative error 0.90. The nonlinear readout still helps, but its marginal benefit is much smaller. Uniform leaky solutions rely on strongly expansive static dynamics balanced by distributed gating. The carry cannot be localized to one coordinate in any tested frame. Bounded and contractive heterogeneous solutions exist, showing expansion is not mathematically necessary, but they occupy narrow or architecture-specific basins. Standard MSE strongly favors signal sacrifice to suppress off-target variance. Active-only objectives reveal excellent latent recall, and carefully decoupled objectives can recover all features in a gated architecture, though robust low-error zero-sacrifice training remains unsolved.

## 11. Direct answer to the central research question

When small RNNs are trained on fixed $k$-delay datasets, the following reproducible solution structures emerge.

**1. A bounded-rank lag operator is the universal substrate.** The target response is $M_k=CA^kB$, or its phase-shifted timing equivalent. Its rank is bounded by the hidden dimension, and its singular values shrink with delay. The spatial floor and temporal realizability gap are distinct, measurable components of error.

**2. Linear recurrences change structure at a delay horizon.** Nilpotent shift-register solutions are optimal or nearly optimal below the horizon but fail exactly at and beyond $k=H$ under post-update timing. Cyclic feedback recovers most of the missing capacity; unequal-modulus non-derogatory modes close the remainder. Output timing shifts the horizon by one.

**3. Three hidden units exploit spatial channel-sharing.** The extra linear capacity over an orthogonal modal construction comes from overlapping input and output residues that let independent temporal modes share channels and cancel off-target lags. It does not come from recurrence-matrix non-normality itself.

**4. Nonlinear readouts and nonlinear recurrences solve different problems.** Readout nonlinearity decodes sign-asymmetric overlapping spatial codes and is most valuable at short delay. Recurrent leaky nonlinearity stabilizes and schedules high-gain temporal transport and becomes more important at long delay.

**5. The two nonlinear mechanisms are jointly trained.** A recurrence adapts to the readout fold present during training. The co-adapted pair cannot be understood by fitting a decoder after the fact or by inspecting either component alone.

**6. High-delay recurrent gating is causally distributed.** Uniform leaky networks use all three units jointly at long delays, even though the gating pattern looks low-dimensional. No coordinate rotation found a one-gate equivalent at delay five.

**7. Output timing changes the learned source, not just the readout.** Models learn phase-compatible recurrent operators. Reading a source at the wrong phase can erase nearly all accessible target information.

**8. Multiple nonlinear basins coexist.** Expansive distributed carries, bounded heterogeneous rotators, contractive decaying-threshold systems, bounded integrators, tanh families, and state-dependent gated cells are all empirically valid. They differ in optimization accessibility, robustness, and precision–recall behavior.

**9. The apparent capacity boundary is objective-dependent.** Active-target recall remains strong through delay five when false positives are ignored. Standard MSE suppresses variance by shrinking the lag operator or using nonlinear clipping, often sacrificing active signals. A loss switch can destroy a learned operator almost immediately.

**10. Mechanistic interpretation requires intervention.** Passive eigenspectra, low-rank descriptions, probes, or final errors are insufficient. Frozen-weight activation swaps, rotated gating interventions, operator counterfactuals, residue surgery, timing crossovers, and objective switches are the evidence that distinguishes causal mechanisms from correlated signatures.

These structures are robust at different levels. Rank floors, phase-indexed horizons, operator shrinkage, timing compatibility, and the objective frontier are broad features of the task. The exact nonlinear basin is less universal and depends on initialization, architecture, and optimization. The most accurate answer is therefore not one canonical circuit, but a constrained family of circuits organized around the same lag-operator problem.

## 12. Implications for mechanistic analysis of learned dynamical systems

Although the networks here are tiny, the methodological implications are broader.

First, **representation and mechanism are not synonymous**. A state may contain information decodable by a powerful probe without the trained model using that decoder. Conversely, a mechanism can be causally indispensable while contributing little descriptive variance. Probe success and low-dimensional summaries must be supplemented by interventions.

Second, **the operator is often a better unit of analysis than the state basis**. Hidden coordinates can rotate without changing function. Raw channel identities can be near-degenerate. Markov parameters, singular values, impulse-response phases, and response kernels expose invariant or functionally relevant structure.

Third, **training objectives define effective capacity**. A network’s observed failure may reflect the loss function’s preferred balance rather than an inability to transmit information. Capacity studies should report both signal recall and the costs paid elsewhere, especially false-positive variance.

Fourth, **architectural modularization changes the basin, not only the hypothesis class**. Separating a gate from a rotator or bounding a transport unit can reveal solutions that an unconstrained dense network rarely finds. Conversely, a theoretically elegant parameterization may make optimization worse. Existence and accessibility must be studied separately.

Fifth, **corrections are scientifically productive**. The shift from recurrence non-normality to residue channel-sharing, the removal of the high-delay linear decodability boundary by spectral anchoring, and the refinement of canonical-channel degeneracy all improved the theory. In each case, a stronger controlled intervention replaced an appealing but incomplete descriptive account.

## 13. Limitations and unresolved questions

The conclusions are bounded by the available evidence.

The primary datasets have sequence length ten, input dimension five, and delays at most five. Findings about generated delay-six or delay-seven data are useful boundary tests but do not carry the same evidential weight as the official fixed sets.

Most primary claims concern hidden sizes at most three. The rank and nilpotent-horizon logic generalizes algebraically, but the observed nonlinear basins may change substantially once the hidden state reaches or exceeds the input dimension. A six-unit model achieved much better delay-six performance under feature-balanced training, suggesting that angular and spatial capacity can qualitatively alter the frontier.

The realizable linear floors are high-quality multi-restart or certified numerical estimates, not analytic global optima in every setting. The spatial floor and nilpotent cliff have stronger formal status than all reported nonlinear boundaries.

Several nonlinear results are basin-sensitive. Bounded attractors and zero-sacrifice gated solutions were sometimes achieved by only a subset of seeds. They establish existence and identify promising mechanisms, but not robust default behavior.

The active-only objective intentionally ignores false positives. Its low active error should not be described as solving the original full-sequence task. Its value is diagnostic: it reveals latent transport capacity and maps the tradeoff that standard loss resolves differently.

The exact causal role of spectral expansion in nonlinear models remains partly unresolved. Linearization proves that the activation kink is load-bearing in expansive trained networks, and objective sweeps link standard loss to larger radii in many settings. Yet active-only models can also depend on the kink, and simple negative-branch occupancy does not fully localize variance suppression. A complete operator theory for nonlinear gated transport is still missing.

The training dynamics of structural allocation are also incomplete. Loss, phase, singular values, and channel identities converge on different time scales. Existing studies falsify several simple narratives but do not yet provide a universal acquisition theory across architectures.

Finally, the best objective for jointly preserving active recall and suppressing variance has not been found. Decoupled penalties and state-dependent gates improve the frontier, but robust three-unit, zero-sacrifice, low-error delay-five performance remains open.

## 14. Conclusion

The fixed-delay task exposes how a tiny recurrent network responds when an elementary desired computation exceeds its state dimension. The answer is not to build a miniature perfect delay line. The network constructs a low-rank lag operator, allocates its limited spatial and temporal modes, and then uses nonlinearity, timing, and objective-dependent compromises to recover as much of the desired mapping as possible.

The linear backbone is now clear. A delay-independent spatial floor coexists with a growing temporal realizability cost. The latter appears as singular-value shrinkage of the target Markov operator. A nilpotent shift register has an exact phase-indexed horizon; cyclic feedback reaches beyond it; unequal-modulus modes refine the response; and three-state channel-sharing lets independent temporal modes cooperate within the spatial rank budget.

Nonlinear solutions build on this substrate in more than one way. A nonlinear readout decodes overlapping nonnegative spatial rays. A leaky recurrent activation creates a derivative-floor carry that stabilizes expansive dynamics and distributes temporal routing across all hidden units. These mechanisms divide labor, co-adapt, and vary oppositely with delay. Alternative architectures reveal bounded and contractive solutions, proving that the common expansive basin is not the only mathematical possibility.

The loss function is as important as the architecture. Standard MSE values silence on a sparse target and often attenuates or gates away the desired signal to avoid variance. Active-only training reveals that strong recall remains geometrically possible at high delay, but at a prohibitive false-positive cost. The observed model is therefore a point on a recall–variance frontier, not a direct readout of raw capacity.

The most general scientific lesson is methodological. Learned dynamical systems should be analyzed as fitted operator–nonlinearity pairs under a specific phase convention and objective. Final error, eigenspectra, probes, and low-rank summaries are useful but insufficient. The decisive evidence comes from interventions that preserve the trained system while changing one causal component. In these small RNNs, such interventions transform a collection of apparent anomalies—feature sacrifice, explosive spectra, timing sensitivity, dead zones, rare bounded solutions, and objective collapse—into one coherent story of constrained operator design.

## Evidence provenance

This synthesis is based exclusively on the local fixed-delay research corpus and its associated completed experimental records. The most influential source papers were the two full milestone syntheses on jointly fitted recurrence–readout mechanisms and the bounded-rank operator, together with the complete papers on spatial rank bottlenecks, the Jacobian dilemma, activation placement, output timing, readout co-adaptation, closed-form linear theory, heterogeneous rotational amplification, distributed derivative-floor carry, bounded attractors, contractive dual-threshold dynamics, residue channel-sharing, frame-aware irreducibility, phase-compatible operators, sparse-state decodability, spectral anchoring, eigenspace triage, nonlinear timing access, dimensional elevation, temporal singular-value shrinkage, the nilpotent delay-capacity budget, bounded integrators, phase-basin initialization, and the objective-dependent recall–variance frontier. Later completed records on abrupt objective switching, test-time linearization, nonlinear endpoint families, gated recurrent units, and bounded-architecture controls were used to update the synthesis beyond the archived paper set. No external source or newly run experiment was used.

### Local source concordance

The following title-level concordance identifies the principal local papers underlying each part of the synthesis without relying on internal database identifiers.

| Scientific role in this synthesis | Principal source titles |
|---|---|
| Foundational spatial bottleneck and early nonlinear geometry | *The Geometry of Forgetting: Rank Bottlenecks and Feature Sacrifice in Small RNNs*; *The Jacobian Dilemma: Structural Limits of Lossy Compression and Non-Linear Partitioning in Bottlenecked RNNs* |
| Separation of readout and recurrent nonlinear mechanisms | *Where and Why Nonlinearity Helps Small k-Delay RNNs: Readout Cone-Decoding and a Derivative-Floor Recurrent Carry*; *Readout Co-Adaptation in Small k-Delay RNNs: The Recurrence Accommodates the In-Loop Readout Nonlinearity, with a Capacity Boundary at k=5* |
| Linear floors, poles, and acquisition | *A Closed-Form Linear-Systems Theory of Small k-Delay RNNs: Optimal Poles, a Proven Spatial Floor, an H=3 Non-Normal Residue Dividend, and Acquisition Dynamics*; *The Phase Basin: Eigenvalue Phase, Not Modulus or Basis, Governs Learnability of the Above-Cliff Linear k-Delay Dividend* |
| Correction from recurrence non-normality to channel-sharing | *Channel-Sharing, Not Recurrence Non-Normality: A Causal Account of the H=3 Advantage in Small Linear k-Delay RNNs* |
| Delay horizon and recurrence-family structure | *Delay-Capacity Budget and the Non-Nilpotent Dividend in Small Linear k-Delay RNNs* |
| Per-direction allocation and operator shrinkage | *Eigenspace Triage and Its Escape: A Causal Anatomy of the Spatial Rank Floor in Small k=0 RNNs*; *From Spatial Floor to Temporal Shrinkage: A Causal Anatomy of Per-Channel Allocation in Small k>0 RNNs and Its Nonlinear Escape* |
| Objective-dependent information in linear states | *Objective-Dependent Sparse-Lag Decodability of the Linear State in Small k-Delay RNNs*; *Spectral Anchoring Removes the High-k Sparse-Lag Decodability Boundary in Small Linear k-Delay RNNs* |
| Distributed nonlinear carry | *The Derivative-Floor Carry as an Irreducible, Jointly-Distributed Gating Schedule in Small k-Delay RNNs*; *Delay-Graded, Frame-Aware Irreducibility of the Derivative-Floor Carry in Small k-Delay RNNs* |
| Timing and phase compatibility | *Output Timing Controls Phase-Rank and Feature-Merging Bottlenecks in Small k-Delay RNNs*; *Output Timing Trains Phase-Compatible Operators in Small Linear k-Delay RNNs*; *Interface-Relative Timing Access in Leaky k=3 RNNs* |
| Heterogeneous, bounded, and contractive basins | *The Divergent Rotational Amplifier: Decoupling Spatial Gating from Temporal Phase in Small k-Delay RNNs*; *Operator-Level Interventions and Capacity Boundaries of Spectrally Bounded Continuous Attractors in Heterogeneous RNNs*; *The Decaying Dual-Threshold: A Strictly Decoupled Geometric Regime for Small k-Delay RNNs*; *Escaping the Spatial Floor: Bounded Integrators and Leak-Bounded Coupling* |
| Objective-dependent recall–variance frontier | *Objective-Induced Spectral Expansion: Isolating Geometric Capacity from Variance Suppression in h=3 RNNs*; *Mapping the Objective-Dependent Capacity Frontier: An Empirical Law of Recall vs. Variance in Small k-Delay RNNs* |
| Integrated milestone accounts | *How Small k-Delay RNNs Solve Delay: A Jointly-Fit Recurrence-Readout Pair Whose Mechanisms Are Causally Real but Descriptively Hidden*; *The Bounded-Rank Operator and Its Allocation Face: A Consolidated Account of How Small k-Delay RNNs Decide What to Keep* |

The more recent completed experimental records used for the objective-switch, gated-recurrent-unit, nonlinear-family, and bounded-architecture updates are described directly in the relevant sections because they had not yet been consolidated into additional full papers in the local archive.
