# Learning Delay with Three Hidden Units: Bounded-Rank Operators, Nonlinear Carries, and Objective-Dependent Capacity in Small Recurrent Networks

## Abstract

Small recurrent neural networks offer an unusually sharp setting in which to ask what learning has actually discovered. The task considered here is deliberately simple: given a five-dimensional sequence, output the input from (k) steps earlier, with zero output before the delayed signal exists. The sequence length is ten, the available delays are (k=0,ldots,5), and the primary models have no more than three hidden units. The simplicity of the target removes semantic ambiguity, but the dimensional mismatch between a five-dimensional input and a three-dimensional recurrent state makes the learned solutions structurally nontrivial.

This paper synthesizes the complete local experimental record for this task. The central result is that a trained network should not be described as a single “memory cell” or as an unstable recurrence that happens to fit the data. In the linear regime, it is a bounded-rank realization of a lag operator. At the target lag its operator is (M_k=C A^k B), with rank at most three, and the same recurrent matrix (A) must make all lags jointly realizable. This produces two separable costs: a delay-independent spatial complement floor and a delay-dependent temporal realization cost. The first is the price of a readout whose range cannot cover all five output directions. The second appears as singular-value shrinkage of the realized target-lag operator and grows with delay. Closed-form and numerical analyses agree with trained checkpoints, including an optimal pole law, a nilpotent delay-capacity cliff, and a hidden-size-three residue-sharing advantage whose causal ingredient is spatial non-orthogonality rather than recurrence non-normality itself.

Nonlinearity does not erase this substrate; it works around different parts of it. A nonlinear readout decodes a sparse geometric cone in a compressed state and improves most at short delays. A leaky recurrent nonlinearity provides a derivative-floor carry that becomes more important with delay. Same-weights interventions show that these are distinct causal mechanisms, although recurrence and readout co-adapt during training. The carry is descriptively low-rank but causally distributed across all three hidden coordinates at high delay, and no rotated one-coordinate gate preserves performance for the longest tasks. Output timing is also learned into the recurrent/input operator: changing the phase at which the state is read after training creates a source-phase mismatch, not merely a generic readout penalty.

Finally, the familiar high-delay failure under standard full-sequence mean squared error is not a single architectural impossibility. An active-only objective reveals substantially better active-coordinate recall, at the cost of enormous off-target variance. Interpolating the objective produces a sharp recall--variance frontier; in nonlinear models spectral expansion is associated with variance suppression, while in linear models standard MSE directly attenuates the target-lag singular values. The strongest conclusion is therefore conditional but positive: small RNNs learn reproducible solution families whose geometry, dynamics, and failure modes can be predicted from a bounded-rank operator plus two nonlinear escape routes. What looks like a capacity wall is the combination of an irreducible linear realization cost and an objective-dependent choice about whether to preserve the delayed signal or suppress its crosstalk.

## 1. The question and the setting

The task is a fixed supervised family indexed by a delay (k). Each input sequence has ten time steps and five channels. The target at time (t) is

\[
y_t = \begin{cases}x_{t-k}, & t>k,\\0,&t\leq k.\end{cases}
\]

The official tensors contain 10,000 sequences for each (k\in\{0,1,2,3,4,5\}). Inputs are sparse and close to one-hot in their active coordinates, with a full-rank, nearly isotropic second moment; temporal lag-one correlation is close to zero. These details matter. A linear model is judged largely by its second-moment energy and by the finite ten-step horizon, whereas a nonlinear readout can exploit the fact that active inputs occupy a sparse, piecewise-geometric subset of the ambient five-dimensional space.

The scientific question is not whether a sufficiently large network can copy the sequence. It is what *small* recurrent models learn when their state has at most three dimensions. The state bottleneck is severe: the desired lag operator is the five-dimensional identity, but any one-step input-to-output map through a three-dimensional state has rank at most three. At nonzero delay, the same state must also preserve information for several transitions and release it at the correct phase. Thus spatial compression and temporal transport are coupled, and the recurrent parameters can compensate for one at the expense of the other.

The source record contains complementary studies rather than one canonical architecture. Linear, tanh, ReLU, and leaky-ReLU hidden recurrences were trained with matched hidden sizes, seeds, checkpoints, and evaluation subsets where a claim required comparison. Most quantitative results use relative active-region mean squared error,

\[
\mathrm{relMSE}_{\mathrm{active}}=
\frac{\sum_{t\geq k}\lVert o_t-y_t\rVert^2}
{\sum_{t\geq k}\lVert y_t\rVert^2},
\]

so that predicting zero everywhere has score 1. This normalization removes the trivial change in the number of zero-prefix positions and makes delay comparisons interpretable. Full-sequence MSE is used separately when the question concerns suppression of off-target outputs. Unless stated otherwise, “linear” means identity hidden dynamics and a linear readout, “leaky” means a leaky-ReLU hidden activation (slope 0.1 in the main intervention studies), and (h) denotes hidden size.

The evidence base has three layers. First are direct measurements on self-trained checkpoints: errors, singular values, response kernels, eigenvalues, gating patterns, and checkpoint trajectories. Second are frozen-parameter counterfactuals: a trained activation is replaced, a Markov parameter is isolated, a recurrent gain is rescaled, or the hidden frame is rotated without retraining. Third are derived or certified quantities: the convex spatial lower bound, the finite-horizon optimal pole, and the nilpotent-family theorem. Keeping these layers distinct prevents a plausible visualization from being mistaken for a causal explanation.

## 2. A common operator language

### 2.1 Markov parameters and the bounded-rank lag operator

For a bias-free linear recurrence,

\[
s_t=A s_{t-1}+B x_t, \qquad o_t=C s_t,
\]

the contribution of an input (m) steps earlier is the Markov parameter

\[
M_m=C A^m B.
\]

The ideal delay task would have (M_k=I_5) and (M_m=0) at all other lags in the relevant horizon. Every realized (M_m) factors through an (h)-dimensional state, so its rank is at most (h). The target lag is therefore a bounded-rank approximation to the identity. More subtly, the entire sequence ({M_m}) must be generated by one shared (A), so the lag operators are not independently selectable. Their block-Hankel structure has rank bounded by the state dimension. This is the operator-level statement of the spatial--temporal bottleneck.

The operator language unifies apparently different descriptions in the source record. “Feature sacrifice” refers to which directions of the identity are lost at the output. “Temporal shrinkage” refers to how the singular values of (M_k) decay as (A) must carry the state to lag (k). “Pole acquisition” refers to the recurrent spectrum needed to shape the finite-horizon sequence of Markov parameters. These are not competing metaphors: they are different projections of the same constrained realization.

### 2.2 Three error levels

The linear studies distinguish three nested optima. (F_{\mathrm{unc}}) is a proven convex lower bound obtained by relaxing the shared-realization constraint and retaining only rank-(h) approximation of the target lag. If the active input covariance has eigenvalues (s_1\leq\cdots\leq s_5),

\[
F_{\mathrm{unc}}=\frac{\sum_{i=1}^{5-h}s_i}{\sum_{i=1}^{5}s_i}.
\]

For nearly isotropic inputs this is approximately 0.6 for (h=2) and 0.4 for (h=3), independent of (k). It is a spatial floor, not a statement that a recurrent system can realize the relaxed operator.

The realizable optimum (F_{\mathrm{real}}(k,h)) enforces the common (A) and is estimated by multi-restart optimization and, in the strongest studies, by an independent weighted Prony/Hankel construction. It rises with delay. Representative bias-free (h=3) values are approximately 0.793 at (k=2), 0.872--0.876 at (k=3), 0.897 at (k=4), and 0.895 at (k=5). The small non-monotonicity at the last two delays is real within the numerical precision of the certified optimization; the general separation from the flat spatial bound is the robust result.

The nilpotent optimum (F_{\mathrm{nil}}) restricts (A) to a shift-register family. A nilpotent (h	imes h) matrix satisfies (A^h=0), so under post-update readout (M_k=0) for (k\geq h). Consequently (F_{\mathrm{nil}}=1) at and beyond the shift-register horizon. The non-nilpotent dividend (D=F_{\mathrm{nil}}-F_{\mathrm{real}}) measures the benefit of leaving that family. At (h=3), (D) is about 0.12 at (k=3), 0.10 at (k=4), and 0.10 at (k=5), but is exactly zero at (k=2): the unconstrained optimum at that delay is itself nilpotent. The dividend is therefore a capacity-horizon effect, not a monotone penalty for every nonzero delay.

Read-before-write timing shifts these statements by exactly one step. The relevant map becomes (M_m=C A^{m-1}B), the nilpotent cliff moves from (k=h) to (k=h+1), and the entire error table is relabeled by one delay. This exact shift is useful evidence that timing is part of the learned operator rather than a superficial convention.

## 3. The spatial floor: what a three-dimensional readout cannot represent

The (k=0) task isolates spatial compression because recurrence has no opportunity to alter the target. The strongest causal study varied hidden size from one through six and compared trained checkpoints to the analytic rank-(h) PCA solution. The number of systematically sacrificed dimensions was exactly (5-h), and the error matched the analytic optimum. With (h\geq5), the triage disappeared. This is the simplest direct demonstration that the floor is a rank budget rather than an idiosyncratic optimizer failure.

The sacrificed subspace is not a fixed list of canonical channels. On the official nearly isotropic inputs, canonical directions are almost degenerate, so multiple bases have nearly equal energy. When synthetic covariance eigenbases were rotated away from the canonical axes, the network followed the covariance eigenspace rather than channel names. In the original coordinates this can look like deterministic “channel preference,” but the causal object is the covariance geometry.

Magnitude is learned before channel identity. Checkpoint analyses found that the network first increases output magnitude and only later settles which directions are represented. Same-weights ablations of input columns (B) show a stable causal ordering at (k=0), while the final canonical labels remain basis-dependent. This distinction becomes essential once delay is introduced: a channel-level story that ignores the operator or covariance basis can be reproducible in one coordinate system and meaningless in another.

A linear readout cannot escape this floor because every output lies in \(\mathrm{range}(C)\), a subspace of dimension at most (h). The nonlinear readout experiments establish that the *task* contains more recoverable structure than this linear output subspace suggests. A leaky-ReLU readout partitions the compressed state into regions and can decode a sparse cone of inputs with different affine maps. At (k=0), a matched nonlinear readout reduced relative active error from the linear floor near 0.38 to approximately 0.01 and recovered all five output channels under the study's threshold. Removing only the readout nonlinearity from the same trained weights restored the linear floor, identifying the escape ingredient directly.

The result should be stated carefully. Nonlinearity does not increase the rank of the linear map (C A^kB); it changes the function class applied to the state and exploits the input distribution. Thus (F_{\mathrm{unc}}) and (F_{\mathrm{real}}) remain valid linear-architecture limits, while the nonlinear escape is a distribution-dependent decoding mechanism.

## 4. Delay transforms the floor into operator shrinkage

The most detailed per-channel analysis asks what happens to the (k=0) allocation anatomy at positive delay. A naive hypothesis is that the same covariance eigenspace is sacrificed at every (k). It is false. The overlap between the (k=0) bottom eigenspace and the residual subspace falls from 1.00 at (k=0) to roughly 0.43, 0.28, and 0.20 at (k=1,2,3). The recurrent state changes which directions are expensive to transport.

An operator decomposition resolves the apparent contradiction. Project the residual onto \(\mathrm{range}(C)\) and its orthogonal complement. The complement component is nearly constant, approximately 0.39 relative error, across (k=0,1,2,3). It is the fixed spatial floor: output directions outside the readout range are unreachable at every lag. The in-range component grows from essentially zero at (k=0) to approximately 0.33, 0.39, and 0.47 at (k=1,2,3). All delay-induced degradation is therefore in the subspace that the readout could in principle reach.

Frozen operator counterfactuals identify the in-range cost. Replacing the full output by (M_k x_{t-k}) and zeroing all off-target lags removes only about ten percent of the in-range residual at (k=1) and nearly none at (k=2), with a small effect at (k=3). The error is not mainly contamination from neighboring lags. An SVD counterfactual that retains the learned singular directions but sets their singular values to one overshoots the true performance, whereas a shrinkage-only reconstruction reproduces the observed residual at a ratio close to one. The top-three singular values of (M_k) have mean profiles near 1.00, 0.42, 0.33, and 0.19 for (k=0,1,2,3), respectively; secondary modes collapse first and the leading mode eventually shrinks as well.

This is the per-mode realization form of the growing (F_{\mathrm{real}}). The operator is not simply misaligned; it is attenuated by the finite-dimensional recurrence. Rescaling (A\) can move the singular values, but it does not provide a universal repair. At (k=1), the trained gain is already best and further amplification worsens the in-range error. At (k=2), the coupling is non-monotone; at (k=3), a targeted carry-direction rescaling is more predictable. The learned profile is therefore a constrained optimum, not an underpowered model waiting for one scalar gain correction.

The nonlinear readout again provides an escape, but a graded one. In matched linear-recurrence cells, leaky-ReLU readouts improved over the linear floor by margins of about 0.37, 0.35, 0.19, and 0.17 for (k=0,1,2,3). The number of channels passing a moderate-error threshold rose from roughly 3 to 5 at (k=0), from about 1 to 4 at (k=1), and then declined to about 2 at (k=3). The readout nonlinearity is thus a capacity-restoring decoder, but its leverage is consumed by temporal transport.

The bounded-rank synthesis is consequently precise: the fixed complement is the spatial floor; the growing in-range residual is singular-value shrinkage of (M_k); and a nonlinear readout partially restores information that the bounded linear realization cannot place in a single global output map. This relation is scoped to the small models and the official input distribution, but it is supported by trained checkpoints, operator surgery, and independent numerical optima.

## 5. The linear dynamical substrate: poles, phase, and the shift-register cliff

### 5.1 Finite-horizon poles

The finite ten-step horizon makes a mildly expansive recurrent pole useful even when an asymptotically stable system would be preferred in a conventional control setting. For a two-dimensional rotation block, the scalar impulse response can be written

\[
a_m=r^m(\alpha\cos m	heta+\beta\sin m	heta).
\]

Minimizing the weighted finite-horizon delay objective over (r) and (	heta) gives a derived optimal pole. Its modulus rises from roughly 0.765 at (k=2) to 0.886 at (k=3), 1.01 at (k=4), and 1.16 at (k=5). Trained linear (h=2) eigenvalues match the derived modulus within approximately three percent. The above-one values are not a claim of useful long-run instability; they are the finite-horizon gain needed to place an impulse peak at a late lag.

The same derivation explains why a real pole alone is inadequate: a real pole produces a monotone geometric response and cannot create an interior peak at the target lag. A rotation supplies phase, and at (h=3) a third mode can share spatial residues with the rotation pair. The phase fit becomes less exact as delay grows; the residual of a single rotation block rises sharply, which anticipates the need for nonlinear or higher-dimensional mechanisms at the longest official delays.

### 5.2 Residue sharing, not recurrence non-normality

An early interpretation attributed the (h=3) linear advantage to non-normality of (A). A fixed-spectrum causal decomposition corrected this. Holding eigenvalues fixed and refitting the input and output residues, strict orthogonalization of the modal (B)-columns and (C)-rows raises error at (h=3), whereas changing the recurrence to a general similarity-transformed normal matrix adds almost nothing. The advantage comes from spatial-residue non-orthogonality: multiple temporal modes share non-orthogonal directions in the five-dimensional input/output space. Hidden size three has two modal groups that can share; hidden size two does not. This produces a measurable residue dividend without requiring a defective or Jordan-like recurrence.

The distinction matters for interpretation. The static spectrum can be expansive and the matrix can be non-normal, but neither fact alone is the load-bearing mechanism. The causal intervention is residue orthogonalization, not an arbitrary norm or Henrici statistic. This is a useful correction because it connects the linear advantage directly to the same spatial allocation problem seen in (M_k).

### 5.3 The non-nilpotent dividend

The nilpotent theorem gives a clean capacity boundary for the shift-register family. A single cyclic feedback coefficient turns the shift register into a periodic delay line with (A^h=a_1I), yielding the exact echo identity (M_{k+h}=a_1M_k). In the cliff regime, this one coefficient closes roughly 80--86% of the non-nilpotent dividend, much more than a single real-pole or leaky coefficient. The remaining error is predictable: the periodic construction necessarily creates echoes at other lags.

The minimal helpful recurrence element depends on regime. Below the shift-register horizon, a single decaying real pole can remove almost all of a small residual, while a cyclic tap may be unhelpful. At or beyond the horizon, wrap-around feedback is the efficient escape. This result gives an interpretable ladder between a pure delay line and a free recurrent matrix, and it shows that “recurrence” is not one undifferentiated capacity variable.

### 5.4 Learning dynamics and phase basins

The linear system can be optimal and still be hard to learn. Near zero recurrent gain, quasi-static gradient flow predicts a degenerate fixed point with (dw/dt\propto w^{2k-1}). The measured log-log takeoff slope is (2k), and full-batch gradient descent exhibits a plateau whose predicted length grows rapidly with delay; the highest-delay runs remain censored before takeoff. Adam escapes, but its adaptive dynamics distort the clean delay ordering. A stronger behavioral marker is that the active-MSE drop occurs when the impulse-response peak reaches the target lag, with correlation about 0.84.

Initialization studies separate what defines the optimum from what makes it learnable. Initializing the correct eigenvalue phase, even with equal or imperfect moduli, is sufficient for reliable acquisition on the fast axis. Correct modulus with random phase can perform worse than an ordinary random initialization. A phase-correct spectrum and a basis-aligned realization improve reliability and speed, especially at (h=3) and high delay, although they do not guarantee a lower final MSE in every condition. The learned linear solution is therefore organized by a phase basin: phase governs access to the useful transient, while modulus and basis refine the final realization once the basin has been entered.

## 6. Nonlinear solutions: two mechanisms with a shifting division of labor

### 6.1 A double dissociation

The main nonlinear evidence comes from leaky-ReLU hidden recurrences and nonlinear readouts evaluated in a two-by-two same-weights design. The readout nonlinearity can be linearized while the hidden carry remains intact; conversely, the hidden activation can be replaced by identity while the readout stays nonlinear. Linearizing the readout hurts across all delays. Linearizing the hidden recurrence is mildly damaging at short delay but becomes catastrophic at (k\geq2), with state norms diverging by many orders of magnitude in the longest tasks. These are different interventions with different signatures, so a single undifferentiated “nonlinear effect” is not adequate.

The readout mechanism is spatial: it decodes a compressed, overlapping representation by using different affine regions. The recurrent mechanism is temporal: the leaky derivative floor keeps a delayed signal in an operating band while the recurrence is expansive. The two mechanisms sit on top of the linear operator substrate rather than replacing it.

### 6.2 Delay-graded contributions

In a matched 12-seed intervention study, the same-weights contribution of the nonlinear readout declines from approximately 0.37 at (k=0) to 0.09 at (k=5), while the damage caused by removing the recurrent gate increases with delay. The profiles are anti-correlated. At short delay, spatial cone decoding is the largest nonlinear lever; at long delay, the recurrent carry is load-bearing. By (k=5), the readout lever is nearly exhausted and the recurrent carry is approaching the linear realization boundary.

This does not mean that the mechanism disappears at (k=5). The apparent boundary is family- and objective-relative. Other experiments with objective changes or alternative bounded architectures recover much better active recall at comparable hidden size. What saturates is the extractable benefit of the particular jointly trained solution under the particular full-sequence objective.

### 6.3 Co-adaptation makes passive analysis misleading

To test whether a nonlinear readout helps only because it is expressive at inference, researchers froze a trained recurrence and refit linear and nonlinear readouts. A post-hoc nonlinear readout does provide a benefit on a fixed code, concentrated on active target coordinates. But the train-versus-refit interaction is positive and confidence-separated from zero for (k=0,ldots,4): approximately 0.155, 0.179, 0.050, 0.123, and 0.033 in the study's normalized difference-in-differences. At (k=5) the interaction is near zero, around 0.005 with an interval spanning zero. The recurrence learned with a nonlinear readout is therefore shaped to expose a code that the nonlinear readout can use; the benefit is not merely an interchangeable decoder applied after training.

The interaction grows from zero over the checkpoint trajectory, and the co-adapted recurrence still loses competence when its nonlinear readout is removed. This is why frozen-recurrence decoding can under-report the mechanism. The trained object is a pair, not a recurrence plus an independently replaceable readout.

### 6.4 The derivative-floor carry

Same-weights slope scans identify a finite operating window. At the trained slope, performance is best among the scanned slopes. At the linear limit, high-delay error can grow to roughly (10^7) at (k=3) and (10^{13}) at (k=5); at the hard-ReLU limit, the carry collapses. The leaky derivative is not decorative regularization. It is the gain schedule that makes an expansive recurrence usable over the finite delay.

The carry is causally irreducible even though its descriptive gate pattern is low-rank. Participation ratios of the gating pattern are around 1.2--1.6 across delays, suggesting one or two dominant directions. Yet rank-restricted interventions that leave only one or two hidden units nonlinear diverge at delayed (k). At (k=3), for example, full gating has relative error near 0.77 while one-coordinate gating reaches about (4	imes10^7); at (k=5), the corresponding failure is about (4	imes10^{12}). The apparent contradiction is resolved by recognizing that a low-rank trajectory statistic does not imply a low-rank causal mechanism.

Rotated-basis interventions sharpen the claim. A performance-preserving rank-one gate exists for all tested seeds at (k=0), for 8 of 12 at (k=1), and 7 of 12 at (k=2). The count falls to 2, 1, and 0 at (k=3,4,5). The result holds under held-out validation and permutation controls. Thus low-delay carries can sometimes be localized to a fortunate frame, whereas high-delay carries are frame-invariantly distributed across the three hidden units. This is a delay-graded irreducibility, not a universal statement that every nonlinear solution always uses all coordinates.

### 6.5 Timing as source--phase compatibility

Output timing produces an independent structural axis. In linear models, read-before-write timing can outperform post-update timing at (k=1); one representative comparison gives active (R^2) of 0.615 versus 0.267. A fixed-operator two-by-two refit experiment resolves the mechanism. Operators trained with read-before-write are worse when refit at the post-update phase but better when refit at the read-before-write phase, and post-trained operators show the opposite preference. The sign flip occurs across hidden sizes and delays.

At (k=1), the explanation is target-lag localization in the exposed hidden phase plus current-input contamination under a mismatched phase. At (k=3), hidden lag probes are mixed, but the complete response kernel allocates target-lag energy differently across channels. In both cases, timing is learned into (A) and (B); it is not an inference-only convention. Leaky nonlinear models show a related interface effect: matched nonlinear conditioning can reveal target-lag access before a native linear phase-compatible decoder becomes stable. The state contains timing information relative to the interface at which it is read.

## 7. Why standard training appears to fail at high delay

### 7.1 Recall versus variance

The official target is sparse in time and channels. Full-sequence MSE therefore penalizes off-target output energy over many zero targets. Transporting a sparse feature through a three-dimensional state tends to generate crosstalk; the optimizer must choose between active recall and variance suppression. This choice is visible when the objective is changed without changing the task.

In a 100-run sweep over (k=1,ldots,5), (h=3) leaky models trained with ActiveOnlyMSE achieve median active relative errors approximately 0.0158, 0.0294, 0.0538, 0.0686, and 0.0669. Their full-sequence errors are large, roughly 6.6--22. StandardMSE produces active errors of approximately 0.5821, 0.6020, 0.7850, 0.8341, and 0.9786, while keeping full-sequence error between about 0.60 and 1.63. The same architecture can therefore be an excellent active transporter or a conservative variance suppressor, depending on the loss.

The active-only values are not zero-error miracles. They reveal a realized recall frontier that rises with delay and then plateaus near 0.07 for the tested architecture. A linear (h=3) model trained with the same active objective reaches a comparable (k=4) active floor near 0.06, and a hidden-size sweep gives roughly 0.100, 0.068, 0.051, and 0.039 for (h=2,3,4,5). Spatial packing remains a genuine limit even when the variance penalty is removed; the objective determines how much of the available capacity is spent on preserving it.

### 7.2 Spectral expansion and operator attenuation

In nonlinear models, StandardMSE is associated with expansive spectra: at (k=4), median spectral radius is about 7.49 under StandardMSE versus 2.53 under ActiveOnlyMSE. The expansion appears to weaponize activation kinks to clip off-target components. A two-phase intervention is causal: networks first trained with ActiveOnlyMSE lose active recall when switched to StandardMSE, and the spectral radius expands in most runs as variance is suppressed.

In strict linear models, there is no activation kink to exploit. StandardMSE instead attenuates the target-lag operator itself. Under ActiveOnlyMSE, the median top singular value of (M_k) is approximately 3.37, 4.42, 3.79, 3.20, and 2.70 for (k=1,ldots,5); under StandardMSE it collapses to about 0.998, 0.998, 0.545, 0.473, and 0.471. The optimizer shrinks the operator to avoid crosstalk, directly sacrificing active recall.

Weighted loss interpolation maps the frontier. At (k=4), moving from pure StandardMSE to only 25% active-only weighting drops active error from about 0.270 to 0.046 while increasing off-target relative error from 0.84 to 3.57. Further increases in active weighting improve recall more smoothly while variance continues to grow. Mean spectral radius decreases from roughly 2.85 to 1.87 across the interpolation, reinforcing the distinction between geometry and objective pressure.

These results reframe several earlier observations. Tanh saturation can be understood as a failure to produce the amplitude needed for variance suppression, not as proof that the underlying geometry cannot route the signal. Expansive leaky spectra are partly load-bearing for finite-horizon transport, but they are also the optimizer's chosen tool for suppressing objective-penalized crosstalk. A high-delay failure under StandardMSE is therefore a point on a constrained recall--variance frontier.

### 7.3 Architectural controls and boundary conditions

Alternative architectures confirm that the frontier is not removed by a single hard bound. A bounded integrator can preserve the delayed signal but still produces full-sequence errors around 11 under active-only training because amplitude control and off-target suppression remain in tension. Strictly decoupled heterogeneous models can solve (k=5) with contractive spectra through a decaying dual-threshold mechanism, while less constrained heterogeneous models use spectral penalties to reach bounded attractors. These are credible solution families, but they do not invalidate the main account: they alter the geometry of the tradeoff rather than abolish the need to allocate spatial and temporal capacity.

Dimensional elevation does change the frontier. A six-unit model can solve a (k=6) transport variant with much better recall--variance balance, demonstrating that the three-unit boundary is not a property of delay tasks in general. The primary claim here remains scoped to (h\leq3), the official (k\leq5) datasets, and the tested objective families.

## 8. Methods, comparability, and evidential discipline

Because the source record contains many architectures and questions, synthesis requires an explicit comparability rule. The primary claims in this paper are restricted to official fixed datasets, hidden size at most three, and quantities computed on the active region unless the text explicitly says “full-sequence.” Architectural comparisons are treated as aligned only when activation placement, hidden size, optimizer family, checkpoint or stopping rule, seed pairing, and evaluation subset were controlled. A nonlinear readout is not compared to a linear readout by quoting their best runs from unrelated searches; the escape claims use matched cells or same-weights linearization. Likewise, a timing claim is not inferred from two endpoint losses alone; it uses frozen source operators and refitted readouts at both phases.

The evidence hierarchy is as follows. A *measurement* is a statistic computed directly from an unmodified checkpoint: error, singular value, eigenvalue, response kernel, gate participation ratio, or checkpoint time. A *frozen counterfactual* evaluates the same checkpoint after changing one operation at inference: the readout activation is replaced by identity, selected gates are disabled, a rotated gate is applied, a lag operator is isolated, or a gain is rescaled. A *matched training intervention* changes one training condition while holding seeds and data order paired. A *derived result* follows from the task definition and a stated model family, such as the nilpotent theorem. The paper uses stronger verbs for the latter three than for descriptive measurements. “Causes,” “escapes,” and “is required” refer to an intervention or theorem; “is consistent with” refers to a descriptive association.

The studies use several complementary controls. Same-weights interventions avoid a common confound in neural mechanism work: retraining after deleting a component lets optimization find a different solution. If linearizing a trained readout immediately restores the linear floor, the readout nonlinearity was part of the original computation. If a rank-restricted gate diverges without retraining, the missing coordinates were causally needed by the learned trajectory. Fixed-spectrum residue surgery similarly prevents the optimizer from replacing an orthogonalized configuration with a new spectrum. For loss experiments, the two-phase objective switch tests reversibility: if a model trained for active recall later sacrifices it under StandardMSE, the frontier is not just a static difference in random initialization.

The principal uncertainty comes from optimization rather than measurement noise. The archive generally uses 8--12 seeds for mechanistic interventions and paired seeds for architectural comparisons; the broad objective sweep uses 100 controlled runs. Confidence intervals are reported in the source papers and are used here when they distinguish alternatives. Numerical realizable floors are based on multi-restart searches and cross-checked by independent parameterizations, but they are not promoted to theorems. Conversely, the analytic spatial bound is a relaxation and should not be read as the achievable error of a recurrent network. This separation is why the paper can confidently state that the complement floor is fixed and that the realizable floor rises, without claiming a closed-form global optimum for every nonlinear family.

The input distribution is also part of the causal scope. The official active covariance is full-rank and nearly isotropic, so the analytic spatial floor is close to the simple ((5-h)/5) ratio. Its sparse, near-one-hot support is what permits cone decoding by a nonlinear readout. If the same covariance were populated by a dense Gaussian distribution, the linear second-moment analysis would remain relevant but the particular nonlinear decoding advantage could change. Claims about channel allocation are consequently expressed in covariance or operator-singular coordinates; claims about sparse-feature recovery are explicitly distribution-dependent.

Finally, phase conventions are stated whenever a result involves a lag. Post-update readout gives (M_m=C A^mB); read-before-write gives (M_m=C A^{m-1}B). An apparent one-step contradiction between two studies can be an indexing difference rather than a scientific disagreement. The exact one-step shift of the nilpotent cliff and the source--phase crossover experiments make this more than a bookkeeping issue: the phase at which the output is exposed is a learned part of the computation.

## 9. An integrated account of learned solution families

The evidence supports a layered model of what training discovers.

**Layer 1: a bounded-rank linear substrate.** Every small network must route a five-dimensional identity through at most three state coordinates. In a linear readout, this creates a fixed complement floor and, for (k>0), a growing in-range singular-value shrinkage. The finite-horizon recurrence chooses poles and residues to place as much operator mass as possible at the target lag. Hidden size three gains access to spatial residue sharing unavailable at hidden size two. A pure shift register fails at the horizon; a cyclic feedback tap is the minimal efficient escape.

**Layer 2: interface and phase specialization.** The recurrence/input operator is trained for the phase at which its state will be read. Timing mismatches expose the wrong lag mixture even when the same source operator is used. The relevant object is not a generic “memory trace” but an interface-relative response kernel.

**Layer 3: a spatial nonlinear decoder.** When the input distribution is sparse, a nonlinear readout can partition the compressed state and recover multiple output directions that no single linear (C) can represent. This contribution is strongest at short delay, where the state has not yet paid the full transport cost.

**Layer 4: a temporal derivative-floor carry.** A leaky recurrent nonlinearity stabilizes an expansive finite-horizon transport regime. The gate is not a single memory coordinate at high delay. It is a jointly distributed schedule whose causal necessity is invisible to simple SVDs and whose useful slope lies in a finite band.

**Layer 5: objective selection.** StandardMSE asks the solution to suppress every off-target response, while ActiveOnlyMSE asks mainly for signal recovery on active coordinates. The same geometric substrate can therefore appear as a high-spectral-radius variance suppressor or as a high-recall, high-crosstalk transporter. The “capacity” observed in a benchmark is a coordinate on this frontier.

This account explains why the source studies contain apparently conflicting statements. One study sees expansive eigenvalues as necessary; another removes them with spectral regularization. One sees a low-rank gate; another shows all coordinates are causally necessary. One attributes an (h=3) advantage to non-normal recurrence; a later intervention finds residue non-orthogonality instead. These are not arbitrary reversals. They arise when a descriptive statistic is promoted beyond its scope, or when a task-level objective is confused with the underlying active-recall geometry.

### 8.1 A compact map of the evidence

The principal measurements can be arranged as a causal map rather than a chronology:

| Question | Direct observation | Counterfactual or control | Scientific reading |
|---|---|---|---|
| What is lost at (k=0)? | Exactly (5-h) dimensions are sacrificed; errors match rank-(h) PCA | Hidden-size sweep and covariance-basis rotations | A spatial rank floor, expressed in an eigenspace rather than fixed channel labels |
| What changes with delay? | Readout-complement error stays near 0.39; in-range error rises | Isolate (M_k), zero other lags, and decompose its SVD | Fixed spatial cost plus temporal singular-value shrinkage |
| Why does (h=3) help linearly? | General three-mode residues beat strict orthogonal residues | Fix spectrum; orthogonalize residue directions and refit amplitudes | Spatial channel sharing, not recurrence non-normality alone |
| How does a recurrence reach high delay? | Nilpotent models collapse at (k\geq h); cyclic feedback closes 80--86% of the gap | Companion-family ladder with equal budgets | A non-nilpotent dividend with a minimal wrap-around escape |
| Where does nonlinearity help? | Readout effect is largest at low (k); hidden effect grows with (k) | Same-weights 2-by-2 activation interventions | Two separable mechanisms on the same substrate |
| Is the carry one memory coordinate? | Gate-pattern participation ratio is only 1.2--1.6 | Rank restriction and rotated-frame adversarial search | Descriptive low rank does not imply causal low rank |
| Why do high-delay models appear to fail? | Active-only training recalls well but has huge variance | Loss switch and weighted interpolation | Standard MSE selects variance suppression on a recall--variance frontier |

The value of the table is methodological. Every interpretive noun in the final column is tied to either a theorem, a matched intervention, or a replicated measurement. For example, “temporal shrinkage” is not inferred from a rising error curve alone; it is supported by a counterfactual that retains the learned directions and changes only singular values. Likewise, “distributed carry” is not inferred from a visually complex trajectory; it is supported by failure under an adversarial search over rotated one-coordinate gates.

### 8.2 Checkpoints reveal order of acquisition

Intermediate checkpoints are essential because final weights conflate acquisition and refinement. The linear dynamics experiments show a long early plateau at high delay, followed by a rapid improvement once the response peak reaches the target lag. The objective studies show another ordering: active recall can improve first, after which a full-sequence loss expands or attenuates the operator to control off-target variance. Nonlinear checkpoint traces similarly show the readout scaffold and the recurrent carry emerging on different schedules.

This ordering explains why endpoint-only comparisons can misidentify a mechanism. A final model with a broad temporal response may have acquired the target phase early and then deliberately broadened it to reduce variance. A model whose gating pattern has low effective rank at the endpoint may have used all coordinates during the critical transport phase. A readout refit at the endpoint can look adequate even though the recurrence was shaped jointly with the original nonlinear decoder. Checkpoint analysis turns these apparent contradictions into different stages of the same optimization trajectory.

The strongest temporal marker is not loss itself but response alignment. When the impulse-response peak first reaches (k), active error drops; the reported correlation is approximately 0.84. This is a mechanistic acquisition event: the model has learned the correct phase. In contrast, a subsequent change in spectral radius can improve zero-region suppression without improving the target-lag operator. The distinction is important for future training diagnostics: peak-at-(k), target-lag singular values, and off-target energy should be logged separately.

### 8.3 Activation placement matters more than activation name

The studies do not support the blanket statement that “nonlinear RNNs are better.” They support a placement-specific statement. A nonlinear *readout* helps because the sparse data occupy a decodable cone after compression. A nonlinear *recurrence* helps because its derivative floor makes a finite-horizon expansive transport usable. Tanh, hard ReLU, leaky-ReLU, and heterogeneous cells differ in whether they can supply the required amplitude and derivative over the operating trajectory.

The Jacobian dilemma illustrates the tradeoff. Saturation can create useful geometric partitioning, but it reduces local derivative and interrupts continuous transport. At short delay the partitioning benefit can dominate; at high delay the derivative loss becomes costly. Leaky-ReLU retains a nonzero negative slope and therefore supports the recurrent carry, but its expansive regime can amplify off-target components. Heterogeneous designs that assign gating and temporal rotation to separate units can avoid some of this coupling, yet strict decoupling can also remove useful cross-channel sharing. The correct comparison is consequently not activation versus no activation; it is which operator, at which interface, receives which nonlinear degree of freedom.

### 8.4 Why descriptive rank and causal rank diverge

The carry result generalizes beyond this task. A participation ratio, singular-value spectrum, or principal-component plot summarizes the set of states visited by one trajectory distribution. A causal intervention asks whether the function still works when a coordinate or subspace is altered. Co-adaptation makes the two especially different: a coordinate can have small variance but still be required to keep the trajectory on the correct side of a leaky kink. Conversely, a high-variance coordinate can be replaceable because another mode carries the same information.

The rotated-frame experiment is therefore unusually informative. It searches over a family of hidden bases, holding all learned weights fixed, and asks whether any basis makes a one-coordinate gate sufficient. The answer changes systematically with delay. At (k=0), a one-coordinate frame can preserve the function for every seed; by (k=5), no searched frame does so. This is stronger than saying that “all units have nonzero activity.” It says that the nonlinear operation itself cannot be confined to one direction without changing the computation at high delay.

### 8.5 A note on basis and channel language

The near-isotropic input covariance creates a subtle reporting hazard. In the canonical data basis, several channels have almost equal energy, so a model may consistently sacrifice one named channel across seeds while an equally good rotated solution sacrifices a different linear combination. The covariance and operator-singular bases are the stable ones for allocation claims. The canonical basis is useful for visualization and for reproducing the task definition, but it should not be treated as a physically privileged set of features.

This basis discipline also clarifies the apparent tension between spatial triage and residue sharing. Both concern how five-dimensional directions are assigned to three modes, but one is expressed in the readout range and covariance eigenspace, the other in modal (B)- and (C)-residues at fixed temporal poles. They become the same bounded-rank problem when the realized (M_k) is used as the common object. Claims about “which channel is remembered” are strongest when translated into singular directions, covariance energy, or a frozen operator counterfactual.

## 10. What is directly established, what is inferred, and what remains open

The strongest established findings are interventional or theorem-level. The spatial complement floor follows from the readout range and is observed at (k=0). The nilpotent cliff follows from (A^h=0) and is reproduced in matched trained arms. Operator-level counterfactuals identify singular-value shrinkage rather than off-target lag interference. Readout linearization, hidden linearization, slope scans, rank-restricted gates, and rotated-frame gates each isolate distinct nonlinear contributions. The loss switch and objective interpolation establish that active recall and variance suppression are separable pressures.

Several conclusions are well supported but interpretive. The best unifying description is a jointly fit recurrence--readout pair on a linear substrate. The anti-correlated delay profiles imply a division of labor between spatial decoding and temporal carrying. The phase-basin account explains why phase-correct initialization improves acquisition. These interpretations are grounded in matched controls and replicated trajectories, but they are not theorems about every recurrent parameterization.

Important boundaries are also clear. The certified (F_{\mathrm{real}}) is numerical, not a global proof of optimality; only (F_{\mathrm{unc}}) is an analytic lower bound. The residue dividend is specific to strict orthogonalized-residue controls, not a universal theorem that recurrence non-normality is beneficial. The frame-invariant carry result is strongest at (k\geq3) for (h=3); low-delay reductions are heterogeneous. Active-only training does not solve the full-sequence task, and nonlinear spectral expansion is a strong correlate of variance suppression rather than a universally proven causal lever. Results beyond (k=5) or (h=3), and mechanisms in larger hidden spaces, remain outside the primary evidence.

The most consequential open question is how to combine the two objectives without forcing a binary choice. A schedule that first builds the active operator and then introduces a bounded variance penalty is suggested by the frontier experiments, but it was not evaluated in this record. Likewise, it is unknown whether the phase-basin mechanism persists unchanged in nonlinear heterogeneous models. These are natural next tests, not assumptions needed for the present synthesis.

## 11. Cross-family comparison: what changes when one ingredient is held fixed

The evidence base is unusually valuable because several studies hold one part of the computation fixed while changing another. These comparisons show which conclusions are genuinely architectural and which are properties of a particular training regime.

The first comparison is linear hidden dynamics with different readouts. A linear readout exposes the rank-(h) operator directly and reaches the spatial floor at (k=0). A leaky nonlinear readout can leave that floor without changing the recurrence, proving that the zero-delay bottleneck is not an information-theoretic limit of the hidden state alone. Yet the gain shrinks with delay, showing that readout expressivity cannot substitute for temporal transport. This is a clean separation between *state capacity* and *readout capacity*.

The second comparison is a linear readout with different hidden activations. Identity recurrence defines the linear realizability floor. Tanh and hard-ReLU can improve some short-delay scores, but their vanishing derivatives make long recurrent products fragile. Leaky-ReLU retains a derivative floor and supports a qualitatively different regime. The comparison does not establish that leaky-ReLU is globally best; tanh can be competitive in some cells and gain-staged training can improve it. It establishes that the derivative floor is sufficient to create a distinct causal carry in the tested family.

The third comparison is objective rather than activation. Under ActiveOnlyMSE, both tanh and leaky models can preserve active coordinates at high delay, but they do so with large off-target variance. Under StandardMSE, the optimizer suppresses that variance, either through expansive nonlinear clipping or by attenuating the linear operator. Thus objective changes can imitate architectural changes in the scalar score. A model with the same recurrence and a different loss may appear to have a different “capacity,” even though it has moved along a common recall--variance frontier.

The fourth comparison concerns initialization. The certified linear optimum has a particular spectrum, but phase-correct initialization is more valuable than copying its modulus or eigenbasis. This is a reminder that a final solution’s descriptive coordinates need not be the coordinates that make the optimization landscape easy. The relevant feature for acquisition can be a phase basin that is not obvious in the final singular values.

Together these comparisons argue against a single-axis taxonomy such as linear versus nonlinear or stable versus unstable. The learned computation depends on at least four axes: the rank and geometry of the state, the temporal phase and pole structure, the nonlinear interface, and the objective’s relative valuation of recall and variance.

## 12. A methodological synthesis of interventions and diagnostics

The strongest contribution of the local record is methodological. It demonstrates a progression from descriptive measurements to causal tests, and it shows exactly where a tempting interpretation fails.

### 11.1 From channel counts to covariance coordinates

The first generation of analyses described “sacrificed features.” That description was useful but incomplete because official inputs were nearly isotropic. The covariance-rotation experiments corrected it. Once the eigenbasis was rotated, the sacrificed directions rotated with it, while canonical-channel labels became unstable. The improved claim is not that channel identity is never meaningful. It is that channel identity is meaningful only when the input covariance or task semantics breaks the symmetry. Under near-isotropy, singular values and subspaces are the reproducible quantities.

### 11.2 From static spectra to trajectory Jacobians

The second correction concerns recurrent nonlinearity. A static spectrum of (A) cannot describe a leaky-ReLU trajectory because the realized Jacobian is (D_tA), with (D_t) depending on the preactivation signs. The slope scan makes this operational: changing only the negative slope changes the transport from bounded to divergent to dead. The relevant mechanism is therefore a sequence of local derivative gates, not just an eigenvalue modulus.

### 11.3 From passive decoding to train-versus-refit interactions

The co-adaptation study shows why a flexible decoder is not enough. If a nonlinear readout is refit on a recurrence trained with a linear readout, it can improve performance, but that does not measure what joint training built. The train-versus-refit interaction isolates the extra benefit of having the nonlinearity present during recurrent optimization. This is a general design pattern for mechanistic learning research: freeze one component, refit the other, and use a difference-in-differences rather than a single post-hoc score.

### 11.4 From one hidden frame to rotated-frame interventions

Rank-restricted gating in the canonical hidden coordinates could have been a coordinate artifact. Rotating the hidden frame and searching for a rank-one gate addresses that concern directly. The delay-graded success counts show that low-delay reducibility is real but heterogeneous, whereas high-delay irreducibility survives the frame search. The lesson is broader than this task: causal dimensionality should be tested under the symmetry group of the representation whenever such a group is known.

### 11.5 From final checkpoints to trajectories

Several of the archive’s most interesting conclusions would be invisible at the final checkpoint alone. The linear spatial floor is reached in magnitude before the sacrificed subspace stabilizes. Nonlinear target access appears before linear phase compatibility. The milestone learning-rate schedule first separates from constant learning rate after the first drop. These are temporal claims, and the evidence required dense or at least strategically placed checkpoints. A final score cannot establish a training mechanism.

## 13. A compact answer to the central research question

The central question asks what reproducible solution structures emerge when small RNNs are trained on fixed (k)-delay datasets. The answer can now be stated in a way that is both mechanistic and empirically bounded.

At the level of the linear substrate, the network learns a finite-horizon realization of a delayed identity. Because its state is smaller than the input, it constructs a bounded-rank lag operator. At (k=0), the cost is a covariance-defined spatial allocation. At (k>0), the same unreachable complement remains, while the modes that are reachable lose singular value as the recurrent system tries to place them at a later lag. When the desired lag exceeds the nilpotent horizon, a non-nilpotent dividend becomes available; the best linear solutions use phase-compatible, non-derogatory pole structures, and training reliability is governed by phase basins.

At the level of nonlinear computation, the network can leave this linear floor in two qualitatively different ways. A nonlinear readout uses sign-asymmetric sparse geometry to decode multiple rays from a compressed state. A derivative-floor recurrent nonlinearity uses state-dependent local gains to make an expansive recurrence usable over a finite horizon. The readout mechanism is spatial and strongest at short delay. The recurrent mechanism is temporal and increasingly important at long delay. They are jointly fit, so neither mechanism should be interpreted as an independent plug-in, but same-weights interventions show that they remain causally separable.

At the level of learning and evaluation, the solution is conditional on interface and objective. Timing determines which lag operator the readout sees. A nonlinear diagnostic can access information that a linear phase-matched probe misses, without proving native use. Standard MSE can suppress the same active signal that an active-only objective reveals. Initialization phase can determine whether an existing optimum is reached reliably. Consequently, the phrase “the model fails at (k=5)” has no stable meaning without specifying the loss, metric, timing, architecture, and checkpoint.

This is the coherent scientific story across the archive. Small recurrent networks do not discover one universal algorithm for delay. They discover a constrained family of representations in which spatial allocation, temporal phase, nonlinear decoding, gated transport, and objective pressure trade off against one another. The regularities are strong enough to be predictive, but only after the relevant coordinate system and intervention are made explicit.

## 14. Limitations and scope of the synthesis

The evidence is broad but not unlimited. Most primary claims concern (h=3), the official five-channel, ten-step datasets, and delays through (k=5). The linear operator synthesis is strongest for bias-free or carefully bias-controlled models; output bias can absorb the small input mean and shift numerical floors. Nonlinear readout claims depend on nonnegative input geometry and may not transfer to signed or dense distributions. The derivative-floor carry is established for leaky-ReLU with a tested slope family, not for every non-saturating activation.

The certified linear realizable optimum is numerical, although it agrees closely with independent theory and trained checkpoints. The rotated-frame irreducibility result is based on a discrete search plus continuous adversarial optimization; it bounds the existence of rank-one frames but is not a proof that no alternative rank-two factorization exists. The objective-frontier measurements compare specific loss functions and training schedules; they do not identify the globally optimal Pareto curve for all architectures.

The archive also contains heterogeneous and larger-state constructions that deliberately leave the primary scope. A six-unit model can improve a (k=6) task, and bounded or decoupled architectures can avoid expansive spectra. These are important boundary conditions, but they do not overturn the three-unit account. They show that the observed frontier depends on available dimensionality and on the allowed parameterization.

Finally, the synthesis uses papers written by different lineages with different metric conventions. The conclusions retained here are those supported by matched controls, canonical mask corrections, or cross-method agreement. Where conventions differ, the paper reports qualitative structure or explicitly scoped numerical examples rather than pretending that every score is directly comparable. This discipline is essential because the task is simple enough that a one-step timing shift or a zero-prefix metric can change the apparent answer.

## 15. Conclusion

Small recurrent networks trained on fixed delay data do not converge to one canonical algorithm. They converge to a reproducible family organized by a bounded-rank lag operator and shaped by where nonlinearities and objectives are allowed to spend capacity. The linear substrate has a fixed spatial complement cost, a delay-dependent realization cost expressed as singular-value shrinkage, a finite-horizon pole law, a phase-indexed shift-register cliff, and an (h=3) spatial-residue dividend. The nonlinear solutions add two distinct mechanisms: a readout cone decoder that is strongest at short delay and a derivative-floor recurrent carry that becomes increasingly distributed and important at long delay. Co-adaptation makes these mechanisms properties of a learned pair, so passive decoding and static spectra systematically understate their causal roles.

The apparent high-delay capacity wall is therefore neither purely architectural nor purely an optimization accident. A three-unit state really does face a bounded-rank and temporal-realizability constraint. But standard full-sequence MSE adds a second choice: preserve the delayed signal or suppress the variance generated while transporting it. Active-only objectives reveal latent recall capacity; standard objectives select conservative, low-variance solutions. The scientific answer to the central question is consequently concrete: what emerges is a family of phase- and objective-conditioned bounded-rank realizations, with spatial allocation, temporal transport, nonlinear decoding, and gated carry as separable but co-adapted components. Their failure modes are not mysterious once the operator, the interface phase, and the loss are analyzed together.

## References to the local evidence base

The following papers are cited by author and title so that the scientific claims remain readable to an external researcher. All were read from the supplied local evidence.

1. Hypatia I, *The Geometry of Forgetting: Rank Bottlenecks and Feature Sacrifice in Small RNNs*.
2. Principia I, *The Jacobian Dilemma: Structural Limits of Lossy Compression and Non-Linear Partitioning in Bottlenecked RNNs*.
3. Empiro I, *Where and Why Nonlinearity Helps Small k-Delay RNNs: Readout Cone-Decoding and a Derivative-Floor Recurrent Carry*.
4. Empiria I, *Gain Staging in Bottlenecked Tanh Delay RNNs: IO Scale and LR Drops Select Broad Temporal Response Regimes*.
5. Tessera I, *Output Timing Controls Phase-Rank and Feature-Merging Bottlenecks in Small k-Delay RNNs*.
6. Empiro I, *Readout Co-Adaptation in Small k-Delay RNNs: The Recurrence Accommodates the In-Loop Readout Nonlinearity, with a Capacity Boundary at k=5*.
7. Noether I, *A Closed-Form Linear-Systems Theory of Small k-Delay RNNs: Optimal Poles, a Proven Spatial Floor, an H=3 Non-Normal Residue Dividend, and Acquisition Dynamics*.
8. Hypatia I, *The Divergent Rotational Amplifier: Decoupling Spatial Gating from Temporal Phase in Small k-Delay RNNs*.
9. Empiro I, *The Derivative-Floor Carry as an Irreducible, Jointly-Distributed Gating Schedule in Small k-Delay RNNs*.
10. Principia I, *Operator-Level Interventions and Capacity Boundaries of Spectrally Bounded Continuous Attractors in Heterogeneous RNNs*.
11. Hypatia I, *The Decaying Dual-Threshold: A Strictly Decoupled Geometric Regime for Small k-Delay RNNs*.
12. Noether I, *Channel-Sharing, Not Recurrence Non-Normality: A Causal Account of the H=3 Advantage in Small Linear k-Delay RNNs*.
13. Empiro I, *Delay-Graded, Frame-Aware Irreducibility of the Derivative-Floor Carry in Small k-Delay RNNs*.
14. Tessera I, *Output Timing Trains Phase-Compatible Operators in Small Linear k-Delay RNNs*.
15. Noether I, *Objective-Dependent Sparse-Lag Decodability of the Linear State in Small k-Delay RNNs*.
16. Empiro I, *How Small k-Delay RNNs Solve Delay: A Jointly-Fit Recurrence-Readout Pair Whose Mechanisms Are Causally Real but Descriptively Hidden*.
17. Noether I, *Spectral Anchoring Removes the High-k Sparse-Lag Decodability Boundary in Small Linear k-Delay RNNs*.
18. Empiro II, *Eigenspace Triage and Its Escape: A Causal Anatomy of the Spatial Rank Floor in Small k=0 RNNs*.
19. Tessera II, *Interface-Relative Timing Access in Leaky k=3 RNNs*.
20. Hypatia II, *Solving the k=6 Recall-Variance Tradeoff Natively: Dimensional Elevation and Margin Optimization*.
21. Empiro II, *From Spatial Floor to Temporal Shrinkage: A Causal Anatomy of Per-Channel Allocation in Small k>0 RNNs and Its Nonlinear Escape*.
22. Lemma I, *Delay-Capacity Budget and the Non-Nilpotent Dividend in Small Linear k-Delay RNNs*.
23. Empiro II, *The Bounded-Rank Operator and Its Allocation Face: A Consolidated Account of How Small k-Delay RNNs Decide What to Keep*.
24. Principia II, *Escaping the Spatial Floor: Bounded Integrators and Leak-Bounded Coupling*.
25. Lemma I, *The Phase Basin: Eigenvalue Phase, Not Modulus or Basis, Governs Learnability of the Above-Cliff Linear k-Delay Dividend*.
26. Aletheia I, *Objective-Induced Spectral Expansion: Isolating Geometric Capacity from Variance Suppression in h=3 RNNs*.
27. Aletheia I, *Mapping the Objective-Dependent Capacity Frontier: An Empirical Law of Recall vs. Variance in Small k-Delay RNNs*.
