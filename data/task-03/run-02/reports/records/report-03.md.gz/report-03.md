# What Small Recurrent Networks Learn When They Must Wait

## Capacity, higher-order escape, algorithm selection, and failure boundaries in fixed k-delay tasks

### Abstract

Small recurrent neural networks trained on fixed delay tasks provide an unusually transparent setting for studying learned computation. The input and output dimension is five, the sequence length is ten, and the principal hidden-state budget is at most three units. The target at time (t) is the input from (k) steps earlier, with zero output during the first (k) positions. This paper synthesizes the complete experimental record available for this task family: optimized linear baselines, nonlinear recurrent checkpoints, controlled input distributions, architecture comparisons, hidden-state interventions, lag-response measurements, and persistence analyses.

The central conclusion is that training does not produce one canonical “delay solution.” It selects among algorithmically distinct families under a capacity and optimization bottleneck. At second order, the recurrent state behaves as a depth-(k) compressed buffer. The effective number of preserved input dimensions is (p\approx\min(d,h/k)), where (d=5) and (h) is hidden size; this law predicts optimized linear reconstruction floors with mean absolute relative error about 0.03, compared with about 0.28 for a naive rank-(h) account. Nonlinear tanh networks can move below this covariance-controlled floor, but only by exploiting higher-order structure in the inputs. That escape is not one scalar phenomenon. Its reachability, depth, and training time are partly independent: the deepest escape occurs at (k=4), even though the additional time between reaching the linear floor and entering the nonlinear regime is shortest there.

Several results identify the conditions and mechanisms of this escape. Exactly silent timesteps are necessary in controlled sparse families; below a delay boundary near (k=4), low instantaneous spatial rank and event separation further gate whether an escape is found. At high delays, successful tanh solutions use a strongly non-normal, super-unit recurrent operator whose raw spectral radius is roughly 2.5–2.8, while saturation stabilizes the finite-horizon trajectory. A complementary low-gain, rank-(k) delay-line algorithm is representationally available at (k=4), concentrates nearly all input-output sensitivity at the target lag, and is retained when rank is held fixed. Yet from the same initialization, unconstrained training grows rank within roughly ten steps and selects the high-gain algorithm instead. This is an optimization-selection boundary, not simply a representational impossibility.

The high-delay signed regime adds a second set of distinctions. In (k=5,h=3) tanh networks, sparse positive support helps formation, weak signed seeds fail mainly through finite-horizon transport rather than absent event detection, and successful paths tolerate much natural sparse traffic while remaining vulnerable to selected collisions. Under the tested signed distribution, those dramatic collision cases are rare and contribute little total error; isolated-event transport weakness dominates. Gated architectures can stabilize high-delay transport but introduce parity and origin-cusp costs on balanced signed data. Radial, symmetry-preserving gates and additive phase-plane nonlinearities mitigate some of these costs, although their success remains architecture- and horizon-specific.

Taken together, the results support a layered account. The task imposes a depth-dependent state-capacity law. Input silence, spatial rank, and event spacing determine which higher-order solutions are reachable. Early optimization forms a recurrent operating point; the exact linear-floor solution is a metastable trap; and the optimizer then selects a recurrent algorithm, often favoring a high-gain non-normal route over an available exact-rank delay line. At test time, the resulting solution has a finite transport horizon and distribution-dependent robustness. The strongest general lesson is methodological as well as mechanistic: capacity, formation, escape, selection, robustness, and natural error contribution are different estimands and must not be collapsed into one score or one causal story.

## 1. The question and the experimental organism

The task is a family of supervised sequence problems indexed by a delay (k\in\{0,1,2,3,4,5\}). Each example is a length-ten sequence with five input channels. If (x_t\in\mathbb{R}^5) is the input at time (t), the desired output is

\[
y_t=\begin{cases}
x_{t-k}, & t>k,\\
0, & t\le k.
\end{cases}
\]

The supplied data contain 10,000 examples for each delay. The task is deceptively small. A five-dimensional vector must be retained while several later vectors enter the recurrent state, and the hidden state in the primary scientific scope has only one, two, or three coordinates. The task therefore forces a recurrent model to make a visible decision about what to preserve, what to compress, and how to transport information through time.

The research question is not merely whether a model obtains a low mean squared error. It is: **when small recurrent networks are trained on fixed delay datasets, what reproducible solution structures emerge in their parameters, dynamics, and failure modes?** Answering this requires comparing intermediate checkpoints, activations, hidden sizes, delay values, input distributions, and architectural constraints under a common measurement framework. A final loss alone cannot distinguish a clean delay line from a distributed high-gain transport mechanism, nor can it reveal whether a poor score reflects a missing representation, an optimization barrier, a late checkpoint, or a rare failure context.

The archived studies provide an unusually rich record for this purpose. They include direct linear optimization, many-seed tanh training, Gaussian covariance-matched nulls, synthetic sparse families, rank-constrained recurrent matrices, gated cells, signed and unsigned data, finite-difference lag-response probes, Jacobian and trajectory decompositions, event-level error censuses, and constrained continuation from intermediate checkpoints. The present paper treats those studies as one cumulative experiment. It does not report a new training run.

Two principles govern the synthesis. First, numerical claims are reported only when they are tied to a defined estimator and a stated scope. Second, interpretations are separated from measurements. For example, a lag-response concentration of 0.999 is a measurement; calling the corresponding operator a delay-line algorithm is a justified interpretation because the response is concentrated at the target lag; calling it the unique mechanism of every successful model would exceed the evidence.

## 2. Data structure, model classes, and measurement conventions

### 2.1 The data are sparse, full-rank, and non-Gaussian

The official input covariance is approximately isotropic and full rank in the five feature dimensions. The per-element variance is about (0.0083), and the temporal covariance is close to white. At the same time, the empirical distribution is far from Gaussian: approximately 97.5% of entries are zero, and measured excess kurtosis is around 66 (with featurewise maxima near 68). Thus the task contains two distinct resources. Its second-order structure is simple and nearly isotropic; its higher-order structure is extremely sparse and heavy-tailed.

This distinction is essential. An optimized linear recurrent model depends only on second moments of the input-output distribution. A nonlinear model can use higher moments, but only if its dynamics and objective make those moments useful. The same dataset can therefore support a strong linear-capacity statement and a separate nonlinear escape statement without contradiction.

### 2.2 Recurrent models and controls

The primary model is a no-skip Elman recurrent network,

\[
h_t=\phi(Ah_{t-1}+Bx_t+b_h),\qquad \hat y_t=Ch_t+b_y,
\]

with (h_0=0), input and output dimension five, and (phi) equal to the identity or tanh. Most mechanistic claims concern (h\le3). Hidden sizes up to six or seven are used as auxiliary controls for capacity and rank, not as a replacement for the small-state regime. Gated recurrent cells, parity-preserving gates, and constrained phase-plane cells are architectural contrasts.

The archive uses several complementary baselines:

* **Optimized linear floors.** Each ((h,k)) cell is optimized with multiple random restarts, often followed by full-batch polishing. In nonlinear-escape studies, the floor is locked before checkpoint comparisons.
* **Covariance-matched Gaussian controls.** These preserve the complete measured space-time covariance while removing higher moments. A genuine higher-order escape should disappear.
* **Synthetic sparse controls.** Event rate, marginal variance, covariance, kurtosis, temporal silence, and instantaneous spatial rank are varied independently where possible.
* **Matched architecture and schedule controls.** Linear versus tanh, tanh versus GRU, rank-held versus rank-free, and different loss weightings are compared with the relevant optimizer, hidden size, and checkpoint schedule held fixed.
* **Intermediate checkpoints.** Claims about learning dynamics use dense or staged checkpoint measurements, not only final states.

### 2.3 A common vocabulary of estimands

The archive repeatedly shows that words such as “capacity,” “escape,” and “reachability” are overloaded. The synthesis therefore uses the following distinctions.

**Second-order capacity** is the best reconstruction achievable by a linear recurrent model under the task distribution. **Escape depth** is the improvement below a locked linear floor, estimated with matched selection to avoid favoring the harder-to-optimize nonlinear model. **Reachability** asks whether training finds such a solution at all; it is not the same as the depth achieved after a solution is found. **Formation** concerns the early operating regime created during optimization. **Selection** concerns which recurrent algorithm is chosen when more than one is available. **Persistence** asks whether a checkpoint label survives a longer training horizon. **Conditional robustness** asks what controlled perturbations damage a learned path. **Natural relevance** asks how frequently those perturbations occur and how much total error they contribute under a specified distribution.

These distinctions make apparently conflicting findings compatible. A rare collision can be highly damaging in a controlled probe but contribute little to population error. A solution can be representationally available under a rank constraint but not selected by unconstrained training. A checkpoint can be transport-dead at step 2,000 and successful at step 8,000. Each statement is true only for its estimand.

## 3. The second-order bottleneck: a delay is a compressed buffer

### 3.1 Why the naive rank argument fails

A static rank argument says that an (h)-unit recurrent state can expose at most (h) linearly independent directions at the output. That intuition is adequate for a one-step or zero-delay projection, but it ignores the pipeline. During a (k)-step delay, several input vectors are simultaneously in flight. The recurrent state must distribute its coordinates across those pending vectors, not devote all (h) coordinates to the vector that will be emitted next.

The archived state-capacity study formalizes this as an effective preserved-dimension law,

\[
p=\min\left(d,\frac{h}{k}\right),
\]

with the predicted linear reconstruction error

\[
\mathrm{MSE}_{\mathrm{floor}}\approx
\frac{T-k}{T}\left(d-p\right)\sigma^2.
\]

Here (d=5), (T=10), and (sigma^2) is the per-coordinate input variance. The expression is best viewed as a close predictor or upper-bound-like law at fractional (h/k), not an exact algebraic identity in every cell. At integer ratios it is particularly tight.

### 3.2 Quantitative validation

Across the primary grid (h\in\{1,2,3\}), (k\in\{0,\ldots,5\}), the state-capacity predictor achieved mean absolute relative error about 0.032 against thoroughly optimized empirical linear floors. The naive rank-(h) predictor had mean absolute relative error about 0.277. For the binding (h=3,k>0) cells, the naive relative error was about 0.42 while the state-capacity error was about 0.032. Auxiliary hidden sizes provided an out-of-sample check: for (h\in\{4,5,6\}) and (k\ge2), state-capacity MARE was about 0.050, versus about 0.912 for the naive predictor, with non-overlapping bootstrap intervals.

The law also predicts saturation. When (h/k\ge d), the model can preserve all five dimensions in principle, and cells such as (h=5,k=1) and (h=6,k=1) reached near-perfect reconstruction, with MSEs on the order of (10^{-4}). At fractional ratios the inferred preserved dimension can sit slightly below (h/k), so the law should not be read as a literal guarantee of exact equality.

### 3.3 Mechanistic evidence for a depth-(k) buffer

Several measurements support the buffer interpretation. Linear decodability probes applied to hidden states found that the total decodable dimension summed across past lags is close to (h), with mean absolute deviation from (h) around 0.27 in the main free-readout analysis. The state is therefore not storing (k) complete five-dimensional vectors; it is allocating a finite budget across a sequence of partially preserved directions. The recurrent spectral radius rises with delay, with mean maximum eigenvalue magnitude roughly 0.09, 0.60, 0.73, 0.94, and 1.13 for delays one through five in one linear analysis. Longer delays demand greater persistence, and at the highest delays the finite optimization horizon becomes difficult even for the linear model.

The clean shift-register picture is useful but not universal. Some free-readout linear solutions use a current-input pathway or alternative coordinate choices, producing a lag-zero impulse peak while achieving comparable loss. Removing the direct pathway moved the peak toward lag (k) in most but not all cells. This is a reminder that the capacity law is more robust than any one parameterization or eigenvalue geometry.

### 3.4 The second-order/higher-order divide

The linear floor is covariance-controlled. A covariance-matched Gaussian surrogate reproduced official linear floors within optimization noise, with absolute differences around (10^{-4}) on floors of order (5	imes10^{-3}). The official data’s extreme kurtosis is invisible to the linear optimum. Therefore any tanh improvement below the linear floor must use higher-order structure.

This result resolves an early apparent disagreement. Conservative best-of-initialization analyses sometimes found no robust tanh advantage in individual cells, whereas broader many-seed studies found a small advantage at high delays. Both can be true: the nonlinear improvement is small, seed-dependent, and higher-order. The linear h/k law defines the second-order baseline; the escape is a separate, distribution-sensitive correction.

## 4. When nonlinear escape is reachable

### 4.1 Escape depth, reachability, and timing are different axes

The archive’s most careful escape measurements use matched-selection estimators. If the (i)-th ordered linear and tanh minima are (L^{\mathrm{lin}}_{(i)}) and (L^{	anh}_{(i)}), a matched estimator compares them at the same selection order, so the greater optimization difficulty of tanh does not automatically look like extra escape. Gaussian-null controls should show zero escape; linear models cannot enter a genuinely higher-order phase.

Three axes then separate:

1. **Reachability:** whether a seed finds the nonlinear solution.
2. **Depth:** how far its final loss lies below the linear floor.
3. **Timing:** when the escape appears during training.

The measured pattern is non-monotonic in delay. At (h=3), corrected escape is near zero at low delay and clearly positive at (k=4) and (k=5). Yet the timing gap between reaching the floor and entering the nonlinear phase is about 160 steps at (k=3), 60 at (k=4), and 100 at (k=5) under one staged protocol. The deepest escape occurs at (k=4), which has the shortest gap. Thus “harder” does not mean “later” in a single scalar sense.

The timing result is reinforced by checkpoint trajectories. Tanh first descends toward the linear floor, then enters a second learning stage. Linear controls never enter it. On covariance-matched Gaussian data, no resolved official-like phase-two onset appears at (k=3) or (k=4); a tiny late (k=5) positive value is only a few tenths of one percent of the official escape and is treated as a control imperfection rather than a genuine higher-order effect.

### 4.2 Input-side conditions: silence and spatial rank

The most decisive input controls separate temporal silence from instantaneous spatial rank. Synthetic events were constructed so that per-channel variance, activation rate, marginal kurtosis, and covariance were held fixed while the number of simultaneously active channels varied. This isolates the geometry of an event from its one-dimensional marginals.

Exactly silent timesteps were necessary for escape in every tested regime. Sparse-and-silent families escaped; dense low-rank families with no silent timesteps did not; replacing silent timesteps with small noise abolished escape; and a dense Student-t control with even higher kurtosis but no silence also failed. Silence is therefore not a synonym for high kurtosis. It is a dynamical condition that creates intervals in which the recurrent state can evolve without a new input injection.

Spatial rank matters differently by delay. Below a boundary near (k^*=4), low-rank events are more favorable: at (k=1) and (k=3), single-channel events escaped more often than full-rank events despite matched covariance and marginal moments. At and above (k=4), that rank gate dissolves; escape becomes widespread and comparatively insensitive to the number of active channels. A predictor using delay, spatial rank, and temporal sparsity outperformed kurtosis-only and rank-only predictors in leave-one-out validation. Temporal sparsity was the strongest individual feature.

The interpretation is a two-regime demand law. Below the onset, the recurrent state can handle the delay linearly for some event arrangements, and nonlinear escape is recruited selectively when low spatial rank reduces interference. At or above the onset, the delay itself exceeds the second-order state capacity, so escape is recruited across a broader range of event geometries. This is an input-side complement to the hidden-state capacity law.

### 4.3 Event separation adds a capacity-load axis

Controlled two-event families hold amplitude, event count, marginal variance, and covariance fixed while varying temporal separation (s). At (k=3,h=3), escape depth increased with separation at slope about 0.0411 per step, with a bootstrap interval [0.0372, 0.0443]. At (k=3,h=2), the slope was about 0.0253 [0.0224, 0.0277]. At (k=4,h=3), the slope was about 0.0018 with an interval spanning zero: escape was already recruited at small separation and then saturated.

Same-channel events interfered more than different-channel events at matched separation. At (k=3), for example, depth at separation two was about 0.0322 for same-channel events versus 0.0083 for different-channel events; at separation three it was about 0.0734 versus 0.0482. A single isolated event at (k=4) escaped more deeply than two co-channel events, indicating that adding a second event can increase representational load rather than simply add useful signal.

These results are evidence for an input-demand axis, not a proof that the recurrent state implements a literal event queue. The controlled channel manipulation supports representational interference; observational collision counts in the official data were not used as a substitute for that causal contrast.

## 5. The dynamics of formation and the barrier at the floor

### 5.1 Formation is an early optimization phenomenon

The recurrent operating point is summarized by the root-mean-square recurrent preactivation. If (a_t=Ah_{t-1}+Bx_t), the full operating point is the RMS of (a_t); decomposed measurements separately track the recurrent term (Ah_{t-1}) and input drive (Bx_t).

At (k=3), the operating point measured when a run first approaches the floor is nearly invariant across a roughly 19-fold range of initialization scales, even though the step-zero RMS tracks initialization with correlation 0.9996. The range-collapse ratio is around 0.09–0.13. A covariance-matched Gaussian control shows a similar collapse. The direct measurement is therefore that the early training trajectory forms a common operating band rather than simply inheriting its initial scale.

This conclusion has a bounded optimizer scope. A heavy-ball momentum method with momentum 0.99 and learning rate 0.5 also reached the (k=3) floor and formed operating points in the same approximate 0.077–0.093 band over central initialization scales. Plain SGD did not cross within budget, and extreme initialization made momentum training unstable. The robust claim is not universal optimizer-independence; it is that operating-point formation is not merely an AdamW artifact in the tested central regime.

At (k=4), the first-crossing distribution develops a heavy upper tail rather than a clean single band. The distribution is not convincingly bimodal; a formal dip test was unimodal with (p=0.395). The correct description is an onset-specific heavy tail, not a second discrete phase of initializations.

### 5.2 The exact floor solution is a metastable trap

A cold-started tanh network can reach the linear-floor loss and continue improving. A network initialized at a specially constructed minimal-drive exact linear-floor solution does not spontaneously do so. It remains near that parameterization until recurrent preactivation rises past a threshold. The floor loss level is therefore not itself a trap; the trap is a particular solution geometry that realizes the floor with minimal drive.

This matters for interpreting staged training. The optimizer’s visit to the floor is not evidence that the linear solution is the final objective. It is a waypoint. A nonlinear escape requires crossing a barrier in parameter space, and the barrier is attached to the exact floor-solution manifold rather than to the scalar loss alone.

### 5.3 Operating point and spectral gain: an estimand-dependent bridge

The recurrent operating point and the learned spectral radius are related, but no single correlation summarizes the relation. Along a single (k=4) training trajectory as normalized floor progress (S) rises from 0.1 to 0.9, recurrent-only operating point and spectral radius co-move positively, with Spearman correlation about +0.47 [0.40, 0.54]. A same-checkpoint endpoint diagnostic gives an even larger recurrent correlation around +0.86 [0.80, 0.90], while the input term is weaker.

Across seeds, however, the operating point at first floor crossing trades off against the final spectral radius. The pooled (k=4) analysis gives recurrent-only Spearman about −0.27 [−0.38, −0.14], surviving within-initialization-scale residualization at about −0.32 [−0.45, −0.19]. The input-drive correlation is weaker. An earlier single-scale analysis suggested that the negative relation was carried by input drive; the larger pooled analysis overturned that reading. This self-correction is important: the relation is a recurrent-operator phenomenon, but its sign depends on whether one asks about movement within a trajectory or variation across seeds.

The safest interpretation is not “coupled” or “decoupled.” The recurrent operator carries a within-run co-movement and an across-seed endpoint tradeoff. These are distinct estimands and should be reported separately.

## 6. Two delay algorithms and the selection boundary

### 6.1 The low-gain delay line

The recurrent operator studies identify two qualitatively distinct solution families. The first is a low-gain, near-nilpotent rank-(k) delay line. It is not merely a low spectral radius. Finite-difference input-output Jacobians measure the energy of response at each lag,

\[
C_k=\frac{E_k}{\sum_j E_j},\qquad E_j=\left\|\frac{\partial y_{t+j}}{\partial x_t}\right\|_F^2.
\]

Rank-held (k=4) solutions have median target-lag concentration (C_k\approx0.9996), with the peak at the target lag in 97% of seeds. Comparable high-gain solutions have (C_k\approx0.025)–0.030 and peak at the target lag in only about 6–9% of seeds. At (k=3), the distinction is quantitative rather than absolute: the low-gain family has (C_k\approx0.999), while the high-gain family has about 0.84. At (k=5), neither tested family recovers clean lag concentration.

The low-gain family is therefore a genuine algorithm: a concentrated lag-(k) transport line. Its near-nilpotent character is a parameter-level signature of the same algorithm, not the definition by itself.

### 6.2 The high-gain non-normal algorithm

The second family uses a strongly non-normal recurrent matrix with raw spectral radius around 2.5–2.8 at (k=4) and (k=5), compared with a linear radius near 0.97 at (k=4) and above one at (k=5). The tanh network’s operator norm is larger still, roughly 4–5.7 in the high-delay cells. Raw super-unit gain would be unstable under repeated linear iteration, but tanh saturation constrains the realized hidden trajectory. De-saturating a trained network caused errors on the order of (10^5); clamping the spectral radius degraded performance; and the realized hidden norm was only about 5% of the unsaturated prediction in one high-delay intervention.

The learning sequence is itself structured. Raw gain is built during the first phase, before the linear floor is reached; saturation is recruited afterward, and it engages only after the nominal (k)-step transport window. A modal ablation suggests that tanh concentrates target-lag transport in a single super-unit mode, while the linear model distributes transport across modes. These findings explain how a network can use a super-unit raw operator without simply diverging: the nonlinear state spends the finite horizon in a saturation-stabilized, non-normal transient regime.

### 6.3 Available but not selected

The decisive selection experiment begins both arms from an identical functional rank-(k) recurrent matrix. In the held arm, the rank-(k) factorization is maintained. In the freed arm, the same initial operator is represented as a full matrix and can grow rank. At (k=4), the held arm retains the low-gain family in 0.875 of seeds [0.719, 0.950], with median spectral radius about 0.283. The freed arm retains it in only 0.031 [0.006, 0.157], with median radius about 2.031. Rank growth above (k) occurs within roughly ten steps in essentially every freed seed and precedes the high-gain crossing.

This is the strongest evidence that the (k=4) transition is not simply a representational impossibility. A functional low-gain delay line is available under a rank-matched parameterization, but unconstrained training does not select it. The most defensible mechanism is implicit optimization bias: surplus-rank directions provide early descent routes toward a broader high-gain basin, while the exact-rank delay-line manifold is thin or poorly conditioned. The experiment does not isolate rank from parameterization, so “selection boundary” is more accurate than a claim that rank alone causes abandonment.

An annealed soft penalty provides an important refinement. It can shape the recurrent operator toward low gain and target-lag concentration, but joint training then fails to find the readout that realizes the floor at (k=4). When the shaped operator is frozen and the best linear readout is solved in closed form, the measured linear floor is recovered. The boundary therefore moves from operator representational insufficiency to readout-optimization and operator/readout coupling, within the tested regime.

At (k=5), no tested rank from one through six in hidden sizes up to seven recruited a functional low-gain route under the tested schedule. This is not a theorem that no such route exists; it is a robust negative over the tested ranks, schedules, and horizon.

## 7. Geometry, latching, and architecture

### 7.1 The non-normal saddle and the shattered high-delay regime

Trajectory perturbation studies give a geometric account of the high-gain route. During exact-zero input windows, the hidden trajectory spans a local subspace. Perturbations can be decomposed into a radial component, which changes amplitude, and a tangent component, which changes phase or position along the learned manifold. Successful low-delay escape can transiently amplify radial perturbations while contracting tangent perturbations. At (k=4), the required radial amplification becomes so large that it bleeds into the tangent direction; a tangent multiplier measured over a four-step window exceeded 5.7 in one study. The resulting “shattered saddle” loses phase stability and makes finite-horizon transport fragile.

This geometric synthesis is compatible with, but not identical to, the raw spectral account. A raw spectral radius, a finite-time Jacobian multiplier, and a lag-response concentration answer different questions. The archive did not establish a complete reduction of signed (k=5) collision damage to the tangent/radial decomposition, so the correct relation is complementary evidence, not a single proven mechanism.

Earlier latching work identified globally contractive and switching latching patterns in nonlinear cells. The more stable interpretation across studies is that useful solutions alternate between input-conditioned expansion, which writes a detectable event into the state, and contraction, which preserves the event while suppressing irrelevant perturbations. Initialization scale alone does not deterministically force one mechanism.

### 7.2 Gating helps one boundary and creates another

Explicit gating can stabilize high-delay transport. At (k=4), GRU-like cells substantially outperform plain tanh models under matched comparisons, consistent with gates decoupling amplitude preservation from phase direction. Yet gating does not restore the clean low-gain delay line: matched GRU cells still show high effective-Jacobian gain and distributed lag responses.

On balanced signed data, monotonic gates face a different problem. A gate based on a one-dimensional signed projection can close near the origin when an event reverses sign. This origin-cusp or parity-exhaustion mechanism produces a plateau in active normalized error around 0.74. A parity-preserving radial gate with a multidimensional quadratic pool improves the (k=5,h=3) active normalized error to about 0.714. Clamping its gate during opposite-sign transitions degrades error to about 0.745–0.758 and causes a 61.9% downstream MSE spike. Restricting the quadratic pool to one or two dimensions also returns the plateau, while a six-dimensional pool maintains a larger nonzero preactivation margin. These interventions support a causal role for avoiding gate closure, but they are bounded to the tested checkpoint family and can introduce out-of-distribution states.

### 7.3 Additive phase-plane nonlinearities

A separate constructive study fixes all biases to zero to enforce odd symmetry and compares multiplicative energy modulation with an additive nonlinear phase-plane expansion. In a constrained (h=3,k=4) signed family, a linear block-triangular phase plane reaches active normalized error around 0.86. Multiplicative modulation worsens it to about 0.91, suggesting that modulating the energy of an existing orbit destroys the superposition of older pulses. An additive nonlinear term that actively warps the two-dimensional phase plane improves error to about 0.66. Restricting the nonlinear write to a one-dimensional envelope collapses performance back toward 0.836. A nonlinear readout briefly reaches about 0.171 at an intermediate checkpoint before degrading, showing that the three-dimensional recurrent core can transiently multiplex a five-dimensional target when the readout is nonlinear.

These results extend the algorithm-selection picture without replacing it. Architectural symmetry and additive state warping alter which solution families are accessible. They also show that apparent capacity floors can have multiple sources: recurrent memory, readout linearity, gate topology, and optimizer stability.

## 8. Sparse-event transport at (k=5): formation, delivery, robustness, relevance

The high-delay signed regime requires a more granular analysis than final MSE. A four-axis synthesis of (k=5,h=3) tanh models separates formation, isolated transport, conditional robustness, and natural relevance.

### 8.1 Formation under sparse positive support

Official positive sparse support strongly favors nonlinear target-lag emergence. Covariance-matched Gaussian controls remove most of the tanh advantage; sparse marginal controls restore much of it; and balanced random signs reduce active reconstruction, target-lag fraction, and seed reliability. In one aligned panel, unsigned positive models achieved mean active (R^2=0.1795) and target-lag fraction 0.5556, whereas balanced signed models achieved active (R^2=0.0863) and target-lag fraction 0.2382.

The inference is that successful high-delay tanh models use higher-order event structure, not merely covariance. This does not mean positivity is universally necessary. Other controlled families show that sign-symmetric sparse inputs can escape when temporal silence and suitable spatial structure are present. The robust statement is narrower: in the official (k=5) all-MSE regime, positive sparse support is a strong formation aid and balanced signs make the successful basin harder to find.

### 8.2 Weak signed seeds detect events but fail to deliver them

Weak balanced-sign seeds often show immediate hidden displacement after an event but weak lag-five hidden norm, weak delayed readout alignment, and low selectivity. Replacing the readout algebraically can rescue a response if a favorable delayed hidden displacement is supplied, but perturbing the immediate target-aligned state does not dynamically create that displacement. Both target and off-target readouts are small, ruling out a simple explanation in which the event is merely routed to the wrong output feature.

The direct measurement is therefore a finite-horizon transport failure. The network notices or perturbs its state at the event time but does not reliably transform that perturbation into a delayed, sign-consistent target output. Bounded reachability searches support this interpretation, but they do not prove an impossibility theorem.

### 8.3 Successful paths are sparse-manifold robust, not silence brittle

Successful paths tolerate much natural sparse traffic. One natural collision retained about 0.9207 of the isolated transport response, and two retained about 0.8437. Dense Gaussian filler, by contrast, reduced retention to about 0.5865. Targeted early same-feature collisions can still cause substantial damage, particularly under balanced signs. Hidden trace decompositions show immediate collision perturbations, with orthogonal disruption emphasized in signed cases and anti-aligned cancellation more prominent in positive cases.

The right description is therefore sparse-manifold robustness. The learned path is not an exact-silence automaton that fails at every nonzero input; it is a finite-horizon transport manifold adapted to sparse traffic. Its robustness boundary depends on amplitude, density, timing, sign, and feature overlap.

### 8.4 Natural error is dominated by isolated events

The natural relevance census makes the most important correction to a purely mechanistic reading. In a held-out official-support balanced-sign panel, early same-feature opposite-sign collisions occurred in 5 of 313 active scalar source events, frequency 0.0160 with Wilson interval [0.00684, 0.03684]. Isolated events occurred in 250 of 313, frequency 0.7987 [0.7508, 0.8394]. In successful signed seeds, the collision class contributed only 0.0154 of active-event error, while isolated events contributed 0.7923. Weak seeds had elevated isolated-event MSE, about 0.3184 versus 0.2572 in successful seeds.

At the observed collision frequency, conditional collision MSE would need to be multiplied by roughly 5.8–6.5 to explain even 10% of total active-event error, and by roughly 29–33 to explain half. The collision vulnerability is real, but under this distribution it is a tail boundary. The dominant population-level failure is global or isolated finite-horizon transport weakness.

This result generalizes as a methodological rule. A controlled perturbation identifies what can break a path. A natural error census identifies what does break it often enough to matter. Neither substitutes for the other.

## 9. Objectives and failure labels also select solution families

The all-timestep objective is not neutral on sparse data. In high-delay cells only about 2.5% of active target entries are nonzero. A model can therefore reduce loss by predicting zeros, even while missing rare delayed events. Event-weighted losses reveal a Pareto family rather than a universal improvement.

In a ten-seed (k=5) synthesis, an event weight of 0.10 improved tanh AUPRC from about 0.227 to 0.278 and F1 from about 0.295 to 0.382, while active MSE increased from 0.00734 to 0.01116 and zero-only MSE increased from 0.00066 to 0.00815. Linear models showed a similar F1/nonzero-MSE improvement but a less consistent AUPRC change. Fully balanced losses improved nonzero-event metrics but produced more false positives and worse zero-entry error.

The conclusion is not that event weighting solves the task. It changes which errors the network is willing to make and therefore which solution family is selected. The original MSE objective favors zero-dominant behavior in some high-delay regimes; event weighting moves along a Pareto frontier toward rare-event recovery. This objective axis must be kept separate from the representational capacity axis and from the nonlinear escape axis.

Checkpoint labels are similarly horizon-dependent. In a (k=5,h=3) signed panel, many seeds labeled transport-dead at step 2,000 became successful by step 8,000. Dense timing analyses did not identify a single independent signature that always preceded recovery. A stronger structural test compared artificial parameter interpolation with constrained continuation. Global straight-line interpolation from delayed to later states succeeded for 15 of 15 seeds, but core-only interpolation succeeded for only 1 of 15 and readout-only for none. When optimization was continued from the delayed checkpoint, core-only updates succeeded for 12 of 15 seeds, readout-only for none, and full continuation for 14 of 15. Successful core branches were far off the natural straight-line core path, with mean orthogonal fraction 0.896, and hybrid endpoints showed that branch cores were compatible with the old readout while natural final cores usually were not.

The inference is precise: straight-line path insufficiency does not imply constrained-update insufficiency. This is another instance of estimand separation. A parameter-space line segment and an optimizer trajectory answer different reachability questions.

## 10. An integrated account of what the networks learn

The findings can be organized as a sequence of constraints and choices.

### 10.1 First constraint: the state is a finite pipeline

The network begins with a hidden-state budget of (h) scalar degrees of freedom. A (k)-step delay distributes that budget over a pipeline, producing an effective second-order capacity of about (h/k) preserved feature dimensions. This is the stable backbone of the entire task family. It explains why linear floors worsen with delay, why spectral persistence rises with delay, and why a naive static rank count overestimates performance.

### 10.2 Second constraint: the input determines whether nonlinear structure is usable

The official distribution provides rare events separated by silent timesteps. Silence creates intervals in which the state can contract, preserve, or reshape an event without an equally strong new injection. Below the onset, low spatial rank and temporal separation reduce simultaneous load; at higher delays, the delay itself forces a broader nonlinear response. Gaussian controls remove the higher-order advantage, and dense heavy-tailed controls show that kurtosis without silence is insufficient.

### 10.3 Third constraint: optimization forms an operating regime before it chooses a final algorithm

Cold-start training first moves toward a floor-like solution. The recurrent operating point at this stage is formed during descent and is relatively insensitive to initialization in central regimes. The exact minimal-drive floor parameterization is metastable. A successful escape requires leaving it, and the nonlinear phase then uses the operating regime to construct a recurrent operator.

### 10.4 Fourth choice: delay-line or high-gain transport

When a rank-(k) delay line is available, it is a clean algorithm with target-lag concentration near one. Yet unconstrained training at the (k=4) boundary grows rank and enters a high-gain, non-normal, saturation-stabilized family. The latter is not merely an imperfect delay line; its lag response is distributed, its raw spectrum is super-unit, and its finite-horizon dynamics exploit nonlinear saturation.

The selection is conditional on architecture, optimizer, parameterization, and horizon. The evidence does not say that high gain is universally optimal or that the low-gain line is globally unreachable. It says that under the tested unconstrained training protocol, the high-gain family is selected even when the low-gain family is available.

### 10.5 Fifth constraint: finite-horizon robustness is distribution dependent

The selected operator must transport information across a finite number of steps. In positive sparse traffic, the learned manifold can be robust. In balanced signed traffic, sign reversals and parity transitions stress gates and non-normal transport. Some collisions are damaging, but natural error can still be dominated by isolated failures because the collision contexts are rare. Longer training can convert an intermediate failure label into a success, and constrained continuation can find parameter states that straight-line interpolation misses.

This account is intentionally layered. It does not claim that all observations reduce to one scalar, one Jacobian, or one phase-space picture. The geometric bottleneck, the h/k law, the operating point, the selected operator, and the natural error census are linked but not interchangeable.

## 11. What is genuinely robust, and what remains conditional

### 11.1 Strongly supported findings

Several conclusions recur across independent protocols and are unusually robust.

* The linear delay problem is governed by an effective (h/k) state-capacity law rather than a static rank-(h) readout ceiling.
* The linear floor is second-order: covariance-matched Gaussian data reproduce it, while nonlinear improvements require higher-order input structure.
* Exactly silent timesteps are necessary for the controlled nonlinear escape families tested here.
* Nonlinear escape is a second learning stage and must be measured against a locked floor with selection bias controlled.
* At (k=4), a functional rank-(k) lag line is available under rank-held training but is not selected by matched unconstrained training.
* High-delay tanh solutions use non-normal, super-unit raw recurrent operators whose finite-horizon behavior is stabilized by saturation.
* In the signed (k=5) regime, isolated or global transport weakness is more important to natural error than the rare early opposite-sign collision class under the tested distribution.
* Objective weighting, architecture, and training horizon change the solution family and can change which failure metric looks favorable.

### 11.2 Conditional findings

Other conclusions are important but deliberately scoped.

The depth of escape increases with hidden size in the tested range, but the exact scaling law beyond that range is unresolved. Gating helps at particular delays but does not universally recover a clean delay line. Positivity is a strong formation aid in the official (k=5) regime but is not a universal requirement for every sparse signed family. The relationship between operating point and spectral gain depends on the estimator. High-gain selection is robust across the tested Elman schedules but not optimizer-general. Radial gates and additive phase planes improve selected signed benchmarks, yet their mechanisms and stability are architecture-specific. Step-2,000 transport-dead labels are not persistent labels, but longer-horizon success does not imply that every intermediate failure has the same cause.

### 11.3 What is not established

The data do not prove a global impossibility theorem for (h\le3) nonlinear networks. They do not show that one geometric saddle is the unique cause of all escape, that raw spectral radius alone predicts performance, or that every successful model uses an identical latching circuit. They do not establish causal control of final performance by the early operating point. They do not show that the low-gain algorithm is impossible at (k=5) in all architectures or under all optimizers. These are productive open questions, not gaps to be hidden by stronger language.

## 12. Implications for recurrent-learning theory

The task offers a useful corrective to several common habits in recurrent-network analysis.

First, “capacity” should be indexed by temporal demand. A state of dimension (h) does not have (h) free dimensions for every delayed vector; it has a pipeline budget. The relevant capacity can be estimated from decodability and lag response rather than from hidden size alone.

Second, the existence of a low-loss state does not tell us which algorithm the optimizer learned. The low-gain line and high-gain operator can have comparable losses but radically different lag-response profiles. Algorithm identification therefore requires input-output dynamical probes, not only parameter spectra.

Third, a nonlinear advantage is meaningful only against a disciplined baseline. Without a locked linear floor, matched selection, and covariance nulls, a claimed escape can be a selection artifact, under-optimization, or a changed objective. The archive’s negative controls are as informative as its positive effects.

Fourth, robustness should be decomposed into conditional and natural quantities. A model can be catastrophically vulnerable to an engineered collision that almost never occurs, or moderately wrong on a common isolated event that dominates total error. Reporting both conditional response and frequency-weighted contribution prevents vivid counterfactuals from being mistaken for population mechanisms.

Finally, learning dynamics and endpoint structure should be measured together. The operating point forms before the final spectral strategy; the exact floor is a trap; intermediate labels can change with horizon; and constrained continuation can discover branches that artificial interpolation misses. A theory that explains only final weights or only final MSE misses the central computational event: how a small recurrent system chooses and stabilizes an algorithm during training.

## 13. Limitations and future tests

The primary scope is narrow by design: five-dimensional, length-ten fixed datasets, hidden size at most three for the main mechanistic claims, and the tested Elman/tanh, linear, and gated architectures. The task distribution is unusual, with extreme sparsity and nearly isotropic covariance. Claims about natural relevance are tied to the specified sparse-support signed process and should not be generalized to arbitrary event streams.

Many experiments use finite seed panels and finite training horizons. The archive addresses this with bootstrap and Wilson intervals, multi-restart floors, matched-selection estimators, and longer schedules, but no finite panel proves universal behavior. Several interventions are hidden-state or parameter-space probes that can move the model off the input-realizable manifold. Such probes are valuable for mechanism discrimination but should not be mistaken for ordinary test-time perturbations.

The matched rank-selection experiment has a parameterization confound: held and freed arms differ in factorization as well as rank freedom. Soft penalties partly address this and reveal a separate readout-trainability boundary, but a single full-matrix parameterization with a continuously annealed rank penalty remains the cleanest next test. Other priority tests are: optimizer comparisons at matched convergence; a joint protocol logging operating point, spectral gain, and lag response on the same trajectories; causal interventions on the phase-one operating point; and systematic tests of whether the three-axis escape account persists at hidden sizes above three.

For signed transport, the key open question is whether the successful radial and additive architectures stabilize a fundamentally different algorithm or merely make the high-gain non-normal route easier to reach. Freezing recurrent cores while optimizing nonlinear readouts, and comparing natural continuation with fixed-readout branch continuation, can separate representation from training instability. At (k=5), longer-horizon and rank-constrained searches should distinguish “not recruited under the tested protocol” from a stronger architectural exclusion.

## 14. Conclusion

Small recurrent networks trained on fixed delay tasks learn more than one thing, and they fail in more than one way. The first layer is a second-order state-capacity law: a depth-(k) delay turns (h) hidden coordinates into roughly (h/k) preserved feature dimensions. The second layer is a higher-order escape: silence, spatial rank, event separation, and non-Gaussian structure determine when tanh networks can move below that floor. The third layer is optimization dynamics: an operating point forms during early descent, the exact linear-floor solution is metastable, and a second learning stage constructs a recurrent algorithm. The fourth layer is selection: at (k=4), a clean rank-(k) delay line exists but unconstrained training grows rank and selects a high-gain, non-normal, saturation-stabilized operator. The fifth layer is finite-horizon robustness: the selected path can be stable on a sparse manifold, fragile under sign and density changes, and naturally dominated by common isolated-event failures rather than rare dramatic collisions.

The answer to the central research question is therefore a structured one. Reproducible learned solutions are organized by the interaction of temporal demand, hidden-state supply, input higher-order structure, operating-point formation, algorithm selection, and horizon-dependent robustness. No single scalar—hidden size, loss, spectral radius, escape depth, or collision response—captures this interaction. The most reliable scientific practice is to state which estimand a measurement supports, lock the appropriate baseline, compare intermediate checkpoints, and preserve the distinctions among what the network can represent, what optimization can reach, what it selects, and what matters under the data distribution.

For an external reader, the practical summary is simple. A small RNN does not first discover a miniature copy of a large delay line and then merely compress it. It learns a sequence of compromises: preserve a limited set of directions, exploit silent intervals, choose a transport operator, and adapt that operator to the statistics of the events it is likely to encounter. The compromises are visible because the task is small enough to inspect, but they are not trivial. A model can be accurate for the wrong reason, inaccurate for a recoverable reason, or apparently fragile only because it is evaluated before its second learning stage. The scientific value of this benchmark is precisely that it makes those distinctions measurable.

## References to the archived studies

The following descriptive titles identify the source studies synthesized here. They are listed by scientific contribution so that the numerical and methodological claims above remain auditable without relying on experiment handles.

1. **The Spatial-Temporal Capacity Bound: Mechanisms of Linear Collapse and Non-Linear Escape in Small Delay Networks.** Foundational spatial/temporal bottleneck and nonlinear folding analysis.
2. **Sparse-Event Objectives Reveal Pareto Solution Families in High-Delay Small RNNs.** Objective-dependent rare-event recovery and zero-entry tradeoffs.
3. **The h/k State-Capacity Law: Reconstruction Fidelity of Small k-Delay RNNs Is Governed by Effective Preserved Dimensions.** Quantitative second-order capacity law and decodability budget.
4. **Dynamical Latching Mechanisms in Sparse-Event Delay Tasks.** Contractive and switching latching mechanisms.
5. **Sparse Positive Events Drive Nonlinear High-Delay Emergence in Small Tanh RNNs.** Formation dependence on sparse positive support and sign balance.
6. **A Bias-Controlled, High-Delay Characterization of the Nonlinear Escape Above the State-Capacity Floor.** Matched-selection escape depth and high-delay concentration.
7. **The Non-Normal Saddle Manifold: Dynamical Geometry of the Nonlinear Escape.** Non-normal saddle and perturbation geometry.
8. **Balanced Signed Events Fail Through Finite-Horizon Transport.** Isolated transport weakness in signed high-delay tanh models.
9. **A Two-Regime Law for Nonlinear Escape: Temporal Silence, Spatial Rank, and the Reachability Boundary.** Controlled silence/rank decomposition and the delay boundary near four.
10. **Collision Routing and Geometric Vulnerability in Gated Recurrent Bottlenecks.** Gated high-delay transport and collision routing.
11. **The Shattered Saddle: Tangent Instability and Geometric Breakdown at High Delay.** Tangent/radial instability at delay four.
12. **Capacity-Linked Escape Depth and the Delay-Dependent Gating Advantage.** Hidden-size dependence and delay-specific gating effects.
13. **Sparse-Manifold Robustness and Collision-Selective Failure in High-Delay Tanh Event Transport.** Controlled filler and collision perturbations.
14. **Parity-Induced Manifold Degradation: The Global Geometric Cost of Monotonic Gating.** Signed-data parity and gating limitations.
15. **Geometric Stabilization of the Shattered Saddle: Explicit Gating at High Delay.** Gate-mediated stabilization of radial/tangent dynamics.
16. **Natural Collision Error Is a Tail Boundary in Signed High-Delay Event Transport.** Frequency-weighted natural relevance census.
17. **Sequential Staging of the Nonlinear Escape.** Intermediate checkpoint evidence for a second learning stage.
18. **A Separation-Dependent Capacity-Load Law for Nonlinear Escape.** Two-event separation and interference controls.
19. **The Geometric Capacity Bottleneck: A Phase-Space Synthesis of Sequence Delay Limits.** Geometry-first synthesis of capacity, staging, and transport.
20. **From Sparse Support to Transport Boundaries: Formation, Transport, Robustness, and Natural Relevance.** Four-axis high-delay sparse-event synthesis.
21. **What a Small RNN Learns on a k-Delay Task: A Three-Axis Account of the Nonlinear Escape.** Reachability, depth, and timing as decoupled estimands.
22. **Explicit Gating Partially Mitigates Separation Load, but the Small-State Bottleneck Persists.** Gating versus temporal separation demand.
23. **The Equivariance–Expressivity Trade-off: Architectural Boundaries of Signed Capacity.** Symmetry-preserving and symmetry-breaking gates.
24. **Two Spectral Strategies Under the Nilpotency Ceiling.** Marginal-stability linear versus saturation-stabilized super-unit tanh operators.
25. **Geometric Scaling Limits of Sequence Delay.** High-capacity gated buffers and orthogonal-basin selection.
26. **The Dimension-Robust Spatial Cost of Symmetry Breaking.** Capacity scaling of parity-equivariant gating.
27. **The Low-Gain Solution Is Capacity-Gated Below the Escape Onset.** Availability of low-gain operators across hidden size and delay.
28. **Step-2000 Transport Death Is Horizon-Sensitive.** Longer-horizon recovery of delayed signed seeds.
29. **The Linear-Floor Solution Is a Trap, and Escape Requires an Operating-Point Threshold.** Metastable floor geometry and thresholded escape.
30. **Boundary Stress of Isometric Transport.** Spectral-radius/performance dissociation under signed demand.
31. **Two Algorithmically Distinct Delay Solutions and Why Unconstrained Training Selects the High-Gain One.** Lag-response identification and matched rank-selection experiment.
32. **Radial Parity Equivariance: Unifying Symmetry and Phase-Encoding via Quadratic Gating.** Radial parity gate construction.
33. **Initialization-Invariant Formation and an Onset-Specific Heavy Tail.** Operating-point formation and estimand-dependent gain relation.
34. **Straight-Line Block Barriers Do Not Predict Core-Only Continuation.** Artificial interpolation versus constrained optimization paths.
35. **How Small RNNs Choose a Delay Algorithm.** Availability, accessibility, selection, and persistence synthesis.
36. **The Three-Axis Structure of the Nonlinear k-Delay Escape.** Formation, escape, selection, and operating-point/gain bridge.
37. **The Symmetry-Shielded Non-Normal Saddle.** Signed transport in constrained spaces.
38. **Available but Rarely Selected: Fixed-Readout Core Recoding in Delayed Transport Escape.** Fixed-readout-compatible branch cores.
39. **Causal Verification of the Origin-Cusp.** Gate-closing interventions and radial parity ablations.
40. **Bypassing Multiplicative Collapse: Additive Nonlinear Phase-Planes.** Additive state warping and transient nonlinear readout multiplexing.
