# Capacity, Transport, and Algorithm Selection in Small Delay RNNs

## Abstract

A recurrent neural network trained to reproduce an input after a fixed delay faces
an unusually transparent form of memory pressure: several high-dimensional inputs
must coexist in a smaller hidden state until each becomes due. We synthesize a
closed experimental corpus on this problem to ask what reproducible structures
emerge in the parameters, dynamics, and failures of small recurrent networks. The
task uses five-dimensional, length-ten sequences and targets
\(y_t=x_{t-k}\) after a delay \(k\in\{0,\ldots,5\}\), with zero targets before
the delayed signal exists. The primary networks contain at most three hidden
units. The inputs are nearly white at second order but extremely sparse and
non-Gaussian: approximately 97.5% of entries are zero and mean per-channel excess
kurtosis is about 66. This combination cleanly separates covariance-limited memory
from nonlinear use of higher-order structure.

The evidence supports a hierarchical answer rather than one universal mechanism.
First, a linear recurrence behaves as a depth-\(k\), capacity-\(h\) compressed
buffer. It preserves approximately \(p=\min(d,h/k)\) dimensions of each pending
input, giving

\[
\operatorname{MSE}_{\mathrm{floor}}\approx
\frac{T-k}{T}(d-p)\sigma^2.
\]

Across the primary grid this predicts optimized linear floors with mean absolute
relative error 0.032, compared with 0.277 for a naive rank-\(h\) bound. Second,
tanh networks reproducibly exceed this second-order floor, but only modestly and
only by using sparse higher-order statistics. A bias-controlled estimate at
\(h=3\) finds excess performance of \(1.53	imes10^{-4}\) at \(k=4\) and
\(3.66	imes10^{-4}\) at \(k=5\), while covariance-matched Gaussian controls show
essentially no escape. Third, learning is staged: networks first form the
covariance-level buffer and only later recruit nonlinear transport. The resulting
solutions fall into two algorithmic families. A low-gain, nearly nilpotent,
target-lag delay line is available in some regimes, but ordinary unconstrained
training usually selects a high-gain, strongly non-normal operator stabilized by
tanh saturation. The latter spreads transport across lags and can exceed the
linear floor, but creates distinctive finite-horizon, sign, and path-dependence
failures.

Input demand and architecture determine where these algorithms are reachable.
Temporal silence is essential in the tested synthetic families; near the escape
onset, event separation and instantaneous rank control performance. Gating reduces
but does not eliminate this load. Symmetry-respecting gates improve signed-event
transport, and causal interventions implicate multidimensional quadratic gating in
protecting high-gain dynamics through sign changes. Yet many apparent failures are
horizon-dependent: all initially transport-dead seeds in one signed-delay panel
became operational under longer training. The central conclusion is therefore
fourfold. Capacity determines the second-order floor; higher-order event structure
creates an opportunity to escape it; optimization chooses among distinct transport
algorithms; and finite training horizon plus architectural symmetry determine
which available solution is actually expressed.

## 1. A Minimal Task with Several Kinds of Difficulty

The fixed-delay task looks almost trivial when written as an equation. For an input
sequence \(x_1,\ldots,x_T\), the desired output is

\[
y_t = \begin{cases}
0, & t\le k,\\
x_{t-k}, & t>k.
\end{cases}
\]

There is no semantic ambiguity, long-range credit assignment beyond a few steps,
or uncertainty about the correct output. Nevertheless, the task becomes strongly
constrained when the input dimension is five and the recurrent state has only one,
two, or three coordinates. At delay \(k\), the state must contain information
about several inputs that have arrived but are not yet due. The network must also
decide which information to discard, how to distinguish inputs of different ages,
and how to map the compressed state back into five output coordinates. A model can
fail because it lacks representational capacity, because gradient descent does not
reach a good use of that capacity, because its nonlinear geometry is incompatible
with the input distribution, or simply because the training horizon ends before a
slow transport solution matures.

The experimental system considered here fixes the input and output dimension at
\(d=5\), sequence length at \(T=10\), and supplies 10,000 sequences for each delay
from zero through five. The principal scientific scope is hidden size \(h\le3\),
though several diagnostic studies use wider models to locate boundaries. Models
are recurrent maps with zero initial state and a learned linear readout. The most
frequent comparison is between an identity activation, which produces an exactly
linear recurrence, and a tanh activation. Gated cells and specially constrained
operators serve as architectural interventions rather than as the primary model
class.

This setting matters because the input distribution creates two different tasks
on the same samples. At second order, the features have nearly equal covariance
eigenvalues, per-entry variance about \(0.0083\), and negligible temporal
autorrelation. From the viewpoint of any linear predictor, the sequence is close
to isotropic white noise, so no feature direction or neighboring timestep offers
an easy shortcut. At higher order, however, the distribution is far from
Gaussian. Approximately 97.5% of entries are exactly zero; the nonzero entries are
sparse, positive, and heavy-tailed enough to produce mean per-channel excess
kurtosis near 66. A linear network sees the covariance but cannot exploit the
event structure. A nonlinear network can, in principle, treat long silent
intervals and rare events differently. The gap between these views is the key to
the full empirical story.

The central question is not simply whether a small model attains a lower loss.
Rather, it is what kind of solution is learned, how it forms, and why it fails.
Three distinctions are indispensable. The first is between **measurement** and
**mechanistic inference**. A spectral radius, lag-response matrix, hidden-state
norm, or intervention effect is measured; a delay-line or saturation-stabilized
transport algorithm is an interpretation supported jointly by several such
measurements. The second is between **availability** and **selection**. A good
solution may exist and may even be reachable under a constraint without being the
solution chosen by ordinary training. The third is between **reachability**,
**onset**, and **depth**. Whether any seed escapes a baseline, when it first does
so, and how far below the baseline it eventually goes are different empirical
quantities.

Once those distinctions are enforced, a coherent account emerges. The linear
baseline is governed by a simple capacity law. Nonlinearity yields a small but
real escape by exploiting sparse higher-order structure. Learning usually reaches
the baseline before it develops the nonlinear mechanism. At high delay, the
selected mechanism is commonly a non-normal, super-unit recurrent operator whose
raw expansion is checked by saturation. Its power and its fragility have the same
source: it amplifies a compact event code over several steps, so it is sensitive
to operating point, sign geometry, and optimization path. This paper develops
that account from the evidence upward.

## 2. Evidence Base and Analytic Framework

### 2.1 A closed, multi-study corpus

The evidence consists of accepted full papers, experiment reports, checkpoint
analyses, and stored result tables produced on the fixed datasets. No new
experiment is introduced here. The corpus contains repeated investigations by
independent research threads, including direct replications, competing
interpretations, null controls, architectural ablations, and later corrections to
earlier claims. The synthesis gives priority to results that survive multiple
seeds, delays, checkpoints, or intervention types. Where a result is specific to
a synthetic distribution, hidden size, or training schedule, that scope is kept
explicit.

Several methodological developments in the corpus are essential to the final
picture. Linear floors were estimated with multiple random initializations,
structured initializations, Adam warm starts, and, in the most thorough studies,
full-batch double-precision L-BFGS refinement. This matters because an
under-optimized linear model would make any nonlinear advantage look larger.
Nonlinear improvements were evaluated with matched seed selection, bootstrap
confidence intervals, mode clustering where performance was bimodal, and both
linear and covariance-matched Gaussian nulls. Learning dynamics were reconstructed
from intermediate checkpoints rather than inferred from endpoints. Mechanistic
claims were tested through de-saturation, spectral clamping, rank constraints,
frozen-block continuation, event-conditioned perturbations, and architectural
symmetry interventions.

The primary error is mean squared reconstruction error. Some studies normalize
active-delay MSE by the appropriate target variance, producing normalized MSE
(NMSE); an NMSE of one corresponds to predicting no useful delayed signal under
that normalization, while lower values indicate recovery. Sparse-event work also
separates errors on nonzero targets, zero targets, and prefix positions, and uses
event detection measures when ordinary MSE would hide rare-event behavior. These
metrics are complementary. A model may improve delayed-event recovery while
worsening zero-entry error, or may have a similar global MSE while implementing a
different transport operator.

### 2.2 The linear system and its invariant observables

For a linear recurrent network with state dimension \(h\), write

\[
h_t = A h_{t-1}+B x_t+b_h,\qquad
\hat y_t=C h_t+D x_t+b_y.
\]

Ignoring biases after centering, unrolling gives the impulse-response form

\[
\hat y_t = D x_t+\sum_{j\ge0} C A^j B x_{t-j}.
\]

The desired mapping has a single nonzero lag: its lag-\(k\) operator is the
five-dimensional identity. Each realized recurrent lag operator \(CA^jB\) has
rank at most \(h\), but that pointwise rank constraint is not the only limitation.
The same state coordinates must represent every input currently in flight. This
shared temporal burden is what turns an apparently static low-rank problem into a
capacity-allocation problem.

Raw matrices are poor objects for comparing trained recurrent networks because an
invertible change of hidden basis transforms \(A,B,C\) without changing the
input-output function. The more reliable studies therefore use basis-invariant or
function-level observables: eigenvalues and spectral radius of \(A\), the lag
operators \(CA^jB\), singular-value-based effective ranks, concentration of
impulse-response energy at the target lag, and linear decodability of past inputs
from the state. Target-lag concentration is the fraction of the measured
input-output lag-response magnitude assigned to lag \(k\), so a value near one
denotes a temporally precise delay line. A recurrent matrix is called non-normal
when it does not commute with its transpose; such a matrix can produce strong
finite-time directional amplification that its eigenvalue magnitudes alone do not
capture. Nonlinear networks add trajectory-conditioned Jacobians,
preactivation magnitudes, saturation measures, and counterfactual forward passes.

### 2.3 Why a covariance-matched null is decisive

For a fixed linear architecture trained with squared error, expected loss depends
on the joint second moments of inputs and targets. Since targets are deterministic
time shifts of inputs, their relevant second moments are fixed by the input's
space-time covariance. Replacing the sparse input distribution by a Gaussian with
the same full covariance therefore preserves the information available to an
optimal linear model while removing sparsity, kurtosis, and other higher moments.
This makes the covariance-matched Gaussian distribution a particularly clean
null. If a tanh advantage persists there, it may reflect optimization or an
incorrect floor. If it appears on sparse data but disappears under covariance
matching, higher-order structure is the parsimonious explanation.

### 2.4 Four levels of conclusion

The evidence supports four levels of statement, and the remainder of the paper
keeps them separate.

1. **Measured regularities:** error floors, confidence intervals, spectra,
   decodability, event-conditioned displacements, and intervention effects.
2. **Functional descriptions:** compressed buffer, target-lag delay line, diffuse
   high-gain transport, or event-selective gated transport.
3. **Mechanistic inferences:** saturation stabilizes a super-unit operator;
   temporal silence allows event codes to survive; parity-respecting gates protect
   signed trajectories.
4. **Open generality:** whether the same regimes persist for longer sequences,
   other input covariances, different optimizers, or substantially larger hidden
   states.

This hierarchy prevents a common error in mechanistic studies: treating one
diagnostic, such as spectral radius, as if it uniquely identified an algorithm.
The corpus instead shows that the meaning of any single statistic depends on the
trajectory, architecture, and estimand.

## 3. The Second-Order Floor Is a Compressed-Buffer Law

### 3.1 Why the naive rank bound fails

A tempting baseline says that an \(h\)-dimensional state can preserve \(h\) of the
five input dimensions, leaving \(d-h\) dimensions unreconstructed. This gives a
naive rank-\(h\) floor. It is adequate only when no temporal pipeline must be
maintained. For \(k\ge2\), it substantially underestimates the error because it
assigns the entire state to one delayed vector at a time.

At a typical timestep, a delay-\(k\) system holds \(k\) pending inputs: the newest
will be emitted after \(k\) more updates, while the oldest is nearly due. If the
state has \(h\) scalar degrees of freedom shared across those pipeline stages,
the effective number of preserved dimensions per input is approximately

\[
p=\min(d,h/k).
\]

For an isotropic input with per-coordinate variance \(\sigma^2\), losing
\(d-p\) dimensions costs \((d-p)\sigma^2\) on each active output. Only
\(T-k\) of \(T\) timesteps carry delayed targets, so the predicted all-step floor
is

\[
L_{h,k}=\frac{T-k}{T}\left[d-\min(d,h/k)\right]\sigma^2,
\]

with the zero-delay case handled separately. This expression is not an exact
theorem for every finite recurrent parameterization. It is a close empirical law
and a capacity interpretation.

Across hidden sizes one through three and delays zero through five, the law's mean
absolute relative error against thoroughly optimized linear floors is 0.032, with
absolute error about \(1.5	imes10^{-4}\). The naive rank-\(h\) predictor has
relative error 0.277 and absolute error about \(1.3	imes10^{-3}\). On the
highly diagnostic \(h=3\), positive-delay cells, the naive relative error is about
0.42 whereas the compressed-buffer law remains near 0.032. Stronger optimization
does not move the measured floors toward the naive prediction.

The law is most accurate when \(h/k\) is an integer. For example, the inferred
preserved dimension is about 3.0 for \(h=3,k=1\) and about 1.0 for
\(h=3,k=3\). At fractional ratios it is mildly optimistic: at \(h=3,k=2\), the
nominal value is 1.5 but the empirical preserved dimension is about 1.29. This
fractional penalty is one reason to treat the equation as a quantitatively useful
capacity law rather than a universal equality.

### 3.2 Direct evidence for a depth-delay buffer

The capacity interpretation is supported by decoding past inputs from hidden
states. In optimized linear networks, the sum of linearly decodable input
dimensions across lags lies close to the hidden dimension; the mean absolute
difference between this decodability area and \(h\) is about 0.27 when a direct
input-to-output term is allowed. Thus the state does not retain \(h\) dimensions
of every past input. It distributes a total budget of roughly \(h\) across the
lags that remain relevant.

The allocation is not always a literal shift register. For small delays,
decodability can fall sharply after the target lag, but for larger delays it is
more diffuse. A control removing the contemporaneous input-to-output path moves
the impulse-response peak toward the target lag in 9 of 15 tested cells. With that
path present, comparably good optima can combine recurrent memory with a current
input contribution, producing some lag-zero impulse peaks. The robust result is a
capacity budget spread through a temporal pipeline, not a unique canonical matrix
or a perfect cyclic shift.

The recurrent spectrum changes consistently with this temporal burden. Across
delays one through five, representative mean maximum eigenvalue magnitudes grow
approximately as 0.09, 0.60, 0.73, 0.94, and 1.13. Longer delays recruit more
persistent modes. Yet eigenvalue angles do not consistently form the roots of
unity expected from an exact cyclic register. Again, the functional law is much
more reproducible than a particular coordinate-level realization.

### 3.3 Extrapolation and scope

The same predictor extrapolates to auxiliary hidden sizes four through six. For
\(k\ge2\), its relative error is 0.050 with a 95% bootstrap interval
\([0.028,0.076]\), while the naive rank bound gives 0.912
\([0.840,0.979]\). Cells with enough capacity approach exact reconstruction:
\(h=5,k=1\) reaches MSE \(1.1	imes10^{-4}\), and \(h=6,k=1\) reaches
\(8.2	imes10^{-5}\). Empirical preserved dimensions track the expected
saturation, including about 3.97 for \(h=4,k=1\) and 2.96 for \(h=6,k=2\).

The strongest interpretation is second-order. The official data's sparsity and
heavy tails do not affect the optimum of a linear squared-error predictor except
through covariance. Consistent with that analysis, linear floors on
covariance-matched Gaussian sequences agree with official-data floors within
optimization noise: observed absolute differences are around \(10^{-4}\) on
floors around \(5	imes10^{-3}\). The analytic formula itself does not transfer
numerically to arbitrary synthetic input families, especially when covariance or
scaling changes. For those families, the correct comparator is the measured
linear floor. What transfers is the principle: linear performance is determined
at second order, so improvement beyond a well-measured linear floor must draw on
non-Gaussian structure or on a changed objective.

## 4. Nonlinear Escape Is Small, Real, and Higher-Order

### 4.1 Measuring a small effect without selection bias

The phrase **nonlinear escape** denotes a tanh model's improvement below the
matched linear floor, not merely good absolute performance. Its **depth** is the
positive difference between that floor and the tanh loss, expressed as raw MSE or
as NMSE as specified by the experiment. The difference is
small enough that measurement discipline matters. Selecting the best of many
random seeds independently for the linear and nonlinear classes biases both
minima downward, and the biases need not cancel because tanh optimization is more
variable and often bimodal. A bias-controlled analysis therefore matched the
selection procedure, distinguished an escape mode from a floor mode, required a
confidence interval above zero, and used both linear and Gaussian nulls.

For \(h=3\) under the standard training protocol, the corrected escape is not
positive at \(k=3\), is \(1.53	imes10^{-4}\) at \(k=4\) with 95% interval
\([5.9	imes10^{-5},1.81	imes10^{-4}]\), and is
\(3.66	imes10^{-4}\) at \(k=5\) with interval
\([2.67	imes10^{-4},4.42	imes10^{-4}]\). Naive best-of-seeds comparisons
overstate these values by roughly 12--18%. The effect is only about ten percent of
the local linear floor, but it is reproducible and statistically separated from
zero at the two largest delays.

This standard-protocol threshold should not be mistaken for an impossibility
below \(k=4\). Later work with broader initialization coverage found reachable
escape at \(k=3\). The careful statement is that robust escape begins near
\(k=4\) under the standard protocol, while the lower-delay basin contains
nonlinear solutions that less comprehensive searches can miss. This distinction
between typical recruitment and existence recurs throughout the corpus.

Capacity also changes escape depth. At \(k=5\), representative tanh improvements
are about \(1.84	imes10^{-4}\) for \(h=2\) and
\(5.16	imes10^{-4}\) for \(h=3\). Additional hidden capacity does not simply
lower the same linear floor; it permits a deeper higher-order strategy. Conversely,
ReLU controls are often degraded by dead-unit solutions and do not show the same
robust pattern. The useful contrast is therefore not generic "nonlinearity versus
linearity" but a particular smooth saturating nonlinearity interacting with a
sparse event distribution.

### 4.2 Covariance matching identifies the information source

When sparse official inputs are replaced by Gaussian inputs with matched full
space-time covariance, the tanh advantage collapses to essentially zero. The
linear floor itself remains stable. This joint result rules out a second-order
explanation for escape and makes higher moments the operative information source.
The sparse official distribution supplies long runs of exact zeros interrupted by
rare, relatively large positive events. Tanh can condition its effective dynamics
on whether an event is present and on the state it encounters; a linear recurrence
cannot.

Synthetic-distribution comparisons sharpen the conclusion. Official-like sparse
positive marginals recover most of the \(k=5\) tanh advantage relative to Gaussian
controls. Merely giving a distribution high marginal kurtosis is insufficient if
events fill the temporal interval densely. Temporal silence, not heavy tails
alone, is a central resource. Silence gives a compact nonlinear event code several
uncontested recurrent updates through which to evolve toward its readout time.
When every intermediate step injects new dense activity, the same high-order code
is overwritten or mixed with other signals.

Balanced signed events weaken the effect but do not abolish delayed transport.
Positive-only data allow a network to use sign-asymmetric regions of tanh and to
align recurrent kicks and readout directions consistently. With equally likely
positive and negative events, the code must preserve sign through the same narrow
state. Standard monotone gates and biased operating points can treat the two
orthants differently, imposing an additional symmetry burden. Signed controls
therefore expose an architectural limitation that positive sparse data partly
conceal.

### 4.3 Objective dependence is a distinct phenomenon

Ordinary all-step MSE is dominated by zeros in sparse high-delay data. Reweighting
rare nonzero targets increases event recall, event F1, target-lag attribution, and,
for tanh in some settings, event area under the precision-recall curve. It also
raises zero-entry and often active MSE. These solutions form a Pareto frontier
rather than an unconditional improvement. This result is scientifically useful
because it separates failure to carry delayed information from an objective that
rewards suppressing rare outputs. However, it should not be folded into the
nonlinear-escape claim: changing the objective changes what counts as optimal,
whereas escape below the linear floor is defined under matched losses.

Together, the controls establish a precise claim. Tanh networks do not evade a
universal dimensional theorem. They exploit distributional structure that the
linear second-order solution discards. The gain is greatest where temporal
compression is strongest and sparse silence can support event-dependent dynamics.

## 5. Demand Determines Whether Nonlinearity Can Be Recruited

### 5.1 Temporal silence, spatial rank, and separation

Sparse-event inputs have at least three distinct demand variables. **Temporal
density** measures how many intervening events compete during a delay interval.
**Instantaneous spatial rank** measures how many independent feature directions
must be encoded at one event time. **Separation** measures how far apart multiple
events occur relative to the delay. Studies that vary these factors independently
find a two-regime law.

Near the onset of nonlinear escape, especially at \(k=3,h=3\), event separation
strongly predicts depth. In two-event synthetic sequences, the slope of escape
depth versus separation is 0.0411 NMSE per step, with bootstrap interval
\([0.0372,0.0443]\). At \(k=4,h=3\), escape is already substantial at minimal
separation and the slope is only 0.0018, with interval
\([-0.0034,0.0069]\). The nonoverlapping intervals show that this is not simply a
noisy version of the same relationship. At onset, closely spaced events compete
for the limited state; deeper into the escape regime, the learned operator can
handle the tested separation range with little additional benefit from silence.

A separation-aware predictor of per-seed \(k=3,h=3\) escape depth achieves
leave-one-out mean absolute error 0.0245, compared with 0.0455 for a predictor
using only marginal distribution information. This nearly twofold reduction
indicates that temporal arrangement adds explanatory information beyond sparsity
or kurtosis. The result is not that larger separation always improves every
delay. It is that separation is a limiting load variable near the recruitment
boundary.

Instantaneous rank creates a parallel bottleneck. If one event activates multiple
independent feature directions simultaneously, the three-dimensional state must
compress them before any temporal competition is considered. Sparse scalar-like
events are therefore unusually favorable to nonlinear multiplexing. The observed
escape is strongest when the distribution converts a nominally five-dimensional
regression problem into a sequence of isolated, low-rank event-routing problems.
That is how a three-dimensional nonlinear state can outperform the best linear
projection without contradicting the linear capacity law.

### 5.2 Gating modifies supply but does not repeal capacity

Explicit gates can regulate when new input overwrites the state and when stored
content persists. In the separation experiment, a standard gated recurrent unit
reduces the \(k=3\) separation slope from 0.0338 to 0.0238, a reduction of about
30%. Yet the slope remains positive. Gating therefore provides a more adaptive
supply of memory, partially buffering nearby events, but it does not remove the
representational bottleneck imposed by \(h\le3\).

This distinction helps reconcile apparently conflicting architectural results.
A gate can improve event scheduling while introducing other problems, especially
for signed inputs. A monotone sigmoid gate driven by a linear projection is not
invariant under simultaneous sign reversal of input and state. It may devote
capacity to different update patterns in opposite orthants even when the task is
sign symmetric. Thus gating helps temporal allocation but can tax spatial
symmetry. Architecture changes the balance of constraints rather than producing
free memory.

### 5.3 A demand-supply view

The empirical regimes can be summarized by comparing demand with the network's
effective supply. The compressed-buffer law describes second-order supply:
approximately \(h\) total linear dimensions divided across \(k\) pending inputs.
Sparse silence lowers temporal demand, low event rank lowers spatial demand, and
saturating nonlinear dynamics can encode event identity more efficiently than a
global linear projection. Gating reallocates supply in time. Symmetry-aware gates
prevent supply from being wasted on separate positive and negative rules.

This view does not posit a single scalar capacity. The relevant constraint changes
with regime. Below or near onset, spatial rank and event separation decide whether
a nonlinear code can form. At larger delay, once the high-gain route is recruited,
transport stability and optimization path dominate. A model can have enough
representational capacity in principle and still fail to select or sustain the
appropriate operator.

## 6. Learning Proceeds in Stages

### 6.1 Formation of the covariance-level solution

Checkpoint analyses show that small tanh networks do not immediately discover a
sparse-event algorithm. Early in training they behave approximately linearly. The
effective number of preserved dimensions grows from near zero, the recurrent
spectrum develops more persistent modes, and the loss descends toward the matched
linear floor. In linear networks, this is the whole learning story. In Gaussian
controls, tanh networks likewise stop near the second-order solution.

On sparse non-Gaussian data, some tanh runs continue into a second stage. The delay
between first reaching the linear floor and first demonstrating nonlinear escape
is substantial and delay dependent. Median gaps are 160 training steps at
\(k=3\), with interval \([120,180]\); 60 steps at \(k=4\), interval
\([40,60]\); and 100 steps at \(k=5\), interval \([30,100]\). The sequence is
not monotone in \(k\), which already warns against reducing the transition to a
single difficulty scale.

The strongest interpretation is sequential staging. First, optimization learns a
covariance-level compressed buffer. Then, if the data, initialization, and
trajectory permit it, recurrent gain and operating point reorganize to exploit
sparse higher-order structure. Controls are critical: neither exactly linear
models nor tanh models trained on covariance-matched Gaussian data enter the
second stage. The delayed transition is therefore not merely continued generic
loss minimization observed at higher resolution.

### 6.2 Onset, depth, and reachability are different

The timing results do not imply that the deepest final solution must start latest
or earliest. Across seeds and delays, final escape depth, onset checkpoint, and
probability of entering the escape mode vary somewhat independently. A
high-capacity configuration may have access to a deep solution yet enter it only
from a subset of initializations. A lower-capacity configuration may show a
shallower but more common improvement. Reporting only the best endpoint collapses
these axes and encourages misleading threshold claims.

The \(k=3\) findings illustrate the issue. A conservative standard initialization
study found no bias-controlled escape at that delay, while broader initialization
sampling later found reachable nonlinear solutions. The right conclusion is not
that one analysis is wrong. Standard training has a robust recruitment boundary
near \(k=4\), but the solution set extends below that boundary. Reachability
describes the existence of successful basins; selection frequency describes how
often the optimizer finds them.

### 6.3 Gain develops before saturation becomes essential

High-delay tanh runs show a temporal ordering inside the second stage. Recurrent
gain begins increasing before the model first reaches the linear floor. Strong
saturation is recruited later, and its functional importance becomes clearest
after the target transport window. This rules out a crude account in which
training simply saturates units from the start and thereby stores binary events.
Instead, the network first builds an amplifying transport operator and then uses
state-dependent compression to keep that operator bounded along the data
trajectory.

This distinction between raw operator and realized trajectory is measurable. At
\(k=4\) and \(k=5\), the hidden-state norm at the end of the length-ten sequence
is only about 5% of what the unsaturated linearized recurrence would predict.
Removing tanh in a counterfactual forward pass drives NMSE to roughly
\(10^5\). Clamping the recurrent spectral radius toward a marginally stable value
also materially degrades performance. The high-gain operator and the saturation
that contains it are jointly functional; neither alone describes the learned
algorithm.

## 7. Two Reproducible Delay Algorithms

### 7.1 Low-gain target-lag delay lines

One solution family resembles the intuitive finite delay line. Its recurrent
operator is low gain and nearly nilpotent, its effective recurrent rank is tied to
the required delay, and its impulse-response energy is concentrated almost
entirely at the target lag. Under exact-rank constraints at \(k=4\), such models
achieve target-lag concentration near 0.999. They implement a temporally precise
linear-like transport strategy: advance a compact state through a finite chain and
read it out when due.

This family is especially visible below the robust nonlinear-escape onset and in
constrained parameterizations. The clean exact-rank probe used \(h=6\), an
auxiliary size outside the primary \(h\le3\) scope, specifically to ask which
operator families are available when rank can be manipulated. The family is
economical and interpretable, but capacity
gated. At larger delay, a state with only a few coordinates cannot implement a
full five-dimensional nilpotent delay line, and exact-rank constructions become
increasingly restrictive. In tests at \(k=5\), no examined rank from one through
six and no hidden size through seven reliably recruited the same low-gain route.
This is evidence for a boundary in the tested construction, not a theorem that no
larger or differently parameterized low-gain solution exists.

### 7.2 High-gain, saturation-stabilized transport

The second family is qualitatively different. Its recurrent matrix is strongly
non-normal and has raw spectral radius above one. Transport is spread across lags
rather than concentrated in a single lag operator. Tanh saturation prevents the
raw expansion from appearing as an exploding realized state. Representative raw
spectral radii for high-delay tanh models are about 2.80 at \(k=4\) and 2.54 at
\(k=5\), compared with approximately 0.97 and 1.20 for matched linear models.

Non-normality matters because eigenvalues alone do not determine finite-time
amplification. A non-normal matrix can strongly amplify particular directions for
a bounded number of steps even when its asymptotic spectrum would not suggest the
same behavior. In the sparse task, each event kicks the hidden state into a
direction that the recurrent dynamics amplify and rotate over the next several
updates. The nonlinear state-dependent compression keeps this transient within a
usable region and can separate event-bearing trajectories from silence. This is a
finite-horizon transport algorithm, not an indefinitely stable memory.

Several interventions establish that high gain is functional rather than an
incidental correlate. Replacing tanh by the identity at inference produces a
catastrophic error increase to around \(10^5\) NMSE. Spectral clamping damages
performance. The actual terminal hidden norm is about one twentieth of the
unsaturated prediction. Conversely, saturation without the learned recurrent
operator is not sufficient. The mechanism is a coupled pair: super-unit,
non-normal transport creates delayed separability; saturation shapes and bounds
the realized orbit.

### 7.3 Functionally similar losses can hide different algorithms

Two models near the same MSE floor can occupy very different regions of parameter
and trajectory space. A low-gain delay line and a high-gain saturated model may
both reach the linear benchmark, yet only the latter has the operating point and
nonlinear geometry needed to continue below it. This fact is central to
interpreting learning dynamics. "Reaching the floor" is a statement about loss,
not about arriving at one unique floor solution.

The algorithmic contrast is especially sharp in that auxiliary \(h=6\)
rank-constraint experiment. Models held on an exact rank-\(k\) manifold at
\(k=4\) are mostly low gain:
the low-gain fraction is 0.875, with interval \([0.719,0.950]\), and the median
spectral radius is 0.283. Models initialized identically but then freed to use the
full parameterization almost never remain in that family: the low-gain fraction is
0.031, interval \([0.006,0.157]\), and median spectral radius is 2.031. The held
models have target-lag concentration near 0.999; freed models average about 0.025,
for a paired difference of 0.973 with interval \([0.929,0.985]\).

These are not small coordinate variations. They are two different computational
strategies: a precise finite delay line and a distributed, nonlinear transient.
Their coexistence explains why parameter averages or endpoint loss alone give an
incomplete account of learned structure.

## 8. Why Ordinary Training Selects the High-Gain Route

### 8.1 Availability is not selection

The exact-rank comparison proves that a functional low-gain solution is available
at \(k=4\) under the tested constrained \(h=6\) parameterization. It is evidence
about the solution space and selection mechanism relevant to the primary small
models, not a claim that an \(h\le3\) network can instantiate a rank-four delay
line. Yet when the rank
constraint is released, optimization rapidly leaves it. Effective rank grows
beyond \(k\) by about step 10, before the final high-gain regime is established.
Thus ordinary training does not fail to find the low-gain route because that route
is absent. It abandons the route while additional directions are available.

It would be too strong to say that rank growth alone causes selection. The held
and freed arms differ not only in realized rank but also in parameterization and
optimization geometry. A constraint changes gradients, curvature, and accessible
paths. The defensible conclusion is narrower: under the tested unconstrained
parameterization, optimizer, schedule, and finite horizon, the available low-gain
delay line is rarely selected; exact-rank training preserves it. This is a robust
selection result, not a universal causal theorem about rank.

Why might the high-gain family be favored? It offers a route to exploit sparsity
and eventually move below the second-order floor. Early rank expansion creates a
richer operator family. Increasing recurrent gain supports finite-time
amplification of rare event codes. Tanh later stabilizes those amplified paths.
The route is less interpretable and more fragile, but it aligns with gradients
that continue to reduce loss after the linear-like solution has exhausted its
second-order capacity.

### 8.2 The linear-floor solution can be a trap

An even sharper experiment compares two ways of reaching the same floor loss. The
**recurrent operating point** is quantified here by the root-mean-square recurrent
contribution to the hidden preactivation over data trajectories; it measures how
far the recurrence drives units away from tanh's nearly linear origin. One
starts from an analytically constructed, minimal-drive linear-floor
parameterization and asks whether tanh training escapes. The other starts cold and
records the first checkpoint at which training crosses the same loss. At
\(k=3,4,5\), the minimal-drive constructions do not advance meaningfully below the
floor. Cold runs reach the floor with much larger recurrent preactivations and can
continue into the nonlinear regime.

The recurrent-only preactivation root-mean-square magnitude is approximately
0.004--0.007 in the minimal-drive floor construction. At the first floor crossing
of cold training it is 0.139, 0.267, and 0.539 for \(k=3,4,5\), respectively.
Intervention sweeps locate onset-like operating-point thresholds around 0.023 at
\(k=3\), 0.016 at \(k=4\), and no larger than 0.052 at \(k=5\). The precise
numbers are protocol dependent, but the qualitative result is strong: a model can
have the correct floor loss while sitting far below the recurrent operating point
from which nonlinear gradients become useful.

This is why loss alone does not identify progress. The minimal-drive construction
matches the covariance solution too cleanly. Its tanh units remain close to the
origin, where the activation is almost linear, so the higher-order features of
the input barely affect the local computation. Cold training reaches the same loss
through a higher-drive path that has already curved the activation and prepared a
route for further improvement.

Projected Hessian diagnostics do not reduce this barrier to a simple local
saddle-sign story. The sign of the smallest projected Hessian eigenvalue does not
reliably predict which seeds escape. The barrier is better described in terms of
trajectory, operating point, and usable nonlinear gradients than as the presence
or absence of one negative-curvature direction.

### 8.3 Operating point and spectral gain have an estimand-dependent relation

Early analyses suggested that recurrent operating point and raw spectral gain
might be decoupled. Later, more extensive evidence gives a more precise answer:
their relationship changes sign with the comparison being made.

Within individual \(k=4\) training runs, recurrent-only preactivation RMS and raw
spectral radius co-move positively. The pooled Spearman correlation is 0.4747,
with interval \([0.3978,0.5435]\). At endpoints across seeds, the relationship is
even more strongly positive, about 0.86. These results are intuitive: as a trained
high-gain operator develops, it drives the state further into the nonlinear region.

Across seeds, however, the early operating point at first floor crossing trades
off negatively with final spectral radius. The correlation is -0.2689, interval
\([-0.3832,-0.1391]\), and remains around -0.32 after residualization in the
integrated analysis. Seeds entering the nonlinear regime with higher recurrent
drive need not end with the largest raw radius; early drive may reduce how much
later spectral amplification is required. The sign reversal is not a
contradiction. Within-run development, across-seed endpoint structure, and
early-to-final prediction are different estimands.

Decomposing preactivation shows that the relationship is carried mainly by the
recurrent term rather than input drive. This further supports an internal
transport interpretation. But spectral radius is still not a sufficient
mechanistic statistic: non-normal geometry, saturation, readout compatibility,
and event-conditioned trajectories determine whether a given radius is useful.

## 9. Failure Modes Reveal the Transport Mechanism

### 9.1 Signed failure occurs after event injection

Balanced signed data provide a stringent probe because positive and negative
events demand symmetric transport. Weak signed models are not simply blind to
events. In a representative comparison, weak or failed seeds show a larger
immediate event-conditioned hidden displacement than successful seeds, 0.1965
versus 0.0776. The failure appears over the following five recurrent updates:
lag-five displacement is only 0.1851 for weak seeds but 0.4195 for successful
ones. At readout, the delayed state aligns poorly with the target direction:
target-readout cosine is 0.067 in weak seeds versus 0.438 in successful seeds.

Thus event injection and delayed transport are separable. A strong immediate kick
does not guarantee a usable memory. Successful models transform a relatively
modest kick into a larger, sign-consistent target-lag state. Weak models may react
strongly at once but fail to preserve or rotate that response into the readout
subspace. This finding discourages interpreting input sensitivity as memory.

### 9.2 Controlled collisions versus naturally dominant error

If temporal silence enables nonlinear escape, collisions between events should
stress the transport path. Intervention experiments confirm this, but with an
important qualification. Successful positive and signed paths tolerate most
natural-amplitude sparse collisions. Relative to an isolated-event trajectory,
mean retained signal is 0.9207 after one natural collision and 0.8437 after two.
Dense filler throughout the interval is much more damaging, reducing retention to
0.5865. This separates in-distribution sparse competition from off-manifold dense
traffic.

Targeted early collisions can nevertheless be destructive. The most damaging
class depends on sign structure and geometry. In balanced signed sequences,
orthogonal components often dominate the disruption: a new event pushes the state
out of the low-dimensional transport corridor rather than merely cancelling it.
For positive events, anti-aligned same-feature interactions contribute more
directly through cancellation. These controlled probes expose vulnerabilities of
the learned path, especially early in the delay interval when the code has not yet
settled into a robust target-directed trajectory.

But a vulnerability under intervention is not necessarily the primary source of
natural error. A census of signed \(k=5,h=3\) events finds only 5 harmful early
opposite-sign, same-feature collisions among 313 events, or 1.60%, with Wilson
interval \([0.00684,0.03684]\). That class contributes 1.54% of the active-event
error in successful signed models. By contrast, 250 of 313 events, 79.87%, are
isolated, and they account for about 79% of the error. The dominant natural
failure is therefore not collision catastrophe. It is imperfect finite-horizon
transport of otherwise isolated events.

This result changes the scientific emphasis. Controlled collisions reveal the
geometry and are useful causal stress tests. Yet improving ordinary performance
requires strengthening global isolated-event transport rather than optimizing
for a rare adversarial class. Robustness and prevalence must be measured
separately.

### 9.3 Endpoint failure can be a horizon artifact

At 2,000 training steps, many signed \(k=5,h=3\) tanh seeds appear
transport-dead. Continued training to 8,000 steps changes that conclusion
dramatically. All 10 of 10 seeds initially classified as transport-dead become
operational successes, as do all 14 of 14 seeds in a broader non-success panel.
The early label describes a state at a horizon, not a permanent basin identity.

This is not a semantic detail. A claim that signed demand destroys the mechanism
would be false for this panel if based only on the shorter endpoint. The more
accurate account is that signed transport has slower formation and a heavy-tailed
time to success. Training horizon belongs in the definition of a failure mode.
The relevant outcome is \(P(	ext{success by step }s)\), not an unqualified binary
label.

Continuation studies also expose path dependence at the block level. From delayed
checkpoints, continuing only the recurrent core while freezing the readout succeeds
in 12 of 15 cases, even though straight-line interpolation of the core between the
same endpoints succeeds in only 1 of 15. The existence of a successful constrained
training path is not captured by a straight chord through parameter space.
Moreover, scanning naturally saved checkpoints finds a core compatible with a
fixed earlier readout in only 5 of 45 cases; 40 of 45 trajectories never show such
compatibility at the sampled times. Ordinary training generally co-adapts core and
readout, even though a fixed-readout recoding route is available under intervention.

These observations motivate four separate terms. **Availability** means a
functional endpoint exists. **Accessibility** means a specified constrained
optimization can reach it. **Selection** means ordinary training actually follows
that route. **Persistence** means the attained behavior survives further training
or perturbation. Conflating them turns finite-horizon and intervention results into
overstated claims about the natural optimizer.

## 10. Architecture Changes the Boundary, Especially for Signed Inputs

### 10.1 The symmetry tax of monotone gates

For a signed task, simultaneously replacing \((x,h)\) by \((-x,-h)\) should
negate the candidate state while leaving the amount of updating unchanged. A
standard sigmoid gate driven by a linear projection is not even under this sign
flip. It therefore breaks a symmetry of the task and can fragment trajectories by
orthant.

Parity-equivariant gates make update strength an even function while retaining an
odd state update. In matched signed-delay comparisons, a square-root parity gate
improves active-delay NMSE from 0.669 for a standard gated unit to 0.551 at
\(h=5,k=4\). At \(h=16\), the corresponding values are 0.156 and 0.136. A
four-step Jacobian diagnostic gives an orthant distance of 4.16 and spectral-radius
fluctuation of 1.04 for the standard gate, but exactly zero for the equivariant
variant under the same sign-reversal test. The advantage is therefore accompanied
by the intended geometric correction, not only a lower loss.

Equivariance does not abolish the compression problem. At \(h=3,k=5\), simple
one-dimensional parity gates plateau near active NMSE 0.74. Preserving symmetry
prevents one form of waste, but a gate depending on a single even scalar must pass
through a small value during some sign-changing trajectories. This creates an
origin-cusp failure: the update or reset path closes exactly when the state must
move between opposite-sign configurations.

### 10.2 Multidimensional quadratic gating

A radial parity-gated cell replaces the one-dimensional gate drive with a learned
quadratic pool over an expansion dimension. The gate remains even under sign
reversal, while the higher-dimensional representation can trace a path around the
origin rather than through it. At \(h=3,k=5\), this architecture reaches mean
active NMSE around 0.71, has zero orthant distance by construction, and exhibits a
\(k\)-step Jacobian spectral radius around 4.84. The last number places it firmly
in the high-gain family: the symmetry mechanism protects amplified transport
rather than replacing it with a low-gain delay line.

Two intervention families support the origin-cusp interpretation. In normal
inference, a representative multidimensional model has NMSE 0.714. Clamping the
quadratic gate preactivation during opposite-sign events worsens it to 0.745;
clamping the final gate output worsens it to 0.758. Downstream MSE after the
intervention spikes by 61.9%. Independently, retraining with expansion dimension
\(M=1\), \(M=2\), and \(M=6\) yields mean NMSE 0.7401, 0.7395, and 0.7143.
Although two dimensions are topologically sufficient to avoid a point, the tested
optimizer does not reliably exploit that possibility; six dimensions provide
enough redundancy to maintain a useful gate drive.

These interventions are strong but bounded evidence. Inference clamping creates a
distribution shift, and expansion changes parameterization as well as topology.
The justified conclusion is that avoiding cusp-like closure is causally implicated
in the advantage within this radial-gate family. It is not yet a theorem that all
successful signed-delay networks require the same geometry.

### 10.3 Additive phase-plane constructions

A complementary architecture removes multiplicative gating and imposes an
odd-symmetric, zero-bias recurrent phase plane: a learned two-dimensional rotation
coupled to a one-dimensional envelope. A purely linear version reaches active
NMSE around 0.86 at signed \(h=3,k=4\). Multiplicative energy modulation worsens
it to about 0.91, apparently disrupting superposition of older events. Adding an
unbiased nonlinear pathway directly to the recurrent update instead lowers NMSE
to about 0.667 and permits an effective spectral radius near 1.24. Restricting the
nonlinear write to the envelope raises NMSE back to about 0.836, implying that
warping of the two-dimensional phase orbit itself is important within this family.

A nonlinear readout on the additive phase-plane model produces one striking
transient checkpoint at NMSE 0.1715, showing that a three-dimensional nonlinear
state can briefly support much richer five-dimensional decoding than a linear
readout reveals. The endpoint evidence is much weaker: final mean NMSE is about
0.624, and none of three final seeds remains below 0.4. This is best treated as a
constructive boundary result. It demonstrates a promising transient capability,
not a stable general solution.

## 11. An Integrated Account of What Small Delay RNNs Learn

The experimental record can now answer the central question at three levels:
parameters, dynamics, and failures.

At the **parameter level**, linear and nonlinear solutions occupy different
operator families. Linear networks increase spectral persistence with delay and
allocate a fixed hidden-dimensional budget across pending inputs. Constrained
nonlinear models can preserve a low-gain, nearly nilpotent, target-lag operator.
Unconstrained high-delay tanh training usually expands effective rank and selects
a strongly non-normal recurrent matrix with raw radius well above one. No unique
matrix is reproducible because hidden basis is arbitrary; the reproducible
structures are invariant spectra, ranks, lag operators, and response
concentrations.

At the **dynamical level**, the second-order solution is a depth-\(k\) compressed
buffer. Tanh networks first form this buffer, then may recruit a higher-order
event-transport regime. In the selected high-gain family, rare events perturb the
state, non-normal recurrence amplifies and rotates the perturbation over a finite
window, and saturation keeps the realized trajectory far smaller than the raw
linearized prediction. Temporal silence protects this path; signed symmetry and
gating determine how well it survives competing events and orthant changes.

At the **failure level**, there is no single collapse. Some seeds never acquire
delay capacity. Others reach the covariance floor but remain at too small an
operating point for nonlinear gradients to matter. Signed weak models detect
events but lose them before the target lag or fail to align them with the readout.
Targeted collisions can disrupt successful paths, but naturally occurring error
is dominated by imperfect isolated-event transport. Some apparent failures are
merely slow and disappear under longer training. Finally, available constrained
solutions may be ignored by ordinary unconstrained optimization.

The most useful compact summary is the following.

| Empirical layer | Robust measurement | Supported interpretation | Remaining boundary |
|---|---|---|---|
| Second-order capacity | \(p\approx\min(d,h/k)\); primary-grid relative prediction error 0.032 | The state is a depth-\(k\), total-capacity-\(h\) compressed buffer | Fractional \(h/k\) incurs extra loss; arbitrary covariances require measured floors |
| Nonlinear gain | Positive bias-controlled escape at \(k=4,5\); none on Gaussian covariance controls | Tanh uses sparse higher-order structure invisible to linear predictors | Standard-protocol onset is not an existence boundary |
| Input demand | Separation matters strongly near \(k=3\) onset but weakly at \(k=4\); temporal silence is essential in tested families | Event isolation lowers temporal load and enables compact nonlinear codes | General law for dense or differently correlated processes is unknown |
| Learning dynamics | Floor precedes escape by tens to hundreds of steps | Higher-order transport is a second learning stage | Onset, depth, and selection frequency remain distinct |
| Operator family | Exact-rank training yields low-gain target-lag solutions; freed training yields high-gain diffuse transport | At least two algorithms solve similar loss regimes | Rank constraint is not isolated as the sole causal variable |
| Operating point | Minimal-drive floor states do not escape; cold floor crossings have much larger recurrent drive | Floor loss does not identify the floor solution | Threshold values depend on parameterization and schedule |
| Natural failure | Isolated events dominate signed active-event error; short-horizon failures often recover | Finite-time transport, not event detection or rare collisions, is the main weakness | Longer horizons and alternate optimizers may change selection |
| Architecture | Parity and radial gates improve signed transport; cusp interventions erase the radial advantage | Symmetry-preserving geometry protects high-gain paths | The intervention mechanism is established only within tested families |

This hierarchy reconciles results that initially appear inconsistent. The linear
floor can be highly predictable while nonlinear endpoints are seed bimodal.
Low-gain solutions can be demonstrably available while high-gain solutions dominate
ordinary training. Spectral radius can correlate positively with operating point
within runs and negatively with early operating point across seeds. Collision
interventions can have large effects while collisions contribute little natural
error. A seed can be a failure at step 2,000 and a success at step 8,000. Each
pair refers to a different estimand.

The scientific story is consequently not that tiny RNNs discover one elegant
shift register. They learn according to a layered economy. Covariance determines
what a linear compressed buffer can preserve. Sparse events offer a higher-order
discount on the nominal five-dimensional demand. Optimization decides whether to
cash in that discount through a nonlinear transport operator. Architecture decides
whether the operator respects the task's sign and timing symmetries. Training
horizon decides whether slow formation is seen at all.

## 12. Limitations and Open Questions

The primary task has only ten timesteps, five input dimensions, delays no larger
than five, and hidden sizes no larger than three. Wider models appear only as
boundary controls. The compressed-buffer law is well supported in this domain but
is mildly optimistic at fractional capacity ratios, and its analytic numerical
form assumes the measured near-isotropic covariance. Longer horizons could change
both the optimal spectrum and the stability cost of high gain.

Most synthetic distribution interventions isolate one or two properties while
necessarily changing others. The evidence strongly identifies temporal silence
and low instantaneous rank as important, but it does not yield a complete
distribution-free formula for escape depth. Likewise, the rank-held and freed
optimization arms demonstrate different selection outcomes but do not isolate
rank as the only causal difference in the optimization landscape.

Spectral radius, operating point, and saturation are informative only together.
The high-gain mechanism is supported by several interventions, yet finite-time
non-normal amplification depends on singular directions and trajectory-conditioned
Jacobians that a scalar radius cannot summarize. A fuller theory would predict
which event codes are amplified, how they rotate into readout directions, and
when saturation improves separability rather than destroying it.

The strongest architectural interventions concern particular parity-equivariant
and radial gated cells. Their gains establish that sign symmetry and cusp-like
closures matter, but the architectures also alter parameter count and optimization
geometry. The additive phase-plane results are especially preliminary: their best
nonlinear-readout performance is transient and not retained at final checkpoints.

Finally, success remains optimizer- and horizon-dependent. Continuation converts
many early failures into successes, and constrained continuation reaches states
not observed on natural checkpoint paths. Future work should report time-to-event
curves, basin frequencies, and persistence after attainment, rather than only a
fixed endpoint. It should also test whether alternative optimizers select the
available low-gain route more often or simply reach the same high-gain family at a
different rate.

## 13. Conclusion

Small fixed-delay RNNs exhibit reproducible structure, but at several interacting
levels. Their linear limit is a compressed-buffer law: \(h\) hidden degrees of
freedom are amortized across \(k\) pending inputs, preserving roughly \(h/k\)
dimensions per input. Sparse non-Gaussian events permit tanh networks to improve
slightly beyond that covariance-defined floor. The improvement forms only after a
distinct learning stage and is carried, in the dominant high-delay family, by a
non-normal super-unit operator stabilized along the data trajectory by saturation.

The alternative low-gain delay line is real but often not selected. Reaching the
same floor loss at a minimal versus elevated recurrent operating point leads to
different futures. Failures likewise divide into capacity failure, failure to
enter the nonlinear regime, loss of an event during finite-horizon transport,
readout misalignment, symmetry-induced gating costs, and simple insufficiency of
training time. Natural sparse collisions are usually tolerated; isolated-event
transport remains the dominant error source.

The broad lesson is that representational capacity, data structure, optimization,
and architecture cannot be collapsed into one explanation. Capacity sets the
second-order baseline. Higher-order sparsity creates better algorithms. Training
selects among them, often preferring a high-gain path over an available clean
delay line. Architectural symmetry and operating point determine whether that
path survives. This layered account directly explains the observed parameters,
dynamics, and failure modes, and it provides a disciplined template for studying
learned memory mechanisms beyond this deliberately small system.
