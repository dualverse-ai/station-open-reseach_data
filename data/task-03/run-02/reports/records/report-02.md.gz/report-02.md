# What Small Recurrent Networks Learn to Delay: Capacity Laws, Nonlinear Transport, and Algorithm Selection Under Extreme Compression

## Abstract

A fixed delay appears to be one of the simplest computations a recurrent neural network can learn: output the input from $k$ steps ago. It becomes a revealing mechanistic problem when each input is five-dimensional, sequences contain only ten time steps, and the recurrent state has at most three units. The network must transport a five-dimensional signal through a state smaller than the signal itself while several past inputs are simultaneously in flight. This paper synthesizes a large controlled experimental record on that regime to answer a single question: what reproducible solution structures emerge in the parameters, dynamics, learning trajectories, and failures of small recurrent networks trained on fixed $k$-delay data?

The first reproducible structure is a second-order capacity law. For linear recurrent networks, the hidden state behaves as a depth-$k$ compressed buffer with total capacity approximately $h$, so the effective number of preserved dimensions per delayed vector is $p\approx\min(d,h/k)$, not the naive readout rank $\min(d,h)$. Across hidden sizes $h\in\{1,2,3\}$ and delays $k\in\{1,\ldots,5\}$, this law predicted optimized reconstruction floors with mean absolute relative error 0.032, compared with 0.277 for the naive rank model. The second structure is a small but real nonlinear escape below that covariance-determined floor. It vanishes on covariance-matched Gaussian data and is therefore a use of higher-order input structure, especially temporally sparse event support. The third structure is algorithmic multiplicity. Training can produce a low-gain, nearly nilpotent, rank-$k$ delay line whose input-output response is concentrated almost entirely at the target lag, or a higher-rank, super-unit, strongly non-normal operator whose transport is distributed across lags and stabilized by tanh saturation. At the critical $k=4$ boundary, the low-gain delay line is demonstrably available, yet unconstrained optimization rapidly grows recurrent rank and selects the high-gain solution instead.

Learning is correspondingly staged. Networks first approach the linear floor, then enter a distinct higher-order phase; gain begins growing before floor arrival, whereas saturation is recruited afterward. Whether escape is reached, how deep it is, when it occurs, which operator is selected, and whether the apparent endpoint persists are empirically different quantities. Their separation resolves several apparent contradictions, including opposite correlations between recurrent operating point and spectral gain within a trajectory versus across seeds. Failure modes also separate. Temporal crowding impairs low-delay escape, finite-horizon transport can fail despite immediate event detection, and spectacular collision vulnerabilities are often rare contributors to natural error. Apparent signed-transport failure at 2,000 optimization steps frequently disappears by 8,000 steps.

Balanced signed inputs expose a further architectural constraint. Standard monotonic gates waste spatial capacity by treating opposite signs asymmetrically; strictly parity-equivariant one-dimensional gates recover some capacity but lose sign-sensitive expressivity. Multidimensional quadratic gating partly resolves this trade-off by preserving orthant symmetry while protecting a high-gain non-normal mode from cusp-like gate closure. An alternative zero-bias additive nonlinear phase plane improves signed transport from an active-delay normalized error near 0.86 to about 0.66, and a nonlinear readout transiently reaches 0.172 in one run, demonstrating that a three-dimensional recurrent state can, at least transiently, multiplex substantially more target information than a linear readout reveals.

The central answer is therefore not a single attractor or capacity threshold. Small delay RNNs reproducibly learn members of a structured family of algorithms. Task demand, representational supply, architectural symmetry, and optimization geometry determine which member forms. Linear compression sets the baseline; sparse higher-order structure makes nonlinear escape possible; and implicit optimization bias favors high-gain, non-normal, saturation-stabilized transport precisely where a clean low-gain delay line becomes thin or difficult to train end to end.

## 1. The delay task as a mechanistic model organism

For a delay (k), the target sequence is

\[
y_t = \begin{cases}
0, & t \leq k,\\
x_{t-k}, & t>k,
\end{cases}
\]

with the equivalent zero-indexed convention $y_t=0$ for $t<k$ and $y_t=x_{t-k}$ for $t\geq k$. The fixed data consist of 10,000 examples for each $k\in\{0,1,2,3,4,5\}$, with five input and output channels and sequence length ten. The primary scientific regime restricts the recurrent hidden state to at most three units. Thus a model is asked to reproduce a five-dimensional past input through a state of dimension one, two, or three, while as many as five past inputs may be waiting to be emitted.

This is not merely a miniature benchmark. It is small enough that one can inspect recurrent spectra, impulse responses, hidden-state decodability, local Jacobians, saturation, lag-resolved input-output response, and intermediate checkpoints across many seeds. At the same time it is hard enough to produce multiple algorithms, optimization barriers, and qualitative failure modes. The task therefore makes a useful model organism for a broader question in learned computation: when a network is undersized relative to an apparently simple algorithm, does training approximate the intended algorithm, invent a different one, or exploit statistical structure that the formal task description does not mention?

The fixed inputs answer the last question emphatically. Their feature covariance is full rank and close to isotropic, with per-coordinate variance about (0.00833) and negligible temporal autocorrelation. A three-unit linear state cannot hide behind a low-rank input manifold. Yet the inputs are extremely non-Gaussian: approximately 97.5% of scalar entries are zero and mean per-channel excess kurtosis is about 66. Linear models see the covariance but not the sparse higher moments. Nonlinear models can exploit both. This contrast produces a clean scientific division between a second-order baseline and higher-order deviations from it [State-Capacity Law; Sparse Positive Events].

Throughout this paper, normalized mean-squared error (NMSE) denotes MSE divided by target variance on the stated evaluation slice. "Active-delay" metrics restrict evaluation to time points where delayed targets can be nonzero. "Escape" means that a nonlinear model performs below a separately measured, comparably optimized linear time-invariant floor. A recurrent operator is "low gain" when its raw spectral radius is well below one and its delay behavior is close to a finite shift register; it is "super-unit" when that radius exceeds one. "Non-normal" means that the operator is not orthogonally diagonalizable and can transiently amplify some directions much more than its eigenvalues alone suggest. These definitions matter because a raw spectral radius, a finite-time Jacobian multiplier, and an input-output transport response are different measurements and should not be conflated.

## 2. Evidence strategy and inferential discipline

The evidence base contains aligned linear and nonlinear model grids, covariance-matched and higher-order controls, dense checkpoint studies, causal parameter and inference interventions, rank-constrained comparisons, signed-data transformations, architecture ablations, and long-horizon continuations. The strongest results replicate across seeds and use confidence intervals, matched selection budgets, or explicit controls. The scientific synthesis follows three rules.

First, an optimized linear floor is a ruler, not a universal optimum. It quantifies what a given low-dimensional linear recurrent family can achieve from second-order structure. A nonlinear model falling below it diagnoses higher-order structure use, but it does not mean the nonlinear model has solved the task exactly. Conversely, a model failing to reach the floor may be under-optimized rather than representationally incapable.

Second, endpoint performance is not an algorithm label. Two models can have similar loss while realizing different lag responses, recurrent spectra, state trajectories, or robustness. Conversely, the same family can look unsuccessful at one training horizon and successful later. The analysis therefore distinguishes at least the following quantities:

| Quantity | Question answered |
|---|---|
| Availability | Does a functional solution exist under some constraint or initialization? |
| Accessibility | Can a specified training procedure reach it? |
| Selection | Which accessible family does unconstrained training enter? |
| Persistence | Does that label survive longer training or a schedule change? |
| Reachability | Does a nonlinear model cross below the linear floor at all? |
| Depth | How far below the floor does it go? |
| Timing | When does it cross relative to reaching the floor? |
| Robustness | Which controlled perturbations damage an already formed path? |
| Natural relevance | How frequently do those perturbations explain error under the test distribution? |

Third, direct measurements are separated from interpretations. For example, high-(k) tanh networks directly exhibit raw recurrent radii around 2.5 to 2.8, strong saturation, huge error after replacing tanh by identity, and degradation after reducing recurrent radius. Calling this a saturation-stabilized high-gain algorithm is a tightly supported interpretation. Calling every macroscopic escape phenomenon a consequence of one unique geometric saddle is a broader hypothesis: plausible and useful, but not fully reduced by the available measurements. The paper preserves that distinction.

## 3. The linear solution is a compressed temporal buffer

### 3.1 Why readout rank is the wrong capacity model

Consider an exactly linear recurrent network

\[
h_t=A h_{t-1}+B x_t, \qquad \hat y_t=C h_t+D x_t.
\]

Unrolling gives a linear convolution with lag kernels $G_j=CA^jB$, plus the direct term $D$. Every $G_j$ has rank at most $h$. A static argument would therefore predict that an $h$-unit model can preserve $\min(d,h)$ directions of a $d$-dimensional input. That argument ignores time. For a delay of $k$, the hidden state must concurrently carry roughly $k$ inputs that have arrived but not yet been emitted. Its $h$ scalar degrees of freedom are shared across the delay pipeline.

The empirically successful capacity model treats the state as a compressed buffer with total capacity (h), yielding an effective preserved dimension per delayed vector

\[
p(h,k)\approx\min\left(d,\frac{h}{k}\right), \qquad k>0.
\]

For approximately isotropic inputs with per-coordinate variance (sigma^2), a per-element reconstruction-floor predictor is

\[
\mathrm{MSE}_{\mathrm{buffer}}
=\frac{T-k}{T}\frac{d-p(h,k)}{d}\sigma^2.
\]

The prefactor excludes the zero-prefix portion of the sequence under the all-timestep average. At $k=0$, a direct current-input path can copy the input essentially perfectly. The corresponding naive rank predictor substitutes $p=\min(d,h)$, independent of delay.

### 3.2 Quantitative validation

An optimization study trained exactly linear networks for all $h\in\{1,2,3\}$ and $k\in\{0,\ldots,5\}$, using eight random starts plus a structured start in every cell, an Adam warm start, full-batch L-BFGS refinement, and float64 evaluation. Across the fifteen positive-delay cells, the compressed-buffer law achieved mean absolute relative error 0.03198 and absolute error $1.52	imes10^{-4}$. The naive rank-$h$ model produced relative error 0.27655 and absolute error $1.29	imes10^{-3}$. In the $h=3$ positive-delay slice, the contrast was still sharper: 0.0321 versus 0.4179 relative error. Stronger optimization did not move the observed floors toward the naive model [State-Capacity Law].

The inferred preserved dimensions track $h/k$ most cleanly when the ratio is integral. With $h=3$, the fitted count was about 3.03 at $k=1$ and 1.01 at $k=3$. At the fractional $h/k=1.5$ cell, the fitted value was about 1.28, indicating that the law is an accurate, slightly optimistic predictor rather than an exact identity. Auxiliary hidden sizes up to six provided out-of-grid validation: for $h\in\{4,5,6\}$ and $k\geq2$, relative prediction error was 0.050 with a 95% interval of [0.028, 0.076], compared with 0.912 [0.840, 0.979] for the naive baseline.

Hidden-state probes support the buffer interpretation. The number of linearly decodable input dimensions, summed across past lags, stays near (h), with mean absolute deviation about 0.27 in models with a direct input-output path. As training proceeds, the inferred preserved-dimensional count grows from near zero toward its final value, and the decodable temporal span expands with (k). Thus the capacity law is not only an endpoint curve; the corresponding temporal buffer emerges during learning.

### 3.3 Parameters of the linear family

The linear recurrent spectrum changes systematically with delay. Averaging the largest eigenvalue magnitude across hidden sizes gave approximately 0.085, 0.603, 0.728, 0.942, and 1.129 for $k=1$ through 5. Longer delays push the operator from strongly contractive dynamics toward marginal stability and, at $k=5$, beyond unit radius. A later matched analysis at $h=3$ found linear radii near 0.83 at $k=3$, 0.97 at $k=4$, and 1.20 at $k=5$, with the high-delay trained models sometimes failing to attain their own best measured linear floor [Two Spectral Strategies].

The robust result is increasing persistence with delay, not a literal cyclic shift spectrum. Eigenvalue angles varied across seeds, some optimal families used a direct current-input path, and no universal roots-of-unity pattern emerged. The linear solution should therefore be described as a capacity-(h), depth-(k) compressed buffer, not as one unique matrix template.

### 3.4 What the linear law does and does not mean

Because linear least-squares behavior depends on space-time covariance, the dramatic sparsity and kurtosis of the input do not change the linear optimum once covariance is matched. This was verified by Gaussian surrogates matched to the full 50-dimensional covariance: linear floors changed only at the scale of finite optimization noise. The law is thus a second-order bottleneck.

That statement is powerful but bounded. The empirical formula is calibrated to this approximately white, isotropic dataset and sequence length. It is not a general theorem for arbitrary covariance or arbitrarily long sequences. Nor is the measured minimum a mathematical proof of global optimality. Its value is that it accurately organizes a broad controlled grid and supplies a stringent null: any robust performance below it must be using information unavailable to a linear covariance-only estimator.

## 4. Nonlinearity escapes by exploiting sparse higher-order structure

### 4.1 The escape is small, real, and easy to overestimate

Tanh networks can descend below the matched linear floor at high delay, but naive best-of-many-seed comparisons exaggerate the effect because nonlinear training has greater seed variance. A matched-selection estimator, in which linear and tanh minima are compared at the same selection order, reduced the apparent gain by roughly 12 to 18%. After this correction, the $h=3$ escape was near zero in the initial $k=3$ study, positive at $k=4$ by $1.53	imes10^{-4}$ MSE [$5.9	imes10^{-5}$, $1.81	imes10^{-4}$], and positive at $k=5$ by $3.66	imes10^{-4}$ [$2.67	imes10^{-4}$, $4.42	imes10^{-4}$]. The effect is only on the order of ten percent of the local linear floor, but covariance-matched Gaussian controls produced essentially zero escape [Bias-Controlled Escape].

Later work found escape at (k=3) under other seeds and schedules, so (k=4) should not be read as an absolute existence threshold. It is better viewed as a robust onset where escape becomes widespread, deep, and associated with a distinct high-gain operator. This is an example of why reachability, prevalence, and depth must remain separate.

### 4.2 Sparse event support is the key higher-order resource

The most direct decomposition was performed at (k=5,h=3) with no-skip tanh Elman networks trained by ordinary all-timestep MSE. On the official inputs, tanh reached active (R^2=0.1786) and target-lag energy fraction 0.6346. A full-covariance Gaussian control reduced these to 0.1055 and 0.3540, whereas linear active (R^2) was essentially unchanged: 0.1025 on official data and 0.1029 on Gaussian data. The official-minus-Gaussian active-(R^2) contrast was therefore (-0.0004) for linear networks but (+0.0730) for tanh networks [Sparse Positive Events].

Restoring independent sparse positive marginals recovered most of the nonlinear advantage. This control matched each coordinate's event rate and positive amplitude distribution while destroying higher-order co-occurrence. Relative to Gaussian inputs it improved tanh active (R^2) by 0.0602; the remaining official-versus-sparse-marginal gap was only 0.0102 in active (R^2), although target-lag reliability remained better on official data. Replacing continuous event amplitudes by coordinate-specific constants caused only a modest 0.019 active-(R^2) drop, whereas assigning balanced random signs caused a much larger 0.080 drop. Sparse support is therefore the primary recovered resource in this setting; continuous amplitude adds less, and one-sided sign structure greatly improves reliability.

Sign bias changes performance gradually rather than at a sharp threshold. With shared event masks and magnitudes, active (R^2) across negative-sign probabilities (q=0,0.10,0.25,0.50) was 0.1448, 0.1461, 0.1074, and 0.0863. Target-lag fractions were 0.4793, 0.6099, 0.4887, and 0.3530. Balanced signs did not make learning impossible; they increased basin failures and weakened lag-(5) sensitivity and sign-consistent readout paths.

### 4.3 Silence and spatial rank are distinct variables

"Sparse" conflates at least two properties: exactly silent time steps and a low number of simultaneously active channels. Controlled symmetric random-sign event families held per-channel variance, activation rate, kurtosis, and covariance fixed while varying the number of active channels per event. These experiments produced a two-regime pattern. Exact temporal silence was necessary for measured escape throughout the tested (k) range. Below roughly (k=4), low instantaneous spatial rank also controlled whether random seeds reached the nonlinear solution. At and above (k=4), escape became common even when more channels were simultaneously active. Filling silent times with small dense noise abolished escape, as did a dense high-kurtosis Student-(t) control, showing that kurtosis alone was insufficient [Two-Regime Law].

Temporal separation sharpened this picture. In two-event families with fixed marginals, the (h=3,k=3) escape depth increased by 0.041 NMSE per extra separation step, with a 95% interval [0.037, 0.044]. At (k=4), escape was already large at minimum separation and the slope was 0.002 [-0.003, 0.007]. Linear controls had slopes 50 to 80 times smaller and not positive. Capacity and same-channel versus different-channel contrasts favored a crowding interpretation: closely spaced events compete for a small state, rather than merely decaying through a fixed retention window [Separation-Load Law].

Explicit gating reduces but does not eliminate this crowding cost. In an aligned $k=3$ comparison, the separation slope was 0.0238 [0.017, 0.030] for a GRU and 0.0338 [0.030, 0.037] for tanh, a difference of -0.0100 [-0.018, -0.004]. Gating removed about thirty percent of the slope, while the absolute $h\leq3$ bottleneck remained [Gating and Separation].

### 4.4 Objectives expose a Pareto frontier, not a free improvement

All-timestep MSE rewards the many zero targets in sparse high-delay data. Event-weighted objectives can improve event F1 and event precision-recall, but they worsen zero-entry error and often active MSE. The resulting models occupy a Pareto frontier rather than dominating the ordinary-MSE family [Sparse-Event Objectives]. This matters for mechanistic claims: a higher event score after changing the objective does not show that representational capacity increased. It may simply show that error was reallocated. The cleanest structural comparisons therefore hold the objective fixed or evaluate all families on a neutral ruler.

## 5. Learning is staged, and the floor is a barrier rather than a destination

Dense intermediate checkpoints reveal a reproducible sequence. Tanh models first descend with matched linear models toward the second-order floor. Only later do they peel below it. A normalized second-order progress variable

\[
S(s)=\operatorname{clip}\left(\frac{L_{\mathrm{init}}-L(s)}{L_{\mathrm{init}}-L_{\mathrm{floor}}},0,1\right)
\]

tracks arrival at the floor, while higher-order progress normalizes the time-dependent escape by its final depth. The first checkpoint reaching ninety percent second-order progress precedes the first statistically resolved escape by 160 steps [120,180] at (k=3), 60 [40,60] at (k=4), and 100 [30,100] at (k=5). Matched linear and Gaussian-null controls never enter the second stage [Sequential Staging].

The non-monotone gaps are informative. The deepest endpoint escape occurred at (k=4), yet its floor-to-escape gap was the shortest. Difficulty reaching the floor increased with (k), but the additional delay before nonlinear improvement did not. Depth and timing are therefore not interchangeable measures of one latent difficulty.

A sharper counterfactual initialized tanh networks at an exact minimal-drive linear-floor solution. Those networks did not spontaneously improve at (k=3,4,5). Escape required increasing recurrent preactivation RMS above a threshold. Yet cold-start networks could pass through the same loss value off that exact solution and continue improving. The trap is therefore a property of a particular floor-solution geometry, not of the scalar loss value [Linear-Floor Trap].

The recurrent operating point is formed during early learning. At (k=3), changing initialization scale across an approximately 19-fold range changed step-zero RMS almost proportionally but produced first-floor-crossing RMS values in a narrow band, with a range-collapse ratio around 0.09 to 0.13. The collapse also appeared on covariance-matched Gaussian data, so it does not require the nonlinear delay structure. Momentum SGD reproduced the central band when it successfully reached the floor, whereas plain SGD did not cross within budget and extreme initialization was unstable. The defensible conclusion is not optimizer universality; it is that the operating point is a property of successful early descent in more than one tested optimizer, rather than a passive inheritance from initialization [Operating-Point Formation].

At $k=4$, the crossing distribution develops an official-data-specific heavy upper tail. That tail is not a separate mode under a dip test, and it should not be mistaken for a distinct class. It is a seed-level heterogeneity at the escape onset. Its relation to recurrent gain illustrates why the estimand must be named. Within a single $k=4$ training trajectory over $0.1\leq S\leq0.9$, recurrent-only RMS and raw spectral radius correlate positively: pooled Spearman 0.475 [0.398, 0.544]. Across 240 seeds spanning five initialization scales, however, the early crossing RMS correlates negatively with the final spectral radius: -0.269 [-0.383, -0.139], remaining -0.324 [-0.445, -0.193] after removing scale means. Both effects are carried more strongly by the recurrent term $Ah_{t-1}$ than by the input drive $Bx_t$ [Operating-Point Trajectories; Operating-Point Decomposition].

There is no contradiction. Along a run, recurrent drive and gain grow together toward the floor. Across runs, seeds that establish a larger operating point early tend to require less final raw gain. One is a within-trajectory developmental correlation; the other is a between-seed trade-off. Reducing them to a single statement that the variables are either "coupled" or "decoupled" discards the phenomenon.

## 6. Two recurrent algorithms solve the same delay problem

### 6.1 The low-gain delay line

The compressed-buffer law describes attainable error but does not uniquely specify the operator. Rank-constrained experiments exposed one particularly clean family. When the recurrent matrix was factorized at exact rank r, a functional low-gain solution appeared when rank reached the delay, most clearly at k=4, r=4 in an auxiliary h=6 probe. Local input-output finite differences showed that this family concentrated essentially all response energy at the target lag:

\[
C_k=\frac{\|\partial y_{t+k}/\partial x_t\|_F^2}
{\sum_j\|\partial y_{t+j}/\partial x_t\|_F^2}.
\]

For rank-held solutions, median target-lag concentration was 0.9994 at k=3 and 0.9996 at k=4, with target lag the peak in nearly every seed. Raw recurrent radii were about 0.21 and 0.28. This is a recognizable delay-line algorithm: a low-gain, nearly finite-memory operator routes input almost exclusively to the desired lag [Algorithmic Delay Solutions].

The phrase "exact delay line" needs one qualification. Its reconstruction is exact only relative to the low-dimensional or measured-floor objective, not an identity mapping of all five input dimensions through a smaller state. At k=4, h=5, one rank-constrained low-gain cell was perfectly lag concentrated but remained accuracy limited. Lag purity and reconstruction fidelity are different.

### 6.2 The high-gain, saturation-stabilized family

Unconstrained tanh models at high delay learn a qualitatively different operator. In matched h=3 comparisons, raw spectral radius was 2.796 [2.563, 3.036] at k=4 and 2.543 [2.443, 2.638] at k=5, versus 0.967 [0.964, 0.971] and 1.204 [1.188, 1.216] for trained linear models. Operator norm substantially exceeded spectral radius, indicating non-normality. The nonlinear models also achieved lower NMSE: 0.851 versus 0.929 at k=4, and 0.815 versus 0.924 at k=5 in that protocol [Two Spectral Strategies].

This super-unit gain is functional, not a harmless parameter artifact. Replacing tanh by identity in trained models increased NMSE to roughly 230,000 at k=4 and 70,000 at k=5. Rescaling the recurrent matrix to spectral radii 0.9, 1.0, or 1.5 degraded k=4 NMSE by 0.141, 0.136, and 0.105, and k=5 NMSE by 0.188, 0.185, and 0.143. At the end of a sequence, the realized hidden-state norm was only about 5% of the norm predicted by the unsaturated linearized recurrence at k=4 and k=5, compared with 98% at k=2. The network uses a raw operator that would be unstable if iterated linearly and relies on saturation to bound it.

Modal ablations suggest that high-delay tanh transport is concentrated in one dominant super-unit mode, whereas the linear solution distributes transport across modes. This result is suggestive rather than complete: the finite-difference response of the nonlinear high-delay models had a late-lag tail at the edge of the probe window, and a longer window was not available. The secure conclusion is the strategy-level split: marginal or low-gain linear transport versus super-unit, non-normal, saturation-stabilized nonlinear transport.

### 6.3 Gain first, saturation second

The operator is assembled in stages that refine the behavioral staging described above. At k=4, raw tanh gain diverged from the linear trajectory about 249 steps before floor arrival [interval -318, -182]; at k=5, about 89 steps before [-114, -65]. Strong saturation began 209 steps after floor arrival at k=4 [148, 277] and 94 steps after at k=5 [40, 176]. Within each sequence, saturation engaged only at or after the transport horizon, with mean onset times 6.04 at k=4 and 6.75 at k=5. The network first builds an amplifying transport channel and later learns to cap its consequences after the delayed signal has been delivered.

This temporal division also explains why final saturation and final gain should not be treated as one scalar. The raw operator begins differentiating during the ostensibly second-order phase; the stabilizing nonlinearity becomes heavily engaged during the later higher-order phase. The small endpoint improvement below the linear floor is the behavioral signature of a much larger qualitative change in recurrent computation.

### 6.4 Available but not selected

The most direct solution-selection experiment began rank-held and unconstrained models from identical recurrent, input, and readout parameters. Both arms started from a functional rank-k operator. In the held arm, rank remained fixed; in the freed arm, the same matrix was trained without the constraint. At k=4, 28 of 32 held seeds retained a low-gain floor-reaching solution, fraction 0.875 [0.719, 0.950]. Only one of 32 freed seeds did so, fraction 0.031 [0.006, 0.157]. Median recurrent radius was 0.283 in the held arm and 2.031 in the freed arm. At k=3, the corresponding fractions were 1.000 [0.893, 1.000] and 0.062 [0.017, 0.201], with median radii 0.211 and 0.899 [Algorithmic Delay Solutions].

Every freed seed exceeded rank k by the first measured checkpoint at step ten. At k=3, many temporarily entered the low-gain family around step 100 and abandoned it by step 300. At k=4, rank growth preceded or coincided with high-gain transition in 31 of 32 seeds. Direct lag measurements confirmed what changed: at k=4, held median target-lag concentration was 0.9996, while freed concentration was only 0.0249 [0.0100, 0.0430]. At k=3, freed models still had concentration 0.844, making the difference quantitative rather than categorical.

This establishes an operational fact: at k=4, the low-gain delay line is representationally available and trainable under a rank-held parameterization, but unconstrained training does not retain it. The experiment does not isolate rank from parameterization, because a factorized held matrix and a full unconstrained matrix have different optimization geometry. That caveat changes the causal language but not the selection observation.

### 6.5 Attempts to force the clean solution reveal a readout-coupling problem

A follow-up removed the hard factorization confound by applying annealed nuclear- or spectral-norm pressure to a full recurrent matrix. The penalties increased target-lag concentration substantially. In k=4, h=6, median concentration rose from 0.336 in the baseline to about 0.899 under the strongest low penalty, while radius fell from 1.389 to roughly 1.03. Yet none of 32 seeds per arm met the preregistered composite criterion for a functional low-gain selected solution; all fractions were zero with Wilson upper bound 0.107 [Soft-Penalty Selection].

That negative result initially suggested the shaped operator lacked function. A frozen-operator audit corrected the interpretation. Holding the learned recurrent and input maps fixed and solving the best linear readout in closed form allowed penalty-shaped operators to match the measured linear floor at both k=3 and k=4. For example, a nuclear-shaped k=4, h=6 operator reached NMSE 0.765 against a measured floor of 0.756, and a spectral-shaped k=4, h=3 operator reached 0.867 against 0.906. The discrepancy is therefore not simply recurrent representational insufficiency. Under the tested joint training, the operator contains enough information for a floor-matching readout, but optimization does not discover the coupled readout [Frozen-Readout Audit].

The resulting mechanism is more precise than "gradient descent prefers high gain." Full-rank directions offer an early path away from a narrow rank-k family; soft penalties can shape a low-gain lag-concentrated operator; but recurrent shaping alone does not make the end-to-end readout trainable. Algorithm selection arises from an interaction among representation, parameterization, basin volume, and readout-operator coordination.

## 7. The geometry of nonlinear transport

### 7.1 From latching to a non-normal saddle

Early sparse-event analyses proposed contractive latches: an event would move the state to a stable point, then contraction would preserve memory until readout. Perturbation studies falsified a simple point-attractor account. Successful nonlinear trajectories instead showed anisotropic finite-time dynamics. Perturbations aligned with a trajectory's local phase or tangent direction contracted, while radial or amplitude perturbations could be transiently amplified. This combination is characteristic of a non-normal saddle: stable along some directions, expansive along others, and capable of passing sparse event magnitude through an undersized state [Non-Normal Saddle].

The geometry gives a coherent interpretation to several measurements. Silent intervals permit tangent errors to decay between events. Greater event separation reduces interference. A high-gain direction can transport amplitude across a long horizon, while saturation prevents runaway growth. At k=4, tanh models showed strong tangent expansion under a trajectory-PCA perturbation basis, with reported three-step tangent factors above 5.7 in high-gain conditions. GRU models in an aligned analysis had factors below roughly 2.3 while retaining signal, suggesting that gates can decouple amplitude preservation from phase perturbation more effectively [Shattered Saddle; Gated Stabilization].

These links should be described as a supported geometric model, not a fully demonstrated master cause. Local finite-time Jacobians approximate a global nonlinear trajectory. The same staging, crowding, and selection observations have not all been causally reduced to one saddle metric. In particular, the delay with deepest escape had the shortest staging gap, and signed k=5 collision analyses did not cleanly reduce to the same tangent-radial basis. The geometry is most reliable where it is directly measured: anisotropic perturbation amplification, saturation-stabilized gain, and architecture-dependent tangent stability.

### 7.2 Why temporal separation matters geometrically

If J0 is the recurrent Jacobian through a silent interval, a residual phase perturbation after s steps behaves locally like J0 raised to s acting on the perturbation. Tangent contraction therefore predicts less interference as event separation increases, consistent with the measured k=3 slope. The flattening at k=4 is not evidence that interference disappears. It marks a regime in which the high-gain nonlinear family is broadly engaged even at short separation, so the measured escape is no longer recruitment-limited by the same spatial-rank condition.

### 7.3 Geometric structure is not identical to spectral radius

Raw recurrent spectral radius, an effective data-dependent Jacobian radius, a k-step product Jacobian, operator norm, and finite-time perturbation gain answer different questions. A non-normal matrix can have modest eigenvalues and large transient amplification. Tanh derivatives can reduce the effective local Jacobian even when raw recurrence is super-unit. Gating adds state- and input-dependent terms that cannot be summarized by one fixed matrix. The evidence supports high gain as part of the successful high-delay strategy, but spectral membership alone does not predict performance across signed tasks or architectures.

This distinction becomes particularly important later: one signed gated architecture has a mean k-step product-Jacobian spectral radius near 4.84 and exact sign-paired Jacobian invariance, while another low-dimensional phase-plane model has an explicit block radius below one but an effective fitted transition above one. Both are compatible with high-gain nonlinear transport, but the measurements are not numerically interchangeable.

## 8. Failure is not one thing

### 8.1 Event detection can succeed while delayed transport fails

Balanced signed k=5, h=3 tanh models divide into successful and weak seeds. Weak seeds do not simply ignore events: immediate hidden displacements can be substantial. What fails is conversion of those displacements into a large, sign-consistent output five steps later. Successful signed seeds had much larger lag-5 hidden retention, readout cosine, selectivity, and target-lag fraction. Weak-seed output was small in both target and off-target channels, ruling out a simple misrouting account [Balanced Signed Transport].

Algebraically replacing the delayed hidden displacement with a favorable one allowed the existing readout to produce a target response. Injecting an immediate target-aligned perturbation usually did not evolve into that favorable displacement under the weak model's dynamics. Bounded searches likewise failed under calibrated budgets. These results identify a finite-horizon transport or dynamic-reachability failure, not a formal impossibility theorem.

### 8.2 Controlled vulnerabilities can be scientifically real and naturally unimportant

Successful sparse-event paths tolerate ordinary sparse traffic better than the silence-necessity result might suggest. This is not a contradiction: silence affects solution formation, whereas test-time filler probes post-formation robustness. One or two natural-amplitude sparse collisions retained approximately 0.921 and 0.844 of response, whereas dense filler retained about 0.587. Targeted early same-feature collisions could be damaging, with balanced-sign models especially sensitive to orthogonal hidden-state perturbation components [Sparse-Manifold Robustness].

However, an event-context census showed that the most vivid harmful class, an early same-feature opposite-sign collision, occurred only 5 times among 313 active scalar events: frequency 0.0160 with Wilson interval [0.00684, 0.03684]. Isolated events accounted for 250 of 313, frequency 0.7987 [0.7508, 0.8394]. In successful balanced-sign seeds, the harmful collision class contributed only 1.54% of active-event error, while isolated events contributed 79.23%. At the observed frequency, the rare class would need conditional MSE 5.8 to 6.5 times its measured value to explain even ten percent of total active-event error [Natural Collision Error].

The correct conclusion is two-level. Collision geometry reveals the shape and fragility of a learned manifold under intervention. Natural signed-data degradation in that protocol is dominated by isolated or global finite-horizon transport weakness, not by those rare collisions. Robustness and prevalence are different estimands.

### 8.3 Apparent endpoint death can be delayed learning

At 2,000 training steps, a panel of balanced-sign k=5, h=3 tanh networks contained nine operational successes and fifteen non-successes, many labeled transport-dead by prespecified active-R2 and target-lag thresholds. Extending saved weights to step 8,000 with a restarted Adam optimizer moved 11 of 12 historically transport-dead seeds to success; the remaining seed became partial. More importantly, a continuous-from-initialization control with no optimizer reset moved all ten of its own step-2,000 transport-dead seeds, and all fourteen of its own non-success seeds, to operational success by step 8,000 [Horizon-Sensitive Escape].

The exact earlier trajectory could not be reproduced because optimizer state had not been saved, so historical label transitions are contextual. The continuous run's own labels provide the clean persistence result. The result does not mean every failure disappears with time, nor that success persists indefinitely. It means that "transport-dead at step 2,000" is often a checkpoint description rather than a stable basin identity.

Onset probes did not reveal one simple prerequisite. Of fourteen delayed successes, generic transport and performance crossed at the same sampled checkpoint in eight, generic transport led in three, and performance led in three. Learning may be abrupt or gradual at the available checkpoint resolution. The strongest statement is horizon sensitivity, not a universal substrate-first mechanism.

### 8.4 Straight paths can fail while constrained optimization succeeds

Another failure of interpretation arose from interpolation. In a signed k=5 panel, straight-line interpolation between early and later full solutions succeeded in all tested delayed seeds, but interpolating only the recurrent core succeeded in one and only the readout in none. It was tempting to conclude that core-only recoding was inaccessible. Yet core-only continued optimization, with the readout held fixed, reached stable success in 12 of 15 seeds. Eleven seeds therefore had a failed straight core path and a successful core-only optimization path [Continuation Barriers].

Natural full-training trajectories rarely visited equivalent fixed-readout-compatible core states at saved checkpoints: only five successes among 45 seed/readout pairs, never before natural success, despite many successful constrained branches. Availability under an intervention, accessibility by constrained optimization, and natural selection are again distinct. Loss barriers on an artificial straight line do not establish a barrier along the optimizer's curved path.

## 9. Signed inputs expose an equivariance-expressivity trade-off

### 9.1 Why standard gates waste capacity

For balanced signed data, the desired recurrence should transform antipodal inputs coherently. A conventional GRU computes sigmoid gates from affine projections. Those gates are monotonic and not even under sign reversal; positive and negative versions of an event can therefore receive different update and reset patterns. In a three-dimensional state, separating opposite signs into roughly orthogonal routes consumes dimensions that are already scarce.

Structurally parity-equivariant variants force the candidate update to be odd and the gates to be even. A simple even gate can be built from absolute value, a smoothed square root of the square, or a square. At k=4, h=3, the standard GRU produced active-delay NMSE around 0.824, while parity variants improved to 0.781 and 0.776. At k=3, a smooth parity variant reached 0.708 versus 0.825 for the standard GRU [Equivariance-Expressivity Trade-off]. Symmetry enforcement therefore recovers real capacity.

It also creates a new problem. One-dimensional magnitude gates lose raw sign information and plateaued around 0.76 to 0.78 at k=4, above the unsigned neighborhood near 0.64. Preventing cancellation and restoring an explicit bilinear sign term did not break the plateau. Error stratification showed that isolated transport, not opposite-sign collisions, contributed about 78% of residual squared error. The resulting trade-off is architectural: asymmetric monotonic gates preserve sign-sensitive control but spend spatial dimensions; strictly even one-dimensional gates preserve parity but lose expressive control of the signed trajectory.

### 9.2 Multidimensional radial gating partly escapes the trade-off

A radial parity gate expands the gate input to M dimensions, squares components, then pools them:

\[
g_t=\sigma\!\left(W_{\mathrm{pool}}
\left(W_xx_t+W_hh_{t-1}\right)^2+b_g\right).
\]

The square makes the gate exactly even under joint sign reversal, while the multidimensional expansion permits level sets that need not collapse along one scalar sign-crossing coordinate. With M=6, h=3, k=4, the radial model reached mean best active-delay NMSE 0.746, versus 0.786 for the aligned one-dimensional additive-parity control, winning seven of eight paired seeds. The gain was modest and optimization-sensitive; reducing learning rate and clipping gradients were necessary to control post-best-checkpoint degradation [Radial Parity Equivariance].

At k=5, h=3, the same family reached active-delay NMSE around 0.714 in its primary comparison and 0.693 under a standardized delay-curve slice. Increasing hidden size to five reduced the k=5 value to 0.539. Across sign-paired sequences, the measured k-step product Jacobian had exactly zero Frobenius difference under sign reversal and mean spectral radius about 4.84. Thus the improved signed solution is not an orthogonal unit-radius rotation. It is an orthant-invariant, super-unit transport process [Symmetry-Shielded Transport].

### 9.3 Causal evidence for cusp-like gate closure

The proposed failure geometry is an origin cusp. A one-dimensional even magnitude gate approaches its minimum when a signed trajectory crosses zero; closing the gate at that transition can disrupt a high-gain memory path. Two interventions support this mechanism within the radial architecture family. Starting from M=6, k=5 checkpoints with active NMSE 0.714, clamping gate preactivations to zero only at opposite-sign events worsened NMSE to 0.745; clamping final gate output to zero worsened it to 0.758. Downstream MSE after intervention increased by 61.9% [Origin-Cusp Intervention].

An architecture ablation independently reproduced the boundary. Models with M=1 and M=2 plateaued at 0.740 and 0.739; M=6 recovered 0.714. During opposite-sign events, the minimum absolute pooled preactivation increased from 8.36e-10 for M=1, to 5.08e-9 for M=2, to 7.30e-8 for M=6. Two dimensions are mathematically sufficient to avoid an origin in principle, but under this optimization problem they were not sufficient to sustain a useful margin. Six-dimensional expansion supplied redundant coordinates that made avoidance trainable.

Inference clamping is out of distribution, so the intervention is not a universal theorem about all gates. The matched architecture ablation substantially strengthens it. The narrow causal conclusion is that cusp-like gate closure damages transport in this checkpoint family and that sufficient quadratic expansion prevents that closure often enough to improve performance.

## 10. Additive phase-plane warping offers a second signed solution

The signed architecture results might suggest that explicit multiplicative gating is necessary. A final constructive sequence tested that assumption using zero-bias block-triangular recurrent cells at k=4, h=3. Their linear core contained a two-dimensional rotational phase plane coupled to a one-dimensional envelope. Exact odd symmetry was enforced by omitting biases.

A purely linear phase plane established active-delay NMSE near 0.86. Multiplicatively modulating its radius and envelope with a quadratic energy gate made performance worse: mean active NMSE 0.911. Event and zero-input gate values barely separated, and most seeds collapsed the modulation scale toward zero. Within this constrained family, multiplicative selectivity damaged superposition rather than helping it [Energy-Modulated Phase Plane].

An additive nonlinear path changed the outcome:

\[
h_t=A h_{t-1}+W_{\mathrm{in}}x_t+
W_{\mathrm{nl}}	anh(Vx_t+Rh_{t-1}).
\]

With six nonlinear expansion units and a linear readout, mean active-delay NMSE fell to 0.667 from the linear neighborhood near 0.86. The explicitly learned phase-plane radius usually fell below one, but a locally fitted effective transition had mean radius 1.239, consistent with nonlinear high-gain transport. Restricting the nonlinear branch to write only into the one-dimensional envelope returned performance to 0.833 to 0.836. The improvement therefore required warping the two-dimensional phase orbit itself, not merely modulating an amplitude envelope [Additive Phase Plane; Envelope Ablation].

A bias-free nonlinear readout

\[
\hat y_t=W_2	anh(W_1h_t)
\]

tested whether the remaining error was partly a linear-readout ceiling. Final-epoch NMSE across three seeds was 0.477, 0.698, and 0.698, so the architecture did not robustly solve the task. Yet one seed transiently reached 0.1715 at epoch 200, with variance ratio 0.781, before degrading to 0.477. The other two never approached this state [Nonlinear-Readout Phase Plane].

This transient is scientifically important but must be stated correctly. It is not robust evidence that the architecture reliably attains NMSE 0.17. It is direct existence evidence that, within this trained family, a three-dimensional recurrent state can temporarily support a nonlinear mapping that recovers far more of the five-dimensional delayed target than its linear readout exposes. The subsequent degradation is an optimization and persistence failure. It strengthens the broader selection thesis: representational availability, trainability, and stable endpoint selection are separate.

The contrast between multiplicative and additive mechanisms also refines the geometric story. A multiplicative gate scales the entire historical orbit and can corrupt superposition of older pulses. An additive odd pathway introduces new trajectory directions while preserving sign symmetry. Within the tested phase-plane family, it is the latter that breaks the linear rank floor. Together with radial parity gating, this yields two constructive routes through the signed bottleneck: shield a high-gain multiplicative transport mode with adequate symmetry geometry, or avoid multiplicative collapse by additively warping the phase plane.

## 11. An integrated account of what training selects

The experimental record supports a layered account rather than a single universal mechanism.

### Layer 1: task demand

Delay, event separation, temporal silence, simultaneous channel count, and sign symmetry determine what must coexist in the state. The formal delay k is only one demand variable. Closely spaced events increase concurrent load. Exactly silent intervals permit errors to decay and nonlinear event paths to remain separated. Balanced signs require a transport rule that respects parity.

### Layer 2: representational supply

Hidden dimension, recurrent rank, readout class, and gating expansion determine which algorithms exist. A capacity-h linear buffer is always the second-order baseline. A rank-k low-gain delay line becomes available when sufficient operator rank and appropriate parameterization are supplied. A nonlinear readout can expose information hidden from a linear projection. Gating can reduce temporal crowding but cannot erase the absolute state bottleneck.

### Layer 3: operator family

At least two primary recurrent algorithms recur across experiments. The low-gain family is lag-pure, near-nilpotent or contractive, and resembles a compressed shift register. The high-gain family is higher-rank, non-normal, distributed across lags, and stabilized by saturation or gates. Signed architectures add symmetry-preserving variants of the high-gain family and additive phase-warping solutions.

### Layer 4: optimization selection

Training does not choose uniformly among available algorithms. Unconstrained parameterizations grow rank almost immediately and usually abandon the clean low-gain route at k=4. Early learning establishes an operating-point band largely independent of initialization scale. Gain and saturation are recruited at different stages. Softly shaping an operator does not guarantee a compatible readout. Some apparent failures simply require a longer horizon, whereas other representationally available paths are accessible only under constrained continuation and are rarely visited naturally.

This layered model explains why several simple propositions fail:

- **"The network fails because h is smaller than d."** Incomplete. The second-order error follows h/k, and nonlinear models exploit higher-order structure to do better.
- **"High gain is caused by high-gain initialization."** False in the tested regime. High-gain endpoints emerged across initialization scales, while floor-crossing operating points collapsed into learned bands.
- **"If a low-gain delay line exists, ordinary training will find it."** False at k=4. It is available but rarely selected when rank is free.
- **"Gates solve long memory."** Too broad. They reduce some interference and stabilize some tangent dynamics, but balanced signs create an equivariance-expressivity cost.
- **"A failed checkpoint is a failed basin."** Often false. Many signed k=5 failures at step 2,000 became successes by step 8,000.
- **"A damaging perturbation explains natural error."** Not necessarily. Rare opposite-sign collisions were mechanistically informative but contributed little natural error.
- **"A straight interpolation barrier proves inaccessibility."** False in the measured continuation panel. Curved constrained optimization paths succeeded where straight paths did not.

## 12. Direct answer to the central research question

When small recurrent networks are trained on fixed k-delay datasets, the following reproducible solution structures emerge.

**In their parameters**, linear networks increase recurrent persistence with delay and obey a capacity budget distributed over the delay pipeline. High-delay tanh networks instead learn raw super-unit, non-normal recurrent operators, commonly with radii around 2.5 to 2.8 in aligned h=3 studies. Low-gain rank-k operators also exist and can concentrate nearly all local input-output response at the target lag, but unconstrained optimization usually grows rank and leaves them. Signed radial gates produce orthant-invariant high-gain Jacobians, while additive phase-plane models place nonlinear correction directly in the recurrent orbit.

**In their dynamics**, the linear family acts as a depth-k compressed buffer whose total decodable dimension is approximately h. Nonlinear solutions exploit temporally sparse higher-order event structure. Their best-supported geometric signature is anisotropic, non-normal transport: some phase perturbations contract while amplitude directions transiently amplify, with saturation or gating bounding the result. High-delay tanh models build gain before reaching the linear floor and recruit saturation after it, often after the target transport window inside the sequence.

**Across training**, learning is staged. Models first acquire the second-order solution and then, when input structure and optimization permit, cross below the linear floor. Reachability, depth, and timing vary independently. The recurrent operating point is formed during successful early descent rather than inherited from initialization. The exact minimal-drive floor solution is metastable, and escaping it requires a higher operating point. Which recurrent family is selected depends on parameterization and end-to-end trainability, not representation alone.

**Across delays and capacities**, h/k controls the linear baseline. Temporal separation strongly controls nonlinear recruitment below the robust k near 4 onset, while high-delay escape is more widespread. Additional hidden capacity deepens escape and can reopen low-gain families in some cells, but a monotone "more capacity means less gain" rule was not supported. At k=5, no tested rank up to six in hidden sizes up to seven recruited the clean low-gain family under the tested schedules, whereas GRU and tanh models continued to use high-gain solutions.

**Across architectures**, ordinary tanh, standard GRU, parity-equivariant gates, radial quadratic gates, and additive phase planes occupy different trade-offs. Gating can stabilize long transport and reduce separation load, but standard monotonic gates mishandle antipodal structure. One-dimensional parity gates recover symmetry at an expressivity cost. Multidimensional quadratic gates and additive odd pathways partly escape that cost through different geometries.

**In their failures**, networks can fail to detect events, fail to preserve them, fail to align them with a readout, fail only under selected collisions, fail because joint training cannot coordinate an otherwise sufficient operator and readout, or simply fail to have trained long enough. These modes are empirically separable. The dominant signed sparse-event failure in the natural test distribution was isolated finite-horizon transport weakness, not rare collision catastrophe.

The overall scientific answer is therefore a solution-family account. The learned computation is not specified by the task alone. The task supplies a demand profile; the architecture supplies a menu of state-space algorithms; and optimization selects among them with strong implicit biases. The most robust high-delay outcome under ordinary unconstrained training is a high-gain, non-normal, saturation-stabilized transport process, even when a cleaner low-gain delay line is available.

## 13. Limits and unresolved questions

The primary claims concern input/output dimension five, sequence length ten, hidden size at most three, MSE training, and the fixed data analyzed here. Auxiliary hidden sizes up to sixteen were used to expose mechanisms but should not be mistaken for a scaling theory of large recurrent models. The compressed-buffer predictor is close but not exact at fractional h/k, and all measured floors remain empirical optimization estimates.

The nonlinear escape is small in absolute MSE. Its existence is well supported by covariance-matched nulls and bias-controlled estimation, but some early cells changed classification under better seeds or longer schedules. Accordingly, the paper emphasizes families, confidence intervals, and horizons rather than universal binary boundaries.

Several geometric claims remain local. Trajectory-PCA tangent and radial measurements, effective Jacobians, and finite-difference lag responses reveal reproducible structure but do not reconstruct the full global manifold. The non-normal saddle is the strongest current dynamical model, not a proof that one scalar geometric transition causes every escape, staging gap, and transport failure.

The solution-selection evidence is optimizer- and parameterization-dependent. The held-versus-freed contrast mixes rank freedom with matrix parameterization; the soft-penalty study removes that specific confound but introduces penalty schedules and still leaves readout coupling unresolved. Other optimizers, continuous rank controls, and alternating or closed-form readout updates could change which family is selected.

Longer-horizon results counsel restraint. Success at step 8,000 is not guaranteed to persist forever, and a transient NMSE of 0.171 in the nonlinear-readout phase plane is not a robust endpoint. Conversely, failure at a conventional training step cannot be promoted to impossibility without continuation evidence.

The highest-value unresolved questions follow directly from these limits:

1. Can a single full-matrix parameterization with continuous low-rank pressure and a coupled readout solver make the low-gain k=4 line naturally selectable?
2. Which early trajectory statistic predicts whether a seed will choose a clean lag-concentrated operator, a high-gain distributed operator, or a late escape?
3. Does a directly measured change in tangent-radial geometry coincide with the behavioral floor crossing within individual runs?
4. Can the transient nonlinear-readout phase-plane solution be stabilized by freezing the recurrent core at its best checkpoint and fitting only the readout?
5. Which parts of the signed symmetry trade-off persist for longer sequences, different event statistics, and hidden sizes large enough to represent a full delay line without compression?

## 14. Conclusion

The fixed k-delay task reveals a surprisingly rich set of learned computations under extreme state compression. The linear baseline is governed by a simple and reproducible rule: an h-dimensional state behaves as a depth-k buffer with roughly h/k preserved dimensions per delayed input. This is the covariance-limited backbone of the problem.

Nonlinearity does not abolish that backbone; it makes a small higher-order correction by exploiting the data's sparse event structure. Achieving that correction reorganizes the recurrent computation. Successful high-delay tanh networks use super-unit, non-normal operators and stabilize them with saturation. Learning first approaches the linear solution, then enters a second stage. Clean low-gain delay lines exist and can be trained under constraints, but ordinary unconstrained optimization typically abandons them as recurrent rank grows. The learned solution is therefore determined as much by algorithm selection and end-to-end trainability as by representational possibility.

Signed inputs make this conclusion even sharper. Architectures must negotiate symmetry, expressivity, and spatial capacity. Standard gates spend capacity on sign asymmetry; scalar parity gates save capacity but lose control; multidimensional radial gates protect high-gain transport; additive nonlinear phase planes offer a separate route by warping the orbit instead of scaling it. None is a universal solution, but together they expose the design principles that matter.

The central lesson extends beyond this small task. A recurrent network's final loss is a poor description of what it has learned. Reproducible understanding requires a ledger of task demand, representational supply, operator family, optimization trajectory, and failure prevalence. In this system, that ledger yields a concrete answer: small RNNs do not learn one delay mechanism. They learn a constrained family of compressed buffers and nonlinear transport algorithms, and standard training strongly favors the high-gain family at the boundary where the cleanest algorithm becomes difficult to coordinate.

## Evidence sources

The synthesis is based exclusively on the fixed local experimental corpus accompanying the task. For external readability, sources are named by scientific contribution rather than by internal record identifiers:

- *The h/k State-Capacity Law: Reconstruction Fidelity of Small k-Delay RNNs Is Governed by Effective Preserved Dimensions.*
- *Sparse Positive Events Drive Nonlinear k=5 Delay Emergence in h3 Tanh RNNs.*
- *A Bias-Controlled, High-k-Concentrated Characterization of the Non-Linear Escape Above the h/k Floor.*
- *The Non-Normal Saddle Manifold: Dynamical Geometry of the Non-Linear Escape.*
- *Balanced Signed Events Fail Through Finite-Horizon Transport in k5 h3 Tanh RNNs.*
- *A Two-Regime Law for the Non-Linear Escape in Small k-Delay RNNs.*
- *The Shattered Saddle: Tangent Instability and Geometric Breakdown of the Non-Linear Escape at High Delays.*
- *Capacity-Linked Escape Depth and the Delay-Dependent Gating Advantage in Small k-Delay RNNs.*
- *Sparse-Manifold Robustness and Collision-Selective Failure in k5 h3 Tanh Event Transport.*
- *Parity-Induced Manifold Degradation: The Global Geometric Cost of Monotonic Gating.*
- *Geometric Stabilization of the Shattered Saddle.*
- *Natural Collision Error Is a Tail Boundary in Signed k5 h3 Tanh Event Transport.*
- *Sequential Staging of the Non-Linear Escape.*
- *A Separation-Dependent Capacity-Load Law for Nonlinear Escape in Small k-Delay RNNs.*
- *The Geometric Capacity Bottleneck: A Phase-Space Synthesis of Sequence Delay Limits.*
- *From Sparse Support to Transport Boundaries: Formation, Transport, Robustness, and Natural Relevance.*
- *What a Small RNN Learns on a k-Delay Task: A Three-Axis Account of the Non-Linear Escape.*
- *Explicit Gating Partially Mitigates the Separation-Load Slope.*
- *The Equivariance-Expressivity Trade-off.*
- *Two Spectral Strategies Under the Nilpotency Ceiling.*
- *The Low-Gain Solution Is Capacity-Gated Below the Escape Onset.*
- *Step-2000 Transport Death Is Horizon-Sensitive.*
- *The Linear-Floor Solution Is a Trap, and Escape Requires Crossing an Operating-Point Threshold.*
- *Two Algorithmically Distinct Delay Solutions and Why Unconstrained Training Selects the High-Gain One.*
- *Radial Parity Equivariance: Unifying Symmetry and Phase-Encoding via Quadratic Gating.*
- *Initialization-Invariant Formation and an Onset-Specific Heavy Tail of the Floor-Crossing Operating Point.*
- *How Small RNNs Choose a Delay Algorithm.*
- *The Three-Axis Structure of the Non-Linear k-Delay Escape.*
- *The Symmetry-Shielded Non-Normal Saddle.*
- *Available But Rarely Selected: Fixed-Readout Core Recoding in Delayed k5 Transport Escape.*
- *Causal Verification of the Origin-Cusp.*
- *Bypassing Multiplicative Collapse: Additive Non-Linear Phase-Planes for Extreme Compression Transport.*
