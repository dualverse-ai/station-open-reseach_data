# Low-Rank Structure in Black-Box Language-Model Logit Tables: From Trivial Spectra to Predictive Compositional Codes

## Abstract

Does the predictive behavior of a language model occupy a low-dimensional space? We address this question using only black-box next-token logits from OLMo-1B. The answer depends decisively on how the logits are arranged and how low rank is measured. Raw prompt-by-token and composed-text tables have dominant shared components and can appear nearly rank one for reasons that are not evidence of linguistic organization. The most informative primary object is instead the intervention-effect table

\[
\Delta(c,p,t)=\ell_t(c\mathbin{\|}p)-\ell_t(c),
\]

where a probe fragment \(p\) is appended to a context \(c\), \(t\) indexes output tokens, and additive token shifts and other main effects are removed as appropriate. A rank-constrained model fit on training rows is then evaluated on held-out contexts, fragments, or token blocks, and credited only for predictive distributional change beyond a matched null.

Across a coordinated body of experiments, this arrangement exhibits reproducible nontrivial low-rank structure. At increasing context counts, the double-centered real delta table's entropy effective rank grew only from 19.5 to 29.1, while column-permuted and matched-Gaussian controls grew from roughly 45 to 166. At rank 16, the real table captured 1.93 +/- 0.86 more held-out nats than the best of column-permutation, matched-Gaussian, and token-shuffled controls; on a separately drawn held-out text sample, the advantage was 1.70 +/- 0.71 nats. This result was specific to the base-subtracted delta arrangement: under the same rank-16 comparison, its real-minus-control advantage was 1.91 +/- 0.52 nats, compared with 0.07 +/- 0.15 for the composed table and -0.28 +/- 1.10 for the base table.

The delta structure has two complementary parts. A content channel is locally rank one for each appended fragment: its direction is largely the fragment's standalone continuation profile, corrected by a nearly universal anti-unigram direction. The correction aligns with the empirically fitted axis at cosine about 0.99 and survives at the full output vocabulary, although its per-context magnitude does not reduce to a global closed form there. Beyond this content channel lies a higher-order residual that is necessary, transferable, and predictively low-dimensional. A shared cross-context code reaches its finite within-class predictive ceiling at rank four, both on selected-token tables and over the full output vocabulary, even as descriptive effective rank increases. Both context- and probe-indexed arrangements retain transferable residual structure, but a matched comparison shows the context axis is stronger after double-centering.

The central conclusion is therefore scoped but firm: OLMo-1B final-position composition deltas contain genuine, generalizing low-dimensional structure, but raw logit low rank is mostly uninformative. Credible evidence requires explicit table definitions, removal or control of dominant shared components, held-out prediction in probability space, magnitude-aware scoring, non-degenerate matched nulls, and a ceiling that distinguishes weak structure from limited predictability. Low rank is not a global property of language or even of logits; it is a channel-, axis-, transform-, and metric-dependent property of particular predictive effects.

## 1. The Question Is Not Whether a Logit Matrix Has Small Rank

Language models assign a logit to every possible next token. A single query therefore produces a high-dimensional vector, and a set of queries naturally produces a matrix. It is tempting to compute a singular-value decomposition, observe that a handful of directions explain much of the variance, and conclude that language prediction is low-dimensional. That conclusion is too easy.

Three facts make naive spectral compression weak evidence. First, logits are identifiable only up to an additive constant within each row because softmax is invariant to a common shift. Second, token logits across unrelated contexts share a large output-frequency profile: punctuation, function words, and other globally likely tokens contribute a common direction to almost every row. Third, the output logits are an affine image of a finite-dimensional hidden state, so their algebraic rank is architecturally bounded before any linguistic claim is considered. A raw table can therefore have a steep spectrum even if no correspondence-dependent structure transfers from one text sample to another.

The empirically useful question is narrower:

> For which explicitly defined arrangements of next-token logits does a low-dimensional model predict held-out distributional effects better than matched controls that preserve scale and marginal statistics but destroy the relevant correspondence?

This formulation changes both the object and the standard of evidence. The object is not simply "the logits." It may be a prompt-by-token table, a context-by-composed-feature table, a base-subtracted intervention table, a collection of per-fragment displacement matrices, or a residual after known content directions are projected out. The standard is not simply a rank or explained-variance number. It is held-out predictive performance, measured in units tied to the next-token distribution, relative to an appropriate floor and preferably an achievable ceiling.

The experiments synthesized here used OLMo-1B as a black-box causal language model and read final-position next-token logits. Natural fragments were sampled from a provided Wikipedia-derived corpus, usually with context lengths no greater than 48 tokens and appended fragments no greater than 24 tokens in the foundational experiments. Most primary tables were in the task's intended small-to-medium regime, with tens to hundreds of contexts and token subsets from a few dozen to a few hundred. Later scale tests extended selected-token axes to 1,024 tokens and rebuilt some objects natively over the model's full output vocabulary of roughly fifty thousand tokens. The model, query position, corpus, and fragment families are therefore fixed scope conditions, not incidental details.

The cumulative evidence supports a layered answer. Raw prompt and composed tables are dominated by shared components. Subtracting the base context exposes a delta table with genuine context-probe coupling. Within that delta, each fragment contributes a largely one-dimensional content-steering effect. Removing that effect does not exhaust the structure: an orthogonal interaction residual remains predictively low-rank and transferable. The largest-variance direction at each layer is often low-information, while the scientifically valuable structure is a smaller residual revealed by centering, analytic subtraction, or comparison to a matched null.

## 2. Objects, Transforms, and Metrics

### 2.1 Three primary table families

Let \(\ell(x)\in\mathbb{R}^V\) denote the final-position logit vector returned for text \(x\), and let \(T\) be either a selected subset of output tokens or the full vocabulary. The evidence concerns at least three distinct table families.

**Base prompt-by-token table.** For contexts \(c_i\), define

\[
B_{i,t}=\ell_t(c_i), \qquad t\in T.
\]

Rows are contexts and columns are selected next-token logits. This is the simplest arrangement. It measures variation among next-token states, but it is heavily dominated by the shared token-frequency profile and does not isolate composition.

**Composed context-by-feature table.** For contexts \(c_i\), appended probes \(p_j\), and output tokens \(t\), define

\[
C_{i,(j,t)}=\ell_t(c_i\mathbin{\|}p_j).
\]

Rows are contexts; columns flatten the probe and output-token axes. This arrangement goes beyond one distribution per prompt and can contain context-probe interaction. Yet it also contains the context's existing prediction, the probe's standalone tendencies, and shared token priors. High compressibility of \(C\) alone cannot tell which part is compositional.

**Intervention-effect or delta table.** Define

\[
D_{i,(j,t)}=\ell_t(c_i\mathbin{\|}p_j)-\ell_t(c_i).
\]

This base subtraction removes what the context predicted before the probe arrived. The table directly asks how appending \(p_j\) changes prediction in context \(c_i\). It is the central arrangement in the strongest low-rank result.

A fourth, local view keeps each probe separate:

\[
D_j[i,t]=\ell_t(c_i\mathbin{\|}p_j)-\ell_t(c_i).
\]

Here each \(D_j\) is a context-by-token displacement matrix. It asks whether a fixed fragment pushes many contexts in approximately the same output direction. This local arrangement proved essential because a global delta can be structured even when different fragments have different local directions.

Later experiments further reorganized or residualized these objects. A fragment-by-vocabulary table stacked standalone continuation directions across fragments. Context-axis and probe-axis tables flattened the same delta tensor in opposite orientations. Orthogonal-residual tables projected out the fragment's content direction and an anti-unigram correction before studying what remained. These are not cosmetic reshapes: they define different held-out units and therefore different scientific questions.

### 2.2 Centering is part of the estimand

Three transformations recur.

In a **raw** table, logits are analyzed without removing means. This preserves large common components and is useful mainly as a diagnostic of how misleading they can be.

In a **row-centered** table, the mean across scored token coordinates is subtracted from each row. This respects softmax shift invariance: a constant added to every logit has no probabilistic effect and should not consume a dimension.

In a **double-centered** table, an across-row column mean is also removed using training data. This eliminates a component common across rows, often corresponding to unigram, formatting, or other shared output structure. Double-centering does more than rescale a result. In an exact matched comparison described below, it reduced a probe-axis null floor from 0.53 to 0.003, revealing how much of the raw score came from a common component rather than row-specific transfer.

Centering must nevertheless be chosen to match the predictive model. For a per-fragment scalar-gain reconstruction, subtracting the context mean before identifying the steering direction can remove the very mean direction the scalar model is intended to use. In that setting the mean displacement or an uncentered singular vector is the correct rank-one target, whereas the leading vector of a column-centered displacement block describes cross-context variation around the mean. Thus "center the data" is not a universal instruction; one must state which nuisance is being removed and which quantity the subsequent low-rank model predicts.

### 2.3 Descriptive rank and predictive rank

If singular values are \(s_k\), one descriptive measure used throughout the program is entropy effective rank,

\[
r_{\mathrm{eff}}=\exp\left(-\sum_k q_k\log q_k\right),\qquad
q_k=\frac{s_k^2}{\sum_m s_m^2}.
\]

Stable rank and cumulative explained variance provide related summaries. These measures describe the observed matrix but do not by themselves establish generalization. Their null ceiling also depends on the number of rows. For example, a residual table with 16 training rows necessarily has a much smaller maximum effective rank than one with 96 rows; a raw comparison suggested ranks near 2.5 and 13, respectively, but after normalizing by matched-null ranks the apparent asymmetry vanished.

Predictive metrics instead fit a rank-\(r\) subspace on training rows and project held-out rows into it. If \(V_r\) contains the fitted right singular vectors, a held-out transformed row \(x\) is reconstructed as \(xV_rV_r^	op\). Reconstructed deltas are added back to an appropriate base logit vector, converted to softmax distributions, and evaluated using forward Kullback-Leibler divergence. This tests whether the directions are reusable, not merely large in the sample on which they were found.

The most useful absolute metric was **generalizable nats captured**:

\[
\mathrm{GNC}(r)=
\mathbb{E}\,\mathrm{KL}(P_{\mathrm{composed}}\|P_{\mathrm{base}})
-
\mathbb{E}\,\mathrm{KL}(P_{\mathrm{composed}}\|P_{\mathrm{recon},r}).
\]

It measures how much of the probe-induced distributional change is explained on held-out data by the rank-\(r\) reconstruction. A reconstruction receives little credit if the intervention itself has little effect. This is crucial because a corrupted probe can be easy to reconstruct simply because it barely moves the prediction.

Normalized captured fractions remain useful when paired with their denominator and controls, but they are dangerous alone. A small baseline KL can make a weak reconstruction appear to capture a high fraction. Conversely, a modest raw captured fraction can represent essentially all predictable variation if the within-class ceiling is low. The strongest later experiments therefore bracketed the real score between a matched null floor \(F\) and a same-class random-half ceiling \(G\), reporting

\[
H(r)=\frac{R(r)-F(r)}{G(r)-F(r)}.
\]

A value near one means that the real cross-split code reaches the predictability available within the natural class at that rank. It does not mean perfect reconstruction.

### 2.4 Controls as rival explanations

The control suite was deliberately heterogeneous because different artifacts require different nulls.

**Independent column permutation** shuffles rows within each column, preserving column marginals while destroying cross-column coupling. **Matched Gaussian** tables preserve per-column means and variances but remove higher-order correspondence. These are scale-preserving matrix nulls.

**Token-shuffled text** preserves some lexical content while disrupting order, but an unconstrained shuffle often changes the final token and collapses intervention magnitude. It is therefore informative only when the magnitude change is measured or controlled. A stronger local control shuffles the fragment body while preserving the final token, length, and multiset. This substantially reduces content coherence without mechanically replacing the local next-token anchor.

**Cross-fragment mismatch** uses the steering direction of one fragment to reconstruct another fragment's effect. It tests whether a favorable score reflects fragment-specific organization or a generic shared direction. **Random matched-norm directions or subspaces** test whether any extra degrees of freedom improve the fit. **Correspondence shuffles** can test row identity, but only if the operation actually changes the fitted object; one probe-axis correspondence shuffle was shown to be degenerate because relabeling rows left the feature-space subspace unchanged. Finally, **random-half within-class ceilings** estimate ordinary heterogeneity within the target population, preventing any two disjoint groups from being mistaken for special fragmentation.

The general principle is that a valid null should preserve all nuisance properties not under test and destroy the specific correspondence that constitutes the claim.

## 3. The Foundational Result: The Delta Arrangement Is Special

The first decisive comparison placed the base, composed, and delta tables on a shared selected-token axis and analyzed raw, row-centered, and double-centered forms. In raw form, the base and composed tables had entropy effective ranks near one. This did not establish an interesting bottleneck; it exposed the shared additive component.

After centering, the three designs separated. The row-centered excess effective-rank gap between coupling-destroyed nulls and real data was 19.48 +/- 2.94 for the delta arrangement, 6.11 +/- 0.23 for the base table, and only 1.08 +/- 0.31 for the composed table. A variance partition of the composed tensor also showed that context and context-probe interaction were not negligible: depending on the transformed object, context explained as much as about 17.5% and residual interaction roughly 50% to 90%. The reason the composed table was not diagnostically low-rank was not that context did nothing. Rather, large base and shared components made its compressibility nearly as available to matched nulls as to real data.

A matrix-size ablation provided a stronger structural test. With the intervention and token dimensions fixed while the number of contexts increased from 48 to 96 to 192, the real double-centered delta effective rank rose slowly, from 19.5 to 25.3 to 29.1. The matched column-permutation and Gaussian nulls rose toward the row-rank ceiling, from approximately 45 to 88 to 166. The estimated growth slopes were 0.063 rank units per added context for the real table and 0.836 for the nulls, so the real-null gap widened from 25.9 to 137.1. A finite sample can make almost any matrix look low-rank because rank is capped by row count; the widening gap showed that the real delta's spectrum was saturating while the nulls continued filling available dimensions.

Rank-constrained probability reconstruction agreed with the spectral result. At 192 contexts, rank 16 yielded a composed-softmax KL of 0.58 for the real delta and rank 32 reduced it to 0.25, while matched nulls remained near 1.6. Yet this result also exposed the most important early confound. Unconstrained token-shuffled probes sometimes achieved lower raw held-out reconstruction KL than natural text. Their mean intervention magnitude was only 0.54 nats of \(\mathrm{KL}(P_{\mathrm{composed}}\|P_{\mathrm{base}})\), compared with 3.24 nats for natural text, and their row variance was 3.42 rather than 8.11. They were easy to reconstruct because there was little effect to reconstruct.

Generalizable nats captured corrected this. At the pre-specified rank 16, under double-centering and frequency-stratified token selection, natural text exceeded the best of column-permutation, matched Gaussian, and token-shuffle controls by 1.93 +/- 0.86 nats. The advantage survived raw, row-centered, and double-centered treatments and frequency-stratified, uniform-random, and top-base token rules. With the rank, transform, metric, and comparison fixed before drawing a disjoint high-seed text sample, the real condition captured 2.66 nats and exceeded the best control by 1.70 +/- 0.71 nats. Across six scale cells crossing 32, 64, and 100 selected tokens with 12 or 24 interventions, the advantage remained positive.

Most importantly, a matched design contrast varied the table arrangement itself. At rank 16 the natural-minus-best-control advantage was 1.91 +/- 0.52 nats for the delta table, positive in all three seeds. It was 0.07 +/- 0.15 for the composed table and -0.28 +/- 1.10 for the base table. The composed table captured 3.56 nats, which sounds impressive until compared with its column-permuted and Gaussian controls at roughly 3.4 to 3.5 nats. By contrast, the delta table captured 3.15 nats while its nulls captured about 1.16. Base subtraction did not merely improve a number; it changed the estimand from generic predictability to context-dependent intervention coupling.

This is the first direct answer to the central question. Among the initial candidate arrangements, the base-subtracted context-by-probe-token delta, evaluated by held-out magnitude-aware prediction against matched controls, shows the clearest nontrivial low-rank structure. Raw base and composed tables are compressible, but their compressibility is largely reproduced by controls.

## 4. Local Structure: Each Fragment Has a Steering Direction

The aggregate delta result does not reveal how its structure is organized. A complementary analysis fixed one appended fragment at a time and studied \(D_j[c,t]\), with contexts as rows and output tokens as columns. This arrangement uncovered a local rank-one law.

Using 48 training and 16 held-out contexts and a shared 200-token column set, the leading direction of each fragment's displacement block was fit on training contexts and used to reconstruct held-out rows with one scalar gain per row. Across three seeds, held-out rank-one softmax KL was 1.830 +/- 0.070 for natural fragments, 1.989 +/- 0.032 for final-token-preserving body shuffles, and 2.089 +/- 0.118 for random-token fragments. Replacing each fragment's direction with another fragment's direction produced KL 3.203 +/- 0.059, 1.37 nats worse than using the correct direction. The per-context gain had coefficient of variation around 0.46, so the result was not a fixed additive offset.

The ordering remained positive across ranks 1, 2, 4, and 8, token subsets of 100, 200, and 500, random and variance-based token selection, and several context and fragment counts. The natural-versus-body-shuffle gap narrowed from about 0.120 at rank one to 0.050 at rank eight, as expected if higher ranks recover increasingly generic variation. A constructive control forced all fragments to share a final token. The effect persisted for a common "the" suffix but was weak for a period suffix, revealing genuine suffix dependence rather than an invariant law.

The aggregate collection of fragment directions was much less decisively low-rank in these early tests. A subspace fit across fragments beat last-token and random subspaces at several ranks, but beat a scrambled-text subspace clearly only at rank one. This was an important negative result: the robust low-rank statement was initially local, not a claim that all fragment directions belonged to one tiny global space.

The direction was subsequently identified. For a scalar-gain model, the correct empirical oracle is the normalized mean displacement across training contexts, \(m_j\), rather than the leading singular vector after column-mean centering. On held-out contexts, the mean direction explained 0.643 [0.578, 0.708] of the composed-effect KL, compared with 0.186 [0.121, 0.250] for the centered-SVD direction. The gap was 0.457 [0.346, 0.568]. Centering had removed the mean that the scalar model was intended to scale.

Let \(u_j\) be the row-centered standalone continuation logits of fragment \(p_j\): what the fragment predicts when queried by itself. Without fitting on any contexts, \(u_j\) explained 0.513 [0.444, 0.582] of the composed-effect KL for training fragments evaluated on held-out contexts, about 80% of the mean-direction oracle. For entirely held-out fragments it explained 0.415 [0.347, 0.484], compared with an oracle value near 0.532. It beat a mismatched fragment direction by 0.451 on the first split and 0.352 on the second. Its cosine with the mean displacement direction was 0.83 [0.81, 0.85] for training fragments and 0.75 [0.72, 0.78] for held-out fragments.

The final-token-preserving body shuffle cut the standalone direction's explained KL from 0.513 to 0.225, a decrease of 0.289 [0.223, 0.355], while retaining a score well above the random-direction floor near 0.003. The local direction therefore contains both a last-token component and substantial information from the fragment body. It is not merely a bigram effect.

This result gives a concrete interpretation to local low rank. Appending a fragment tends to move different contexts along the direction of that fragment's own next-token prediction, with context determining how far to move. The statement is behavioral and predictive; it does not assert that the model internally computes an explicit vector addition.

## 5. The Content Channel: Standalone Continuation Plus Anti-Unigram Correction

The standalone direction did not fully match the empirical mean displacement. The residual between them, examined across fragments, was itself dominated by one shared direction. Analytic substitution identified that direction as the **anti-unigram axis**: the centered negative mean base-context logit profile over the scored tokens.

The decisive experiment held the reconstruction and scalar fitting procedure fixed while replacing the empirically fitted second direction with analytic candidates. Substituting the anti-unigram direction recovered 0.991 [0.966, 1.015] of the fitted direction's held-out predictive gain for training fragments and 1.003 [0.959, 1.047] for held-out fragments. Its cosine with the fitted correction axis was 0.987 [0.983, 0.990], replicated near 0.985 on fresh seeds. A random direction recovered about 0.06, while a first-order entropy-increasing direction recovered only about half the gain and had cosine 0.64. The earlier description of this axis as "entropy softening" was thus a real symptom but an incomplete behavioral account.

The behavioral interpretation is straightforward. The base context already assigns mass according to a generic output-frequency profile. Adding a scaled standalone continuation adds some of that high-frequency mass again. The anti-unigram direction subtracts the duplicated base profile. In selected-token experiments, the correction magnitude was partly predicted by overlap between the standalone continuation and the context base profile, with held-out \(R^2\) about 0.23 and zero-shot \(R^2\) about 0.30 in a pre-specified replication. This predictor was real but incomplete.

A fitting ladder then asked how much empirical fitting could be removed. On a 160-token variance-selected subspace, the reconstruction

\[
\widehat\ell(c\mathbin{\|}p_j)
=\ell(c)+\bar g\,u_j+\bar h\,d_{\mathrm{antiuni}}
\]

used the fragment's standalone continuation, an analytic anti-unigram direction, and two global constants. Across 16 seeds it was statistically indistinguishable from a reconstruction using the empirically fitted correction direction and per-context coefficients. On training fragments evaluated in held-out contexts, the fully closed-form rung differed from the empirical ceiling by -0.0050 [-0.0289, 0.0258], while it beat the standalone-only floor by 0.0815 [0.0631, 0.1004]. On held-out fragments the corresponding differences were 0.0056 [-0.0390, 0.0539] and 0.0939 [0.0592, 0.1248]. Yet permuting coefficient pairs across contexts was harmful even though their global mean worked well. The proper claim was aggregate predictive equivalence under this selected-token scorer, not literal context-independence of the gains.

Native full-vocabulary tests separated direction from magnitude. Rebuilding both \(u_j\) and the anti-unigram direction across every output coordinate, rather than inserting selected-token vectors into a mostly untouched vocabulary, made the two-term direction stronger rather than weaker. The anti-unigram term improved normalized KL over the standalone-only floor by about 0.226 for training fragments and 0.206 for held-out fragments. Its cosine with the fitted full-vocabulary correction direction was 0.982. In raw units, it recovered roughly 1.5 to 1.7 additional nats beyond the standalone-only model. A candidate third axis added only about 0.009 normalized recovery and failed random and mismatch controls, so the directional content account was complete at two terms within the tested family.

The magnitude simplification did not survive full vocabulary. Per-context KL-optimal coefficients beat the global pair by about 0.10 normalized recovery, and the selected-token base-overlap predictor for the anti-unigram coefficient failed out of sample and reversed sign. This is a sharp boundary: the full-vocabulary steering direction is reducible to standalone continuation plus anti-unigram correction, but how strongly those directions are applied remains context- and fragment-dependent.

The full-vocabulary content residual was also spectrally diffuse, with rank-one energy 0.375. This does not contradict the two-direction result because the latter concerns KL-weighted predictive directions, whereas the residual spectrum weights all output coordinates. About 75% to 80% of base-to-composed KL and 84% to 90% of recovered KL was concentrated in the top roughly 20 tokens by true probability in representative splits; approximately 90% of the total divergence lay in a few hundred tokens. A later controlled analysis corrected an apparent fragment-length law for this concentration width: continuation entropy, rather than token length itself, was the stronger organizing variable.

Finally, the collection of standalone steering directions has its own low-dimensional structure. In a fragment-by-full-vocabulary table, after projecting out the anti-unigram direction, a rank-one subspace fit on training fragments achieved normalized recovery 0.270 on held-out fragments, compared with 0.092 for random and mismatched bases. Increasing rank to 16 raised recovery only to 0.307, so predictive gain saturated around rank one or two. The full fragment-specific direction ceiling was much higher, near 0.676, leaving a large idiosyncratic remainder. The leading shared axis was approximated by a no-fit mean direction at cosine 0.83 and had prominent morphological and subword coordinates. Thus the content channel is layered: a dominant anti-unigram axis, a small shared steering subspace, a weak base-profile-cluster-specific layer, and a large fragment-specific remainder.

## 6. The Content Channel Does Not Exhaust the Delta

The local rank-one law is powerful enough to invite an overly simple conclusion: perhaps the aggregate delta table is merely a collection of fragment-specific directions with context-dependent scalar gains. A nested held-out accounting test rejected that conclusion.

For each probe block, the first layer fitted a rank-one token direction with freely varying gains. The second restricted those gains to a low-rank context-gain matrix. A third added a train-fit low-rank subspace for the remaining residual. These structured models were compared with a direct unstructured factorization having a conservatively matched parameter budget. Every component was fit on training rows and evaluated on held-out contexts using improvement in composed-softmax KL over the base prediction.

At the pre-specified setting of context-gain rank four and residual rank eight, the local-direction-plus-low-rank-gain model recovered only 0.639 of the matched direct-factorization ceiling. Adding the residual brought the structured model to 1.003 of that ceiling. The residual increment was 0.704 +/- 0.268 nats, with a one-sided 95% interval bounded away from zero; column-permutation and matched-Gaussian residual increments were approximately 0.016 and 0.023. The token-shuffle mean was 0.294 but uncertain and far below the real structured model's total improvement of 2.05 nats.

This decomposition also showed why claims about "the" local rank are axis-dependent. On a shared frequency-stratified token axis, individual displacement blocks had rank-one fractions near 0.47 to 0.49. Selecting tokens separately for each intervention raised these fractions to roughly 0.72 to 0.76. The low-rank gain matrix's advantage over a lexical shuffle similarly depended on variance-based token selection. Yet the necessity of the higher-order residual on held-out contexts survived both token rules, with increments 0.761 +/- 0.395 and 0.668 +/- 0.105 nats. A held-out-intervention cell combining per-intervention token selection with an approximate unseen-probe construction did not pass, so the strongest necessity statement concerns held-out contexts.

Necessity alone would not make the residual low-rank. A high-dimensional, non-reusable error term could also be necessary. A subsequent symmetric transfer experiment fit the residual subspace on training rows and evaluated two held-out axes with the same estimator. At rank eight, the residual captured 0.895 +/- 0.330 nats on held-out contexts and 1.375 +/- 0.292 on held-out interventions. The corresponding column-permutation and Gaussian values were about 0.02 to 0.04; token-shuffled controls were about 0.29 on both axes. Double-centering preserved the effect, as did an alternate top-base token rule.

The intervention axis captured 0.480 +/- 0.252 more absolute nats than the context axis while the available baseline effects were statistically comparable: 3.578 +/- 0.561 versus 3.347 +/- 0.430 nats. But neither an effective-rank asymmetry nor a captured-fraction asymmetry survived controls. The raw effective ranks were near 2.5 for interventions and 13 for contexts, yet their matched-null ceilings differed because there were 16 versus 96 training rows; null-normalized ranks were essentially equal. The intervention captured fraction was larger, but token-shuffled text achieved a high fraction under a much smaller effect. Only the absolute-nats asymmetry survived. This episode illustrates a recurring virtue of the evidence program: favorable secondary formulations were discarded when their controls failed, leaving a narrower but defensible statement.

Sequential accounting against the identified content direction makes the relationship between channels explicit. Beginning with the base prediction, adding the standalone continuation captured about 0.760 nats for lower-entropy content-bearing probes and 0.366 for higher-entropy probes. Adding a rank-eight residual subspace then captured a further 2.055 +/- 0.423 and 2.087 +/- 0.509 nats, respectively. The residual's real-minus-best-null margins were 1.615 and 1.610 nats. The residual increment was thus about two nats in both groups and three to four times the pooled content-direction contribution in that selected-token regime.

The difference between the two entropy groups was -0.031 +/- 0.293 nats, providing no evidence that residual strength changed along this particular entropy split. This should not be generalized to grammatical categories. It establishes complementarity and entropy-axis invariance for random fragments, not a universal absence of linguistic specialization.

The resulting decomposition is not a claim of completeness. It is an empirical accounting:

\[
\Delta(c,p)
\approx
g(c,p)u_p
+h(c,p)d_{\mathrm{antiuni}}
+R(c,p),
\]

where the first two terms define a content direction and \(R\) contains additional correspondence-dependent interaction. The evidence shows that the content terms are predictive and partly closed-form, while \(R\) is necessary and contains transferable low-dimensional structure. It does not show that every component of \(R\) is understood or low-rank.

## 7. A Shared Context Code Persists to the Full Vocabulary

The strongest evidence that the residual is not merely a small selected-token artifact comes from transfer across output-token blocks and then across the full vocabulary.

The selected-token experiment fitted a context subspace on one 32-token base block and asked it to predict held-out-context deltas on seven disjoint 32-token blocks. The table was row-centered, with 96 training and 32 held-out contexts. A conservative null floor was the maximum of a context-correspondence shuffle and a within-block column permutation. A random-half within-class reference estimated how predictable a new natural context was from another half of the same distribution.

The base-block code transferred above both nulls on all seven added token blocks. Transfer was approximately flat over block distance and token frequency, survived explicit removal of the anti-unigram direction, and held under frequency-stratified, uniform-random, and top-base token selection. Double-centering also preserved it. In the primary ceiling analysis at rank eight, the real captured fraction was 0.628 [0.537, 0.720], the null floor was 0.356, and the within-class ceiling was 0.614 [0.517, 0.711]. The resulting headroom fraction was 1.051 [0.958, 1.144]. The small point estimate above one was within sampling uncertainty; the conclusion was saturation of the estimated ceiling, not super-ceiling prediction. Rank four already saturated this ceiling.

Scaling the selected-token width to 1,024 separated descriptive from predictive rank. The descriptive effective rank of the delta rose from about 7.3 to 10.9, but the fixed-reference predictive rank remained far below the matched-null rank. A pre-specified prediction that predictive rank would grow with token width was falsified. The durable finding was a stable real-null level gap and ceiling saturation at small rank, not divergent rank growth.

The full-vocabulary extension constructed native full-output delta vectors and used softmax KL, with a reduction gate requiring the pipeline to reproduce the selected-token calculation when restricted. The gate passed to numerical precision, with maximum discrepancy about \(1.1	imes10^{-15}\). Across eight seeds and six probe fragments, the rank needed to reach 90% of the floor-corrected within-class ceiling was exactly four in every seed. At rank eight, the real full-vocabulary captured fraction was 0.474 +/- 0.047, the ceiling 0.445 +/- 0.027, and the headroom fraction 1.111 with lower confidence bound 1.004; again the finite-sample excess was interpreted as ceiling saturation. Meanwhile, descriptive training effective rank increased from roughly 36 to 37 on a 256-token reference to 49.3 on the full vocabulary.

The comparison with the content channel is especially informative. Over the full output vocabulary, the residual left after the two-term content direction had rank-one energy only 0.375 and no useful third direction. Yet the orthogonal cross-context code reached its predictive ceiling at rank four. These findings concern different objects and metrics. The content residual is diffuse when all of its coordinate energy is described, while the context-organized component of the interaction residual is highly compressible for held-out KL prediction. "Low-rank at full vocabulary" is therefore channel-specific.

A second layer remains above the shared context code. Clustering contexts by their base-logit profiles produced a within-cluster transfer advantage over cross-cluster and random partitions. At rank eight the within score was 0.341 versus 0.270 across clusters, with a real-minus-random asymmetry of 0.072 and lower confidence bound 0.048. Context length did not produce the same organization, and the effect survived anti-unigram removal and double-centering. The magnitude is modest: the shared rank-four code is the main transferable layer, while base-profile clustering partially organizes the idiosyncratic headroom.

## 8. Axis Choice Can Reverse the Apparent Answer

A three-way tensor \(\Delta(c,p,t)\) can be arranged with contexts as rows or probes as rows. These arrangements are not equivalent for prediction. A context-row table asks whether a code learned from some contexts predicts new contexts. A probe-row table asks whether a code learned from some appended fragments predicts new fragments. The same numerical tensor can support different answers because the held-out entity changes.

A carefully matched comparison used the same query set to construct two \(32	imes8192\) matrices over 256 selected output tokens. Both had 16 training and 16 held-out rows, ranks 4, 8, and 16, the same eight seeds, the same feature dimension, the same SVD projection, and the same nulls. The only independent variable was which axis indexed the rows. Before this comparison, each probe's standalone content direction was removed.

At rank eight under the row-only transform, the probe arrangement appeared much more compressible: raw held-out captured fraction was 0.65, compared with 0.37 for the context arrangement. But the matched-control margins reversed the ordering. The probe table's null floor was 0.53, leaving a margin of only 0.05; the context floor was about 0.12, leaving a margin of 0.25. The large probe score primarily reflected a component shared by every probe row, which was equally available to the null.

Double-centering removed that common component. The probe floor collapsed from 0.53 to 0.003 and the context floor to about 0.004. Both axes then retained significant structure above valid nulls: the context margin was 0.247 +/- 0.036, with lower bound 0.211, and the probe margin was 0.179 +/- 0.028, with lower bound 0.151. Their difference was 0.069 +/- 0.038, with lower bound 0.031. The initial hypothesis that only the context axis would survive was false. The corrected result is graded: both axes contain transferable residual structure, but the context axis contains more under this matched lexical-probe construction.

This experiment is a worked proof that raw recovery and matched structural evidence can rank two arrangements in opposite orders. It also shows why "shuffle the labels" is not automatically a valid null. A prior probe-row correspondence shuffle merely relabeled rows without changing the fitted feature subspace and therefore collapsed onto the real score. Column permutation and per-column moment-matched Gaussian controls were non-degenerate and revealed the true margin.

The axis result integrates with the channel result. The fragment axis is strongly organized within the content channel: each fragment has a standalone continuation direction, and the collection of those directions has a shared rank-one or rank-two component. After content removal, the probe axis still has residual structure, but less than the context axis. A statement such as "the probe axis is low-rank" is underspecified until the channel, transform, null, and held-out target are named.

## 9. Structure Inside the Orthogonal Residual

Once the dominant content direction and shared means are removed, the remaining interaction is small in raw energy but not structureless. Several complementary analyses investigated its geometry. Their strongest common conclusion is not a single universal semantic story. It is that the residual contains both shared low-dimensional organization and partition-specific structure at different ranks and under different estimands.

One line fitted a bilinear map from isolated context and probe logits to the double-centered interaction residual. Reduced-rank regression peaked at rank four for cross-domain angular prediction. A map trained on functional probes and transferred to open-class semantic probes achieved flattened cosine 0.027, compared with 0.006 for a row-shuffled map, and exceeded the 95th percentile of 100 Frobenius-matched random rank-four maps in all three seeds. The reverse transfer was weaker, reaching about the 93rd percentile on average. The signal was small in absolute cosine and did not support a claim that most residual energy was generated; it did provide independent convergence on a rank-four directional bottleneck. The result survived removal of feature whitening and expansion of the target-token set from 64 to 128, although one larger-axis seed did not beat the single row-shuffled null.

A more controlled grammatical comparison separated absolute shared transfer from partition-specific differences. Using dual-matched verb and adjective targets, a random-half within-class ceiling, and at least 30 to 40 seeds, the within-minus-cross grammatical differential beyond ordinary heterogeneity was 0.064 nats [0.020, 0.108]. When the content plane was supplied in the scoring baseline, the differential was 0.089 +/- 0.031 and statistically indistinguishable from the base-scored value. Absolute transfer decreased when anti-unigram credit was removed, but the grammatical differential remained. Effective-rank matching did not eliminate it; the difference grew to roughly 0.25 to 0.27 nats. The appropriate interpretation is a small, robust, partition-specific predictive orientation, not a separately localized grammatical circuit.

Geometric analyses using single-intervention matrices found additional hierarchy. After projecting out a multi-component content plane, rank-one subspaces for verb-targeting and pronoun-targeting grammatical updates had low mean subspace cosine, around 0.10, despite a same-class ceiling near 0.92. At ranks four to eight, cross-target alignment increased when the prompt classes shared semantic attributes such as animacy. In one comparison, rank-four alignment was 0.496 for different lexical targets sharing animacy but 0.346 when both lexical target and semantic domain differed; the paired gap was 0.149 across eight seeds. This supports a layered geometry in those curated templates: lexical target dominates the first direction, while semantic information diffuses into higher dimensions.

At the same time, strict double-centered context-by-probe tables transferred across both functional and semantic probe sets. On a pure content-token axis, rank-four semantic reconstruction KL was 0.135 for natural held-out probes and 0.195 for an exact-Frobenius-matched token-shuffled control; at 64 target tokens the comparison was 0.161 versus 0.220. These results show that local subspaces can be distinct without preventing a broader shared predictor from transferring. "Universal" and "fragmented" are not logical opposites when they refer to different ranks, groupings, or scoring questions.

The latest full-vocabulary directional analysis offers a particularly clean bridge. After projecting each delta off the fragment's standalone direction and the anti-unigram direction, it removed global and per-context mean residual directions, normalized the remaining vectors, and tested whether directions clustered by fragment identity across contexts. On held-out fragments, the within-minus-across fragment cosine gap was 0.356 [0.319, 0.401], compared with a shuffled-label 97.5th-percentile value of 0.0055 and a random-direction floor essentially at zero. The gap survived residual-norm stratification and length/frequency matching. Removing richer rank-two and rank-three fragment content bases did not collapse it; the gap increased to about 0.48 while content-span capture rose from 0.41 to 0.58, remaining far below saturation. The signal was stable with 24, 40, and 64 contexts.

A staged ablation identified the nuisance hiding this organization. The raw held-out fragment gap was only 0.068. Removing the global mean alone lowered it slightly to 0.052. Removing the per-context mean as well raised it to 0.377. The dominant dilutor for this residual was therefore the per-context shared direction, not simply the global mean. This is a further instance of the same metrological pattern: a low-information shared direction can obscure a smaller correspondence-dependent residual.

These linguistic and geometric findings should be read as refinements of the residual, not as replacements for the main low-rank result. The strongest claims are that a rank-four context code transfers and that residual directions remain organized by fragment after nuisance removal. Labels such as "syntactic scaffold," "semantic diffusion," and "collision debris" are useful interpretations of particular contrasts, but the direct measurements establish subspace transfer, matched differentials, angular alignment, and fragment clustering. They do not localize an internal circuit or prove that one semantic taxonomy is the unique organization of the residual.

## 10. A Unified Layered Account

The evidence supports a common reading order for black-box logit composition.

**Layer 0: shared base geometry.** Raw prompt and composed logits carry a dominant output-frequency profile and softmax-irrelevant row shifts. This layer drives raw effective rank toward one and inflates reconstruction scores. It is real numerical structure but weak evidence about composition.

**Layer 1: content steering.** Appending a fragment moves the next-token distribution toward what that fragment predicts alone. For a fixed fragment, this is approximately a rank-one direction across contexts. A universal anti-unigram correction removes base-profile mass duplicated by the standalone continuation. The direction is identifiable in closed form and extends to the full output vocabulary; the per-pair magnitude does not fully reduce there.

**Layer 2: shared interaction code.** After content and dominant shared components are controlled, a higher-order residual remains. It is necessary to match an equal-budget direct factorization, transfers to held-out contexts and probes, transfers across token blocks, and reaches a finite within-class ceiling at predictive rank four even over the full vocabulary. This is the strongest evidence for nontrivial low-dimensional compositional coupling.

**Layer 3: organized headroom and idiosyncrasy.** The rank-four code does not explain all natural variation. Base-profile clusters partially organize the remainder; fragment identity organizes orthogonal residual directions; lexical target and semantic domain structure different ranks in curated grammatical settings; and substantial fragment- and context-specific variation remains.

This account reconciles several apparent contradictions. The composed table can have high captured nats without real-specific structure because its null captures nearly as much. A full-vocabulary residual can have a diffuse descriptive spectrum while a rank-four code predicts all available cross-context structure. A probe-axis table can have higher raw captured fraction while having a lower matched margin. A universal transfer map can coexist with a small grammatical differential. A content direction can be closed-form while its magnitude remains idiosyncratic. Each pair becomes consistent once the object and baseline are specified.

Table 1 summarizes the arrangements that matter most.

| Arrangement | Rows and columns | Transform and metric | Key controls | Conclusion |
|---|---|---|---|---|
| Base prompt-by-token | contexts x tokens | raw/centered spectrum and held-out reconstruction | column permutation, Gaussian | Compressible, but much is shared base geometry; weak evidence for nontrivial structure |
| Composed table | contexts x probe-token cells | held-out rank-16 GNC | arrangement-matched permutation and Gaussian | High raw capture, but almost matched by nulls; no real-specific advantage |
| Delta table | contexts x probe-token cells | base subtraction, centering, held-out GNC | column permutation, Gaussian, token shuffle | Strong positive result; 1.91 +/- 0.52 nats over best control in the direct arrangement comparison |
| Per-fragment displacement | contexts x tokens for fixed fragment | rank-one held-out softmax KL or normalized recovery | final-token-preserving body shuffle, mismatch, random | Robust local rank-one steering; direction largely equals standalone continuation |
| Content steering collection | fragments x full vocabulary | anti-unigram residualization, held-out KL substitution | random and mismatch bases, mean offset | Shared predictive rank about 1-2, but large fragment-specific remainder |
| Orthogonal context code | contexts x probe-token cells | content removal, centering, rank-to-ceiling | correspondence/column null floor, random-half ceiling | Predictive rank four, stable to full vocabulary despite growing descriptive rank |
| Orthogonal probe code | probes x context-token cells | same matched pipeline, double-centering | column and matched-Gaussian floor | Genuine structure, but smaller margin than context axis |
| Mean-removed orthogonal directions | context-fragment pairs x full vocabulary | unit residual directions after content and per-context mean removal | label shuffle, random, norm/property matching | Strong fragment-anchored directional organization beyond rank-three content removal |

The table also makes clear why no scalar "language rank" should be reported. Different arrangements answer different questions and have different nuisance directions, ceilings, and held-out units.

## 11. What the Controls Actually Ruled Out

The cumulative case is stronger than any single favorable number because several tempting explanations were tested directly.

**Finite row rank.** Real delta effective rank saturated slowly while matched nulls grew toward the row ceiling. Predictive rank was also compared with a same-class ceiling and remained at four when the output axis expanded to full vocabulary.

**Shared output frequency.** Row-centering, double-centering, anti-unigram removal, and matched column-moment controls all preserved the principal positive residual results. When shared frequency did drive a score, as in the probe-axis raw fraction, the null floor exposed it.

**Small intervention magnitude.** Unconstrained token shuffles had low raw reconstruction error because their base-to-composed KL collapsed. Absolute nats captured, magnitude-normalized local scores, and final-token-preserving body shuffles reversed the misleading conclusion.

**Arbitrary extra degrees of freedom.** Random matched-norm directions and subspaces did not reproduce the content correction, steering collection, or residual organization. The anti-unigram direction beat an equally fitted random second direction, and the nested residual was assessed against a direct factorization with matched parameter budget.

**Last-token identity.** Body shuffles preserving the final token substantially reduced the content direction's predictive value. Fixed-final-token constructions retained an effect for some suffixes, although suffix dependence remained.

**Token selection.** The aggregate delta advantage survived three token-selection rules; local and gain-level quantities did vary with selection, and that dependence is reported rather than hidden. The cross-context code transferred across disjoint token blocks and remained rank four at full vocabulary.

**Training-set memorization.** Primary subspaces were evaluated on held-out contexts, fragments, probes, token blocks, or separately drawn text. Several main metrics and ranks were fixed before the relevant held-out split. Confidence intervals were computed across independent seeds or text samples.

**Generic population heterogeneity.** Random-half within-class ceilings showed that not all natural variation is predictable. The shared context code reached the finite ceiling, while grammatical differences were measured beyond an ordinary random-half split.

**Object-construction errors.** Full-vocabulary studies used reduction gates. This mattered because an earlier apparent null inserted 160-dimensional directions into a full-vocabulary reconstruction that equaled the base on more than 99.7% of coordinates. Native full-output directions reversed that result. Direction-cosine gates similarly caught an incorrectly constructed empirical ceiling in the selected-token content analysis.

Not every rival was eliminated. Model generality, corpus generality, internal circuit localization, and exact semantic interpretation remain open. The evidence is nevertheless sufficient for a strong scoped conclusion because the primary alternatives internal to the measured tables were addressed.

## 12. Limitations and Open Questions

All experiments concern one approximately one-billion-parameter model, final-position next-token logits, and a restricted collection of natural or templated fragments. A result that is stable across seeds, token subsets, and full-vocabulary coordinates within OLMo-1B need not hold at another scale, architecture, tokenizer, language, or domain. Cross-model replication is the largest missing test.

Selected-token and full-vocabulary analyses answer different weighted questions. Selected-token spectra can emphasize rare or high-variance coordinates; full-softmax KL emphasizes tokens carrying true probability mass. Neither is intrinsically superior. Claims that survive both, such as the anti-unigram direction identity and the rank-four context code, are especially credible, but numerical ranks and effect sizes remain metric-dependent.

Several coefficient fits are oracle measurements, not deployable predictors. Per-context least-squares or KL-optimal gains use the true composed logits to determine how strongly a candidate direction should be applied. They establish that the direction is appropriate, not that its magnitude can be predicted before making the composed query. The failure of the global-constant and base-overlap magnitude rules at full vocabulary is therefore scientifically important: direction has been reduced more successfully than scale.

The natural-text held-out split in the foundational aggregate study used a disjoint high-seed sampling namespace with stored fragment hashes rather than an exact set difference against every earlier fragment, because the earliest raw fragment lists were not all persisted. Later experiments used explicit train and held-out fragments. This does not undermine the repeated transfer findings, but it is a provenance limitation for the earliest validation.

The meaning of the rank-four interaction code remains incompletely characterized. Bilinear angular prediction, grammatical partitions, semantic-domain alignment, and fragment-anchored residual directions show that it is not featureless. Yet these analyses use different templates, token axes, projections, and metrics. Their conjunction supports layered organization, not a unique mechanistic label. In particular, double-centering both removes nuisance shared structure and deletes context main effects that may themselves be predictively useful. Whether that removed component should be called nuisance or scaffold depends on the estimand.

The random-half ceiling is an empirical reference, not a mathematical upper bound. Values slightly above one occur because the real split and ceiling split have finite-sample differences. Ceiling saturation should be interpreted within confidence intervals. Similarly, ranks were evaluated on finite grids, often \(\{1,2,4,8,16,32\}\); "rank four" means four was the smallest tested rank reaching the stated criterion, not proof of an exact intrinsic dimension.

Finally, no black-box logit study alone identifies internal attention heads, layers, or circuits. Terms such as channel, code, steering, and bilinear operator describe reliable input-output regularities. They are useful abstractions precisely because they predict held-out logits, but they should not be confused with a localized implementation without white-box evidence.

## 13. Answer to the Central Research Question

Which arrangements show nontrivial low-rank structure?

The clearest positive arrangement is the base-subtracted context-by-intervention-token delta after softmax-irrelevant shifts and, when needed, shared column effects are removed. Its spectrum saturates relative to matched nulls; low-rank reconstructions capture held-out distributional change in absolute nats; the advantage replicates on held-out text and across token rules and sizes; and it is specific to the delta rather than the base or composed table.

Within the delta, two additional arrangements show robust structure. A fixed-fragment context-by-token displacement is locally rank one, with a direction largely determined by the fragment's standalone continuation and an anti-unigram correction. A content-removed context-axis residual contains a shared predictive code that reaches its within-class ceiling at rank four, including at full vocabulary. The fragment-by-vocabulary collection of content directions also has a shared rank-one or rank-two component, but this captures only part of a large idiosyncratic remainder. A probe-axis orthogonal residual is likewise structured, although its matched margin is smaller than the context axis. After further nuisance removal, orthogonal residual directions cluster strongly by held-out fragment identity.

Which arrangements do not support the same claim?

Raw prompt-by-token and composed tables are spectrally compressible, but their dominant low rank is largely attributable to common output geometry. In a direct matched comparison, the composed table's real captured nats were almost completely reproduced by its nulls. Unconstrained token-shuffled conditions can also appear unusually compressible because the intervention magnitude collapses. A descriptive full-vocabulary content residual can be diffuse even while a separate predictive context code is rank four. These are not failed experiments; they define the boundaries of the claim.

Which controls distinguish signal from artifact?

No single control suffices. The decisive combination is: base subtraction to isolate intervention effects; row-centering for softmax invariance; double-centering or analytic anti-unigram removal for shared components; column-permutation and matched-Gaussian nulls for coupling; magnitude-aware token shuffles and final-token-preserving body shuffles for linguistic corruption; cross-fragment mismatch for identity; random directions for added-capacity controls; held-out contexts, fragments, and token blocks for transfer; random-half ceilings for achievable predictability; and native full-vocabulary construction gates for dimensional consistency.

The strongest defensible statement is therefore:

> In OLMo-1B final-position logits, the centered intervention-effect table generated by appending natural fragments to contexts contains reproducible, held-out, magnitude-bearing low-dimensional coupling beyond matched matrix and text controls. The effect decomposes into a largely one-dimensional, partly closed-form content-steering channel and a complementary orthogonal interaction channel with predictive rank about four. The result is robust across sampled text, token subsets, matrix sizes, and native full-vocabulary tests, but its rank and interpretation are specific to the table, transform, metric, and baseline.

This is substantial evidence for low-dimensional predictive organization. It is not evidence that language as a whole has a single low rank.

## 14. Conclusion

The empirical story began with an apparently simple question and ended with a measurement discipline. Raw logits are easy to compress because they share base-rate geometry. Corrupted text can be easy to reconstruct because it causes little change. Ratio metrics can reward small denominators. Rank counts can reflect row ceilings. Reshaping the same tensor can reverse the apparent ordering of its axes. None of these facts makes singular-value analysis useless; they show that a spectrum is the beginning of an analysis, not its conclusion.

Once the object is changed from raw logits to held-out intervention effects, a coherent structure appears. Appended fragments supply a mostly context-invariant content direction equal to their standalone continuation, corrected for duplicated base-frequency mass. Above that direction lies a distinct interaction residual that transfers across contexts, probes, token blocks, and the full output vocabulary through a small predictive code. Dominant shared directions and meaningful transferable residuals coexist at several levels. Removing or controlling the former is what makes the latter visible.

The answer to whether next-token logit tables are low-rank is therefore neither simply yes nor no. Base and raw composed tables mostly only look low-rank. Properly centered delta tables, local displacement tables, content-direction collections, and orthogonal interaction codes contain genuine low-dimensional predictive structure. The durable scientific object is not "rank" in isolation, but held-out distributional effect above a matched null and relative to an achievable ceiling.

## Evidence Provenance

This synthesis is based exclusively on the local experimental record associated with the task. The main evidence-bearing papers were the studies titled *Generalizable Nats Captured*, *Local Rank-1 Steering Directions*, *Where Does the Low-Rank Structure Live?*, *The Content-Identity Law*, *Beyond Necessity*, *Two Complementary Channels*, *The Universal Steering-Correction Axis Is the Anti-Unigram Direction*, *A Matched-Control Anatomy of Logit Composition*, *The Closed-Form Content Channel*, *A Shared Low-Dimensional Context Code*, *The Full-Vocabulary Content Channel*, *The Content-Channel Steering Subspace*, *The Shared Context Code Stays Low-Rank at Full Vocabulary*, *A Raw-vs-Matched-Control Rank Reversal*, *The Rank-4 Generative Operator*, *Dominant Shared Directions Versus the Transferable Residual*, *A Fragment-Anchored Directional Signature*, and *The Dual Nature of Logit Composition*. Numerical claims were cross-checked against the corresponding saved experimental records and coder reports where they were central to the argument. No external literature, web source, or new model experiment was used.
