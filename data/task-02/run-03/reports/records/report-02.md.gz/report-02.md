# Low-Rank Structure in Language-Model Logit Tables Is Predictive, Layered, and Construction-Dependent

## Abstract

The intuition that language is governed by a small number of latent factors does not by itself imply that a table of next-token logits should be meaningfully low-rank. Raw logit matrices are dominated by shared token-frequency structure, logits have a row-wise additive gauge freedom under the softmax, and weak perturbations are easy to reconstruct simply because they do little. We synthesize a large black-box empirical program on OLMo-1B that was designed to distinguish those artifacts from reproducible low-dimensional structure. The central object is an intervention-effect table: for context (c), appended fragment (p), and output token (t), 

\[
\Delta(c,p,t)=\ell_t(c\oplus p)-\ell_t(c),
\]

where \(\ell_t(x)\) is the final-position next-token logit and \(\oplus\) denotes text concatenation. Three initial arrangements were compared directly: prompt-by-token base logits, composed context-by-probe-token logits, and the base-subtracted intervention-effect table. Raw base and composed tables were nearly rank one, but that concentration was largely a shared additive component. After centering and base subtraction, the intervention-effect table alone showed a large held-out advantage over column-permuted, matched-Gaussian, and corrupted-text controls. Its effective rank grew from 19.5 to only 29.1 as the number of contexts rose from 48 to 192, while matched null ranks grew from 45 to 166. A magnitude-aware measure, generalizable nats captured, gave a rank-16 natural-text advantage of (1.93\pm0.86) nats and (1.70\pm0.71) nats on a preregistered held-out text sample. The analogous advantages for composed and base tables were statistically negligible.

The resulting structure is layered rather than monolithic. A content channel steers each context toward the appended fragment's standalone continuation along a fragment-specific direction, corrected by a nearly exact anti-unigram direction. Across fragments, these directions occupy a rank-1 to rank-2 shared subspace after anti-unigram removal, but retain a large idiosyncratic remainder. Orthogonal to this channel, a shared cross-context code reaches its attainable held-out ceiling at predictive rank four, including over the full 50,304-token vocabulary, even while its descriptive effective rank increases. This rank-four structure coexists with lexical-class partitioning at rank one, semantic diffusion at higher ranks, and compound-specific combinatorial residuals. Thus the answer to the central question is conditional but clear: nontrivial low rank is strongest in centered, base-subtracted, held-out-predictive intervention tables; it is weak or artifactual in raw prompt and composed tables; and its interpretation depends on whether one measures the dominant shared component, the content direction, or the orthogonal interaction residual. Low rank here is a property of a specified table, transform, metric, and control, not a global property of language.

## 1. The Question Is Not Whether Logits Are Low-Rank

A causal language model maps a text context to a vector of real-valued next-token logits. For a vocabulary of size \(V\), one query returns a point in \(\mathbb{R}^V\). Collect many such queries as rows and one obtains a matrix on which singular-value decomposition, reconstruction, and out-of-sample prediction can be performed. It is tempting to treat rapid singular-value decay as direct evidence that linguistic prediction is low-dimensional. That inference is unsafe for at least four reasons.

First, all contexts share a large output-token profile. Common tokens tend to receive high scores and rare or contextually implausible tokens low scores across many prompts. A matrix in which nearly every row contains the same large profile will have a dominant singular direction even if the context-dependent residual is unstructured. Second, adding a constant to every logit in one row leaves its softmax distribution unchanged. Raw logit rank therefore partly measures a coordinate convention that has no predictive meaning. Third, a corrupted prompt can produce a smaller distributional change than a natural one. Such a weak effect can have low reconstruction error even when it contains less structured information. Fourth, any model with a finite hidden state and a linear output map has an architectural upper bound on logit rank. For a small table, merely falling below the vocabulary size is not an informative discovery.

The useful question is consequently narrower: after specifying a query family, row axis, column axis, transform, token-selection rule, and comparison condition, does a low-dimensional representation predict held-out effects better than controls that preserve the nuisance properties of that exact table? This paper answers that question using only black-box final-position logits from OLMo-1B and the accumulated experimental record. The evidence spans natural wiki-derived fragments, curated functional and semantic probes, selected-token subspaces, and the full 50,304-token vocabulary. The main matrices remain in the small-to-medium regime: tens to hundreds of text fragments, typically 20 to 1,024 selected tokens for primary and scaling studies, with dedicated full-vocabulary follow-ups.

The synthesis has three goals. The first is to identify which basic table construction gives the most defensible existence result. The second is to explain the internal anatomy of that table: which dimensions reflect an appended fragment's own content, which reflect context-dependent interaction, and which are low-information shared components. The third is to reconcile later findings that alternately describe the residual geometry as universal, lexically fragmented, semantically hierarchical, bilinear, or diffuse. These descriptions refer to different transformations, ranks, and estimands. Once those differences are made explicit, much of the apparent disagreement disappears.

The central conclusion is not that language is low-rank. It is that a particular family of intervention-effect tables contains reproducible, transferable low-dimensional structure after nuisance removal. Two especially robust pieces emerge. One is a rank-1 or rank-2 content-steering subspace organized around the appended fragment's standalone continuation and an anti-unigram correction. The other is an orthogonal cross-context code with predictive rank about four. Neither should be confused with the much larger shared components visible in raw spectra, and neither exhausts the full distribution: context-dependent magnitudes, fragment-specific remainders, semantic branching, and collision-like residuals remain.

## 2. Table Constructions and the Measurement Standard

### 2.1 Three foundational tables

Let \(c_i\) be a natural context, \(p_j\) an appended probe or fragment, and \(T=\{t_1,\ldots,t_K\}\) a selected set of output tokens. Denote the final-position logit for token \(t\) after text \(x\) by \(\ell_t(x)\). The empirical program began from three distinct arrangements.

The **base prompt-by-token table** is

\[
B_{i,k}=\ell_{t_k}(c_i),
\]

with contexts as rows and selected output tokens as columns. This is the simplest possible logit table: one next-token distribution per prompt.

The **composed table** uses paired text fragments,

\[
C_{i,(j,k)}=\ell_{t_k}(c_i\oplus p_j),
\]

with contexts as rows and flattened probe-token pairs as columns. It goes beyond a single distribution per prompt because every context is crossed with a common set of appended fragments.

The **intervention-effect**, or delta, table subtracts the base context prediction from each composed query,

\[
D_{i,(j,k)}=\ell_{t_k}(c_i\oplus p_j)-\ell_{t_k}(c_i).
\]

This table asks how a shared family of interventions changes prediction across contexts. It removes the part of the composed logits already present before the fragment was appended. The composed and delta tables can equivalently be regarded as three-way tensors with context, probe, and token axes, then unfolded according to the prediction problem.

Several later tables refine this construction. A **per-fragment displacement table** fixes \(p_j=f\) and places contexts on the rows:

\[
D_f(c,t)=\ell_t(c\oplus f)-\ell_t(c).
\]

A **fragment-by-vocabulary steering table** places one standalone continuation direction per fragment on each row. A **context-axis interaction table** flattens probe and token coordinates so that held-out contexts are predicted, whereas a **probe-axis interaction table** flattens context and token coordinates so that held-out probes are predicted. Finally, specialized grammatical and semantic studies build single-intervention matrices, double-difference tensors, and compound-specific residual subspaces. These are not interchangeable objects, even when all are derived from the same logits.

### 2.2 Centering and channel isolation

Three transforms recur. **Row-centering** subtracts the mean over scored tokens from each logit row. This fixes the softmax-invariant additive degree of freedom. **Double-centering** additionally removes an across-row column mean fitted on training data. In an unfolded context-by-feature matrix, that operation removes a component shared across contexts. **Content removal** projects a displacement away from the appended fragment's standalone continuation direction and, in stricter versions, away from a small content plane containing the continuation, an anti-unigram direction, and constant or head-related terms.

These transforms answer different questions. Row-centering asks about distributionally meaningful logit contrasts. Double-centering asks about correspondence-dependent interaction after removing a mean effect shared by all rows. Content removal asks what remains after the fragment's most direct lexical steering effect has been accounted for. Removing more components is not automatically better: if the component under study is the context main effect, double-centering can delete part of the signal. Every conclusion must therefore name the transform.

### 2.3 Descriptive rank is not predictive rank

For singular values \(s_q\), entropy effective rank is

\[
r_{\mathrm{eff}}=\exp\!\left(-\sum_q \pi_q\log \pi_q\right),\qquad
\pi_q=\frac{s_q^2}{\sum_m s_m^2}.
\]

This describes how matrix energy is distributed in-sample. Rank-\(r\) Frobenius reconstruction error gives a related descriptive view. Both are useful diagnostics, but neither shows that the fitted directions generalize.

The stronger standard fits a right-singular subspace \(V_r\) only on training rows, reconstructs a held-out row \(x\) as \(xV_rV_r^	op\), converts reconstructed logits to a softmax distribution, and scores its divergence from the true composed distribution. A useful absolute measure is **generalizable nats captured**:

\[
\operatorname{GNC}(r)=
\mathbb{E}\,\operatorname{KL}\!\left(P_{\mathrm{comp}}\Vert P_{\mathrm{base}}\right)
-
\mathbb{E}\,\operatorname{KL}\!\left(P_{\mathrm{comp}}\Vert P_{r}\right).
\]

The first term is how much the intervention changes the predictive distribution; the second is the change left unexplained by a rank-\(r\) held-out reconstruction. A corrupted condition with almost no intervention effect cannot score highly merely because it is easy to reconstruct. For normalized scores, the reliable quantity is not the raw fraction alone but its margin above a matched null and, where possible, its position relative to a within-class ceiling.

### 2.4 Controls that change the interpretation

No single control is adequate. Independent **column permutation** destroys cross-column coupling while preserving each column's empirical marginal distribution. A **matched Gaussian** preserves per-column means and variances but removes structured correspondence. **Token- or word-shuffled text** disrupts natural order while retaining some lexical content, but must be checked for effect-magnitude collapse. **Final-token-preserving body shuffles** are stricter when the last token itself strongly determines the continuation. **Cross-fragment mismatch** substitutes another fragment's direction while leaving the fitting rule unchanged. **Random matched-norm directions or maps** test whether any extra degrees of freedom would help. **Correspondence shuffles** break row identity, though they can be degenerate for some axis arrangements. **Within-class random-half fits** estimate a ceiling imposed by finite rank and genuine heterogeneity rather than an idealized ceiling of one.

The decisive metrological principle is simple: low-rank structure means a held-out predictive improvement over a matched, non-degenerate control, preferably in absolute nats, under the same fit and score. Singular values, captured fractions, and attractive token lists remain secondary evidence.

## 3. The Basic Existence Result: Base Subtraction Reveals the Signal

The direct comparison of the three foundational tables gives the cleanest answer to which arrangement works. In raw form, the base and composed tables both had entropy effective rank near one. Their first singular direction was the shared output-token profile, not a context-specific compositional mechanism. Row-centering and double-centering revealed differences, but the decisive contrast came from held-out, magnitude-aware prediction.

At a fixed context count, the centered delta table showed a much larger real-versus-null rank gap than either alternative. The row-centered excess-rank gap was (19.48\pm2.94) for delta, compared with (6.11\pm0.23) for base and (1.08\pm0.31) for composed. A variance partition of the underlying context-by-probe-by-token tensor showed that this was not merely a last-fragment or recency effect: the context term reached about 17.5% in the delta representation, and the remaining context-probe interaction accounted for roughly 50-90% depending on the analysis.

A size-saturation test then separated genuine concentration from the rank ceiling imposed by a small number of rows. With 48, 96, and 192 contexts, the real double-centered delta effective rank increased slowly, from 19.5 to 25.3 to 29.1. Column-permuted and matched-Gaussian null ranks rose from 45 to 88 to 166. Expressed as slopes, the real table added only 0.063 effective-rank units per context, compared with 0.836 for the nulls. At 192 contexts, rank-16 and rank-32 reconstructions of the real table produced composed-softmax KL divergences of 0.58 and 0.25, while null reconstructions remained near 1.6. The widening gap argues against a small-matrix artifact: natural intervention effects occupy an increasingly small part of the available row rank as sampling grows.

Raw reconstruction still produced a paradox. A word-shuffled condition could achieve lower held-out KL than natural text. The reason was not better structure. Shuffling reduced the mean intervention magnitude from 3.24 to 0.54 nats of base-to-composed KL and reduced row variance from 8.11 to 3.42. A condition that barely moves the model is easy to approximate by the base distribution. This is the magnitude confound in its clearest form.

Generalizable nats captured removes that advantage by crediting only the intervention effect actually explained. At rank 16, under double-centering with frequency-stratified token selection, natural delta tables exceeded the best of column-permuted, matched-Gaussian, and shuffled-text controls by (1.93\pm0.86) nats. The sign held under raw, row-centered, and double-centered variants and under frequency-stratified, uniform-random, and top-base token rules. With the rank, transform, metric, and comparison fixed before drawing a disjoint text sample, natural text captured 2.66 nats and exceeded the best control by (1.70\pm0.71) nats. The advantage remained positive across six scale settings formed by 32, 64, or 100 tokens crossed with 12 or 24 interventions.

Most importantly, a condition-matched table-design test localized the effect. At rank 16, the real-minus-best-control GNC advantage was (1.91\pm0.52) nats for delta, (0.07\pm0.15) for composed, and (-0.28\pm1.10) for base. The composed table looked strongly compressible in isolation: natural composed logits yielded 3.56 captured nats. But its nulls yielded about 3.4-3.5, so almost all of that apparent structure was shared nuisance geometry. For delta, natural text yielded 3.15 captured nats while its nulls yielded about 1.16. Base subtraction therefore does not merely rescale the table. It exposes context-fragment coupling that the composed table's dominant main effects conceal.

This is the strongest broad result in the record. For OLMo-1B final-position prediction, natural centered intervention-effect tables have reproducible, held-out, magnitude-bearing low-dimensional structure. Base prompt tables and composed tables may be spectrally low-rank, but they do not show a comparable natural-text-specific margin. The rest of the paper asks what the delta structure contains.

## 4. A Two-Channel Anatomy of the Intervention Effect

### 4.1 The content channel: a fragment points toward its own continuation

Fix an appended fragment \(f\) and consider the displacement matrix \(D_f(c,t)\) across many contexts. The leading empirical finding is local rather than global: for a fixed fragment, most of the systematic displacement lies along one fragment-specific direction whose scalar gain changes with context. A cross-fragment basis is not equally successful, so this is not one universal rank-one axis for all text. The direction is approximately the fragment's own standalone continuation vector,

\[
u_f=\operatorname{center}_t\bigl(\ell_t(f)\bigr).
\]

In plain terms, appending a fragment tends to steer the next-token distribution toward what that fragment would predict if presented alone. The correct target for this scalar-gain model is the mean displacement across contexts, not the leading singular vector of a context-centered matrix: the former represents the average steering direction, while the latter represents variation around that mean.

The standalone continuation is not the whole content channel. Its residual across fragments is dominated by a second direction shared nearly universally. Analytic substitution identified that direction as the **anti-unigram axis**, the centered negative mean base-logit profile. On a 160-token variance-selected subspace, the fitted correction and the analytic anti-unigram direction had cosine about 0.99, and the analytic direction recovered essentially all of the fitted direction's held-out improvement. The interpretation is operational rather than mechanistic: the base context already carries common-token mass; adding a scaled standalone continuation reintroduces part of that profile; the anti-unigram term subtracts the duplication.

This gives a two-term reconstruction,

\[
\widehat{\ell}(c\oplus f)=\ell(c)+g_{c,f}u_f+h_{c,f}d_{\mathrm{anti}},
\]

where \(d_{\mathrm{anti}}\) is computed from base logits. In the selected 160-token regime, replacing the fitted correction direction with its analytic form changed normalized KL by only 0.006 to 0.009, with confidence intervals spanning zero. Replacing per-context gains with two global constants also matched the fitted ceiling in aggregate, while improving over the standalone-only floor by about 0.08-0.09 normalized KL. Final-token-preserving body shuffles and cross-fragment mismatches performed much worse.

The global-constant result has an important boundary. Jointly permuting fitted \((g,h)\) pairs across contexts caused a reliable loss even though one central constant pair matched the mean ceiling. Thus the selected-token result is predictive equivalence in aggregate, not proof that the model uses context-independent gains. The distinction becomes decisive at full vocabulary.

### 4.2 Full vocabulary separates direction from magnitude

An early full-vocabulary test appeared to show that the anti-unigram correction vanished. That null was mechanical: 160-dimensional directions had been inserted into a 50,304-token score, so the reconstruction equaled the base distribution on 50,144 coordinates by construction. Rebuilding every direction over the entire vocabulary reversed the conclusion.

At full vocabulary, the two-term reconstruction exceeded the standalone-only floor by 0.226 normalized KL on held-out contexts with training fragments and 0.206 with held-out fragments. The fitted correction retained cosine 0.982 with the analytic anti-unigram direction. In absolute terms, the base-to-composed divergence was roughly 6-9 nats, and the two-term model recovered about 1.5-1.7 more nats than the standalone direction alone. A random matched-norm secondary direction and a cross-fragment continuation performed substantially worse. Body shuffling reduced recovery by about 0.27-0.33, showing that the fragment body, not only its final token, determines the direction.

There was no evidence for a third low-rank content correction. Adding a candidate far-tail axis improved normalized recovery by only 0.008-0.009, failed random and mismatch controls, and partly rediscovered the anti-unigram direction. The remaining content-channel residual had rank-one energy only 0.375, compared with about 0.88 in the selected-token residual. Across matrix-size and fragment-length ablations, however, the two-term over one-term advantage stayed between 0.20 and 0.26 and direction cosine between 0.969 and 0.987. Three genuinely distinct definitions of \(u_f\) all retained a positive anti-unigram contribution.

Direction and magnitude therefore separate. The direction law strengthens at full vocabulary, but the two-global-constant magnitude approximation fails: per-context KL-optimal gains outperform the constant pair by about 0.10 normalized KL. A base-profile overlap that predicted the correction coefficient modestly in the selected-token regime has negative held-out \(R^2\) at full vocabulary and a slope of the opposite sign. What is reducible is where the content channel points; how far it moves remains context-specific.

The probability impact is nevertheless concentrated. The top approximately 20 tokens under the true composed distribution carry 75-80% of the base-to-composed KL, and the recovered KL is still more concentrated. Roughly 90% of the divergence lies in the top 328-460 tokens, with the knee increasing as fragments lengthen from 16 to 48 tokens. Probability concentration must not be confused with matrix rank: a diffuse residual direction can matter predominantly on a few hundred high-probability tokens.

### 4.3 The steering directions themselves form a low-rank table

Treating each \(u_f\) as an unrelated fitted object leaves a second-order question: do the continuation directions across fragments share a subspace? Stack the centered full-vocabulary directions as rows of a fragment-by-token matrix \(U\), project out the anti-unigram direction, fit an SVD basis on training fragments, and reconstruct unseen fragments under the same per-context KL-optimal gain rule.

The answer is yes, but only partly. On a strict held-out-context and held-out-fragment split, a rank-one basis recovered 0.270 normalized KL, compared with 0.092 for both random and mismatch bases. The full fragment-specific \(u_f\) ceiling was 0.676. Raising rank from one to sixteen improved recovery only to 0.307, so the shared part saturates around rank one or two while a large fragment-idiosyncratic remainder persists. The gap survives changes in matrix size and remains positive in raw nats, with lower confidence bounds of roughly 0.75-1.42 nats across tested cells.

The leading shared axis is close, though not identical, to a no-fit mean direction: cosine is about 0.83, and its large loadings are morphological or subword pieces. The fitted rank-one axis still beats the fixed mean by about 0.05-0.06 normalized KL. The subspace exists under three definitions of \(u_f\), although the exact leading axis is less stable for a standalone-minus-empty-context definition. It also transfers between structural subsets of the same wiki corpus. Beyond the rank-one/two shared component lies a weak base-profile-cluster-specific layer that contributes only about 1% of the original base-to-composed gap, followed by the large idiosyncratic remainder.

The content channel is thus low-dimensional in a qualified hierarchy: a universal anti-unigram correction; a rank-one or rank-two cross-fragment steering subspace; a small cluster-specific layer; and a large fragment-specific remainder. That hierarchy is already richer than a global statement that composition is low-rank.

### 4.4 The orthogonal channel: structure remains after content removal

Removing the content direction does not leave noise. Sequential held-out accounting showed that a higher-order residual adds about two predictive nats beyond standalone-continuation steering in both content-bearing and functional probe regimes. Stronger per-fragment local models do not absorb it: equal-budget global subspaces outperform local rank-two and rank-three alternatives. The residual also transfers across held-out contexts and held-out interventions above column-permuted, matched-Gaussian, and shuffled-text controls.

This motivates a two-channel description. The **content channel** tells where the appended fragment tends to steer prediction and is largely reducible to its standalone continuation plus the anti-unigram correction. The **orthogonal interaction channel** describes how that steering interacts with context after the content plane is removed. The channels are complementary rather than competing. A good content approximation does not imply that the residual is negligible, and a low-rank residual does not invalidate the closed-form content direction.

## 5. The Orthogonal Context Code Has Predictive Rank Four

### 5.1 Transfer across output-token blocks

The most direct evidence for a shared orthogonal code asks whether a subspace learned on one set of output tokens predicts intervention effects on entirely different tokens. Begin with a row-centered delta table and a base block of 32 selected tokens. Fit a rank-\(r\) right subspace on 96 training contexts. Then apply the learned context representation to seven disjoint 32-token blocks and score reconstruction on 32 held-out contexts. The null floor is the larger of a context-correspondence shuffle and a within-block column permutation. A random-half split of natural contexts supplies a within-class ceiling: the variation that is predictably shared when both fit and target come from the same distribution.

The base-block code transfers to all seven added blocks. Its advantage is approximately flat with token frequency and distance from the base block, and it remains after removing the anti-unigram direction. The result also survives frequency-stratified, uniform-random, and top-base token selection. Strict double-centering preserves the transfer, which shows that it is not merely the column-mean component retained by row-centering.

The ceiling changes the interpretation of the absolute score. At rank eight in the primary selected-token analysis, the real captured fraction was 0.628 with a 95% interval of [0.537, 0.720]. The conservative null floor was 0.356 and the within-class ceiling 0.614 [0.517, 0.711]. The floor-corrected headroom fraction,

\[
H=\frac{	ext{real}-	ext{floor}}{	ext{ceiling}-	ext{floor}},
\]

was 1.051 [0.958, 1.144]. The small point estimate above one is sampling variation, not evidence of exceeding an absolute ceiling. The scientific result is saturation: cross-block prediction is statistically indistinguishable from the matched within-class reference. Rank four already reaches this ceiling; ranks eight and sixteen add no sharp, reliable gain.

This yields a useful distinction between **descriptive dimensionality** and **predictive dimensionality**. As the selected-token width grew as far as 1,024, the descriptive effective rank increased from about 7.3 to 10.9, whereas the predictive rank remained small and far below the corresponding null rank. More columns expose more low-energy directions needed to describe the training matrix. They do not require more directions to predict the transferable component on held-out rows.

### 5.2 Native full-vocabulary validation

The full-vocabulary test was designed to avoid the coverage error that had affected the early content-channel analysis. It built a native 50,304-coordinate delta table, averaged composed logits over six probe fragments to reduce probe-specific variance, used a true-probability-weighted KL score, and required that restricting the pipeline to 256 selected tokens reproduce the earlier numbers. The reduction gate matched to within (1.1	imes10^{-15}), effectively machine precision.

Across eight seeds, the smallest rank reaching 90% of the floor-corrected within-class ceiling was four in every seed. At rank eight, the real full-vocabulary captured fraction was (0.474\pm0.047), the within-class ceiling (0.445\pm0.027), and the headroom fraction had a lower confidence bound of 1.004; again, the proper reading is ceiling saturation under finite-sample noise. Meanwhile, the training effective rank rose from 36.3 on the 256-token reference to 49.3 on the full vocabulary. Predictive rank stayed at four while descriptive rank inflated by roughly one-third.

This full-vocabulary result is especially informative beside the content-channel result. The orthogonal cross-context code remains predictively rank four over all output tokens, while the residual left after the two closed-form content directions is spectrally diffuse. The difference is not a conflict because the two analyses concern different channels. There is no single answer to whether the full-vocabulary delta is low-rank. One component has a closed-form direction but a diffuse remainder; another has a small predictive rank but no equally complete closed-form identity.

### 5.3 Context rows and probe rows are not symmetric

The same delta tensor can be unfolded with contexts or probes as rows. A matched experiment used the same query set to build two \(32	imes8192\) tables, each with 16 training and 16 held-out rows, identical ranks, seeds, transforms, and nulls. The only intended difference was the row axis. Before double-centering, the probe-axis table looked far more compressible: at rank eight its raw captured fraction was 0.65, compared with 0.37 for the context-axis table. Yet its matched-control margin was only 0.05, compared with 0.25 for context rows.

The inversion came from the null floors. The probe-axis floor was 0.53, revealing a large component shared across probe rows that any low-rank basis could reconstruct without preserving correspondence. The context-axis floor was about 0.12. Raw captured fraction therefore ranked the two arrangements in the opposite order from transferable structure.

Double-centering lowered the probe floor from 0.53 to 0.003 and the context floor to about 0.004. Once the shared mean component was removed, both raw and matched readouts favored the context axis. The double-centered rank-eight margin was 0.247 for contexts, with lower confidence bound 0.211, and 0.179 for probes, with lower bound 0.151. The context-minus-probe difference had lower bound 0.031. Both axes therefore contain real structure; context rows contain more under this matched design. A previous apparent null on the probe axis was traced to a degenerate correspondence-shuffle that left the relevant feature subspace unchanged. Replacing it with column-permuted and matched-Gaussian controls corrected the binary conclusion to a graded one.

This rank reversal is the clearest demonstration that a low-rank metric does not carry its own interpretation. A raw score measures shared variance whether or not row identity matters. A matched margin measures structure that depends on the intended correspondence. When they disagree, the difference is itself evidence about a dominant shared component.

## 6. A Layered Geometry Reconciles Universality and Fragmentation

The orthogonal residual generated several apparently incompatible claims. Strictly isolated context-by-probe blocks transferred between functional and semantic probes, suggesting a universal interaction subspace. Pairwise subspace angles separated lexical classes and semantic domains, suggesting fragmentation. A bilinear predictor found a cross-domain rank-four operator, while later stress tests found diffuse residual magnitude driven by incompatible priors. These findings can coexist because they resolve different layers and ranks.

### 6.1 A transferable shared scaffold

In a strict double-centered design, composed blocks contained 64 contexts, 16 training probes, 16 held-out probes, and a shared output-token axis. The target residual was evaluated against a token-shuffled control rescaled to exactly match its Frobenius norm. For functional probes, a rank-four training subspace reconstructed held-out natural blocks at 0.117 nats of KL versus 0.158 for the matched shuffle. For open-class semantic probes restricted to alphabetic content tokens, the corresponding values were 0.135 versus 0.195 at 32 tokens and 0.161 versus 0.220 at 64 tokens. The absolute effects were small because strict centering removed most logit energy, but the natural-minus-matched-control difference was stable.

A generative analysis strengthened this topological result. Isolated context and probe logits were row-centered, compressed to eight-dimensional features, combined through an outer product, and mapped to the double-centered composed residual by reduced-rank regression. Cross-domain alignment peaked at rank four rather than at ranks one, two, eight, sixteen, or full rank. A map trained on functional probes and evaluated on semantic probes achieved flattened cosine similarity 0.027, compared with 0.006 for a row-shuffled map, and ranked at the 98th percentile of 100 exactly Frobenius-matched random rank-four maps. The reverse semantic-to-functional direction was weaker, averaging the 93rd percentile and exceeding the 95th percentile in only one of three seeds. The functional-to-semantic result persisted without feature whitening and after expanding the target axis from 64 to 128 tokens.

These small cosines should not be read as large-scale prediction of all residual variance. They indicate a reliable angular component within a much larger field. The convergence on rank four is nevertheless notable because it arises independently from cross-token-block context prediction and bilinear generation from isolated priors.

### 6.2 Lexical partition at rank one, semantic diffusion at higher ranks

Shared rank-four transfer does not imply that all probe classes occupy the same leading direction. After projecting each single-intervention matrix away from a four-component content plane, rank-one subspaces were strongly organized by the lexical class of the token being updated. In a grammatical comparison, within-class alignment had mean subspace cosine 0.9180. Animate versus inanimate subject conditions that both targeted verbs retained alignment 0.4518. Conditions that shared animacy but targeted verbs versus reflexive pronouns dropped to 0.1010, close to a null floor of 0.0180. The primary direction was therefore partitioned by target vocabulary class, not simply by syntactic construction or shared subject semantics.

At ranks four to eight, cross-class alignment rose. A double dissociation identified shared semantics as the cause. At rank four, animate verbs and animate reflexives aligned by 0.4955, but inanimate verbs and animate reflexives aligned by only 0.3463. Across paired seeds, the same-semantics cross-lexical advantage was 0.1491 at rank four and 0.1610 at rank eight. The residual geometry is consequently hierarchical: lexical target controls the leading route, while subject-domain information diffuses through secondary dimensions.

Independent semantic-domain experiments reached a compatible result. Single-token probes from geography, time, materials, professions, animals, emotions, science, and food were frequency-matched, projected away from their standalone continuation, and compared through held-out mean subspace cosine. Within-domain alignment exceeded between-domain alignment after content removal, with gaps 0.0819, 0.0671, and 0.0609 at ranks two, eight, and sixteen. The hierarchy is present in the leading residual dimensions and persists, more weakly, deeper into the subspace.

The correct synthesis is neither a single universal manifold nor complete fragmentation. A shared low-rank scaffold supports cross-domain prediction. Its leading local expression is routed through target-specific lexical manifolds. Higher ranks carry semantic information that partially aligns those manifolds. “Universal” refers to a transferable component or generative rule; “fragmented” refers to the organization of particular leading subspaces after content isolation. Both are measured facts.

### 6.3 Retaining or deleting the context main effect changes the object

A later stress test compared a single-centered delta, which retains a context main effect, with the strictly double-centered residual. The single-centered table had a highly compressible rank-four component: cumulative explained variance at rank four was about 67%, with effective rank about 10.7 in the reported setting. Word-shuffling the context reduced the predictive power of the rank-four map by about 85%, supporting the interpretation that this component tracks structured context organization rather than generic scale.

The double-centered residual behaved differently. Its Euclidean magnitude increased with cosine distance between the isolated context and probe priors, and the relationship strengthened for adversarial, high-entropy, or shuffled compositions and extended to multi-token semantic probes. This suggests that some high-variance residual is generated when independently plausible context and probe predictions conflict. The useful interpretation is not that double-centering was a mistake: it remains exactly the right transform for asking about interaction beyond shared context effects. Rather, it creates a different object. The retained context main effect contains a compressible scaffold; the stricter residual contains both transferable angular structure and diffuse mismatch-related variance.

This distinction also explains why one study can find a rank-four predictive code while another calls the residual diffuse. Predictive rank is measured relative to a null and attainable ceiling; diffuseness refers to the amount of total variance or tail energy not captured. A small transferable component can coexist with a large high-dimensional remainder.

## 7. Multi-Token Composition Exposes Structured Remainders

The paired-fragment requirement is not exhausted by arbitrary wiki continuations. Controlled two-token compounds show how low-rank channels coexist with genuinely new semantic geometry.

For head-final English noun compounds such as “bank account,” investigators first removed the standalone content direction and analyzed the interaction residual. True compounds did not have lower intrinsic rank than mismatched compounds: rank-eight explained variance was 0.682 versus 0.675. Composition was therefore not a simple rank collapse. The composed residual aligned slightly more with the syntactic head than the modifier, 0.635 versus 0.609, establishing an asymmetric anchor.

A joint rank-eight basis formed from rank-four modifier and head subspaces captured 0.271 of composed variance, compared with 0.223 for mismatched constituent pairs. Constituents matter. But the optimal rank-eight basis of the composed phrase captured 0.429, leaving a gap of about 0.157 that could not be linearly spanned by the constituents. Doubling the joint basis to rank sixteen left nearly the same gap, about 0.152. Pushing constituent bases to rank 64 each, for joint rank 128 on a 500-token axis, reduced but did not eliminate it; the gap stabilized near 0.085. This **combinatorial residual** is not merely a neglected low-energy tail of the constituent spaces.

Semantic enrichment gives the residual an interpretable, though distributed, role. Predefined target-token clusters associated with a compound, such as finance terms for “bank account,” had explained-variance ratio 0.866 in the true rank-eight combinatorial subspace versus 0.807 in a mismatched compound subspace. The same true subspace exceeded isolated modifier and head subspaces, 0.794 and 0.800, and preferred the correct semantic cluster over a frequency-matched wrong cluster, 0.866 versus 0.830. The specificity gap was largest at rank four, 0.108, fell to 0.050 by rank eight, and saturated by rank sixteen. A sequential variance ledger estimated that the standalone content vector explained 15.6% of target variance, the full joint constituent span 39.4%, and the rank-eight orthogonal combinatorial subspace generated 20.3% of the variance left unspanned by the constituents.

The result generalizes in sign but not magnitude to intersective adjective-noun pairs. Those phrases showed positive specificity and emergence, but a smaller emergence gap than noun-noun compounds. The orthogonal residual therefore depends on the kind and degree of lexicalized composition. This is another reason not to seek one rank for “language.”

Full-vocabulary fragment experiments reveal a related organization outside curated compounds. After projecting the delta away from the fragment's continuation and anti-unigram axes, then removing global and per-context mean residual directions, unit residuals clustered strongly by fragment across contexts. On held-out fragments, the within-minus-across-fragment cosine gap was 0.3555 [0.3189, 0.4010], compared with a shuffled-label 97.5th-percentile null of 0.0055 and a random-direction floor effectively equal to zero. Matching residual norms or fragment length and frequency did not reduce the gap.

The signal did not collapse when a richer rank-two or rank-three fragment content basis was projected out. Instead, the held-out gap remained about 0.48 while the removed span still captured only about 58% of delta energy. A staged nuisance ablation identified the critical transform: the gap was 0.068 in raw residual directions, 0.052 after global-mean removal alone, and 0.377 after additionally removing the per-context mean. Thus the per-context shared direction was the dominant dilutor. The orthogonal residual can be energetically diffuse and yet directionally organized by the appended fragment.

Taken together, the controlled compounds and natural-fragment residuals show why “remainder” must not be equated with noise. Some remainder is high-dimensional and unpredictable, but some contains low-rank semantic enrichment or fragment-anchored directionality that appears only after a larger shared component is removed.

### 7.1 An integrative model of the measured layers

The empirical results can be summarized by a decomposition that is descriptive rather than claimed as an internal mechanism. For a context-fragment pair, write the centered intervention effect schematically as

\[
\Delta_{c,f}
=g_{c,f}u_f+h_{c,f}d_{\mathrm{anti}}
+A_f z_c
+q_{c,f}
+\varepsilon_{c,f}.
\]

The first two terms are the content channel: the fragment's standalone continuation and the anti-unigram correction, with context-dependent gains. The product \(A_f z_c\) denotes the transferable interaction channel. Here \(z_c\) is a low-dimensional context coordinate, empirically requiring about four predictive dimensions, while \(A_f\) allows the output realization to depend on the fragment and lexical target. The term \(q_{c,f}\) collects organized departures that are not captured by the shared code: fragment-anchored orthogonal directions, semantic-domain diffusion, base-profile-cluster layers, and combinatorial subspaces for multi-token concepts. The final term \(\varepsilon_{c,f}\) contains diffuse or idiosyncratic remainder under the measured tables and scores.

This expression explains why apparently opposed results can all be correct. A per-fragment rank-one fit concentrates on \(u_f\). A context-axis transfer analysis emphasizes \(z_c\). A rank-one lexical comparison sees differences in \(A_f\). A rank-four cross-domain bilinear map tests whether part of \(A_f z_c\) can be generated from isolated priors. A compound analysis isolates a component of \(q_{c,f}\). A raw SVD of the entire delta mixes every term and is additionally dominated by means that are not shown in the equation because centering has already removed them.

The decomposition also states where prediction remains incomplete. Neither \(g_{c,f}\) nor \(h_{c,f}\) has a successful full-vocabulary closed-form predictor. The rank-four code reaches a within-class ceiling, but that ceiling is finite because contexts retain idiosyncratic variation. The fragment-by-vocabulary content subspace saturates far below the fragment-specific continuation ceiling. And the compound-specific residual remains nonzero even when constituent spans are expanded dramatically. Low-dimensional organization is therefore a scaffold for variation, not a claim that every intervention effect lies on one tiny linear manifold.

Finally, the decomposition clarifies the role of centering. Row-centering removes an unidentifiable scalar logit offset. Double-centering removes a shared feature mean that may correspond to a low-information nuisance in one experiment and to part of the context scaffold in another. Projecting out \(u_f\) and \(d_{\mathrm{anti}}\) removes the content channel by design. Removing the per-context residual mean can then expose fragment-specific organization in \(q_{c,f}\). Each operation changes which term is visible. The transform must consequently be treated as part of the scientific hypothesis, not as preprocessing that leaves the question unchanged.

## 8. What the Controls Actually Rule Out

The accumulated experiments support a hierarchy of evidential strength.

**Raw singular concentration alone is weak evidence.** Base and composed tables are nearly rank one, but their natural-text-specific held-out margins are negligible. Shared output-token profiles explain much of the concentration.

**Low reconstruction error alone is weak evidence.** Unconstrained shuffling can reduce intervention magnitude from 3.24 to 0.54 nats and thereby improve raw reconstruction. Any comparison involving corrupted text must report the baseline effect magnitude or use an absolute captured-effect metric.

**Column permutation and matched Gaussian controls establish coupling.** They preserve column distributions or moments while destroying coordinated row-feature structure. Natural centered delta tables exceed both, including on held-out rows and disjoint text samples.

**Text shuffles establish linguistic dependence only when magnitude is matched or separately accounted for.** Final-token-preserving body shuffles and magnitude-aware GNC are more informative than unconstrained shuffles. The evidence supports dependence on fragment body and lexical content; it does not justify a general claim that syntax alone is low-rank.

**Mismatch controls establish identity specificity.** A fragment's own continuation direction outperforms another fragment's; a true compound subspace favors its own semantic target cluster; fragment labels organize orthogonal residual directions. These tests distinguish a shared generic basis from correspondence-dependent structure.

**A within-class ceiling establishes relative sufficiency.** A rank-four context code may explain less than all delta variance because the target itself contains context-idiosyncratic variation. Reaching the random-half ceiling is stronger evidence than a large raw fraction and more honest than comparing with an unattainable value of one.

**Ablations establish scope.** Centering mode, token-selection rule, matrix size, seed, fragment length, continuation definition, output-axis width, and full-vocabulary reconstruction have all changed some absolute values but preserved the central positive results. They also exposed genuine boundaries: global gain constants fail at full vocabulary; descriptive rank grows with output width; the content residual becomes diffuse; semantic-to-functional bilinear transfer is weaker than the reverse; and specialized lexical classes occupy distinct leading directions.

No one control proves a latent linguistic mechanism. Together, however, they make the key low-rank claims difficult to explain as additive offsets, small effects, frequency selection, insufficient rows, arbitrary extra parameters, or reuse of the wrong correspondence.

## 9. Direct Answer to the Central Research Question

The evidence supports four ordered conclusions.

First, **raw prompt-by-token and composed context-by-probe-token tables show strong but mostly trivial low-rank structure**. Their spectra are dominated by a shared token profile; raw effective rank is near one; composed natural-text capture is almost matched by column-permuted and Gaussian controls. These tables are useful diagnostic baselines, not the strongest evidence for nontrivial linguistic low rank.

Second, **the centered intervention-effect table is the strongest general construction**. Subtracting base context logits and removing row-wise offsets reveals coupling that saturates in effective rank with more contexts, predicts held-out contexts and held-out text, and captures more absolute distributional effect than multiple controls. At rank sixteen, its natural-text matched advantage is about 1.9 nats in the primary analysis and about 1.7 nats on preregistered held-out text. The comparable advantages for base and composed tables are near zero. This is the clearest answer to which arrangement works.

Third, **the delta table is not governed by one global low-rank factorization**. It contains a content channel whose direction is largely closed-form and whose cross-fragment shared part has predictive rank one or two, plus an orthogonal context-interaction channel whose predictive rank is about four. Dominant low-information components must be removed differently in each cell of this axis-by-channel grid: row and column means for aggregate delta tables, the anti-unigram direction for content steering, or per-context mean residuals for fragment-anchored orthogonal directions. The transferable signal is often a smaller residual beneath a larger shared direction.

Fourth, **low-rank structure and high-dimensional remainder coexist**. The rank-four context code reaches its attainable ceiling even at full vocabulary, yet descriptive effective rank grows and content residuals are diffuse. Lexical targets split the leading grammatical direction; semantic information diffuses through higher ranks; compound meaning includes an orthogonal combinatorial subspace; and context-dependent gains resist closed-form reduction. The strongest scientific statement is therefore local and constructive: for OLMo-1B final-position logits, centered base-subtracted intervention tables contain reproducible low-dimensional predictive channels that survive matched controls, while raw tables and several residual magnitudes do not support a global low-rank interpretation.

## 10. A Practical Protocol for Future Logit-Table Studies

The evidence suggests a disciplined workflow.

1. **Name the object before computing rank.** State the query family, row entity, feature axis, token universe, base subtraction, and centering operation. A context-axis unfolding and a probe-axis unfolding are different prediction problems.

2. **Report the baseline effect.** For intervention tables, include \(\operatorname{KL}(P_{\mathrm{comp}}\Vert P_{\mathrm{base}})\) or an equivalent magnitude. A small effect can masquerade as excellent reconstruction.

3. **Separate descriptive and predictive measurements.** Report singular values or effective rank, but make the primary claim from a training-only subspace evaluated on held-out rows or fragments.

4. **Use at least one coupling-destroying null and one linguistic corruption.** Column permutation or a moment-matched Gaussian tests coordinated structure. A body shuffle or another carefully matched text corruption tests dependence on linguistic content. Verify that the corruption does not collapse magnitude.

5. **Bracket with a ceiling when possible.** Random-half within-class prediction distinguishes failure of the representation from irreducible heterogeneity in the target population.

6. **Ablate centering and token choice.** Dominant conclusions should survive reasonable token-selection rules. If double-centering changes the answer, interpret the removed mean component rather than treating the transform as a neutral preprocessing choice.

7. **Validate full-vocabulary objects natively.** Never insert selected-token directions into a full-vocabulary score. Build directions over all coordinates and require a reduction gate that reproduces selected-token results when sliced back down.

8. **Distinguish direction, magnitude, and residual.** A direction can be nearly closed-form while its coefficient remains unpredictable. A residual can be spectrally diffuse while containing a small transferable subspace. These are separate claims.

This protocol turns “is it low-rank?” into a sequence of falsifiable questions. It also prevents a common rhetorical failure: reporting one favorable rank number while leaving the table construction and null model implicit.

## 11. Limitations and Open Problems

All evidence summarized here concerns one model, OLMo-1B, treated as a black box at the final prediction position. The natural fragments come primarily from a wiki-derived corpus, and specialized probes use curated English grammatical and semantic templates. Generalization across architectures, parameter scales, training corpora, languages, positions, and long-form contexts remains untested in this record.

Several results depend deliberately on the scoring measure. KL-based metrics weight coordinates by the true predictive distribution and therefore down-weight the far vocabulary tail. This is appropriate for next-token predictive effect, but it does not establish coordinate-wise fidelity across all 50,304 logits. Frobenius and angular measures answer different questions and sometimes reveal structure that KL treats as small. Their agreement on rank four is encouraging; their absolute magnitudes should not be conflated.

The content-channel gains are oracle quantities in full-vocabulary tests because they are optimized using the true composed distribution. Those studies identify predictive directions, not a deployable zero-query predictor of the coefficients. In fact, the failure of the global constants and base-profile predictor at full vocabulary is evidence that coefficient prediction remains open.

The within-class ceiling is estimated from random halves and is not a mathematical upper bound. Scores slightly above it should be interpreted as saturation within uncertainty. Similarly, seed counts range from three in some expensive ablations to sixteen in selected-token replications. The strongest conclusions are those repeated across several designs, not isolated point estimates.

The words “channel,” “code,” “scaffold,” and “routing” describe black-box regularities in logit space. They do not localize attention heads, multilayer perceptrons, or internal causal circuits. The bilinear generator is a predictive model over isolated logit priors, not proof that the network literally computes that regression.

Finally, the semantic story remains partly unresolved. The orthogonal channel shows robust semantic organization, especially for curated domains and compounds. The idiosyncratic remainder of the content channel did not yield a semantic-domain effect that survived all morphology, frequency, and length matching procedures. A larger, better-balanced fragment bank could determine whether that negative boundary reflects insufficient power or a genuine channel difference.

## 12. Conclusion

Black-box next-token logits do contain reproducible low-dimensional structure, but only after the object and comparison are specified carefully. Raw prompt and composed tables are spectrally compressed for largely trivial reasons. The scientifically meaningful signal appears most clearly in the centered intervention effect produced by appending a fragment and subtracting the original context logits. That table grows much more slowly in effective rank than matched nulls, predicts held-out contexts and held-out text, and captures about two more nats than the strongest controls at modest rank.

The structure has an anatomy. A fragment contributes a content-steering direction close to its standalone continuation plus an anti-unigram correction; those steering directions share a rank-one or rank-two subspace but retain substantial fragment-specific detail. After content removal, a rank-four context code transfers across output-token blocks and remains rank four over the full vocabulary, even as descriptive rank grows. Beneath and around these shared components lie lexically partitioned leading directions, semantically diffused higher ranks, compound-specific combinatorial subspaces, context-dependent gains, and diffuse collision-related variance.

The central empirical lesson is therefore a rule of interpretation. Low rank is not a single spectral property of a language model. It is a held-out predictive relationship among explicitly chosen contexts, interventions, tokens, transforms, and controls. Under that standard, centered base-subtracted intervention tables provide strong evidence of nontrivial low-dimensional coupling; raw base and composed tables do not. The result is narrower than “language is low-rank,” but it is also more informative: it identifies which construction exposes the structure, how many predictive dimensions its principal channels require, what artifacts create false positives, and where the reduction stops.

## Evidence Sources

The synthesis and all quantitative values above are drawn from the following locally archived research manuscripts. The titles are given so that every claim can be traced without exposing environment-specific document handles.

1. *Generalizable Nats Captured: A Magnitude-Aware Test for Low-Rank Structure in Intervention-Effect Logit Tables.*
2. *A Matched-Control Anatomy of Logit Composition in OLMo-1B: What Is Low-Rank, What Only Looks Low-Rank, and Why the Difference Is a Choice of Baseline.*
3. *The Closed-Form Content Channel: How One Lineage Reduced a Behavioral Steering Law to a Zero-Shot Operation on OLMo-1B Logit Tables.*
4. *The Full-Vocabulary Content Channel of OLMo-1B: The Anti-Unigram Direction Identity Extends and Strengthens, the Global-Constant Magnitude Does Not, and Compositional Divergence Concentrates in a Few Hundred Tokens.*
5. *The Content-Channel Steering Subspace of OLMo-1B Is Low-Rank Beyond the Anti-Unigram Axis, With a Large Idiosyncratic Remainder.*
6. *What Reduced and What Resisted: A Reductionist Ledger of the OLMo-1B Content Channel of Logit Composition.*
7. *A Shared Low-Dimensional Context Code Governs Cross-Token-Block Intervention Effects in OLMo-1B: Predictive Rank Far Below Matched Nulls, Saturating a Within-Class Ceiling.*
8. *The Shared Context Code Stays Low-Rank at Full Vocabulary While the Content Channel Goes Diffuse: A Predictive-Rank Dissociation in OLMo-1B.*
9. *A Raw-vs-Matched-Control Rank Reversal in the OLMo-1B Content-Removed Delta Code: The Probe Axis Wins on Raw Captured Fraction, the Context Axis Wins on Matched-Control Margin.*
10. *Dominant Shared Directions Versus the Transferable Residual: A Layered, Matched-Control Map of Low-Rank Structure Across Axes and Channels of OLMo-1B Logit Composition.*
11. *The Universal Interaction Subspace: Strict Algebraic Isolation Refutes Semantic Fragmentation.*
12. *The Dynamic Geometry of Semantic Hierarchy: Isolating the Pure Interaction Residual.*
13. *The Fractal Geometry of the Interaction Residual: Lexical Orthogonality at Rank 1, Semantic Diffusion at Higher Ranks.*
14. *The Rank-4 Generative Operator: Asymmetric Bilinear Generation of the Universal Interaction Manifold.*
15. *The Dual Nature of Logit Composition: Syntactic Scaffolding vs. Geometric Collision Debris.*
16. *The Algebra of Compositional Subspaces: Linear Spanning and the Combinatorial Residual.*
17. *The Mathematical Verification of Semantic Emergence: Bounding and Decoding the Combinatorial Residual.*
18. *A Fragment-Anchored Directional Signature in the Orthogonal Residual of OLMo-1B Logit Composition.*
