# Low-Rank Structure in Black-Box Language-Model Logit Tables: A Matched-Control Synthesis of Composition, Steering, and Residual Geometry

## Abstract

The claim that language has low-dimensional predictive structure is attractive but easy to test badly. A prompt-by-token logit matrix can look low-rank because all rows share a unigram profile, because a control condition has almost no effect to reconstruct, or because a ratio metric rewards a small denominator. This paper synthesizes the archived black-box experiments conducted for the low-rank logit-table task on OLMo-1B, a one-billion-parameter causal language model. The central conclusion is conditional and considerably sharper than the slogan “language is low-rank.” Low-rank structure is reproducible when the table is defined as an intervention effect, when the shared additive components are removed or matched, and when success is measured by held-out predictive information in absolute nats relative to a scale-matched null and, where possible, a within-class ceiling. It is not a universal property of every arrangement of logits.

The strongest evidence concerns the displacement produced by appending a text fragment to a context. The row-centered delta table, `delta(c,p) = logits(c+p) - logits(c)`, contains at least two predictive channels. A content channel steers the context toward the appended fragment’s standalone continuation and applies an anti-unigram correction. This direction-level law survives construction of genuine full-vocabulary vectors, held-out contexts and fragments, body-shuffle controls, matched-norm random directions, and changes in the definition of the standalone direction. The correction direction is the centered negative mean base-logit profile, with cosine about 0.98–0.99 to the empirically fitted axis; the selected-token version is nearly zero-shot computable. At full vocabulary the direction law remains, but its per-context magnitudes do not collapse to two global constants, and the residual beyond the two terms is diffuse.

The complementary interaction channel is predictively low-dimensional. A shared context code reaches 90% of its floor-corrected within-class ceiling at rank four in every one of eight full-vocabulary seeds, even though descriptive effective rank grows from about 36 on a 256-token slice to about 49 on the full 50,304-token vocabulary. The code transfers across disjoint token blocks and survives anti-unigram removal and double-centering. A finite ceiling matters: approximately 39% of held-out cross-block variation remains outside the global code, and a second base-profile-cluster-specific code explains a modest but reproducible part of that headroom. A matched context-versus-probe comparison shows that raw captured fraction can reverse the scientific ordering: the probe axis has the larger raw score, but the context axis has the larger matched-control margin.

The residual is structured at several scales. A fragment-anchored directional signature survives removal of richer rank-2 and rank-3 content bases. Grammatical geometry is neither one universal tensor nor arbitrary noise: at low rank it partitions by target lexical class, while higher ranks show semantic diffusion; homogeneous agreement and reflexive paradigms transfer better than heterogeneous mixtures. Multi-token compounds retain a head-noun bias, linearly span part of their constituent geometry, and generate a frequency-matched, target-specific orthogonal combinatorial residual. Explicit negation and privative modifiers add displacement rather than algebraically suppressing the noun’s core direction.

Finally, a preregistered vulnerability test asks whether the relation between variance rank and transfer rank depends on semantic homogeneity of the context set. Using 192 candidate contexts, 64 training contexts, 32 held-out contexts, six probes, a 256-token frequency-stratified axis, eight seeds, column-permutation and Gaussian nulls, and exact first-versus-second singular-direction margins, the homogeneous regime increased `g = margin(v1) - margin(v2)` by 0.093 (95% bootstrap interval [0.037, 0.145]) relative to the heterogeneous regime. The manipulation check passed: mean pairwise base-logit cosine increased by 0.219 [0.196, 0.242], while within-set base-logit variance decreased by 1.201 [0.984, 1.426]. A simple punctuation/format/subword covariate was correlated with the contrast but did not remove it; the adjusted intercept remained 0.068 [0.024, 0.142]. Thus the archived evidence supports a revised, conditional map: dominant variance and transferable structure can separate, and the separation itself depends on the organization of the context sample.

## 1. Research question and scope

The task is to determine when black-box next-token logits exhibit nontrivial low-rank structure. A model is queried with a text context and returns a vector of logits, one coordinate for each possible next token. The task does not license a global statement about language or about all model representations. It asks a more exact question: which arrangements of these vectors yield reproducible low-rank structure, which controls distinguish that structure from trivial artifacts, and how much of the conclusion survives changes in text sample, token subset, centering, matrix size, and held-out data?

The distinction between an arrangement and a model is essential. The same model can produce a raw prompt-by-token table, a composed table containing context-plus-probe queries, an intervention-effect table obtained by subtracting the base context, or a paired/double-difference table targeted at a grammatical contrast. These matrices have different row and column meanings and therefore different estimands. A singular value is not a scientific conclusion until the row axis, column axis, transform, token-selection rule, null, and held-out target are named.

The evidence considered here is restricted to the local archive for this task. The model is OLMo-1B, queried at the final position with black-box next-token logits. Text fragments are drawn from the supplied corpora or from controlled grammatical and semantic templates. The primary natural-text studies use contexts and probes in the task’s small-to-medium regime, generally tens to hundreds of fragments, fragment lengths below 64 tokens, and selected-token axes between 20 and 256 coordinates. Several scale-up studies query the full 50,304-token vocabulary. No claim below is intended to generalize automatically to another model, another layer, another token position, another corpus, or another vocabulary metric.

## 2. Why naive low-rank evidence fails

### 2.1 Shared additive components

Logits are invariant to adding the same constant to every coordinate of a row after softmax. More importantly, rows from unrelated contexts share a strong base-rate or unigram profile. A raw prompt-by-token matrix can therefore have an enormous first singular value and an effective rank close to one. This is not evidence that contexts are governed by one meaningful latent factor. It is a property of the coordinate system and the marginal token distribution. The raw table is useful as a diagnostic, but it is not the main object for a composition claim.

The standard correction is row-centering, subtracting each row’s mean over the scored token axis. Double-centering additionally subtracts column means, removing a shared token-direction component. Neither transform is universally “correct”; they answer different questions. The important requirement is that the same transform be applied to real data and controls, and that the paper state whether it is studying the dominant shared component or the residual beneath it.

### 2.2 The magnitude confound

Several early analyses used reconstruction error or explained-variance fractions. A control in which appending a corrupted fragment barely changes the distribution can be reconstructed with a very small error, even if no meaningful cross-context coupling exists. In the archived studies, unconstrained token shuffling produced lower raw held-out KL than natural text because the shuffled intervention had much smaller effect magnitude: mean composed-versus-base KL was about 0.54 for shuffled fragments versus 3.24 for natural fragments in one matched comparison. The low error was a small-denominator effect.

The remedy is to report absolute predictive information, not only relative error. The principal metric introduced in the archive is generalizable nats captured (GNC): the held-out KL divergence between the true composed distribution and the base distribution, minus the residual KL after reconstructing with a train-fitted subspace. GNC credits a method for explaining an intervention effect only to the extent that the effect exists and transfers. Column-permutation and matched-moment Gaussian controls preserve per-column scale while destroying cross-column coupling. A token-shuffle control tests order dependence but must be interpreted with its effect magnitude reported.

### 2.3 The ceiling problem

A null floor tells us that a method beats a coupling-destroyed baseline. It does not tell us how much predictable variation is available. The within-class random-half ceiling addresses this: train and test halves are drawn from the same natural context distribution, with matched rank and matrix shape. The ceiling estimates the best transfer available when genuine context heterogeneity, rather than a mismatch of domains, is the limiting factor. A finite ceiling is scientifically informative. In the context-code studies it is around 0.61–0.65 captured fraction, leaving roughly 39% of cross-block variation outside the common code.

The most defensible statements therefore have the form “rank four captures the held-out effect above a matched null and reaches the finite within-class ceiling,” not “the matrix has rank four.” The former is a predictive claim; the latter is a descriptive shortcut that can be false even when the first claim is true.

## 3. The table designs and measurement protocol

The archive explored three broad arrangements and several specialized variants.

1. **Prompt-by-token tables.** Rows are contexts and columns are selected next-token logits, with raw or centered logits. These tables establish the shared-profile confound and serve as baselines.

2. **Composed tables.** Rows are contexts and columns are probe-by-token blocks, where each block contains logits after appending one probe. Composed tables can look highly compressible because they retain the base context and probe main effects. Their low-rankness is not necessarily real-specific: at rank 16 a composed table had GNC about 3.56 nats, while its column-permutation and Gaussian controls captured approximately 3.4–3.5 nats.

3. **Intervention-effect or delta tables.** For context `c`, probe `p`, and token `t`, the entry is `delta(c,p,t) = logit(t | c+p) - logit(t | c)`. Rows can index contexts, probes, context–probe pairs, or fragments. This subtraction is the central design choice. It removes the unchanged base prediction and exposes how composition moves the distribution.

4. **Paired and composed-fragment tables.** Double-difference tables compare matched contexts with and without a grammatical relation; subspace-enrichment tables compare constituent and compound phrases. These designs test whether a relation, target vocabulary, or emergent semantic identity appears in a residual that cannot be explained by isolated components.

Across designs, the archived workflow has four non-negotiable elements. First, the table definition is fixed before looking at the held-out result. Second, singular vectors are fit on training rows or fragments only. Third, controls preserve shape and scale whenever possible. Fourth, every positive is reported with seeds, matrix sizes, ranks, and an explicit scope statement.

## 4. The first durable result: intervention effects, not raw composition, carry real coupling

The earliest comprehensive study compared base, composed, and delta arrangements under raw, row-centered, and double-centered decompositions. In raw form, base and composed tables both had effective rank close to one because of a shared additive component. After main-effect removal, the delta table had the largest excess effective-rank gap over coupling-destroyed controls: approximately 19.48 ± 2.94, compared with 6.11 ± 0.23 for the base table and 1.08 ± 0.31 for the composed table.

The result is not simply “delta has more singular values.” In a context-scaling experiment with 48, 96, and 192 rows, the real double-centered delta effective rank increased only from about 19.5 to 29.1, whereas column-permutation and Gaussian nulls rose from approximately 45 to 166. The real slope was about 0.063 rank units per added context, compared with about 0.836 for the nulls. At 192 contexts and rank 16, the real composed-softmax KL was about 0.58, while nulls remained near 1.6. The gap widened with matrix size, as expected for a genuine shared organization rather than a finite-sample rank coincidence.

The effect is specific to the subtraction. At rank 16, the real delta arrangement had a real-minus-best-control GNC advantage of about 1.91 ± 0.52, while the composed arrangement’s advantage was only 0.07 ± 0.15 and the base arrangement’s was −0.28 ± 1.10. A preregistered held-out text split retained a positive real-minus-control gap of 1.70 ± 0.71 nats, with real captured effect around 2.66 nats. The advantage persisted across selected-token widths of 32, 64, and 100 and across 12- and 24-probe conditions. This is the core existence result: a precisely defined delta table contains transferable, magnitude-bearing coupling that matched controls do not reproduce.

The interpretation must remain modest. The natural-versus-shuffled comparison did not prove that syntax is the low-rank factor. Word shuffling preserved some lexical content while collapsing effect magnitude. The strongest conclusion is that natural text induces a transferable coupling in the intervention-effect table, and that the coupling is not explained by shared column marginals, matched Gaussian noise, or a trivial base table.

## 5. Two channels in the delta: a content law and an interaction code

The archive’s most coherent scientific synthesis is a two-channel account. The channels are defined behaviorally in output-logit space, not as claims about a particular attention head or MLP.

### 5.1 The content channel: standalone continuation plus anti-unigram correction

Let `u_f` be the centered next-token logit vector obtained by querying an appended fragment `f` alone. The content hypothesis says that appending `f` to any context moves the context toward `u_f`, with a context-dependent gain. A fixed final fragment was tested across many contexts, and a rank-one direction fit on training contexts reconstructed held-out contexts better than final-token-preserving body shuffles, random-token sequences, and cross-fragment mismatches. In one three-seed comparison, held-out rank-one KL was 1.830 ± 0.070 for natural fragments, 1.989 ± 0.032 for final-token-preserving shuffles, and 2.089 ± 0.118 for random sequences. Using a different fragment’s direction increased KL to about 3.20, a 1.37-nat penalty over the correct direction.

The fitted direction was not exactly the standalone continuation. A two-term law added a universal correction axis. Analytic substitution identified this axis as the anti-unigram direction: the centered negative mean base logit over the scored tokens. Replacing the fitted axis with this analytic vector recovered 0.991 [0.966, 1.015] of the empirical correction gain on held-out contexts and 1.003 [0.959, 1.047] on held-out fragments. Its cosine with the fitted axis was 0.987 [0.983, 0.990], compared with about 0.06 for random directions. A first-order entropy/temperature direction recovered only about half of the gain, so entropy softening was a symptom of subtracting duplicated base-profile mass, not the mechanism itself.

The mechanism is simple in output-space terms. The base context already assigns high-frequency tokens substantial logit mass. Scaling the fragment’s standalone continuation adds some of that generic mass again. The anti-unigram correction subtracts the double count. In the selected-token regime, two global constants multiplying the continuation and correction directions matched the per-context fitted ceiling in aggregate, while a standalone-only floor was lower by roughly 0.08–0.09 normalized KL. The result is a direction-level closed form, not a claim that all coefficients are context-independent.

### 5.2 Full-vocabulary extension and the boundary of the closed form

A crucial artifact was corrected in the full-vocabulary study. A prior apparent null inserted 160-dimensional directions into a 50,304-dimensional reconstruction; on 50,144 coordinates the prediction equaled the base by construction. Rebuilding both directions natively over all 50,304 tokens reversed the conclusion. The two-term direction law beat the standalone-only floor by +0.226 on held-out contexts and +0.206 on held-out fragments in normalized-KL recovery, with raw additional recovery around 1.5–1.7 nats. The anti-unigram cosine remained 0.982. Body shuffling collapsed the recovery by approximately 0.27–0.33, and matched-norm random directions were far worse.

The full-vocabulary result also states what does not generalize. A candidate third tail axis added only +0.009 recovery and failed its mismatch and random controls; its rank-one energy was 0.375, indicating a diffuse residual. The two-global-constant magnitude simplification failed: a per-context KL-optimal ceiling exceeded the global-constant version by about 0.10. The selected-token predictor of the correction coefficient, which had explained roughly 0.23–0.30 of its variance, did not transfer to full vocabulary and even reversed sign. Thus the content channel has a robust direction identity but learned, context-sensitive magnitudes and a diffuse full-distribution remainder.

The full-vocabulary divergence is nevertheless probability-concentrated. Ranking tokens by their true composed probability, the top approximately 20 tokens carried 75–80% of the base-to-true KL and the recovered KL was even more top-heavy, around 84–90%. Across the tested settings the 90% knee was a few hundred tokens, roughly 328–460, but a follow-up with shared sequences showed that apparent growth with fragment length was an entropy confound. The defensible statement is concentration by probability rank with a width governed more by entropy than by token count.

### 5.3 The orthogonal interaction/context-code channel

After removing the content channel or using a strict double-centered delta transform, a complementary context code remains. Its defining test is cross-token-block transfer: fit a rank-r right subspace on one 32-token block, then predict held-out contexts on seven disjoint blocks. The code beat context-correspondence and column-permutation floors, survived anti-unigram removal, and remained positive under frequency-stratified, uniform-random, and top-base token selection. The transfer was nearly flat over block distance and token frequency.

The code reaches a finite within-class ceiling. At a primary row-centered rank-eight point, real captured fraction was 0.628 [0.537, 0.720], the null floor was 0.356, and the within-class ceiling was 0.614 [0.517, 0.711]. The headroom fraction was 1.051 [0.958, 1.144], statistically indistinguishable from one. Rank four already saturated the ceiling, and the estimate remained stable under anti-unigram removal and double-centering. The finite ceiling means that around 39% of held-out cross-block delta variation remains context-idiosyncratic; it is not evidence that the code failed.

The full-vocabulary replication is especially important. A native full-vocabulary pipeline reproduced the selected-token result to machine precision when restricted to the 256-token slice, ruling out the coverage artifact. At all eight seeds, the rank needed to reach 90% of the floor-corrected ceiling was four. The descriptive effective rank rose from 36.3 on the 256-token reference to 49.3 at full vocabulary, but predictive rank stayed four. This is the clearest dissociation in the archive: descriptive spectrum and predictive dimensionality are different quantities.

## 6. Hierarchical residual structure

The finite ceiling is not an endpoint. It defines a residual object whose organization can be tested.

### 6.1 A second context code

After subtracting the shared context code, contexts were clustered using train-only base-logit profiles. A balanced two-cluster model was evaluated by within-versus-cross-cluster transfer on held-out contexts and disjoint token blocks, with random equal-size partitions as the parameter-budget control. At rank eight, real within-cluster captured fraction was 0.341 and cross-cluster was 0.270, an asymmetry of about 0.071. The real-minus-random asymmetry was 0.072 with lower confidence bound 0.048. Clustering by context length did not organize the residual.

The result survived anti-unigram removal and double-centering: lower confidence bounds for the real-minus-random asymmetry were approximately 0.047 and 0.046. The effect is partial, not a complete explanation of the headroom. It indicates a hierarchy: a global context code, followed by a base-profile-conditional code, followed by genuinely idiosyncratic variation. It does not establish discrete context types or a localized internal circuit.

### 6.2 Fragment-anchored structure beyond content

The full-vocabulary residual orthogonal to a fragment’s standalone direction and the anti-unigram axis contains a directional signature anchored to fragment identity. After removing global and per-context mean residual directions, the held-out within-minus-across-fragment cosine gap was 0.3555 [0.3189, 0.4010], compared with a shuffled-label null near 0.0055 and a random-direction floor near zero. Residual-norm stratification and length/frequency matching preserved the effect.

This was not leakage of a richer content vector. Removing rank-2 and rank-3 fragment content bases increased rather than erased the held-out gap, to roughly 0.48 at rank three, while span capture rose only from 0.41 to 0.58 and remained far from saturation. The staged ablation explains why the raw signal was small: raw gap was 0.068, global-mean removal gave 0.052, and global plus per-context removal gave 0.377. The per-context shared direction is the dominant dilutor. The evidence supports an interaction direction organized by fragment identity, while leaving its semantic interpretation open.

### 6.3 Content-channel steering directions as a collection

The set of standalone directions `{u_f}` is itself not arbitrary. After removing the anti-unigram axis, a rank-one or rank-two shared subspace transfers to held-out fragments and beats random and mismatch bases. The leading shared axis is richer than a fixed mean offset but has cosine about 0.83 with a no-fit morphological mean direction. The shared subspace survives changes in the definition of `u_f`, matrix size, structural family, and raw-nats scoring, yet a large fragment-idiosyncratic remainder remains below the full per-fragment ceiling.

Attempts to organize that remainder semantically were not robust after matching morphology, frequency, and length. A weak base-profile-cluster layer was detectable, but a clean semantic-domain claim could not be established at the available fragment-bank size. This negative result matters: semantic organization is not accepted merely because a favorable within-domain comparison exists.

## 7. Arrangement and axis determine the answer

The context code and content channel do not imply that every axis of every table is equally low-rank.

### 7.1 A raw-versus-matched rank reversal

One matched experiment used the same queries, 16 training and 16 held-out rows, 8,192 features, ranks, seeds, and nulls, changing only whether rows indexed contexts or probes. On the row-centered content-removed transform, the probe-axis raw captured fraction at rank eight was about 0.65, versus 0.37 for the context axis. A naive reading would declare the probe axis stronger. The matched-control floor for the probe axis was 0.53, however, while the context floor was about 0.12. After subtraction, the context margin was 0.25 and the probe margin only 0.05.

Double-centering removed the shared component. The context margin became 0.247 [lower bound 0.211], the probe margin 0.179 [lower bound 0.151], and their difference had lower bound 0.031. Thus both axes carry real transferable structure, but the context axis carries more. The raw score and matched margin rank the arrangements in opposite orders because the probe axis has a large shared component that any low-rank basis can reconstruct. This is a direct demonstration that “higher captured fraction” is not synonymous with “more scientific structure.”

### 7.2 Grammatical routing: specific circuits and target manifolds

The grammar-focused studies explain why heterogeneous probe collections can look high-rank. A double-difference matrix mixing relative clauses, adverbs, and prepositional phrases had effective rank 9.55 and worse rank-two transfer than a shuffled control. Restricting the probes to a homogeneous agreement-attraction paradigm reversed the result: at a 64-by-64 scale, intact rank-eight relative unexplained variance was 0.296 versus 0.429 for token-shuffled probes. A reflexive-binding replication gave rank-four values of 0.527 versus 0.676. The conclusion is not that all syntax is one rank-four object, but that a homogeneous structural operation can be isolated and transferred.

The more systematic four-way comparison varied syntactic parse and target lexical class independently. Prepositional and relative-clause constructions targeting verb number shared a predictive subspace; the same parse changes targeting reflexive pronouns also shared a subspace. Cross-target comparisons were less aligned. At rank eight the same-target, cross-syntax mean subspace cosine was 0.628, whereas cross-target comparisons averaged 0.426; at rank one the corresponding values were 0.436 and 0.276. The appropriate synthesis is a target-vocabulary manifold: parse variation can share a routing geometry when the output class is held fixed, while changing the lexical destination fragments the subspace.

The earlier principal-angle work reported a related but coarser hierarchy. Frequency-matched functional probes had within-class subspace cosine around 0.71–0.74, semantic probes around 0.59–0.64, and unsupervised clustering recovered the functional/semantic split with purity about 0.84–0.875. A later hierarchical analysis reconciled this with target-manifold results: at rank one, lexical target dominates and can be nearly orthogonal (about 0.10 for verb versus reflexive targets); at ranks four to eight, semantic diffusion from shared domains such as animacy creates partial alignment. These are not mutually exclusive claims. They refer to different ranks and different partition variables.

### 7.3 Bilinear generation and estimator dependence

A reduced-rank bilinear map from isolated context and probe logits to a double-centered interaction residual peaked at rank four. Trained on functional probes and transferred to semantic probes, the rank-four map achieved flattened cosine similarity 0.027 versus 0.006 for a row-shuffled null and exceeded the 95th percentile of 100 exact-Frobenius-matched random maps in all three seeds. The reverse semantic-to-functional transfer was positive but less decisive, averaging the 93rd percentile and exceeding the 95th percentile in only one of three seeds. Standard L2 `R^2` failed out of domain because magnitude differed; angular scoring isolated directional agreement.

Another analysis argues that strict double-centering removes a rank-four syntactic scaffold and leaves diffuse “collision debris.” It found that rank-four transfer collapses when context syntax is word-shuffled, while prior divergence predicts residual magnitude and is especially high for adversarial or confused compositions. These findings should not be treated as a simple refutation of the bilinear result. They use different transforms and estimands: one retains a context main effect and scores angular routing; the other isolates a double-centered residual and analyzes magnitude. The archive supports estimator dependence as a substantive fact. “Universal interaction manifold” is too broad; the evidence is compatible with a compressible routing scaffold superposed on a diffuse, collision-sensitive residual.

## 8. Multi-token semantic composition

The same matched-control logic applies beyond single probes. For two-token compounds, an algebraic-isolation study projected out the static content channel and compared composed phrases with constituent subspaces. The head noun exerted a larger geometric anchor than the modifier: held-out subspace cosine was about 0.635 versus 0.609. The joint rank-eight constituent span explained 0.271 of composed variance, above a mismatched-pair span at 0.223, but the optimal composed rank-eight subspace explained 0.429. Even after extending the constituent basis to rank 16, the joint span reached 0.378 while the optimal composed span reached 0.530, leaving a gap around 0.152. The residual is therefore not merely a permutation of low-variance constituent directions.

The residual is semantically interpretable when assessed with preregistered target-token clusters rather than by reading one principal vector. For a compound such as a financial noun pair, the true target cluster had held-out explained-variance ratio 0.866 in the combinatorial residual subspace versus 0.807 in a mismatched residual subspace. The effect was strongest at rank four, with a true-minus-mismatch gap around 0.108, narrowed by rank eight, and saturated by rank 16. The same protocol found weaker but positive effects for intersective adjective–noun phrases, consistent with residual magnitude depending on lexicalization.

The sequential ledger is revealing. For noun–noun compounds, the standalone content vector explained 15.6% of target variance, the full joint constituent span 39.4%, and the remaining 60.6% was not spanned by the constituents. The rank-eight combinatorial residual accounted for 20.3% of this nonredundant semantic target variance. This is a scoped claim about target-token enrichment, not a claim that one vector “means” the compound.

Privative and explicitly negative constructions sharpen the interpretation. Strict unigram-matched tests found no suppression of the noun’s core target subspace: suppression difference-in-differences was approximately +0.0085 for privative adjectives, +0.011 under hard frequency matching, and −0.0014 for explicit forms such as “no” or “without.” In contrast, displacement targets were enriched in the orthogonal combinatorial residual, with gaps +0.055 for privative modifiers and +0.082 for explicit absence terms. Within these conditions, composition is geometrically additive: it retains the core concept and adds a specific displacement rather than deleting the constituent.

## 9. The homogeneity vulnerability test

The newest experiment directly tests a condition left implicit in the layered map: does the relation between variance rank and transfer rank depend on how homogeneous the context set is?

### 9.1 Object and preregistered estimand

For each seed, 192 candidate natural contexts were sampled. The analyzed table had 64 training contexts and 32 held-out contexts, six shared probes, and 256 frequency-stratified output tokens. Each row concatenated six probe blocks, yielding a 64 × 1,536 row-centered composition-delta matrix. The primary directions were literally the first and second right singular vectors of the training table: `v1` and `v2`. For each direction, held-out captured fraction was measured and the matched column-permutation floor was subtracted; a Gaussian matched-moment floor was secondary. The key quantity was `g = margin(v1) - margin(v2)`. The primary contrast was `Delta g = g_homogeneous - g_heterogeneous`.

The heterogeneous condition was a broad random context sample. The homogeneous condition was the tightest cosine nearest-neighborhood of the required size, selected using row-centered full-vocabulary base-context logits, upstream of the delta outcome. The two regimes used the same seeds, contexts-per-split, probes, token axis, transform, ranks, and nulls. The experiment also reported a within-class random-half ceiling and the top-token punctuation/format/subword mass of `v1` as a frequency-concentration covariate. All real and null matrices passed the object-match gates.

### 9.2 Results

The heterogeneous regime had `g_colperm = -0.0795`, 95% bootstrap interval [−0.1339, −0.0261]. Its first-direction margin averaged 0.0529 and its second-direction margin 0.1325. In other words, the high-variance first direction was less transferable than the second direction. In the homogeneous regime, `g_colperm = 0.0135`, interval [−0.0084, 0.0367]; the first-direction margin was 0.0791 and the second-direction margin 0.0655. The first-versus-second gap therefore moved toward zero and slightly positive.

The pre-registered primary contrast was positive: `Delta g = 0.0931`, 95% bootstrap interval [0.0366, 0.1446]. The Gaussian secondary contrast was also positive, 0.0841 [0.0408, 0.1214]. The sign is stable at the aggregate level even though individual seeds vary. The heterogeneous regime reproduced the earlier layered pattern—dominant variance direction below the leading residual in transfer—whereas the tight homogeneous set weakened that anti-correlation and made the first two directions more comparable.

The manipulation check was strong. Mean pairwise cosine of full-vocabulary base-context logits increased from 0.3476 in the heterogeneous regime to 0.5666 in the homogeneous regime, a difference of 0.2190 [0.1958, 0.2418]. Within-set base-logit variance decreased from 6.0416 to 4.8401, a difference of 1.2015 [0.9840, 1.4255]. The selected neighborhood was therefore genuinely more self-similar, not merely labeled homogeneous.

The frequency-concentration control was informative rather than dispositive. The top-20 punctuation/format/subword mass of `v1` was 0.578 in the heterogeneous regime and 0.683 in the homogeneous regime, a difference of 0.105 [−0.100, 0.278]. The raw frequency covariate correlated strongly with the per-seed contrast (`r = 0.836`), so it is a real nuisance. Yet a simple linear adjustment left an intercept of 0.0680 [0.0244, 0.1416] at zero covariate difference. The experiment therefore meets its preregistered “revise” criterion, but the covariate result should not be overinterpreted as a mechanistic decomposition. It establishes that the homogeneity effect is not removed by this simple frequency-concentration adjustment, not that frequency plays no role.

### 9.3 Interpretation

This result revises the layered map conditionally. In heterogeneous context collections, the largest-variance direction can be a shared, low-information component while the second direction carries more transferable context information. In a tight base-logit neighborhood, the first direction becomes more transferable relative to the second. The map therefore depends on the distribution of contexts used to construct the table. “Variance rank is anti-correlated with transfer rank” is not a universal law; it is a regime-dependent statement whose sign can change under a controlled upstream homogeneity manipulation.

The experiment does not show that homogeneous contexts make language globally low-rank. It uses one operationalization—a tightest cosine neighborhood in full-vocabulary base-logit space—one model, six probes, a 256-token axis, and eight seeds. Its scientific value is precisely that it keeps the downstream delta object fixed while changing only the organization of the upstream context set.

## 10. An integrated model of what is low-rank

The archive supports a layered, channel-specific account.

At the outermost level, raw logits contain a shared base-rate direction. Removing or matching it is necessary before a composition claim is meaningful. In the intervention effect, a content channel then carries a fragment-specific standalone direction plus anti-unigram correction. That direction is low-dimensional and transferable; its full-vocabulary magnitudes are not fully reducible. Orthogonal to this content channel lies a context–probe interaction code. Its predictive rank is about four and its ceiling is finite, but its descriptive spectrum is broader. Above the shared code sits a modest base-profile-conditional code and then a large idiosyncratic remainder.

The same hierarchy appears when rows index probes or fragments. A raw probe axis may have a large common component, while its matched-control margin is small. A fragment’s residual direction can nevertheless remain anchored to fragment identity after dominant per-context means are removed. In grammar, a common routing scaffold exists within a target lexical class, while target changes create orthogonal manifolds and semantic features diffuse into higher ranks. In compounds, constituent spans explain part of the update, while a target-specific combinatorial residual adds the emergent component.

This account resolves the apparent contradictions among archived papers. Reports of a universal low-rank manifold measured shared variance or a rank-four predictive scaffold. Reports of semantic fragmentation measured target-class or domain-conditioned angles after content removal. Reports of diffuse full-vocabulary residuals concerned the content-channel remainder, not the orthogonal context code. Reports of a small grammatical differential measured a matched within-class contrast, not the absolute transfer magnitude. These are different layers and estimands of one output-space object.

## 11. What the evidence does and does not establish

The evidence establishes, with held-out and matched-control support, that:

- raw prompt-by-token low rank is largely trivial;
- row-centered intervention-effect tables contain reproducible coupling above column-permutation, Gaussian, and lexical controls;
- the content channel has a full-vocabulary direction law, but not a full-vocabulary two-constant magnitude law;
- the orthogonal context code has predictive rank about four and reaches a finite within-class ceiling;
- descriptive effective rank can grow while predictive rank stays fixed;
- residual structure is hierarchical, with base-profile-conditional, fragment-anchored, grammatical-target, semantic-domain, and combinatorial components under different constructions;
- the variance-versus-transfer relation depends on context-set homogeneity.

It does not establish that language, all hidden states, or all models are globally low-rank. It does not identify attention heads, MLPs, or a mechanistic circuit. It does not prove that the semantic labels used in controlled templates are represented as human concepts inside the model. It does not show that the same rank or metric would hold for long natural documents, other token positions, or other architectures. The archive repeatedly demonstrates that changing the baseline changes the estimand; these boundaries are part of the result.

## 12. Practical recommendations for future logit-table studies

First, define the object algebraically before querying the model. State whether rows index contexts, probes, fragments, or pairs; state the token axis and the transform; and say whether the table is raw, composed, delta, or a paired difference.

Second, report at least one absolute predictive metric. A rank number, explained-variance fraction, or relative reconstruction error should be accompanied by held-out nats or KL and a matched-control margin. If a shuffle control changes effect magnitude, report the magnitude explicitly or use a magnitude-preserving construction.

Third, use a ceiling when the data contain real heterogeneity. A null floor alone cannot tell whether a small positive effect is near the attainable limit or merely above noise.

Fourth, separate direction from magnitude. A direction can be zero-shot identifiable while its coefficient remains context- or fragment-specific. The full-vocabulary content result is a model example: anti-unigram direction identity survives, the two-global-constant coefficient law does not.

Fifth, test the organization of the sample itself. The homogeneity experiment shows that context selection can alter which singular directions transfer. At minimum, report context similarity, within-set variance, and a frequency/format covariate when the first singular direction has conspicuous token signatures.

Finally, make negative results visible. The archive corrected a coverage-bounded full-vocabulary null, rejected a fixed length law for concentration width, failed to reduce full-vocabulary magnitudes to a base-profile formula, and could not robustly establish semantic organization of the content-channel remainder. These corrections make the positive claims more credible.

## 13. Conclusion

The black-box logit tables in this task do exhibit nontrivial low-dimensional structure, but only after the question is made precise. The most reliable object is the intervention effect of appending a fragment, evaluated on held-out contexts or fragments, in absolute predictive units, against controls that preserve matrix shape and effect scale. In that object, a content channel points toward the fragment’s standalone continuation and subtracts an anti-unigram double count. A complementary interaction channel is governed by a rank-four shared context code that transfers across token blocks and remains low-rank at full vocabulary. Both channels have residuals: learned magnitudes, base-profile-conditional codes, fragment-anchored directions, grammatical target manifolds, semantic diffusion, and combinatorial displacement.

The decisive qualification is that low-rankness is layered and conditional. Dominant variance can be low-information; transferable structure can be smaller than the leading singular component; raw and matched-control metrics can reverse an axis comparison; full-vocabulary behavior can differ by channel; and the variance-transfer ordering changes when the context set is made semantically homogeneous. The strongest final claim is therefore exact: for OLMo-1B final-position next-token logits, row-centered intervention-effect tables show reproducible, held-out, matched-control-surviving low-dimensional structure, with the form and apparent rank determined by the table arrangement, channel, baseline, token universe, and context-set organization. That is a substantive empirical answer to the low-rank intuition—and a reason not to replace it with a slogan.

## Source basis

This synthesis was prepared solely from the local task archive: the task specification, archived full papers, archived evaluation reports and submissions, and saved result artifacts under the supplied data directory. Numerical values above are reported results from those materials; no new model queries or experiments were run.

## Appendix A. Definitions and accounting conventions

Because the same words—rank, residual, transfer, and composition—are used for several related objects, it is useful to collect the definitions in one place. Let `l(x)` denote the final-position logit vector returned for text `x`, and let `softmax(l(x))` be the corresponding predictive distribution. For a context `c` and appended fragment or probe `p`, the composition displacement is

`delta(c,p) = l(c+p) - l(c)`.

The base table has rows `c` and columns token coordinates of `l(c)`. The composed table has columns indexed by probe–token pairs and entries `l(c+p)[t]`. The delta table has the same probe–token columns but entries `delta(c,p,t)`. A row-centered table subtracts the mean across the token coordinates in each row. A double-centered table additionally subtracts the mean of each column over the training rows. Since adding a constant to all logits in one row leaves the softmax unchanged, row-centering is a natural invariance operation; double-centering is a stronger nuisance-removal operation that changes the estimand by removing a shared token profile.

For an SVD `X = U S V^T`, the singular directions used in the homogeneity experiment are the right singular vectors `v1` and `v2`, corresponding to the largest and second-largest singular values of the training delta table. They are not cumulative rank-two reconstructions. This distinction matters because the vulnerability test compares the exact transfer margins of the first direction and the second direction. Elsewhere, “rank-r reconstruction” means projection onto the span of the first `r` right singular vectors and is cumulative by definition.

The principal held-out quantity is captured nats. If `KL0` is the mean KL divergence from the true composed distribution to the base distribution and `KLr` is the residual KL after a rank-r reconstruction, then captured nats are `KL0 - KLr`. A normalized captured fraction divides by `KL0`, while a matched-control margin subtracts the corresponding value for a null table. The archive uses both because they answer different questions. Fractions allow comparisons across conditions with different scales, but can be distorted by a changing denominator. Absolute nats preserve effect magnitude, but can be dominated by a broad baseline shift. A claim is strongest when the sign is consistent in both forms and when the null preserves scale.

The within-class ceiling is estimated by repeatedly splitting naturally sampled contexts into two matched halves, fitting a subspace on one half and testing on the other, in both directions. The ceiling is not an oracle for the model’s hidden computation. It is an empirical upper reference for the particular table, token universe, rank, and sampling distribution. In the shared context-code experiment, the ceiling being below one is itself evidence: the context set contains a reproducible component and an irreducible or unshared component. In the homogeneity experiment, the random-half ceiling was reported direction by direction so that the first-versus-second comparison was bracketed rather than interpreted in isolation.

## Appendix B. Control logic and failure modes

The archive’s control set is best understood as a sequence of increasingly demanding counterfactuals.

**Column permutation.** Within each column, row values are permuted independently. This retains each token coordinate’s empirical marginal distribution and its scale, but breaks the alignment of coordinates across rows. It is therefore appropriate for testing whether a right singular subspace captures coordinated cross-column variation. It is not a test of all possible nulls: if the scientific question is about row correspondence or target-class structure, a different permutation is needed.

**Matched-moment Gaussian.** Each column is replaced by Gaussian values with matched mean and variance. This destroys higher-order and cross-column dependencies while preserving first and second marginal moments. Agreement between column-permutation and Gaussian floors is reassuring because the two nulls fail differently. In the homogeneity experiment, the primary column-permutation contrast was 0.093 [0.037, 0.145], and the secondary Gaussian contrast was 0.084 [0.041, 0.121].

**Correspondence shuffle.** A row-level correspondence shuffle breaks the mapping between one context’s profile and another table’s target. It is informative when the rows represent matched entities, but can become degenerate when the null preserves the same row structure as the real table. The archive explicitly rejects a correspondence-shuffle null in the homogeneity run because it was degenerate for that construction. This is a general lesson: a named “shuffle” is not automatically a valid control; its induced object must be inspected.

**Token shuffle.** Shuffling words within a fragment tests sensitivity to order while preserving much of the lexical inventory. An unconstrained shuffle can alter the final token and collapse the intervention magnitude, making its reconstruction look artificially good. Final-token-preserving shuffles are a fairer local control. The full-vocabulary content study used body shuffles and found a large recovery collapse, while the aggregate GNC study reported the magnitude difference explicitly rather than treating the raw shuffled KL as evidence for a stronger low-rank law.

**Random matched-norm directions.** For directional substitution tests, a random vector with the same norm as the fitted direction asks whether the observed gain comes merely from granting the reconstruction one extra degree of freedom. The anti-unigram vector beat this control decisively. For subspace studies, exact-Frobenius-matched random rank-r maps serve the same role: they preserve the total scale of the learned map while destroying its orientation.

**Random equal-size partitions.** When estimating a cluster-specific code, the real clusters and random partitions have the same number of groups, rows, and fitted parameters. A positive real-minus-random asymmetry therefore cannot be explained by per-cluster flexibility alone. This control was decisive in the base-profile second-code study, where real asymmetry was about 0.071 and random asymmetry approximately zero.

These controls also clarify the difference between “artifact” and “nuisance.” A punctuation-heavy first singular direction is not necessarily fake. It can be a real shared component that is uninformative for a particular transfer question. The right response is to match or remove it and state which layer is being measured. The layered map is therefore not a claim that dominant variance is nonexistent; it is a claim that dominant variance and transferable information need not coincide.

## Appendix C. Reproducibility ledger for the central claims

The following compact ledger records the primary numerical anchors used in the synthesis.

| Object and question | Main configuration | Primary result | Interpretation |
|---|---|---|---|
| Natural delta versus controls | 192 contexts, up to 24 probes, selected-token axes, held-out contexts and fragments | GNC advantage about 1.93 ± 0.86 nats at rank 16; held-out text gap about 1.70 ± 0.71 | Real intervention coupling survives scale and text holdout |
| Local fragment steering | 48/16 context split, fixed fragment, 200-token axis | Natural rank-one KL 1.830 ± 0.070 versus final-token-preserving shuffle 1.989 ± 0.032 | One fragment induces a context-invariant direction with context-dependent gain |
| Anti-unigram identity | 8 seeds, selected-token substitution | Recovered correction fraction 0.991 on held-out contexts and 1.003 on held-out fragments; cosine 0.987 | Empirical correction axis is the centered negative base profile |
| Full-vocabulary content law | 50,304 tokens, 4–8 seeds | Two-term minus standalone recovery +0.226 and +0.206; cosine 0.982 | Direction law extends to full vocabulary |
| Full-vocabulary magnitude boundary | Same full-vocabulary object | Per-context ceiling exceeds two-global-constant model by about 0.10 | Coefficients remain context-sensitive |
| Shared context code | 96/32 contexts, six probes, full vocabulary, eight seeds | Ceiling-corrected predictive rank four in all seeds | Orthogonal context code is low-rank predictively |
| Descriptive/predictive dissociation | Same full-vocabulary study | Effective rank 36.3 at K=256 and 49.3 at full vocabulary; predictive rank four | Spectrum overstates predictive dimensionality |
| Context-axis second code | Base-profile clusters, rank eight | Real-minus-random asymmetry about 0.072, lower CI 0.048 | Some ceiling headroom is conditionally organized |
| Fragment-anchored residual | Full vocabulary, held-out fragments | Within-minus-across cosine 0.3555 [0.3189, 0.4010] versus shuffled null about 0.0055 | Residual direction retains fragment identity |
| Axis comparison | Matched 16/16 rows, 8,192 features | Raw probe score 0.65 versus context 0.37; matched margins 0.05 versus 0.25 | Raw and matched readouts can reverse ordering |
| Homogeneity vulnerability test | 64/32 contexts, six probes, K=256, eight seeds | `Delta g` 0.0931 [0.0366, 0.1446] | Variance-transfer relation is context-set dependent |

The table is not a meta-analysis in the statistical sense. The studies use different token universes, fragment families, row counts, and metrics. It is a traceability aid showing which quantitative anchors support which layer of the integrated story.

## Appendix D. Why the apparent contradictions are informative

Several archived papers initially appear incompatible. One reports a universal interaction subspace; another reports semantic fragmentation. One reports that full-vocabulary content residuals are diffuse; another reports a rank-four full-vocabulary context code. One says the probe axis has little structure; another finds a low-rank fragment-direction subspace. These are not all reconciled by saying “the model does everything.” They are reconciled by identifying the changed object.

The universal interaction result uses a double-centered, target-conditioned residual and an angular or subspace-transfer metric. The fragmentation results use pairwise angles between residual subspaces, often split by lexical target or semantic domain. The two can coexist if a common scaffold is shared within a target class while secondary dimensions diffuse by semantic domain. The full-vocabulary diffuse result concerns the content-channel residual after the standalone and anti-unigram directions have been removed. The rank-four result concerns the orthogonal cross-context code and uses a ceiling-corrected predictive rank. These channels are not interchangeable.

Likewise, the probe-axis reversal is not a disagreement about arithmetic. The probe table contains a large shared component, so a raw SVD captures a lot even when row correspondence is destroyed. The matched null estimates that shared floor and leaves a smaller but positive residual. The correct scientific statement is therefore not “the probe axis is low-rank” or “the probe axis is not low-rank,” but “the probe-axis table has a large common component and a smaller transferable component, while the context-axis table has a larger matched-control margin.”

The homogeneity result adds a further layer. The same definition of `v1` and `v2` yields a negative `g` in broad context samples and a near-zero `g` in a tight base-logit neighborhood. This does not invalidate the earlier heterogeneous result; it scopes it. A singular direction’s transferability is a property of a table assembled from a distribution of contexts, not only of the model and token axis. The archive’s most general lesson is therefore conditionality: before asking whether a matrix is low-rank, ask low-rank for which rows, columns, transform, baseline, and transfer target?

## Appendix E. Boundaries and open questions

The evidence leaves several productive questions open. The first is cross-model generality. The archive uses one model, OLMo-1B, so it cannot determine whether anti-unigram correction, rank-four context codes, target-vocabulary manifolds, or additive combinatorial residuals are architectural invariants or properties of this model and corpus.

The second is mechanistic localization. Every conclusion here is made in output-logit space. A transferable direction may be generated by many internal pathways. The rank-four bilinear operator is a predictive map from isolated priors, not an identified circuit. The grammatical target manifolds are geometric destinations, not named heads. White-box layerwise experiments would be needed to connect these output-space factors to internal computations.

The third is the continuum-versus-clusters question. Base-profile clustering organizes part of the context-code headroom, but the archive cannot distinguish discrete context types from a smooth manifold sampled and then discretized. Similarly, target-vocabulary manifolds may have fuzzy boundaries between lexical classes. The present results establish conditional transfer asymmetries, not a final ontology of context or target types.

The fourth is the tail of the distribution. Full-vocabulary KL emphasizes high-probability tokens. The content direction survives the full vocabulary and divergence is concentrated in a few hundred tokens, but the diffuse tail is not irrelevant for every question. Alternative tail-sensitive metrics could reveal additional structure while also increasing variance. The archive’s discipline suggests reporting both probability-weighted predictive quantities and scale-matched geometric quantities when the scientific claim concerns different parts of the vocabulary.

The fifth is the homogeneity operationalization. The vulnerability test used a tightest cosine nearest-neighborhood of full-vocabulary base logits. It passed a strong manipulation check and the preregistered revise criterion, but other operationalizations—different token universes, cluster rules, or entropy-matched sets—could change the magnitude of the contrast. The appropriate next test is a single preregistered re-operationalization, not an unconstrained search over many neighborhoods.
