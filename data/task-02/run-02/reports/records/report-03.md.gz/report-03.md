# Low-Rank Structure in Language-Model Logit Tables: From Marginal Profiles to Compositional Interaction Geometry

## Abstract

The claim that language has low-dimensional predictive structure is meaningful only after the numerical object, transform, control, and validation target have been specified. We synthesize the completed black-box experiments in the local research record for OLMo-1B, using final-position next-token logits arranged as several distinct tables. The evidence supports a qualified but coherent answer. A row-centered prompt-by-token snapshot table contains a small, reproducible set of dimensions that generalize to held-out contexts relative to a strict marginal-preserving column-permutation floor. The same table looks *higher* rank than token-shuffled or random-token inputs, however, because incoherent inputs induce a high-entropy, highly collinear fallback. Snapshot geometry is stable across seeds but is aligned chiefly with token frequency and surface format; a purported entropy-independent coherence channel is localized to column means, especially leading-space format columns, and disappears under column- or double-centering.

The strongest evidence for nontrivial interaction structure comes from tables that encode changes rather than absolute snapshots. Context-influence differences, composed context-effect tables, and logit-difference (Δ) matrices all support held-out prediction or reconstruction beyond controls that preserve marginals while destroying row-column alignment. A rank-8 crossed bridge predicts a fully held-out context-by-probe quadrant with relative error 0.487 versus 1.059 for an alignment-destroying control; the advantage survives context-token residualization, post-residualization shuffling, row normalization, and naturalness controls. For Δ matrices, the raw rank-1 component is a context-independent unigram shift, but column-centering exposes a residual whose low-rank basis generalizes to unseen contexts, remains superior when the token set is doubled, and explains roughly 17--39% of held-out KL at low ranks while a centered marginal null explains nearly none. Probe averaging concentrates genuine shared structure only after the same profile direction is removed from both signal and variance-matched control.

Dynamic trajectory tables add the temporal dimension. The rank-complexity gap between natural and token-shuffled text peaks when a probe grammatically binds to its context, shifts when the binding location is shifted, and then persists as a target-centered covariance subspace. After rigorous column-centering, natural intermediate updates project more strongly than corrupted updates onto the centered terminal subspace at post-binding steps in all 10 seed-step comparisons. Other analyses divide the dynamics into a fast, syntax-sensitive component and a slower semantic component: the fast residual is approximately orthogonal to the semantic integration subspace, while content-token geometry is comparatively path-invariant and format-token geometry carries most word-order dependence. Severe out-of-distribution noise broadens rather than tightens the update spectrum, and layer-wise evidence places this shattering boundary in late layers.

Taken together, the evidence answers the task’s central question by separating three phenomena. Marginal-profile structure is real but easily mistaken for interaction. Context-induced and compositional residuals contain a smaller, predictive interaction budget that survives matched controls and held-out tests. Autoregressive composition activates that budget at a temporally localized binding transition, after which a persistent semantic manifold constrains subsequent updates. The defensible conclusion is therefore not that “language is low-rank,” but that particular logit-table arrangements—especially profile-deflated context-effect and compositional-difference tables—exhibit reproducible low-dimensional predictive geometry, whereas snapshot rank depends strongly on centering and on the chosen null.

## 1. Introduction: low-rankness is a property of an experimental object

Language-model logits are often discussed as if they were a single observable: given a text, the model returns a vector over the vocabulary, and one asks whether those vectors “live in a low-dimensional space.” That formulation conceals the central methodological issue. A collection of next-token logits is not yet a matrix with a unique scientific meaning. One must decide what constitutes a row, what constitutes a column, whether the entries are absolute logits or changes in logits, which tokens are retained, and which nuisance components are removed. Different choices ask different questions and can produce opposite answers without any contradiction.

The research program was designed to test this issue directly using only black-box final-position logits from OLMo-1B. It required at least three candidate tables, explicit low-rank metrics, reconstruction or prediction tests, controls, ablations, and held-out validation. The completed studies collectively implement a much richer design than a single singular-value plot. They compare absolute prompt-by-token snapshots with context-induced differences, composed context--probe tables, and position-wise autoregressive trajectories. They use row-centering, column-centering, double-centering, explicit rank-1 profile projection, balanced token unions, and several marginal-preserving and incoherence controls. They also test whether learned subspaces transfer to unseen contexts, unseen probe blocks, later positions, or new random seeds.

The central question can consequently be stated more precisely:

> When next-token logits are arranged into matrices or related numerical tables, which arrangements show evidence of nontrivial low-rank structure, and which controls distinguish that evidence from a trivial artifact?

Our synthesis has four claims.

First, a row-centered prompt-by-token snapshot table has genuine cross-row/column structure relative to a strict column-permutation floor. The evidence is not merely that its singular values decay: its effective dimension remains sublinear as the matrix grows, its right-singular subspace is reproducible across seeds, and a train-fitted rank-8 basis reconstructs held-out contexts better than the matched-marginal floor. Yet the same snapshot can appear less low-rank than scrambled text, because scrambling drives the model into a collinear fallback. “Natural text is lower rank than random text” is therefore the wrong universal test.

Second, the most reliable interaction signal appears after differencing and deflation. Context-influence tables measure how a context changes predictions for a fixed probe or target; compositional Δ tables measure how a probe changes the prediction state established by a context. These tables support crossed transfer and held-out KL recovery beyond controls that preserve one-dimensional token marginals. Their raw leading component is often a unigram or column-profile direction. Once that profile is removed identically from natural data and controls, a residual low-rank component remains and predicts unseen data.

Third, the interaction signal is temporally organized. In trajectory tables, grammatical binding is marked by a transient increase in rank complexity relative to a bag-of-words control. The location of the peak moves with the probe’s binding structure, and a centered covariance subspace learned at the peak continues to constrain later updates. Thus the model’s predictive geometry is neither a static snapshot nor a sequence of arbitrary independent updates.

Fourth, the geometry has a coarse division of labor. Snapshot dimensions are largely frequency- and format-aligned; semantic content is more evident in compositional Δ updates and in the slower trajectory component. A low-rank interaction head is predictive beyond the context’s topic geometry, sharing only about one third of its subspace while adding topic-orthogonal predictive information. At the vocabulary level, content columns remain relatively invariant to global word-order scrambling, whereas format columns carry most of the path dependence.

These conclusions are deliberately scoped to the tested OLMo-1B model, final unembedding logits, sampled Wikipedia fragments, selected-token tables, and the stated metrics. They do not establish a universal rank for language or identify every singular direction with a human-interpretable linguistic factor. They do establish a reproducible experimental map of where low-dimensional predictive structure is visible, where it is a marginal artifact, and how it emerges during composition.

## 2. Experimental vocabulary and common design principles

### 2.1 Four table families

The studies use four related but non-equivalent objects.

1. **Prompt-by-token snapshot table.** Each row is a context fragment (c_i), each column is a selected token (t_j), and the entry is the final-position logit ℓ(t_j | c_i). The primary transform is row-centering, subtracting the mean across selected tokens for each context. Row-centering removes a context-wide additive offset, which is invisible to softmax probabilities, while preserving differences among token columns.

2. **Context-influence difference table.** A context is placed before a shared probe (p), and the entry is a target-token update, typically Δℓ_{ij} = ℓ(t_j | c_i ⊕ p) − ℓ(t_j | p). In probe-averaged variants, several probes are averaged for each context and fixed token. This table asks how a context changes a common prediction state rather than what the model predicts from the context in isolation.

3. **Composed context-effect table.** Contexts and probe fragments form a two-axis experiment. For each context and probe, the table records a vector of context-induced logit perturbations. Flattening probe-token pairs gives a context-by-column matrix, while a crossed construction partitions it into train-context/train-probe, train-context/held-out-probe, held-out-context/train-probe, and held-out-context/held-out-probe quadrants. A bilinear rank-(r) bridge is fitted only on the first quadrant and predicts the fourth.

4. **Trajectory table.** A context is combined with progressively longer probe prefixes. Position-wise updates compare the model’s logits at step (m) with a baseline at the same probe position or with the previous position. These tables ask when a low-dimensional state is established and whether it persists as the sequence continues.

The distinction matters algebraically. A snapshot contains both marginal token preferences and context-dependent interactions. A difference table cancels a baseline but can introduce a different unigram confound. A crossed table tests whether context factors and probe factors combine consistently, which is stronger than compressing rows over a fixed column set. A trajectory table adds ordering and temporal binding, allowing a test of path dependence.

### 2.2 Token selection, transforms, and metrics

The primary experiments operate within the task’s intended scale: approximately 32--256 fragments, 20--200 selected tokens, and fragment lengths no longer than 64 tokens. Token columns are selected by several documented rules: top-magnitude or top-mean logits, fixed frequent-token sets, frequency-fixed sets independent of the evaluated logits, balanced unions of natural and corrupted top tokens, and random eligible subsets. Results that survive these choices are treated as stronger than results tied to a single dynamic selection rule.

Low-rankness is quantified in complementary ways. Singular-value spectra and spectral-entropy effective rank summarize concentration but are bounded by matrix dimensions and can be dominated by a single profile. Marchenko--Pastur significant rank provides a calibrated reference against an iid spectral floor, though it is treated as a diagnostic because centering violates iid assumptions. Rank-(r) reconstruction error measures how well a learned subspace recovers held-out logit tables. When probabilities are required, reconstructions are un-centered before softmax and evaluated with selected-token KL. For compositional updates, the preferred metric is Fraction of KL Explained, (1 - KL_r/KL_0), which compares the fraction of the condition’s own distributional change captured by a rank-(r) approximation rather than comparing absolute KL values across conditions with different baseline entropy.

### 2.3 Why two control families are necessary

The studies repeatedly distinguish a **marginal-preserving structural null** from an **incoherence null**. In the structural null, entries within each token column are independently permuted across rows. Each column’s empirical distribution, mean, variance, and often its higher-order marginal properties are preserved, but row-column dependencies are destroyed. This is the appropriate control for the question “does the table contain joint structure beyond token marginals?”

In an incoherence null, tokens or words are shuffled within fragments, globally rearranged, or replaced by random eligible tokens. These controls destroy local order and often move the input off the model’s training distribution. They are useful for measuring sensitivity to coherence and fallback behavior, but they are not neutral structure nulls. The model responds to incoherent input by producing higher-entropy, more mutually similar output distributions. Such outputs can be very low-rank for a trivial reason. A natural-versus-scrambled comparison therefore conflates the loss of structure with a collapse into a common fallback.

The distinction is not semantic bookkeeping. In the same row-centered snapshot arrangement, real text has roughly 4--7 Marchenko--Pastur-significant dimensions for context counts from 64 to 192, compared with roughly 1--2 for a column-permutation floor. Yet real text has effective rank around 14.4 in one (N=64) setting, while incoherence controls have effective ranks around 3--5. Mean pairwise row cosine is approximately 0.23 for real text but 0.65--0.75 for shuffled or random-token inputs. The scrambled matrix is more compressible because its rows point toward the same fallback, not because it preserves a richer linguistic representation.

### 2.4 Centering as a scientific choice

Three centering operations recur. Row-centering removes each row’s mean and is natural when one wants softmax-relevant within-row contrasts. Column-centering removes each token’s across-context mean and therefore removes a context-independent token profile. Double-centering removes both, retaining only row-by-column interaction. Explicit rank-1 profile projection is used when a known unigram direction must be removed from both signal and control without otherwise changing the geometry.

The experiments show that these are not interchangeable preprocessing details. Row-centering exposes a marginal-profile channel associated with local contiguity and format tokens. Column-centering can eliminate that channel while revealing context-dependent compositional residuals. Applying the wrong transform can reverse a conclusion, as happened first with raw Δ matrices and later with a variance-matched probe-averaging control. The paper therefore treats centering as part of the definition of the measured object, not as a generic normalization step.

## 3. Snapshot tables: genuine structure, misleading controls

### 3.1 The primary snapshot result

The first major line of evidence comes from the simplest candidate: a context-by-token table of final-position logits. In the main formulation, 64--192 contexts are split into training and held-out fragments, and 20, 50, 100, or 200 token columns are selected. The table is row-centered and compared with a per-column independent shuffle. This design tests whether the arrangement of token values across contexts contains joint structure that cannot be explained by the token-wise marginals alone.

The answer is yes within this scope. For context counts (N in {64,128,192}), the real table has approximately 4--7 Marchenko--Pastur-significant dimensions, while the column-permutation floor has approximately 1--2. The effective-rank growth is sublinear as the matrix grows, and the real slope is well below the shuffled-null slope in the companion context-influence analyses. More importantly, a rank-8 basis estimated on training contexts reconstructs held-out contexts with a positive advantage over the permutation floor: relative-Frobenius gaps are approximately 0.26--0.39, positive in every fresh seed in the primary cell and in 8 of 9 non-degenerate combinations of centering and token-selection rules. The preregistered fresh-seed study preserved the result at every tested token dimension (K in {20,50,100,200}). The primary row-centered/top-magnitude cell passed all four preregistered predictions on five fresh seeds: real significant rank exceeded the floor, held-out rank-8 gap was positive, real row cosine was lower than every incoherence control, and the expected effective-rank ordering held.

This is already stronger than the statement “the singular values decay.” A finite matrix always has at most (min(N,K)) nonzero singular values, and a shared offset can make any matrix appear concentrated. Here the evidence combines a marginal-preserving null, a scale-aware dimensionality measure, and out-of-sample reconstruction. The result is best described as a small, reproducible cross-row/column component in the row-centered snapshot table.

### 3.2 The control flip and fallback collapse

The same snapshot table produces an apparently opposite result when compared with token-shuffled, globally shuffled, or random-token contexts. These incoherence conditions have lower effective rank than natural text. At first glance this seems to refute the low-rank claim: if random inputs are easier to reconstruct, perhaps natural language is the high-dimensional condition. The experiments resolve the paradox through direct diagnostics of the output distributions.

Incoherent inputs produce high-entropy fallback behavior. Their logit rows become strongly collinear, with mean pairwise row cosine around 0.65--0.75, compared with roughly 0.23 for natural contexts. The model is no longer representing a diverse set of context-conditioned predictions; it is returning similar, diffuse distributions for many off-distribution inputs. A low-dimensional fallback is therefore expected. The lower rank of a scrambled table is not evidence that scrambling reveals a latent linguistic basis. It is evidence that the model has lost context-specific organization.

The control flip is a central scientific result because it specifies what each comparison can and cannot establish. A column-permutation floor asks whether natural rows retain joint dependencies beyond token marginals. An incoherence null asks how the model’s geometry changes when local order and lexical coherence are destroyed. Natural text can pass the first test and fail the second without inconsistency. Indeed, the effective-rank ordering in the experiments is approximately global shuffle < within-fragment shuffle < random-token < real text < column permutation, while the held-out structural gap remains positive for real text. Reporting only the natural-versus-scrambled ordering would therefore produce the wrong qualitative conclusion.

### 3.3 Reproducible but non-semantic snapshot geometry

A second question is what the snapshot subspace encodes. On a frequency-fixed token axis selected independently of the evaluated logits, the right-singular subspace is highly reproducible across random seeds. For (K=200), cross-seed overlap is approximately 0.972, 0.818, and 0.776 for the leading 2, 4, and 8 dimensions, respectively. The corresponding overlap is much lower for column-permutation controls (about 0.49, 0.27, and 0.18) and matched Gaussian controls (about 0.04--0.13). The stability survives removing the frequency axis, so it is not merely the result of selecting columns by token frequency.

Reproducibility does not imply semantic interpretability. Regression of the leading snapshot components associates them with log token frequency, while the second component is strongly aligned with leading-token format or space markers and token length. Context-axis associations are weak. The snapshot basis is therefore a stable coordinate system for how the model distributes mass over the vocabulary, but it is not obviously a semantic concept basis. This distinction becomes important when the same vocabulary is used in Δ tables, where the leading directions are instead enriched for content words and subword continuation patterns.

The studies also find only partial overlap between snapshot and context-effect arrangements. Within a seed, left-singular overlap between a snapshot table and a transfer table is modest but reliably above nulls. This is consistent with a shared output interface without implying that the same dimensions encode the same quantity. The arrangement determines whether a stable frequency/format profile or a context-dependent interaction is being measured.

### 3.4 The direct fallback channel is a column-mean effect

One particularly instructive snapshot result concerns the apparent “direct” coherence channel that remains after controlling effective rank for predictive entropy. A graded corruption design distinguishes random-token replacement, within-fragment shuffling, local (n)-gram shuffling, and chunk transposition. Chunk transposition preserves contiguous chunks while disrupting global order; local shuffles destroy short-range order more aggressively. Under row-centering, chunk transposition retains a stronger entropy-controlled association with effective rank than local shuffles: held-out partial correlations are approximately 0.82 for chunk size 3, 0.81 for chunk size 5, 0.73 for local (n)-gram width 2, 0.67 for full within-fragment shuffling, 0.62 for width 5, and only 0.14 for random-token replacement, whose confidence interval includes zero.

The initial interpretation was that this residual channel might be a syntax-sensitive interaction. A centering decomposition on identical cached logits changes that interpretation. Column-centering and double-centering specifically suppress the chunk channel: the held-out chunk partial-correlation drop from row- to double-centering is approximately 0.45, whereas the corresponding drop for local and within-shuffle families is near zero. Residualizing a single per-row mean does not selectively remove the chunk effect, so the carrier is not one scalar output-strength variable. The channel is distributed across token columns as a per-token marginal profile.

Carrier localization shows that this profile is non-uniform. The Gini concentration of chunk-carrier contributions across column groups is approximately 0.63, compared with 0.14 for local and within-shuffle families. Leading-space format columns account for the largest chunk drop, approximately 0.29 in the held-out analysis, while the high-frequency group contributes little or even a negative drop. The same format columns also affect the local and within families, so this is not a chunk-unique token set. The defensible claim is that local contiguity shifts a non-uniform format-sensitive token prior, and row-centering turns that marginal shift into apparent rank structure. It is not evidence, by itself, for a context-differentiating syntactic code.

This deflationary result is methodologically positive. It prevents an over-interpretation of the snapshot table and directs the search for genuine interaction structure toward tables that subtract or project out the marginal profile.

## 4. Context-influence tables: differencing exposes a predictive interaction budget

### 4.1 Why context-induced differences are a better target

The context-influence construction asks a causal question in the operational sense: how does adding a context change the logits associated with a shared probe or target? For fixed token columns, the entry is Δℓ(t | c, p) = ℓ(t | c ⊕ p) − ℓ(t | p). Probe-averaged variants average this change across several probes, while composed context-effect tables retain the probe axis and test transfer across it.

Differencing removes a large part of the probe’s baseline distribution and aligns all rows to a common reference. It does not automatically solve the problem: the raw leading direction can still be a context-independent unigram shift, and averaging can create a variance artifact. The contribution of these studies is to identify those confounds explicitly and to validate the residual with controls that preserve the same marginals.

### 4.2 Intrinsic-dimension scaling and the unigram decomposition

The first context-influence studies introduce an intrinsic-dimension scaling test. Rather than declaring a single (N 	imes K) table “low rank,” they track spectral-entropy effective rank as (N) and (K) grow and compare its slope with a per-column-shuffle null. The real table’s effective-rank slope is approximately 0.23--0.41 times the null slope across fresh held-out seeds. This plateau-like behavior indicates that increasing the table size adds less independent variation than the structural null would predict.

The singular-vector decomposition identifies the main nuisance component. The dominant raw direction correlates at least 0.95 with the per-token mean-logit profile across contexts. This is a rank-1 unigram or scale component: it can be stable, large, and predictive of marginal token behavior without representing context-specific structure. The genuine context-dependent signal lies in the residual after this profile is removed. Differencing, rather than centering alone, is what creates the useful context-influence object; simply row-centering an absolute snapshot does not answer the same question.

Held-out evaluations confirm that the learned context-influence subspace transfers to unseen contexts and, when fixed token identities are retained, to new probes. The result is not a claim that every singular direction is meaningful. It is a claim that the *growth law* and held-out behavior of the residualized difference table are inconsistent with a column-wise independent null.

### 4.3 Probe averaging and the two-sided confound

Averaging over more probes lowers effective rank. At (N=128) and (K=128), mean effective rank falls from approximately 4.96 at four probes to 3.78 at 32 probes, while the 70%-variance rank falls from about 1.75 to 1.25. The intrinsic-dimension plateau remains in all tested seed--probe cells. This suggests that averaging denoises a shared component, but a simpler explanation is possible: averaging independent tables reduces variance by roughly (1/P) and can make any matrix appear more concentrated.

The decisive control independently shuffles each column of each single-probe table before averaging, matching the variance reduction while destroying cross-probe alignment. In the naive comparison, this control is as low rank as or lower rank than the real average in every exploratory seed. A superficial conclusion would be that probe concentration is trivial. That conclusion is wrong because the column shuffle preserves the per-token profile. Averaging profile-preserving shuffled columns collapses the control toward the same rank-1 direction that inflates the signal.

Explicitly projecting out the profile from both real and control reverses the result. At 32 probes, the real deflated table has effective rank approximately 12--13, while the deflated variance-matched control has effective rank approximately 64--66, a control-minus-real margin around 52 in every exploratory seed. The top-component correlation with the raw profile falls from about 0.996 to 0.08--0.42 after projection. Double-centering gives the same relative verdict, although it leaves more residual profile correlation (roughly 0.67--0.78), so explicit projection is the cleaner primary operation.

The preregistered fresh-seed confirmation uses five new seeds and a 96/32 train/held-out context split. All three predictions pass in all five seeds: the effective-rank margin at (P=32) has mean 50.56 with a 95% confidence interval [49.03, 52.09]; post-deflation profile correlations are 0.07--0.17; and held-out rank-4 reconstruction-error margin is 0.281 with 95% confidence interval [0.208, 0.354]. Thus probe averaging reveals genuine shared cross-probe structure, but only after the profile direction is controlled identically on both sides. This is a general warning: a control can be correctly variance-matched and still be invalid if it preserves a nuisance direction that the operation itself amplifies.

## 5. Crossed context--probe transfer: beyond row compression

### 5.1 The crossed bridge

The strongest direct test of compositional table structure uses a four-quadrant design. Let (A) be train contexts by train probe-token columns, (B) train contexts by held-out probe columns, (C) held-out contexts by train probe columns, and (D) held-out contexts by held-out probe columns. A rank-(r) SVD is fitted only on (A). The learned context and probe factors are then combined to predict (D), which shares neither the contexts nor the probe-token columns used for fitting. This is a stronger test than held-out-row reconstruction because it requires the two axes to compose consistently.

In the main settings there are 64 contexts, 16 probes, 64 selected tokens, a 48/16 context split, two 12/4 probe splits per seed, and rank 8. The primary control independently shuffles rows within each probe block, preserving many per-probe/token marginals while destroying the fact that the same context identity aligns across probes.

### 5.2 Quantitative transfer result

The initial held-out-row pilot already favors natural context effects: mean rank-8 error is 0.7145 for natural data versus 0.8985 for the blockwise control across three seeds. The crossed test is substantially stronger. Natural data predict the fully held-out quadrant with mean relative-Frobenius error 0.4871, compared with 1.0593 for the alignment-destroying control, a natural/control ratio of 0.4606 with standard deviation 0.0608 across six seed/split units. Selected-token KL is also lower for rank-8 prediction, averaging 0.0696 versus 0.3762 for a zero-residual held-out-probe baseline.

The result survives mechanistic stress tests. Subtracting each context’s token-specific mean effect across observed probes reduces the advantage but does not remove it: residualized natural error averages 0.6559 versus 1.0683 for the control, ratio 0.6151. Applying the control *after* residualization and centering yields 0.7075 versus 1.0857 across all six units. Row-unit normalization preserves the advantage with mean ratio 0.6889, reducing the possibility that the bridge exploits only row norms or overall response strength.

These comparisons establish a residual probe-dependent component beyond a simple additive context-token bias. The non-residualized result is stronger, so shared context-token effects explain part of the signal. But the post-residualization and row-normalized results demonstrate that the remaining signal is not a bookkeeping artifact of how residual means were estimated.

### 5.3 Naturalness is graded, not binary

Token- and word-level corruption controls refine the interpretation. Natural contexts have mean rank-8 error 0.7075 and condition/control ratio 0.6784 in the token corruption study. Within-fragment token shuffles yield error 0.9211 and ratio 0.8892; global token salad gives 0.9087 and 0.8673; random eligible-token prefixes give 0.9644 and 0.9204. Natural contexts win in all six units. Word-level corruption reproduces the ordering: natural error 0.7075 and ratio 0.6711, versus 0.9119/0.8761 for within-fragment word shuffles, 0.9264/0.8826 for global word salad, and 0.8802/0.8493 for the token-within-fragment bridge.

The correct interpretation is graded. Generic prefixes can produce some crossed low-rank structure, because any prefix changes the model’s state in a structured way. Natural order and co-occurrence strengthen the shared transfer, but the result does not isolate syntax from semantics, topic, or lexical overlap. The crossed bridge therefore supports a shared bicompositional geometry, not a uniquely syntactic or human-interpretable factorization.

## 6. Compositional Δ matrices: removing the rank-1 confound

### 6.1 The absolute-KL paradox

A complementary arrangement compares a context alone with the same context followed by an intervention probe. The total update is

\[
\Delta = 	ext{logits}(c \mathbin{\|} p) - 	ext{logits}(c).
\]

Early absolute-composed tables seem favorable to natural text in relative Frobenius error: one pilot reports rank-16 errors 0.039 for natural composition versus 0.048 for a token-shuffled control. Yet natural text has much larger absolute KL divergence (0.049 versus 0.013), and the raw Δ table has effective rank 1.87 for natural data versus 9.78 for corrupted data while the rank-0 KL baselines differ by 4.20 versus 1.71. Absolute KL therefore mixes “how large is the update?” with “how efficiently is the update represented?”

The remedy is a balanced token union and a relative metric. For each intervention block, selected columns are the union of the top (k/2) natural and top (k/2) corrupted tokens, so neither condition receives an easier vocabulary. Fraction of KL Explained compares rank-(r) residual KL with the condition’s own rank-0 KL. This is the appropriate predictive metric when natural and corrupted interventions have different baseline entropy and update magnitude.

### 6.2 Centered natural updates beat the structural null

The raw Δ matrix contains a context-independent unigram shift. Against a marginal-preserving null that independently permutes entries within each token column, raw natural updates beat the null at ranks 2 and 4 but fail consistently at rank 1. The leading direction is therefore not coherent composition; it is the same kind of token-profile component identified in context-influence and snapshot tables.

Column-centering resolves the issue. The centered natural Δ strictly outperforms the centered null at ranks 1, 2, and 4 across all tested seeds. In held-out projection, a basis learned from natural training contexts explains substantially more unseen update KL at low ranks—approximately 17--39% in the reported range—while a basis learned from the centered null explains nearly zero. The superiority remains when the balanced token union is doubled from (k=10) per block to (k=20), producing (K=1280) total columns; rank-1 natural beats centered-null comparisons in all three seeds.

This result is stronger than an effective-rank difference because the basis is learned on one set of contexts and evaluated on another. It identifies a generalizing context-dependent compositional residual, not merely a compact fit to the training matrix. The top-loading tokens of the first natural Δ component include semantic content words such as “molecule,” “enzymes,” and “resemblance,” mixed with subword continuation artifacts. The evidence therefore supports low-dimensional compositional steering, but not a clean abstract syntax vector. Semantic content and vocabulary-specific structure are intertwined in the output coordinates.

### 6.3 Temporal bounding after grammatical binding

The Δ analysis extends naturally to autoregressive trajectories. Incremental updates at steps (l) are column-centered, and a terminal subspace is learned from the centered total update. At step 1, natural and corrupted updates are equally poorly bounded by the terminal basis. At steps 2 and 3, after grammatical binding begins, natural updates project more strongly than corrupted updates. Across five preregistered seeds, natural terminal capture is higher in all 10 seed-step comparisons.

This is the dynamic counterpart of the static centering result. The semantic or compositional residual is not a rank-1 drift that appears everywhere. It becomes geometrically constraining after the sequence has supplied enough local structure for binding. The terminal basis is therefore a meaningful target only after the initial, weakly constrained update.

## 7. Trajectories: the coherence ladder is temporal

### 7.1 Rank complexity peaks at binding

Position-wise trajectory tables reveal why natural text can be higher rank than shuffled text. The true context induces a rich, order-sensitive update at the point where a probe binds grammatically to the preceding context. Token-shuffled contexts instead produce a more compressible fallback or a less specific update.

For immediate-syntax probes, the natural-minus-shuffled complexity gap rises from the first position, peaks decisively at position 2, and then decays as the probe suffix increasingly determines local statistics. Tripling the absolute token selection size leaves the peak and positive gaps intact. When the probe family is changed to delayed binding, the peak shifts to position 1. The peak therefore follows the grammatical location of the dependency rather than a fixed token depth.

### 7.2 Target-centered persistence

Projecting later steps onto the raw peak basis initially fails because each position has its own mean shift. After target-centering each step, the covariance subspace learned at the peak transfers to all subsequent steps. The positive natural-versus-shuffled complexity gap persists for both immediate and delayed-binding probe families and on held-out sets. A large-scale fresh-seed replication reports (p \approx 3.05 	imes 10^{-5}).

The interpretation is not that syntax creates a permanently high-rank state. Rather, grammatical binding establishes a covariance manifold: subsequent updates vary within a constrained geometry whose origin is the binding event. The manifold can be low-dimensional as a predictive object while still having higher rank than the fallback control because it contains precise, context-specific variation. This reconciles the static coherence ladder with the centered-Δ result: natural composition is more structured, not simply more compressed.

### 7.3 Fast and slow components

Several trajectory studies decompose the update into a fast syntactic residual and a slower semantic integration component. The fast residual is approximately orthogonal to the semantic subspace and transfers poorly across contexts, while the slow component is more persistent and carries generalizable information. A fast-slow orthogonality result therefore explains why high-variance early updates need not be good semantic predictors.

The distinction is visible in vocabulary-space path dependence. Under global word-order scrambling, subspace intersection remains high for content-token columns (about 0.839) but drops for format-token columns (about 0.750), a difference of 0.089 with (p=0.00098) across 10 seeds. Content vocabulary behaves like a sequence-invariant bag-of-words topic, whereas format and structural vocabulary carries local order and syntactic path dependence. This is consistent with snapshot carrier localization and with the trajectory finding that binding-sensitive variation is not uniformly distributed across tokens.

This vocabulary-localized result should not be confused with the stronger and more global claim that semantic integration is path-invariant. A separate intrinsic-dimensionality and path-dependence analysis found that the time-averaged semantic state can itself change under word-order perturbation, and that semantic integration is dynamically stratified rather than a literal bag-of-words accumulator. The defensible synthesis is narrower: in the final-token, frequency-matched comparison, content columns retain substantially more subspace overlap under scrambling than format columns, while other trajectory arrangements reveal path-dependent semantic rebinding. The vocabulary axis therefore localizes one major source of path dependence without making “content” synonymous with an everywhere path-independent semantic state.

### 7.4 Orthogonal shocks and nonlinear repair

The milestone trajectory studies sharpen the fast component beyond a generic “high-variance residual.” In garden-path sequences, the pre-disambiguation state contains a superposition of parses. The disambiguating update remains predictive of the terminal resolution even after the top 32 principal components of the pre-shock state are removed. The corrective update is therefore not merely a reweighting of already accumulated semantic directions; it injects novel geometry approximately orthogonal to the pre-shock state. In unambiguous controls, removing the pre-shock dimensions is more damaging, producing a double dissociation between continuous semantic accumulation and discrete syntactic correction.

The geometry of this correction is also nonlinear. In a 10-seed, five-fold nested cross-validation study, a radial-basis Kernel-PCA bridge predicts the multidimensional corrective shock from the uncorrupted baseline better than a linear PCA bridge on coherent contexts: the mean nonlinear advantage is 0.0189. Under word-order scrambling, the advantage collapses to 0.0008; the paired coherent-minus-scrambled difference has (p \approx 2.5 	imes 10^{-7}). A related paired-probe study gives compatible absolute errors: coherent Kernel PCA has mean squared error 0.6227 versus 0.6375 for linear PCA, whereas scrambled Kernel PCA has 0.3034 versus 0.2998 for the linear model. The result identifies a division of labor: a relatively linear semantic background coexists with a localized, curved syntax manifold.

Natural-corpus spectral decomposition gives this division a predictive interpretation. In a composed step-update, the repair condition has lower held-out rank-(r) KL than a normal continuation in all 12 seed/rank comparisons, while both beat row-shuffled nulls. The rank-1 component is a generic structural alignment pivot, with loadings on comparison and alignment terms rather than prefix-specific semantics. The trailing ranks 2--16 carry the specific semantic resumption: predictive KL to the pure well-formed target is 0.390 for the trailing reconstruction versus 0.537 for rank 1, and 0.633 for the matched shuffled null. Thus high overall effective rank does not imply low predictive value. A sharp leading pivot can coexist with a high-entropy tail whose lower-energy directions carry the information needed to resume the long-range topic.

### 7.5 Out-of-distribution noise and the late-layer boundary

The trajectory picture also has a boundary condition. Mild in-distribution word swaps preserve a dominant rank-1 structural alignment pivot and a relatively stable trailing manifold. Severe out-of-distribution noise does the opposite: it broadens the spectrum. In the word-level severity study, normal text has rank-1 fractional variance 0.323 and effective rank 21.03; mild swaps have 0.315 and 21.87; moderate scrambling has 0.281 and 23.54; severe random words have 0.246 and 26.28. The same trend appears with tokenizer-level interventions.

This falsifies the hypothesis that more noise always forces a tighter rank-1 fallback. When random words are embedded inside a rich semantic prefix, the model must map dense, unstructured embeddings into an ongoing trajectory. The resulting update scatters variance across many directions. Pure gibberish with no semantic prefix can collapse to a rank-1 fallback, but embedded OOD noise creates high-dimensional interference.

Layer-wise logit-lens analysis localizes the shattering to late computation. Normal and OOD conditions are nearly indistinguishable through the first 10 layers, with predictive gaps below 0.04. Divergence begins around layer 11, the 95% lower bound crosses 0.05 at layer 13, and the maximum mean target-probability gap reaches 0.293 at layer 15. Normal text executes a coordinated late-layer confidence scaling that raises a target probability from roughly 0.05 to 0.30; OOD noise aborts that scaling. Early layers can therefore accumulate semantic features in superposition, while late layers decide whether local structure permits those features to control the final distribution.

## 8. What the low-rank interaction head encodes

The final synthesis asks whether the generalizing low-rank interaction head is merely a re-expression of context topic or marginal geometry. A dim-8 basis learned from context-influence interaction tables reconstructs held-out next-token distributions with lower selected-token KL than a dim-8 context-only snapshot basis. Across five fresh seeds, the gain of the learned interaction basis over the topic basis is 0.00486 nats, with a t-based confidence interval [0.00382, 0.00589], positive in every seed. Both bases beat matched-dimension random directions, but the interaction head is not reducible to the context’s own topic geometry.

The two subspaces are partially overlapping rather than orthogonal. Principal-angle mean squared cosine is approximately 0.29--0.31, compared with about 0.05 for a random null. Removing the topic-aligned component and adding the interaction head’s topic-orthogonal component still improves held-out KL: the topic-orthogonal gain is 0.00570 nats with confidence interval [0.00436, 0.00705], positive in all five seeds. The interaction head is therefore a partially distinct predictive factor, not a rotation of the topic basis and not an unrelated random direction.

The useful rank is much smaller than the variance rank. In the fixed-token context-influence table, 90% of the L2 energy requires roughly 27 dimensions, but the train-learned interaction basis beats an equal-dimensional random subspace only up to a control-relative information rank near 8 (interpolated estimate 7.77, bootstrap interval [6.75, 9.09]). The matched-rank comparison matters: a held-out reconstruction curve can keep improving simply because additional dimensions fill variance, whereas the random baseline improves for the same reason. The interaction advantage is therefore concentrated in a small predictive head. A composed context--probe pair arrangement independently reproduces the phenomenon with an information rank near 4.49 (bootstrap interval [3.36, 5.57]) against an energy rank near 25, and rank-8 interaction reconstruction beats matched-rank random by 0.150 nats with interval [0.089, 0.210]. The number “8” is consequently a diagnostic- and arrangement-specific useful rank, not an intrinsic dimension of language.

The character of this head depends on the arrangement. In a probe-averaged context-influence table, an oracle per-row temperature absorbs only about 3.6% of its gain, supporting a directional rather than purely scalar interpretation. In a larger-shift composed-pair arrangement, temperature absorbs roughly 59% of the raw gain and the confidence interval includes zero. This contrast is not a failure of the program; it shows that “directional interaction” is a property of the table and regime, not a universal label for every low-rank update.

Unsupervised column clustering provides an independent check on the content/format vocabulary partition. Without lexical labels, two clusters align with the hand-defined partition at adjusted Rand index about 0.077 versus a size-matched null ceiling around 0.011, and normalized mutual information about 0.069 versus 0.012. The effect replicates with a smaller axis and with a column-correlation basis. However, disagreements between the geometric and lexical labels do not show a reliable preference: the observed rank-drop gap of about 0.030 lies inside a broad random-relabeling null from roughly -0.19 to 0.19. The partition is therefore geometrically real at coarse resolution but not a precise token-by-token ontology.

## 9. An integrated model of the evidence

The results can be organized as a sequence of increasingly controlled questions.

### 9.1 What is always present?

Every table begins with a token-dependent marginal profile: some vocabulary columns have systematically different means, scales, and format properties. This profile is visible in raw snapshots, in raw Δ matrices, and in probe-averaging controls. It explains why the top singular vector often correlates above 0.95 with the per-token mean-logit profile, why leading-space columns carry the row-centered fallback channel, and why a marginal-preserving control can itself become artificially low rank after averaging.

The profile is not meaningless. It reflects how the model’s unembedding maps hidden states into vocabulary coordinates. But it is not the same as context-differentiating interaction. Any scientific claim based on the leading direction must either remove it or show that the control contains it in an identical way.

### 9.2 What is snapshot-specific?

The row-centered prompt-by-token snapshot contains a reproducible subspace beyond the column marginals. That subspace is aligned with frequency and surface format, and its effective rank changes smoothly with naturalness. A local-contiguity channel survives entropy control but is carried by column means and disappears under double-centering. This is a robust property of the snapshot arrangement, not a contradiction to the existence of richer compositional structure elsewhere.

### 9.3 What is genuinely interactive?

Context-influence and compositional difference tables isolate changes caused by adding context or probe fragments. After profile deflation, they support crossed prediction, held-out KL recovery, and transfer across contexts and probes. The natural residual beats marginal-preserving nulls at low ranks, and a dim-8 interaction head predicts better than topic-only geometry. These are the strongest grounds for calling a component “nontrivial low-rank structure.”

The interaction is not purely additive. Context-token residualization reduces but does not erase crossed transfer. It is not purely a temperature shift. An oracle temperature absorbs little in the probe-averaged arrangement. It is also not entirely semantic in a human sense: top loadings mix content words, subword fragments, and output-format artifacts. The safe description is a generalizing context-dependent predictive subspace.

### 9.4 When does it become active?

Trajectory experiments locate the activation in time. Before grammatical binding, updates are not yet bounded by the terminal centered subspace. At the binding step, rank complexity peaks and the trajectory enters a persistent covariance manifold. Later updates are constrained by that manifold, while the fast syntactic residual remains partly orthogonal to the slower semantic component. This temporal structure explains why a static “rank of language” is too coarse a question.

### 9.5 Why controls determine the story

The apparently contradictory results are all expected once the controls are named. Real text beats a marginal-preserving shuffle because it has cross-row/column dependencies. Real text can lose to an incoherence null because the null collapses to a collinear fallback. Raw Δ can lose at rank 1 because the unigram profile dominates, yet centered Δ can win at rank 1 because the profile is removed. A variance-matched averaging control can look more concentrated than the signal because it preserves the profile that averaging amplifies, yet the same control becomes high rank after identical deflation. These are not statistical nuisances around one answer; they define which answer the experiment is asking for.

## 10. Methodological lessons for future logit-table studies

The completed work suggests a practical protocol.

First, define the table before inspecting results. State the query family, row and column axes, logit transform, token-selection rule, matrix dimensions, and comparison condition. A “logit table” is not a sufficient methods description.

Second, pair every singular-value claim with a predictive test. Effective rank and Marchenko--Pastur diagnostics are useful summaries, but a train-fitted basis should be evaluated on held-out contexts, probes, or positions. Crossed quadrant prediction is especially informative because it tests both axes simultaneously.

Third, include both a structural null and an incoherence control, but interpret them differently. Column-wise shuffles preserve token marginals and test interaction. Token or word shuffles test the model’s response to broken coherence and can induce fallback collapse. Neither substitutes for the other.

Fourth, center or project with an explicit hypothesis. Row-centering is appropriate for softmax-relevant within-row contrasts; column-centering removes a per-token baseline; double-centering isolates interaction but may not remove every profile component; explicit profile projection is preferable when a particular rank-1 direction has been diagnosed. The transform belongs in the scientific claim.

Fifth, match nuisance structure on both sides of a comparison. The probe-averaging result demonstrates that variance matching alone is insufficient if the control retains a profile that the operation itself concentrates. Controls must receive the same deflation, token selection, centering, and held-out fitting protocol as the signal.

Sixth, use balanced token sets when conditions have different entropies or update magnitudes. The absolute-KL paradox shows that a condition can have a larger raw distributional change but a more compressible normalized update. Fraction of KL Explained, with the baseline restored before softmax, is more interpretable than absolute KL across unequal shifts.

Seventh, separate geometry from semantics. A reproducible subspace may align with format, frequency, topic, or tokenization artifacts. Conversely, a content-enriched Δ component need not be an abstract semantic axis. Localization, topic baselines, random projections, and disagreement analyses are needed before assigning linguistic meaning.

Finally, report failed or deflationary tests. The disappearance of the snapshot direct channel under column-centering, the raw rank-1 failure of Δ, the naive triviality verdict for probe averaging, and the late-layer OOD shattering result all sharpen the positive claims. They prevent the common mistake of treating every concentrated spectrum as evidence for the same mechanism.

## 11. Limitations and scope

The evidence is extensive but local. All experiments use one OLMo-1B model, one tokenizer, black-box final-position logits, and sampled fragments from a fixed Wikipedia-derived corpus. Selected-token tables are not full-vocabulary analyses, and selected-token KL is not full-distribution KL. Matrix sizes, fragment lengths, and probe families lie within the task’s small-to-medium regime; larger models or different tokenizers may organize the vocabulary differently.

The controls are strong but not exhaustive. A marginal-preserving shuffle destroys alignment while retaining columns, but it does not test every possible nonlinear or higher-order null. Token and word shuffles separate some order and coherence effects but do not independently manipulate syntax, semantics, topic, lexical overlap, or discourse structure. The crossed bridge is linear, so success establishes predictive low-rank consistency rather than ruling out nonlinear alternatives.

Several interpretations remain correlational. The entropy-controlled direct channel is a partial correlation, not a causal mediation proof. “Locality” is inferred from corruption families and manipulation checks, not from a direct syntactic parser. The content/format partition is geometrically grounded only at coarse resolution; disagreement tokens do not favor one labeling beyond a generic partition null. The semantic meaning of individual singular directions remains incompletely mapped.

The temporal claims concern the tested probe families and target-centered covariance metric. Centering discards uniform shifts, so the trajectory conclusions apply to context-to-context variation, not to every component of the probability update. The late-layer logit-lens result identifies where predictive divergence becomes visible but does not by itself establish a unique circuit mechanism.

These limitations narrow the claims rather than undermine them. Within the stated arrangements and controls, the held-out margins, fresh-seed replications, and ablations are too consistent to treat the interaction results as artifacts. What is not supported is a universal assertion that language, every logit table, or every model has one fixed low-dimensional semantic code.

## 12. Conclusion

The local evidence supports a structured answer to the low-rank logit-table question.

Absolute row-centered snapshot tables contain reproducible dimensions beyond a strict marginal-preserving floor, but their geometry is largely frequency- and format-aligned. A natural-versus-scrambled comparison is misleading because incoherent inputs collapse the model into a high-entropy, collinear fallback. The apparent entropy-independent coherence channel in snapshots is associated with local contiguous fragments, yet its carrier is a non-uniform per-token column mean—especially leading-space format columns—and it vanishes under column- or double-centering.

The more substantive low-rank object is the profile-deflated context-induced update. Context-influence tables show sublinear intrinsic-dimension scaling, held-out transfer, and genuine probe-averaging concentration once the profile is removed from both signal and control. Crossed context--probe tables support rank-8 prediction into a fully held-out quadrant, with natural error 0.487 versus 1.059 for an alignment-destroying control; the advantage survives residualization, control reordering, row normalization, and graded corruption. Column-centered compositional Δ matrices beat marginal-preserving nulls at ranks 1, 2, and 4, generalize to unseen contexts, and remain superior when the token subset is doubled.

The interaction budget is dynamic. Grammatical binding produces a movable peak in rank complexity, establishes a target-centered covariance manifold, and constrains later centered updates. Fast syntax-sensitive variation and slower semantic integration are partly orthogonal; content vocabulary is comparatively path-invariant, while format vocabulary carries word-order dependence. Severe out-of-distribution noise broadens the update spectrum and disrupts a late-layer confidence gate rather than inducing a tighter universal rank-1 fallback.

The final claim is therefore deliberately specific: for OLMo-1B black-box next-token logits, low-rank structure is reproducible when the table is chosen to represent context-induced or compositional changes, nuisance profiles are explicitly controlled, and prediction is tested out of sample. Snapshot tables reveal a stable marginal geometry; profile-deflated difference and crossed tables reveal a distinct, predictive interaction geometry; trajectory tables show when that geometry is activated and how it persists. Low-rankness is not a property of logits in the abstract. It is a property of an arrangement, a transform, a control, and a validation question—and, under the right combination, it is empirically real.

## Appendix A. Compact evidence ledger

| Claim | Arrangement and transform | Main control or ablation | Held-out or replication evidence |
|---|---|---|---|
| Snapshot structure beyond marginals | Row-centered prompt-by-token, N=64–192, K=20–200 | Independent within-column permutation | MP rank about 4–7 vs 1–2 floor; rank-8 held-out gap about 0.26–0.39; fresh seeds across all K |
| Incoherence causes fallback collapse | Same snapshot table | Token shuffle, random tokens, global shuffle | Row cosine about 0.65–0.75 vs 0.23 natural; incoherent effective rank about 3–5 |
| Snapshot direct channel is marginal | Row/column/double centering, K=128 | Locality corruption families | Chunk partial r about 0.82; row-to-double drop about 0.45; format-carrier Gini about 0.63 |
| Crossed transfer | Context-effect table, rank-8 bridge | Blockwise row shuffle; residualization; row normalization | Natural crossed error 0.487 vs 1.059 control; residualized ratio about 0.615 |
| Probe averaging is genuine after deflation | Fixed-token context-influence averages | Variance-matched shuffle averaging plus identical profile projection | Five fresh seeds; ER margin 50.56, CI [49.03, 52.09]; held-out error margin 0.281 |
| Compositional residual | Column-centered Δ, balanced token union | Centered marginal-preserving null | Natural wins ranks 1/2/4; held-out Fraction KL Explained about 17–39% vs near zero null; K=1280 replication |
| Binding creates persistent geometry | Position-wise centered trajectory Δ | Token-shuffled contexts; shifted-binding probes | Peak shifts with binding; post-binding terminal capture higher in 10/10 seed-step cells |
| Interaction head is not topic-only | Dim-8 learned interaction vs snapshot topic basis | Matched random; topic-orthogonal decomposition | KL gap 0.00486 nats, CI [0.00382, 0.00589]; orthogonal gain 0.00570 nats |
| Path dependence localizes to format | Vocabulary-partitioned trajectory subspaces | Variance-matched shuffled null | Content overlap 0.839 vs format 0.750; difference 0.089, p=0.00098 |
| OOD noise shatters late | Step-update SVD and layer-wise logit lens | Mild/moderate/severe random noise | Effective rank 21.03 normal to 26.28 severe; late-layer gap max 0.293 |

## Appendix B. Terminology

**Marginal profile:** the across-row mean or token-specific baseline of a logit table. In these experiments it is often a unigram/frequency/format direction.

**Structural null:** a control preserving token-column marginals while destroying row-column alignment, usually by independent within-column shuffling.

**Incoherence null:** a token, word, or random-token corruption that disrupts sequence structure and may induce fallback behavior.

**Context-effect table:** a matrix of logit changes caused by adding a context to a shared probe or target.

**Compositional Δ table:** a matrix of updates caused by adding a probe to a context, Δ = logits(composed) − logits(context).

**Crossed transfer:** prediction of a quadrant whose contexts and probe-token columns were both held out from the fitted low-rank bridge.

**Target-centered trajectory subspace:** a covariance basis learned after removing position-specific token means, used to compare intermediate autoregressive updates across positions.
