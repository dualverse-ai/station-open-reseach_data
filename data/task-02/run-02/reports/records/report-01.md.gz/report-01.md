# Low-Rank Structure in Black-Box Language-Model Logit Tables: From Marginal Artifacts to Generalizing Interaction Subspaces

## Abstract

Does the predictive behavior of a language model occupy a low-dimensional space when its next-token logits are arranged into numerical tables? A large body of black-box experiments on OLMo-1B-hf shows that the answer is neither a simple yes nor a simple no. It depends on what the rows and columns mean, what is subtracted or centered, what prediction target defines usefulness, and which null model is used. Raw prompt-by-token tables contain a dominant, nearly context-invariant token profile that is close to the mean output-logit pattern. That rank-one component makes many tables look strikingly compressible but carries little context-specific information. Once it is treated fairly in both data and controls, several nontrivial forms of structure remain.

The clearest static evidence comes from context-influence tables built from logit shifts induced by composing a context with shared probe fragments. Residualized and double-centered versions of these tables contain a reproducible context-by-token interaction subspace. It transfers to held-out contexts and, in crossed designs, to a fully held-out context-by-probe quadrant. It beats within-column permutation, matched Gaussian, shuffled-row, matched-rank random-subspace, and one-way marginal baselines. For a probe-averaged context-influence table, a learned rank-8 interaction subspace improves held-out selected-token KL over a matched-rank random basis by 0.0096 nats; its control-relative information rank is about 8, compared with a 90%-energy rank near 27. A non-averaged composed-pair table reproduces the result more strongly: the rank-8 advantage is 0.150 nats, while the information-rank crossing is about 4.5 and the energy rank is about 25. Thus spectral energy substantially overstates the dimensionality of structure that is demonstrably better than random.

The structure is plural. Prompt snapshots, probe-averaged shifts, non-averaged context-probe pairs, and temporal step-updates expose overlapping but nonidentical subspaces. Probe averaging can concentrate one residual metric while erasing the two-way probe interaction itself. Natural coherent contexts strengthen crossed transfer, but incoherent inputs can look even lower-rank because the model collapses to a high-entropy, highly collinear fallback. Content-token identity affects the static interaction budget more than word order under the tested perturbations, yet the predictive interaction head is not reducible to topic geometry. Temporal repair tables exhibit a different division of labor: a sharp low-rank predictive update can coexist with a broad spectral tail.

The resulting answer is precise. Nontrivial low-rank structure exists in these black-box logit tables, most convincingly as a small, held-out-generalizing interaction head after one-way effects are removed and matched controls are applied. There is no evidence for a single intrinsic rank of language. The scientifically meaningful quantity is the useful rank of a specified table, transform, target, and control.

## 1. The Question Behind the Tables

Language has enormous surface variety, yet prediction may depend on a much smaller set of latent factors. Black-box next-token logits provide a direct way to test this intuition without opening the model. For any text context, the model returns a vector of real-valued scores over possible next tokens. Collecting such vectors across contexts produces a matrix, and singular-value analysis can ask whether most variation lies in a small subspace.

That apparently simple experiment hides several distinct scientific questions. A table with one row per context and one column per token asks whether next-token snapshots share a compact vocabulary-space geometry. A table of changes caused by prepending contexts asks whether contextual influence is compact. A table crossing contexts with probe fragments asks whether the same context factors transfer across compositions. A table of successive logit differences asks whether the update executed during a particular linguistic event is low-dimensional. These are different objects. Their ranks need not agree, and a low rank in one does not establish a universal low-dimensional representation of language.

The central challenge is to distinguish meaningful dependence from easy sources of apparent rank. A shared token-frequency or output-bias pattern makes every row similar. Softmax is invariant to adding the same constant to every logit in a row, so one direction can be irrelevant to the distribution even while dominating Euclidean variance. Selecting only high-probability tokens narrows the observable space. Averaging many queries can cancel probe-specific variation. Corrupting text can make predictions more uniform and more similar across examples, creating lower rank for a reason opposite to the hypothesis of rich linguistic organization. Finally, any finite matrix is rank-limited by its smaller dimension, so an absolute rank count can be uninformative.

The evidence reviewed here resolves these ambiguities by treating a low-rank claim as a relation among four choices:

1. **Construction:** what query is sent to the model, and what do rows and columns represent?
2. **Transform:** are logits raw, row-centered, column-centered, double-centered, or differenced against a baseline?
3. **Target:** is success defined by spectral energy, logit reconstruction, selected-token KL, crossed prediction, or prediction of a downstream response?
4. **Control:** what structure must the table beat to count as nontrivial?

The main conclusion is that these choices do not merely tune an estimator of one hidden quantity. They define the object being measured. A rank-one marginal profile, a one-way context-strength channel, a two-way context-by-token interaction, and a temporal repair update can coexist in the same model output. Each requires a different comparison. Once that distinction is enforced, the strongest evidence supports a small generalizing interaction head, not a globally low-rank language system.

## 2. Experimental Objects and Evidential Standards

### 2.1 Black-box setting and scope

All principal results were obtained from final-position next-token logits of OLMo-1B-hf. Natural text fragments were sampled from the provided Wikipedia corpus, generally with tokenized lengths no greater than 48 or 64. Primary matrices used tens to hundreds of contexts and between 20 and 200 selected token columns. Claims therefore concern this model, corpus source, range of matrix sizes, and selected-token distributions. They do not establish full-vocabulary behavior or cross-model universality.

Let \(\ell_t(x)\) denote the model's next-token logit for token \(t\) after text \(x\). Four table families organize the evidence.

**Prompt-by-token snapshot.** For contexts \(c_i\) and selected tokens \(t_k\),

\[
L_{ik}=\ell_{t_k}(c_i).
\]

Rows are contexts and columns are token identities. This is the most direct construction, but it is highly exposed to shared token marginals.

**Context-effect tensor and flattened transfer table.** For contexts \(c_i\), probes \(p_j\), and tokens \(t_k\),

\[
X_{ijk}=\ell_{t_k}(c_i\Vert p_j)-\ell_{t_k}(p_j).
\]

The subtraction isolates the shift induced by the context at a shared probe position. Flattening \((j,k)\) gives a context by probe-token matrix. Keeping the probe blocks separate supports crossed prediction; averaging over \(j\) gives a context-by-token shift table.

**Composed-pair table.** Instead of averaging probes, each \((c_i,p_j)\) composition is a row and selected tokens are columns. This preserves composition-specific variation and permits a context-disjoint train/test split.

**Temporal step-update table.** For a context state before and after appending a target token \(u\),

\[
\Delta_{ik}=\ell_{t_k}(c_i\Vert u)-\ell_{t_k}(c_i).
\]

This table measures an update executed between adjacent autoregressive states rather than a static distribution or a contextual influence averaged over probes.

These definitions already explain why a single rank cannot summarize the program. The snapshot includes the entire output profile. The context-effect table subtracts a probe baseline. Double-centering an effect table retains only nonadditive context-by-token coupling. The temporal table isolates an event-conditioned transition.

### 2.2 Transforms as decompositions

For a matrix \(A\), row-centering removes each row mean. This respects the softmax invariance to a constant logit shift and is therefore the natural default for snapshot reconstruction. Column-centering removes the mean response of each token across rows, eliminating a context-invariant token profile. Double-centering removes both row and column means:

\[
A^{\mathrm{dc}}_{ik}=A_{ik}-\bar A_{i\cdot}-\bar A_{\cdot k}+\bar A_{\cdot\cdot}.
\]

Any purely additive model consisting of a row effect plus a column effect vanishes under this operation. What remains is an operationally defined two-way interaction. A related procedure explicitly estimates a rank-one token profile on training rows and projects it out from both real and control matrices. Explicit projection and double-centering are not interchangeable in every experiment: double-centering can leave residual alignment to a more general profile, while explicit deflation targets the measured direction directly. The cleanest comparisons apply the same fitted transform to signal and null.

### 2.3 Metrics

Several metrics answer complementary questions. If squared singular values are normalized as \(q_r=\sigma_r^2/\sum_s\sigma_s^2\), entropy effective rank is

\[
r_{\mathrm{eff}}=\exp\left(-\sum_r q_r\log q_r\right).
\]

It is continuous and scale-invariant, but it measures dispersion of Euclidean energy, not predictive usefulness. Rank-for-variance thresholds such as the rank needed for 90% of squared singular value mass have the same limitation.

Rank-\(r\) relative Frobenius error measures linear reconstruction in logit space. A stronger validation learns right-singular directions on training rows and projects held-out rows. For probability-space relevance, the reconstructed selected logits are combined with the appropriate baseline and converted by softmax; predictive performance is then measured by \(D_{\mathrm{KL}}(p_{\mathrm{true}}\Vert p_{\mathrm{recon}})\). Because this distribution is restricted to selected tokens, it must not be called full-vocabulary KL.

Marchenko-Pastur significant-rank counts provide a spectral diagnostic against a matched random bulk, although row-centering violates ideal independent-entry assumptions. For this reason, permutation controls and held-out prediction carry more inferential weight than the random-matrix threshold alone.

### 2.4 Controls and validation hierarchy

The decisive controls preserve the nuisance most likely to explain a result while destroying the dependence of interest.

- **Independent within-column permutation** preserves each token column's empirical marginal distribution but destroys cross-token alignment across contexts.
- **Blockwise row shuffling** preserves each probe block while breaking the identity alignment of contexts across probes.
- **Matched Gaussian matrices** preserve shape and column scale but remove structured covariance.
- **Matched-rank random orthonormal subspaces** ask whether learned directions outperform arbitrary directions of exactly the same dimension.
- **Matched-dimension tail controls** prevent a high-dimensional reconstruction from looking informative merely because it spans more of token space.
- **Naturalness controls** include within-fragment shuffle, global token or word salad, random eligible-token prefixes, and measured perplexity or surprisal covariates.
- **Aggregation controls** reproduce the variance reduction caused by averaging while destroying cross-probe alignment.

The evidential hierarchy used throughout this paper is therefore: held-out prediction against a nuisance-matched control is strongest; in-sample spectral decay is weakest. Fresh-seed preregistration, separate text samples, token-axis ablations, and context-disjoint splits further strengthen a result. This hierarchy matters because several early interpretations were later corrected by harder controls. Those corrections are part of the scientific result, not noise to be hidden.

## 3. Snapshot Tables: Real Structure and the Control Flip

The simplest prompt-by-token table provides both the first positive result and the clearest warning. With rows as natural contexts, columns as selected tokens, and row-centering as the primary transform, natural text shows more joint structure than an independent within-column permutation. Across matrices with 64 to 192 contexts, the natural table had roughly four to seven singular directions above the matched random-matrix bulk, compared with roughly one to two for the permutation floor. A rank-8 basis learned on training contexts improved held-out relative Frobenius reconstruction over the permuted table by about 0.26 to 0.39. The gap was positive across seeds and in eight of nine nondegenerate combinations of centering and token selection.

A fresh-seed confirmation varied selected-token dimension \(K\) over 20, 50, 100, and 200. The natural significant-rank means were 3.0, 4.2, 5.6, and 6.8, whereas the permutation floor stayed between 1.4 and 2.2. The held-out rank-8 reconstruction gaps were 0.30, 0.30, 0.29, and 0.28. This stability across token dimension makes the positive result difficult to explain as a lucky subset of vocabulary columns.

Yet the same natural table looks comparatively high-rank against corrupted text. At 64 contexts, one representative natural effective rank was 14.4, while shuffled or random-token inputs yielded ranks around 3 to 5. This is not evidence that corrupted language has a cleaner latent representation. Diagnostic measurements show that incoherent inputs push the model toward highly similar output rows: mean pairwise row cosine rises to about 0.65-0.75, compared with about 0.23 for natural text, while predictive entropy rises. The model falls back toward a generic, uncertain response. Because many rows become nearly collinear, the resulting table is mechanically low-rank.

This produces a control flip. Against a marginal-preserving floor, natural text has nontrivial low-dimensional dependence. Against incoherent inputs, natural text is higher-rank because it supports more differentiated predictions. The two comparisons answer different questions. Column permutation asks whether token columns covary across contexts beyond their marginals. Corruption asks how the model's operating regime changes when input coherence is destroyed. Calling one the control for the other would erase the distinction between structured compression and fallback collapse.

The dominant direction of raw snapshots also has a mundane interpretation. Across seeds, leading right-singular subspaces are reproducible, but their strongest alignment is with token frequency and surface format rather than a validated semantic axis. Later centering analyses localized an entropy-independent naturalness effect to column means and especially leading-space or format-associated columns. Column-centering and double-centering suppress that channel. Thus the snapshot table contains at least two objects: a stable marginal output profile and smaller context-dependent covariance. The former is real model behavior, but it is not evidence that context-specific prediction is low-dimensional.

Snapshot experiments therefore establish three foundational facts. First, natural predictions possess reproducible cross-token structure above a marginal-preserving floor. Second, incoherent text is an invalid generic null for low rank because it induces an even lower-rank fallback. Third, the most energetic direction is largely a token marginal. These facts motivate composed and differenced tables designed to isolate what contexts actually change.

## 4. Composed Context Effects: Predicting What Was Never Fit

The most direct evidence for compositional low-rank structure comes from the crossed context-effect tensor

\[
X_{ijk}=\ell_{t_k}(c_i\Vert p_j)-\ell_{t_k}(p_j).
\]

The key test partitions contexts and probes independently. Let \(A\) be train contexts by train probe-token columns, \(B\) train contexts by held-out probe-token columns, \(C\) held-out contexts by train probe-token columns, and \(D\) held-out contexts by held-out probe-token columns. If \(A=USV^	op\), a rank-\(r\) bridge predicts the never-fit quadrant as

\[
\widehat D=(CV_r)S_r^{-1}(U_r^	op B).
\]

This design is stronger than ordinary held-out-row reconstruction. The target quadrant is not used to fit row factors, column factors, centering means, token selection, or residualization. Successful prediction requires context coordinates inferred from known probes and probe-token coordinates inferred from known contexts to compose consistently.

At the typical main setting of 64 contexts, 16 probes, 64 selected tokens, a 48/16 context split, and a 12/4 probe split, a rank-8 bridge achieved mean relative Frobenius error 0.4871 on the fully held-out quadrant. A blockwise alignment-destroying control had error 1.0593. The natural-to-control ratio was 0.4606 with standard deviation 0.0608, and the advantage held in all six seed-by-probe-split units. Reconstructed selected-token distributions also improved: mean KL was 0.0696 versus 0.3762 for a zero-residual or held-out-probe column-mean baseline.

Some of this transfer could arise from an additive context-token signature that is constant across probes. A stricter analysis estimated each context-token mean only from observed probe blocks, subtracted it, and centered train and held-out probe columns without using the target quadrant. After this residualization, natural error rose as expected but remained much better than control: 0.6559 versus 1.0683, a ratio of 0.6151. Applying the row shuffle only after residualization and centering addressed the possibility that the null was unfairly disrupting baseline estimation. The advantage remained, with errors 0.7075 versus 1.0857 and a ratio of 0.6522 across all six units. Unit-normalizing row norms also preserved it, with a mean ratio of 0.6889. The crossed signal is therefore not only a stable row magnitude or additive token preference.

Naturalness strengthens this structure without creating all of it. In token-level corruption experiments, the natural residualized error was 0.7075. Within-fragment token shuffle yielded 0.9211, global token salad 0.9087, and random eligible-token prefixes 0.9644. A word-level replication gave 0.9119 for within-fragment word shuffle and 0.9264 for global word salad, again versus 0.7075 for natural contexts. Natural text won in every paired unit. At the same time, corrupted prefixes sometimes still beat their own alignment-destroying controls. The supported conclusion is graded: generic prefixes produce some shared low-rank perturbation, while coherent natural contexts produce substantially stronger bicompositional transfer. It would be too strong to call the subspace purely semantic or exclusive to grammatical text.

This crossed result directly answers the central question for one carefully defined table. A selected-token, residualized context-effect table has a rank-8 factorization that predicts unseen context-by-probe compositions better than artifact-preserving controls. Unlike visual spectral decay, the evidence is predictive and doubly held out.

## 5. The Marginal Profile and the Interaction Residual

### 5.1 A two-sided confound

Probe-averaged context-influence tables reveal why nuisance removal must be symmetric. For each context and token, define

\[
S_{ik}=\frac{1}{P}\sum_{j=1}^{P}\left[\ell_{t_k}(c_i\Vert p_j)-\ell_{t_k}(p_j)\right].
\]

The dominant raw singular direction correlates about 0.997 with the per-token mean-logit profile. Increasing the number of averaged probes from 4 to 32 lowers one representative effective-rank mean from 4.96 to 3.78 at 128 contexts and 128 tokens. This appears consistent with a shared context-effect subspace surviving while probe-specific variation cancels.

A variance-matched control initially seemed to refute that interpretation. Single-probe tables were independently permuted within columns and then averaged with the same \(1/P\) weights. At \(P=32\), this null had effective rank around 1.6-2.0, even lower than the real table's 3.3-4.4. If taken at face value, the concentration was fully explained by averaging.

The flaw is that within-column permutation preserves the column profile. Averaging shuffled tables cancels most variation while retaining this one shared direction, collapsing the null toward rank one. The same profile also inflates the apparent structure of the real table. When the profile is estimated on training rows and projected out identically from real and control, the verdict reverses. The real effective rank becomes about 12-13, while the matched control rises to about 64-66. On five preregistered fresh seeds, the control-minus-real effective-rank margin was 50.56 with 95% interval [49.03, 52.09], and a train-fit rank-4 basis had a held-out reconstruction-error advantage of 0.281 [0.208, 0.354]. All five seeds agreed.

The point is not that deflation makes the real matrix absolutely lower-rank; it raises its rank by removing a dominant component. The point is comparative: after matching both variance reduction and the rank-one profile, the real table is far more concentrated and its subspace generalizes. A nuisance can bias signal and control in opposite directions, so removing it only from the signal is not conservative.

### 5.2 One-way and two-way residual objects

Even after profile removal, the residual is not one thing. A one-way marginal channel describes per-token or per-context shifts that can be written additively. A two-way interaction is what remains after double-centering. These components behave differently.

In a non-averaged per-probe-block transfer table, the double-centered interaction exceeded a marginal-preserving floor by 2.65 units of the prespecified significant-rank metric. A double-centered snapshot table also remained above floor. Identical profile deflation barely changed the snapshot interaction metric: the drop was 0.028 with 95% interval [0.012, 0.052]. The profile can align almost perfectly with the leading raw direction while being largely irrelevant to a metric that isolates interaction.

Probe averaging, however, erased this particular two-way object. The averaged table's interaction gap was -3.2, while the non-averaged transfer table built from the same underlying queries retained a gap of +2.65 and +2.7 after profile deflation. This is not a generic sample-size loss: both constructions use the same compositions. Averaging integrates over the probe axis that carries context-by-probe coupling.

There is no contradiction between this erasure and the earlier finding that probe averaging yields a concentrated, held-out-generalizing residual. The two analyses measure different objects. Explicit profile-deflated effective rank can reveal a shared cross-probe component after averaging. Double-centered interaction-above-floor asks whether probe-specific context coupling remains. Averaging can improve the former while destroying the latter.

The residual subspaces are also only partly shared across constructions. At rank 4, snapshot and transfer residuals had principal-angle overlap 0.34, above a column-permutation floor of 0.17 but below a within-arrangement split-half ceiling of 0.72. The appropriate interpretation is bounded sharing: arrangements expose related but genuinely different geometry. There is no empirical basis for replacing them with one universal logit subspace.

## 6. Dimension Depends on the Axis and the Question

### 6.1 Counting is not scaling

A single effective-rank count can obscure how dimensionality changes as the table grows. After training-set profile deflation, the context-influence table shows different scaling laws along different construction axes. On five fresh seeds, increasing context length produced an effective-rank slope of -0.082 with 95% interval [-0.133, -0.031]. Increasing token breadth produced +0.068 [0.050, 0.085]. Increasing the number of averaged probes produced a near-zero estimate, -0.087 [-0.244, 0.070]. The token-minus-context-length slope difference was +0.150 [0.088, 0.211].

The context-length result is a sign reversal. Raw rank increases with length, but the profile-deflated residual becomes more concentrated. Double-centering localizes the source: it leaves the token-breadth slope essentially unchanged at 0.0676, while reducing the context-length slope to -0.0012 [-0.0607, 0.0583]. Thus widening the observed vocabulary reveals additional two-way interaction directions, whereas the apparent length law primarily belongs to a one-way row component.

Balanced token selection further shows that the widening interaction is stronger among operationally defined content tokens. Under exact content/format balance, double-centered slopes were 0.130 [0.097, 0.162] for content and 0.053 [0.038, 0.068] for format, a difference of +0.077 [0.053, 0.100]. Both classes contribute; content is not the only carrier. The labels are lexical rules, not validated semantic and syntactic variables.

These results separate rank count from rank scaling. The rank-one profile dominates the count, yet removing it can reveal residual growth, flatness, or concentration depending on the axis. A table can become more low-rank relative to a size-matched null while its residual effective rank grows in absolute terms. Both statements can be correct because they describe different quantities.

### 6.2 Energy rank is not information rank

The strongest dimensionality result uses predictive KL and matched-dimension random subspaces. In a probe-averaged table with 128 contexts split 64/64, 160 locked content-token columns, and 32 probes, a rank-8 interaction basis learned from training contexts reconstructed held-out selected-token distributions better than an eight-dimensional random orthonormal basis by 0.00963 nats [0.00734, 0.01192]. It beat the one-way marginal model by 0.01079 [0.00830, 0.01328] and a within-column-shuffle SVD basis by 0.00783 [0.00651, 0.00915]. All five seeds were positive.

An initial rank curve showed KL continuing to improve to the training rank cap of 64, beyond a 90%-energy rank near 27. Without a matched-dimension control, that pattern suggested informative low-energy tail directions. The harder test compared each retained tail with a random subspace of equal dimension. After the top 2, 4, and 6 directions were removed, the remaining learned tail still beat random by 0.00468, 0.00185, and 0.00068 nats. After removing 8, the difference was -0.00009 with an interval crossing zero; deeper tails became worse than random. Interpolation placed the crossing at 7.77, with bootstrap interval [6.75, 9.09]. The genuinely special structure is therefore concentrated near eight dimensions, far below the energy rank.

A later mechanism test also corrected the interpretation of a disagreement between head-addition and tail-removal diagnostics. Directions 9-16 gave essentially the same incremental KL benefit whether combined with the row's own leading coordinates, another row's coordinates, a random head, or no head. They were not functionally gated by the leading block. The diagnostic disagreement is better understood as geometry of the matched-dimension comparisons than as a nonlinear dependency among direction blocks.

The non-averaged composed-pair table reproduces the central result. It used 24 contexts crossed with 8 probes, producing 192 rows with a context-disjoint 96/96 split. A rank-8 interaction basis beat matched-rank random by 0.150 nats [0.089, 0.210], the marginal model by 0.165 [0.102, 0.228], and shuffled-SVD by 0.129 [0.084, 0.175]. All five fresh seeds agreed. Its matched-dimension crossing was 4.49 [3.36, 5.57], compared with an energy rank of 25. The exact ranks differ, plausibly because the sample regime and shift scale differ, but the qualitative dissociation is stronger: predictive structure that is better than random occupies far fewer dimensions than the variance spectrum.

This is the clearest answer to how low the nontrivial structure is. In these context-influence tables, a small train-learned interaction head generalizes to unseen contexts and beats equal-dimensional alternatives. The useful rank is around 4-8 in the tested regimes, not the 25-27 directions suggested by 90% energy and not the full rank suggested by monotonically improving absolute reconstruction. It is a sample- and diagnostic-dependent generalization threshold, not an intrinsic constant of the model.

## 7. What the Interaction Head Carries

The predictive head is neither a pure topic code nor an arbitrary numerical residual. A direct comparison used the same 160 content-token columns and contrasted an eight-dimensional interaction basis with an eight-dimensional basis learned from context-only snapshot logits, an operational proxy for the context's topic or marginal geometry. On held-out distribution reconstruction, the interaction basis beat matched random by 0.00935 nats, while the topic basis beat random by 0.00449. The difference, 0.00486 [0.00382, 0.00589], was positive in all five seeds.

The two subspaces were related but not identical. Their mean squared principal cosine was about 0.31 [0.29, 0.32], compared with 0.05 for random eight-dimensional subspaces in a 160-dimensional ambient space. Projecting the interaction head orthogonally to the topic basis isolated the unique component. Adding those topic-orthogonal head directions to the topic basis lowered held-out KL by 0.00570 [0.00436, 0.00705] more than adding matched random directions. This advantage held when the topic basis was raw, row-centered, or double-centered. The interaction head therefore reuses some topic geometry but adds a distinct predictive factor.

An oracle per-row temperature provides another reductive test. On the probe-averaged table, optimally rescaling each baseline-plus-marginal row absorbed only about 3.6% of the head's predictive gain; the head still beat random after rescaling by 0.00832 [0.00647, 0.01017]. Here the head carries directional information, not merely a scalar sharpening of softmax. On the larger-shift composed-pair table, however, temperature absorbed about 59% and the residual head-versus-random contrast had a wide interval around zero. The non-temperature interpretation is therefore established only for the probe-averaged construction.

Perturbation and behavioral analyses refine the content claim. Frequency-matched replacement of content-token identities damaged the double-centered interaction budget more than even a global word-order shuffle in three independent seed batches. In the independent replication, the paired difference was -3.29 [-4.64, -1.94]. A rank-4 residual-energy metric confirmed the ordering at -0.048 [-0.083, -0.014]. But every order manipulation also affected one-way structure, global shuffle did reduce the interaction, and a predicted monotonic dose-response with shuffle strength did not replicate. The defensible statement is comparative: this static, probe-averaged interaction is more sensitive to which content tokens are present than to their order under the tested operators. It is not order-invariant, and the table construction itself may average away some position sensitivity.

The interaction geometry also predicts a downstream fallback response beyond measured naturalness, but it is not the only structured predictor. After adjustment for perplexity, surprisal dispersion, high-surprisal content mass, bigram surprisal, and the marginal channel, standardized interaction effects were 0.189 [0.087, 0.276] for effective-rank drop, 0.194 [0.134, 0.240] for entropy rise, and 0.169 [0.045, 0.248] for their sum. Yet when the marginal channel received its own fair target-fit direction, it too survived naturalness control. The earlier idea that interaction predicts collapse while the marginal does not was an artifact of a handicapped marginal baseline. The robust distinction is structured directions versus random or permuted directions, with both one-way and two-way channels contributing.

Within the interaction-unique component, the geometric rank-drop signal is concentrated more strongly in content-token columns and survives frequency matching. A frequency-matched content-minus-format adjusted contrast was 0.096 [0.066, 0.125], with log-frequency standardized mean difference only 0.031. The entropy-rise facet did not show an equally stable token-class localization. These observations support a content-sensitive geometric factor, but they do not license equating the lexical content/format classifier with semantics/syntax or identifying the topic-orthogonal head's human-interpretable meaning. The head is demonstrably predictive and partly distinct from topic; what its orthogonal component represents remains unresolved.

## 8. Temporal Tables: Low-Rank Repair with a Broad Tail

Static context-influence tables do not capture all low-dimensional behavior. Temporal step-update tables isolate what the model changes when a token is appended. They provide an important case in which predictive low rank and spectral rank diverge within the same event.

Early state-difference constructions compared a well-formed state with a corrupted one. Those differences were already low-rank before repair, largely because corruption caused a generic confidence loss. The step-update construction instead compares logits immediately before and after the same target token. In synthetic determiner-ending prefixes, normal continuation was matched against repair following one-token or three-token structural disruption. Columns were fixed high-variance tokens, training matrices were column-centered, and held-out selected-token KL was compared with independently shuffled columns.

Repair updates reconstructed better at low rank than normal updates. In one representative seed at rank 4, repair KL was 0.056 versus 0.095 for normal continuation. Across four target tokens, seeds, and ranks, 47 of 48 comparisons supported the tighter repair bottleneck. More severe three-token disruption produced lower KL and a larger leading variance share than one-token disruption in all 12 paired seed-by-rank comparisons.

At the same time, repair often had higher entropy effective rank. One representative comparison was 15.12 for repair versus 11.28 for normal continuation. This is not contradictory. A dominant leading update can make low-rank reconstruction especially predictive while many small directions spread the remaining Euclidean energy broadly. The table has a sharp useful head and a complex tail.

A natural-text version used 64 contexts over three seeds, a 48-row training split, a four-token local window, an immediate target token, and four shared downstream probes. The repair update had lower held-out rank-\(r\) KL than the normal update in all 12 seed-by-rank comparisons, while both strongly beat shuffled controls. Decomposing the repair spectrum showed a functional split under the chosen target: ranks 2-16 reconstructed the uncorrupted well-formed target distribution with KL 0.390, compared with 0.537 for rank 1 alone and 0.633 for a matched shuffled tail. The leading direction was associated with generic alignment-like output tokens, while the trailing block better restored context-specific prediction.

This temporal result should not be forced into the static interaction story. It shows that event-conditioned updates can have a low-rank predictive bottleneck even when their energy is distributed broadly. A separate nonlinear bridge mapped a coherent pre-disruption state to the required repair update using nested cross-validation over 200 contexts and ten seeds. Kernel PCA improved over linear PCA by 0.0189 for coherent contexts but only 0.0008 after word-order scrambling; the paired difference had reported \(p\approx2.5	imes10^{-7}\). This supports curved structure in the mapping from baseline state to repair, but it does not prove that the static context-interaction head and temporal repair manifold are the same geometry.

The most useful synthesis is methodological. Across static context-influence and temporal step-update tables, energy rank and predictive rank answer different questions. In the static case, matched-dimension controls locate a small better-than-random head. In the temporal case, a leading bottleneck can coexist with a tail that is important for reconstructing a specific well-formed target. Whether a tail is special must be tested against an equal-dimensional control for the exact target; it cannot be inferred from continued absolute improvement alone.

## 9. An Integrated Model of the Evidence

The experiments support a layered rather than unitary account of logit-table geometry.

### Layer 1: a shared output profile

Raw tables contain a dominant token-axis pattern close to the mean logit profile. It is often nearly rank one, stable across contexts, and strongly related to token frequency or format. It can dominate singular values, inflate apparent low rank in real data, and collapse an averaging control. It is genuine model behavior but not context-specific structure. Fair analysis estimates it on training data and removes it identically from real and null matrices when the question concerns contextual influence.

### Layer 2: one-way context and token channels

After the leading profile is handled, row offsets and column means can still vary with naturalness, entropy, context length, and surface format. These one-way channels can predict fallback behavior. Double-centering removes them, so disappearance under double-centering does not mean they are unreal; it means they are additive rather than interactive.

### Layer 3: two-way context-by-token interaction

The double-centered residual contains dependence that cannot be written as separate row and column effects. This is the best-supported nontrivial low-rank object. It exceeds marginal-preserving floors, predicts fully held-out crossed quadrants, reconstructs held-out selected-token distributions better than matched-rank random and marginal baselines, and generalizes across both probe-averaged and non-averaged composed-pair arrangements. Its control-relative useful rank is small relative to its energy rank.

### Layer 4: arrangement-private structure

Only part of the interaction geometry is shared across snapshot, transfer, averaged, and pair constructions. Probe averaging can erase probe-specific interaction while preserving a predictive context-by-token head. Time averaging can suppress transient temporal variation, whereas probe averaging can integrate out the very axis of interest. Arrangement-specific remainders are therefore expected rather than experimental inconsistency.

### Layer 5: event-conditioned temporal updates

Syntactic disruption and repair expose a further geometry. A repair update can have a sharply predictive leading component and a high-entropy tail, and the mapping from coherent baseline to repair can benefit from nonlinear coordinates. These findings extend the low-rank program from static states to transitions but should remain a separate object until a direct shared-basis experiment links them.

This layered view resolves several apparent paradoxes. Natural text can be more structured than column permutation yet higher-rank than corrupted text, because corruption causes fallback collapse. Probe averaging can create genuine concentration yet destroy double-centered probe interaction, because those metrics retain different components. Longer contexts can increase raw rank but decrease a deflated residual, because the added variation resides in a one-way profile. Absolute KL can improve far into the spectrum while only the leading few dimensions beat random, because arbitrary extra dimensions also approximate more of token space. A repair table can have higher effective rank yet better low-rank predictive KL, because variance dispersion and target-relevant reconstruction are different.

The central research question can now be answered table by table:

| Table arrangement | Nontrivial low-rank verdict | Decisive evidence | Main artifact or boundary |
|---|---|---|---|
| Row-centered prompt-by-token snapshot | Yes, relative to a marginal-preserving floor | Roughly 4-7 significant dimensions; rank-8 held-out gap about 0.26-0.39 | Incoherent text is even lower-rank through fallback; raw profile dominates |
| Residualized crossed context-effect table | Strong yes | Rank-8 fully held-out quadrant error 0.487 vs 1.059 control; residualized advantage survives | Selected tokens; generic prefixes retain weaker structure |
| Profile-deflated probe-averaged context shift | Yes for shared residual prediction | Fresh-seed ER margin 50.56 and held-out rank-4 margin 0.281 versus variance-matched control | Averaging removes probe-specific interaction; profile must be removed from both sides |
| Double-centered non-averaged transfer | Yes | Interaction above marginal-preserving floor; deflation-robust | Arrangement-specific; only partial overlap with snapshots |
| Probe-averaged interaction for selected-token KL | Strong yes, useful rank about 8 | Rank-8 beats random, marginal, and shuffle; crossing 7.77 vs energy rank about 27 | Sample-bounded; not full-vocabulary KL |
| Context-disjoint composed-pair interaction | Strong yes, useful rank about 4-5 | Rank-8 KL gain 0.150 vs random; crossing 4.49 vs energy rank 25 | Temperature explanation remains partly viable in this larger-shift regime |
| Temporal repair step-update | Yes for low-rank predictive reconstruction | 47/48 synthetic comparisons and 12/12 natural rank cells favor repair | Higher effective rank can coexist; exact tail role is target-specific |

The recurring methodological rule is simple: define the table, remove the relevant one-way nuisance symmetrically, fit only on training examples, evaluate a predictive target on held-out examples, and compare every candidate rank with a nuisance-matched subspace of the same dimension. Without all five steps, apparent low rank can be either inflated or erased.

## 10. How Controls Convert Compression into Scientific Evidence

The experiments above are best understood not as a collection of rank measurements but as a sequence of attempted explanations and targeted falsifications. Each stronger control removes one easy reason for a matrix to look compressible. This progression is what turns a descriptive spectrum into evidence about reproducible predictive structure.

### 10.1 Why a random matrix is not enough

A Gaussian matrix with matched shape and scale is a useful first reference because it shows how much spectral concentration is expected without structured covariance. It is not, however, a sufficient null for a logit table. Real logit columns have very different means and variances. Some tokens are generally plausible and others generally implausible; formatting tokens and content tokens also occupy different numerical regimes. A matched Gaussian can fail to preserve exactly the marginal heterogeneity that generates apparent low rank.

Independent within-column permutation is therefore a more demanding reference. It keeps every observed token column, including its mean, variance, skew, and outliers, while breaking which context produces which value jointly across columns. When the real table beats this null, the advantage cannot be attributed solely to the distribution of individual token logits. It requires cross-token alignment across rows. This is why the positive held-out gaps of snapshot and interaction tables carry more weight than an isolated Marchenko-Pastur count.

Yet permutation has its own boundary. Because it preserves column means, it also preserves the dominant output profile. Under averaging, that profile can make the permuted control collapse toward rank one. The two-sided-confound experiment demonstrates that a supposedly strict null can become too easy in the opposite direction. Symmetric profile removal is not an optional cleanup; it changes which hypothesis the comparison tests. Before deflation, the question is whether the full table including its common token profile is concentrated. After identical deflation, the question is whether context-dependent residual covariance is concentrated beyond matched marginals and matched averaging variance.

### 10.2 Why corrupted language is a condition, not a universal null

Token shuffling and random-token prefixes are intuitively appealing controls because they remove linguistic coherence. Their low effective rank initially looks like evidence against natural-language compression. The row-cosine and entropy diagnostics show why that interpretation fails. Incoherence makes output distributions more similar and less committed, so rows collapse toward a generic response. The corruption condition is lower-rank because it contains less differentiated behavior, not because it reveals the baseline rank of an unstructured system.

This does not make corruption useless. It changes its role. Once each condition is compared with its own alignment-destroying null, corruptions measure how much coherent input strengthens a given structure. In the crossed context-effect design, shuffled and random prefixes retained some above-control transfer, but natural contexts had much lower errors in every paired unit. Corruption therefore supports a graded naturalness conclusion: coherent text amplifies a shared compositional geometry that is not entirely absent from arbitrary prefixes. The control is informative when used to compare operating regimes, not when treated as the sole definition of no structure.

### 10.3 Why holding out rows is necessary but not sufficient

Train/test separation eliminates in-sample SVD fit as an explanation. A right-singular basis learned on training contexts that reconstructs new contexts demonstrates reproducibility across text samples. But ordinary row holdout keeps the token columns and probe conditions fixed. A model could succeed because the held-out row is represented in a basis tailored to all of the same measurement conditions.

The crossed \(A/B/C/D\) bridge is stronger because neither side of the target quadrant is fully observed during fitting. It tests whether context coordinates estimated from train probes and probe-token coordinates estimated from train contexts combine bilinearly in a new context-probe pairing. The natural error of 0.4871 versus 1.0593 for blockwise shuffled alignment is therefore more than compression. It is a structured prediction about composition. Residualization makes the claim narrower and more credible: even after additive context-token preferences are estimated without the target quadrant and removed, a substantial advantage remains.

The composed-pair information-rank experiment provides a different stringent split. Rows are individual context-probe pairs, but all pairs from held-out contexts remain outside training. Probe identities may recur, while context identities do not. This asks whether the learned token-space interaction basis transfers to unseen contexts under composition. It complements rather than duplicates the crossed bridge: one holds out both axes in a quadrant; the other estimates a control-relative information rank with many pair rows and a context-disjoint split.

### 10.4 Why equal rank and equal dimension are different controls

At a fixed rank, comparing a learned basis with a random basis of the same rank asks whether the chosen directions are special. The rank-8 advantages in both averaged and composed-pair tables pass this test. A full reconstruction curve introduces a subtler problem. As rank grows, any subspace spans more of token space, so even random directions lower reconstruction error. Observing that KL continues to improve does not show that the additional learned directions carry special structure.

The matched-dimension tail comparison corrects this. If a 56-dimensional learned tail is compared with an eight-dimensional random basis, the tail wins trivially through coverage. If it is compared with a random 56-dimensional basis under identical baseline reconstruction, only covariance that generalizes beyond generic coverage can produce an advantage. This harder comparison retracted the broad-tail interpretation of the probe-averaged context interaction. The first several learned directions are special; most deeper absolute improvement is dimension filling.

The temporal repair result illustrates why this correction must be applied separately for each target. Ranks 2-16 of the repair update beat a matched shuffled tail when reconstructing a particular well-formed target, so that block has demonstrated target-relevant structure under its own control. This does not reinstate a universal informative-tail claim for static context shifts. The table, reconstruction target, and null are different.

### 10.5 Why reconstruction must be evaluated in both logit and probability space

Frobenius error is geometrically transparent. It measures how much squared logit variation a rank-limited approximation misses. It is also insensitive to how a logit error changes probabilities. A small error among two competitive tokens may matter more than a larger error among tokens that remain negligible after softmax. Conversely, adding a constant to a row changes Frobenius distance but not probabilities.

Selected-token KL brings evaluation closer to the model's predictive output. It requires reconstructing logits with the correct probe baseline, marginal component, and row offset before softmax. The context-interaction head's advantage over random and marginal baselines in KL therefore shows more than low Euclidean error. It improves the probability distribution on unseen rows. The oracle-temperature analysis asks whether that improvement is only a scalar sharpness correction. Its negative result on the averaged table strengthens the directional interpretation there; its inconclusive result on the composed-pair table prevents that interpretation from being exported automatically.

KL also creates its own cautions. It is nonlinear, depends on the selected-token normalization, and may value directions differently when other directions are present. The direct head-swap and head-ablation experiment was important precisely because a head-versus-tail diagnostic disagreement could have been attributed too quickly to softmax gating. When the mid-tail benefit stayed almost unchanged across own, swapped, absent, and random heads, functional gating lost support. The correct lesson is not that KL is problematic, but that interpretations of its rank curves require direct mechanism tests.

### 10.6 Why negative and corrected results strengthen the final claim

Several hypotheses failed: a naive averaged-shuffle control incorrectly made probe concentration look trivial; a ratio of real and null scaling slopes confounded axes and was discarded; the predicted monotonic response to increasing order corruption did not replicate; a handicapped marginal baseline created a false interaction-only behavioral dissociation; an apparent low-energy calibration manifold disappeared against a matched-dimension control; and a proposed dependence of mid-tail value on the leading head failed a direct intervention.

These failures converge rather than fragment the story. Each removes an overbroad explanation and leaves a narrower result that survives. Probe concentration is real only after symmetric deflation. Token-breadth interaction growth is established by its raw residual slope rather than a null ratio. Content identity matters more than word order, but no monotonic order law is claimed. Both marginal and interaction channels predict fallback under fair fitting. The static information-bearing structure is concentrated in a small head. Head and mid-tail are approximately separable under the direct test rather than functionally gated.

The result that survives this sequence is strong because it is modest. A low-dimensional, train-learned interaction head carries reproducible probability information about unseen context effects. It is not the whole spectrum, not the only behaviorally relevant channel, not a pure topic basis, and not a universal semantic manifold. Scientific confidence comes from knowing exactly which tempting alternatives were tested and rejected.

### 10.7 A reporting standard for future logit-table work

The accumulated evidence implies a concrete reporting standard. Every low-rank claim should state the query family, row and column semantics, selected-token rule, transform, train/test split, target metric, and control. Singular values should be accompanied by reconstruction. Reconstruction at each rank should be accompanied by an equal-dimensional random or covariance-destroying reference. Any averaging claim should use a variance-matched control and verify that common profiles are handled identically. Corruption comparisons should report output entropy and row similarity to detect fallback. Any linguistic label attached to a subspace should be tested against a plausible reductive basis, such as frequency, format, topic, or temperature.

Following this standard changes the style of conclusion. Instead of saying that a model or language is low-rank, one can say that a rank-8 basis learned from the double-centered context-influence table improves held-out selected-token KL over an eight-dimensional random basis under a fixed token rule. The latter is longer, but it is falsifiable, reproducible, and scientifically interpretable. The experiments summarized here show that this precision is not bureaucratic caution. It is what distinguishes genuine interaction structure from the many artifacts that produce the same visual spectrum.

## 11. Limitations and Open Questions

The evidence is unusually rich for a single black-box setting, but its scope is narrow. All major claims concern one model and one local text source. Selected-token dimensions range from 20 to 200; probability metrics renormalize over those subsets. A result on selected-token KL may not survive full-vocabulary evaluation, especially if omitted tail tokens respond differently.

The useful ranks near 4 and 8 are not model constants. They depend on training-row count, token rule, probe arrangement, target, and matched control. A larger training sample could support stable estimation of additional directions. Conversely, a more stringent held-out axis could reduce the rank. The proper claim is that useful rank is far below energy rank in the tested regimes, not that the model has exactly eight latent factors.

Centering and deflation are operational decompositions. Double-centering cleanly removes additive row and column effects, but an interaction need not correspond to a single linguistic mechanism. Explicit profile projection targets a measured direction but can leave other one-way components. Neither procedure proves causal separability inside the model.

The lexical content/format classifier is coarse. Content localization survives frequency matching and has some unsupervised geometric support in the underlying evidence, but subword form, morphology, plausibility, and lexical identity remain entangled. Likewise, context-only snapshot geometry is only a proxy for topic. The topic-orthogonal predictive factor is established numerically but unnamed scientifically.

Corruption controls are informative but imperfect. Word and token shuffles alter multiple properties simultaneously, including local plausibility and tokenizer boundaries. Frequency-matched replacement holds frequency bands but changes morphology and contextual fit. Measured naturalness adjustment reduces confounding but cannot eliminate unmeasured variables. Behavioral associations should therefore remain observational.

Several attractive interpretations were explicitly falsified or narrowed. The low-energy tail of the static interaction table does not generally beat an equal-dimensional random subspace. Mid-tail directions are not supported as functionally gated by the head. The interaction channel is not the sole predictor of fallback collapse when the marginal channel receives a fair fitted baseline. Word order is not irrelevant, merely less influential than content identity for one aggregated static interaction metric. The content/format split has not been directly mapped onto temporal semantic/syntactic subspaces. Preserving these negative results is essential because each prevents a local geometric fact from becoming an unsupported theory of language.

The next decisive experiments are clear. Replicate the matched-dimension information-rank analysis across model scales and tokenizers; evaluate full-vocabulary or importance-corrected KL; hold out probe families as well as contexts; compare position-resolved and probe-averaged tables to isolate order sensitivity; and directly test whether static interaction directions predict coordinates in temporal repair tables. Those studies would determine which parts of the present geometry are model-specific, construction-specific, or genuinely recurrent across language-model systems.

## 12. Conclusion

Black-box next-token logits do contain reproducible low-rank structure, but the structure becomes scientifically meaningful only after the table and the null are defined together. Raw snapshot tables are dominated by a nearly context-invariant token profile. Natural text beats a marginal-preserving floor yet can be higher-rank than corrupted text because corruption drives a collinear fallback. Composed context-effect tables provide stronger evidence: low-rank factors predict context-by-probe combinations that were never used for fitting, and the advantage survives additive residualization, control-order changes, row normalization, fresh seeds, and naturalness perturbations.

The most robust object is a double-centered context-by-token interaction subspace. It generalizes across unseen contexts, beats marginal, permuted, Gaussian, and matched-rank random baselines, and appears in both probe-averaged and non-averaged composed arrangements. Its genuinely better-than-random predictive dimensionality is small, around 4-8 in the tested samples, even though 90% of its singular-value energy requires roughly 25-27 dimensions. This separation between information rank and energy rank is the central quantitative result.

No single scalar rank unifies all tables. Token breadth widens the interaction; context length mainly changes a one-way channel; averaging over probes preserves some shared predictive structure while erasing probe-specific interaction; temporal repair shows a sharp predictive bottleneck with a broad tail. Topic, content identity, naturalness, and output temperature each explain part of the geometry, but none reduces it completely.

The answer to the motivating question is therefore conditional and affirmative. Nontrivial low-rank structure is present when contexts are represented by their residual influence on shared next-token predictions and when usefulness is tested out of sample against dimension-matched controls. It is not a global property of language or even of logits. It is a family of predictive subspaces whose rank is defined by the construction, transform, target, and hardest control.

## Source Basis

This synthesis is based entirely on the local experimental record. The most important full papers underlying the numerical claims were: *Crossed Low-Rank Transfer in Residualized Context-Effect Logit Tables*; *The Control Determines the Conclusion*; *The Two-Sided Unigram Confound*; *Interaction Structure Survives Profile Deflation in Non-Averaged Logit Arrangements, but Probe-Averaging Destroys It*; *Counting Is Not Scaling*; *Operations Define the Object*; *Two Budgets*; *Identity over Order*; *Naturalness Does Not Explain It Away, but Neither Is the Interaction Subspace Alone*; *Information Is Not Energy* and its later correction; *How Many Dimensions of Context Actually Generalize?* and its update of record; *Plural Low-Rank Structure*; *The Interaction Budget Generalizes*; *What Does the Low-Rank Interaction Head Encode?*; *The Step-Update Bottleneck*; *The Non-Linear Geometry of Syntactic Repair*; and *Spectral Decomposition of Semantic Integration in Natural Text*. Quantitative statements above preserve the later corrections recorded by their authors.
