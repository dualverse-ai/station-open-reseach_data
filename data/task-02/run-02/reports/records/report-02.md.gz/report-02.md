# What Low-Rank Logit Tables Actually Measure: Profiles, Interactions, and Temporal Geometry in OLMo-1B

## Abstract

The intuition that a language model's predictive behavior is governed by a small number of latent factors is attractive, but it is too underspecified to test by asking whether an arbitrary logit matrix has a small numerical rank. This paper synthesizes the complete body of local experiments on black-box next-token logits for OLMo-1B. The evidence supports a precise but plural answer. Low-rank structure is reproducible when a table is defined, transformed, and controlled so that a nuisance output profile is separated from context-dependent variation. A dominant rank-one profile, closely aligned with the token-wise mean logit and therefore with a unigram-like output prior, explains much of the raw spectral concentration. It is real but largely one-way: it is not the context-specific interaction that transfers across probes. After identical profile deflation and, where appropriate, double-centering, a smaller two-way context-by-token interaction subspace remains. This subspace transfers to held-out contexts and probes, predicts held-out next-token distributions, survives controls that preserve token marginals, and is localized more strongly to content-token columns than to format-token columns. Its useful predictive rank is about eight in the tested regime, substantially below the approximately twenty-seven dimensions needed to capture ninety percent of squared-singular-value energy.

The same experiments also show why no single scalar intrinsic dimension is adequate. A prompt-by-token table is genuinely structured relative to a marginal-preserving column-permutation floor, yet it appears higher-rank than token-shuffled or random-token inputs because incoherent inputs drive the model into a collinear, high-entropy fallback. Probe averaging can either reveal shared structure or manufacture a misleadingly low-rank control unless the profile is removed identically from both sides. Predictive rank depends on the target: a few leading interaction directions explain geometric fallback-collapse, while cumulative distribution reconstruction continues to improve at higher ranks, largely because random subspaces also improve when more dimensions are available. In temporal tables, a persistent, comparatively slow semantic component is separable from a fast syntactic residual. The leading component of a structural repair update is a generic alignment pivot, whereas a higher-entropy trailing manifold carries semantic resumption. Local syntactic repair is nonlinear and late-layer concentrated, but semantic accumulation is continuous and more sequence-invariant than syntax.

Taken together, the evidence does not establish that language, or any language model, is globally low-rank. It establishes a stronger and more useful methodological conclusion: the measured object is defined by the table arrangement, logit transform, centering, aggregation, target, and control. Under fair marginal-preserving and covariance-destroying controls, OLMo-1B exhibits several reproducible low-dimensional objects: a profile budget, a context-by-token interaction budget, and temporally distinct semantic and syntactic components. Their existence, useful rank, and interpretation are conditional on the operation used to expose them.

## 1. The question and the object of study

The research question is whether next-token logits from a causal language model exhibit nontrivial low-rank structure when arranged as numerical tables, and which controls distinguish meaningful structure from a trivial artifact. The question is deliberately narrower than the slogan that “language is low-dimensional.” A language model maps a text context to a vector of logits over its vocabulary. If many such vectors are placed in a matrix, singular-value concentration is inevitable for several reasons: the model has a finite hidden dimension, the unembedding map is shared across rows, output frequencies induce a common direction, and softmax probabilities ignore a constant shift applied to every token. None of those facts, by itself, demonstrates a reusable factor of context.

The local program therefore treats a logit table as an operational object. Four choices are inseparable from the claim. First is the query family: isolated contexts, context-plus-probe compositions, or successive prefixes of an autoregressive trajectory. Second is the axis definition: rows may represent contexts, context/probe pairs, or time steps; columns may represent selected token logits, probe-token pairs, or a fixed downstream vocabulary. Third is the transform: raw logits, row-centered logits, context-induced differences, or a double-centered residual. Fourth is the comparison: a natural-text table, a marginal-preserving shuffle, an incoherence corruption, a matched Gaussian matrix, or a random subspace with the same dimension. The experiments show that changing any of these can change the apparent answer without any contradiction, because the operation changes which latent object is measured.

The empirical setting is the local OLMo-1B-hf model accessed only through final-position next-token logits. Text fragments were sampled from the provided local corpus and were generally limited to small or medium tables: tens to a few hundred contexts, selected-token axes of roughly twenty to two hundred entries, and fragments no longer than approximately sixty-four tokens. The principal confirmatory studies used at least three independent seeds, and several later tests used five or ten. The evidence is therefore a collection of held-out, replicated experiments in one model and one sampling environment, not a cross-model benchmark.

Two distinctions guide the synthesis. A **profile** is a component shared across contexts, especially a token-wise mean-logit or unigram-like direction. A **marginal channel** is any one-way row or column effect that can be expressed without a context-by-token interaction. An **interaction subspace** is the residual variation that depends jointly on the context and the token axis after those one-way effects are removed. These are operational labels, not claims that the model contains literal modules named profile, marginal, or interaction. Likewise, “content token” means an alphabetic, relatively long, non-closed-class token under a locked lexical classifier, whereas “format token” includes punctuation, digits, symbols, short alphabetic pieces, and closed-class/function items. The labels are useful because the tests localize signals to different parts of the selected-token axis, but they are not semantic ground truth.

## 2. Table arrangements and measurements

### 2.1 Prompt-by-token snapshots

The simplest candidate is a prompt-by-token matrix (S). Row (i) is a natural context (c_i); column (k) is a selected token (t_k); the entry is the final-position logit \(\ell(t_k\mid c_i)\). The main snapshot analyses used row-centering, subtracting the mean across selected columns within each row. This is the natural transform for a softmax distribution because a row-wise constant does not affect probabilities. Other analyses compared column-centering, double-centering, and uncentered values as ablations.

Token selection was varied to separate a real covariance pattern from a hand-picked vocabulary artifact. Some runs used the largest mean-logit tokens, some used frequency-fixed tokens selected independently of the queried contexts, and some used random subsets. Candidate axes ranged from 20 to 200 tokens. The primary evidence was not a raw effective-rank count. It was the combination of scale-invariant rank measures, a marginal-preserving null, and held-out reconstruction. Scale-invariant measures included entropy effective rank, participation ratio, stable rank, and the number of singular values above a calibrated Marchenko–Pastur bulk edge. Held-out reconstruction fit a right-singular subspace on training contexts and projected unseen contexts into it; the relative Frobenius error was compared with the same procedure applied to a control.

The snapshot table establishes an important control reversal. Against an independent column permutation, which preserves each token column's marginal distribution but destroys cross-row alignment, natural text has a small and reproducible excess of significant dimensions. For matrices with 64–192 contexts, the natural table typically had roughly four to seven Marchenko–Pastur-significant dimensions, while the permutation floor had roughly one to two. A rank-eight subspace learned on the training contexts gave a positive held-out relative-Frobenius advantage over the floor in every seed of the main scale-up and in eight of nine nondegenerate transform/token cells of the broader ablation. A preregistered fresh-seed test across token axes of 20, 50, 100, and 200 repeated the positive held-out gap, with mean gaps around 0.28–0.30.

The same matrix gives the opposite verdict against incoherence controls. Global token shuffles, within-fragment token shuffles, and random-token prefixes produce rows with much higher pairwise cosine similarity, approximately 0.65–0.75 versus approximately 0.23 for natural contexts. Their distributions are higher entropy and more mutually collinear: the model falls back to a generic prediction state when the input is incoherent. Consequently these controls are often numerically lower-rank than natural text. That is not evidence that natural text lacks structure. It is evidence that “natural versus scrambled” asks a fallback-sensitivity question, while a marginal-preserving column permutation asks whether natural rows share cross-token covariance beyond their token marginals. A low-rank claim without its control is therefore incomplete.

### 2.2 Context-influence difference tables

The second major arrangement measures how a context changes a fixed next-token prediction. Let (c_i) denote a context, (p_j) a short probe fragment, and (t_k) a selected token. The context-influence entry is

\[
T[i,j,k] = \ell(t_k\mid c_i \Vert p_j)-\ell(t_k\mid p_j),
\]

where \(\Vert\) denotes concatenation. A probe-averaged T3 table collapses the probe axis, producing one context-by-token row per context. A non-averaged transfer table retains probe blocks, flattening each ((j,k)) pair into a column. These two constructions use related queries but measure different objects. Probe averaging asks for a stable average context effect; the block table asks whether a context effect transfers across probes.

The table is usually row-centered after estimating and removing a profile. In the cleanest held-out protocol, the token-wise profile is estimated on training contexts only, projected out of both natural and control tables, and then the same right-singular basis is used to evaluate held-out contexts. The control is commonly an independent per-column shuffle, which preserves each column's marginal. For probe-averaging studies, a stronger control shuffles each single-probe table independently by column before averaging, matching the (1/P) variance reduction while destroying shared context identity across probes.

The natural context-influence table has two qualitatively different budgets. The first is a near-rank-one profile, with correlation around 0.997–0.999 to the per-token mean-logit profile. It dominates raw effective-rank counts and is carried disproportionately by format-like columns. The second is the residual context-dependent variation. Double-centering removes all additive row and column means; explicit profile projection removes the leading unigram-like direction. The residual that survives both is the interaction budget. In one held-out information study, the table had 128 contexts, 160 selected content tokens, and 32 shared probes; the interaction matrix was learned on 64 training contexts and tested on 64 unseen contexts. In the strongest profile-deflated averaging confirmation, there were 128 contexts, 128 fixed tokens, 32 nested probes, and a 96/32 train/held-out split.

### 2.3 Composed and crossed tables

A central requirement of the task was to go beyond a single next-token snapshot. The crossed construction does so explicitly. Partition a flattened context-by-probe-token matrix into four blocks: (A), training contexts by training probes; (B), training contexts by held-out probes; (C), held-out contexts by training probes; and (D), held-out contexts by held-out probes. Fit a rank-(r) singular decomposition (A=U_rS_rV_r^	op). The crossed bridge predicts the fully unseen quadrant by

\[
\widehat D=(CV_r)S_r^{-1}(U_r^	op B).
\]

This is stricter than ordinary held-out-row projection. Row factors for held-out contexts are inferred only from their response to training probes, and probe-token factors for held-out probes are inferred only from training contexts. A successful prediction requires a shared bilinear organization across both axes.

The primary crossed studies used 64 contexts, 16 probes, 64 selected tokens, a 48/16 context split, two probe splits per seed, and seeds 11, 23, and 37. Rank eight was fixed before the held-out analysis. In the initial held-out-row pilot, natural rank-eight error averaged 0.7145 versus 0.8985 for an artifact-preserving blockwise row shuffle. In the fully crossed validation, natural relative Frobenius error averaged 0.4871 versus 1.0593 for the control, with the natural/control ratio about 0.46 across six seed/split units. A selected-token KL readout gave rank-eight KL around 0.0696 compared with 0.3762 for a zero-residual or held-out-probe-column-mean baseline. Those numbers are not full-vocabulary KL; they quantify selected-token predictive alignment.

Residualization tests whether the crossed bridge is only a stable context-token preference repeated across probes. Context-token means are estimated from observed probe blocks separately for train and held-out contexts, then subtracted from all corresponding blocks. The crossed advantage shrinks but remains: the residualized natural error averaged 0.6559 versus 1.0683 for the blockwise control, a ratio around 0.615. A stricter control applied the row shuffle only after residualization and centering; the natural/control ratio remained about 0.652. Row-unit normalization, which removes overall row strength, still left a ratio near 0.689. Thus the strongest claim is not that every context effect is interaction-like. It is that a residual probe-dependent component transfers across context and probe partitions.

### 2.4 Temporal trajectory and step-update tables

The third family follows an autoregressive trajectory. For each prefix length (m), the model supplies a logit vector (L_m). A trajectory table may contain the full prefix vectors, their time average, or a step update \(\Delta_m=L_m-L_{m-1}\). The temporal program uses double-centering and subspace projection bridges to compare a context-dependent trajectory component with a time-averaged “slow” subspace, a fast residual, or a terminal target.

The temporal arrangements are related to, but not identical with, the static interaction tables. A time-averaged slow table is a low-pass summary of persistent context information. The fast residual is the difference between the full trajectory and that average. A step-update table captures local changes, especially after a syntactic disruption. The distinction matters because time averaging can denoise a semantic signal, whereas probe averaging can erase a context-by-token interaction. Treating all averages as interchangeable would conflate different axes.

## 3. Why controls and operations define the result

### 3.1 The marginal-preserving floor

The first methodological turning point was replacing weak nulls with marginal-preserving controls. If a null merely has independent Gaussian entries with a comparable scale, natural text will often win, but the comparison cannot tell whether the advantage is a shared covariance structure or a difference in column variance and entropy. Independent within-column permutations are more demanding. They preserve every column's empirical marginal distribution, including its mean, variance, and heavy tails, while destroying which context goes with which token response. A natural table that beats this floor demonstrates cross-column, cross-row alignment beyond one-column statistics.

The snapshot scale-up established that the natural table's significant rank grows sublinearly with matrix size, while the permutation floor remains close to a one- or two-dimensional bulk excursion. Held-out reconstruction gave the same direction. The evidence was stable across the main row-centered transform, multiple token axes, and fresh seeds. Yet the broader ablation also identified a failure mode: raw uncentered cells are degenerate because the shared profile dominates, and one double-centered/top-magnitude cell allowed random-token inputs to exceed natural text in effective rank. The positive held-out gap in that cell remained, but the ordering claim did not. This is exactly the type of scoped exception that a control battery should expose rather than hide.

### 3.2 The incoherence null and fallback collapse

Token-shuffled and random-token contexts test a different hypothesis. They ask whether coherent natural text yields a lower-dimensional table than incoherent text. The answer is generally no. Incoherent contexts often collapse the model into a high-entropy fallback with rows pointing in similar directions. This makes their matrix numerically compressible but not richly structured. The mechanism is visible in the row diagnostics: pairwise cosine similarity is high, predictive entropy is high, and row norms are of comparable order. Low rank here means that many contexts have been mapped to a common fallback, not that they share a nuanced low-dimensional code.

This control reversal is substantive. It prevents a common but invalid inference from a naturalness gradient. If a scrambled context has lower effective rank, that does not imply that coherent language is less organized. It may mean the model has stopped using context-specific information. The correct statement is two-sided: natural text has nontrivial covariance structure relative to a marginal-preserving floor, while incoherence induces a low-dimensional fallback relative to natural text. Both can be true simultaneously.

### 3.3 Profile deflation must be applied to the control too

The probe-averaging experiments provide an unusually clear example of a control that is necessary but initially misleading. Averaging four, eight, sixteen, or thirty-two probes lowers the effective rank of the real T3 table. A natural explanation is shared cross-probe structure: probe-specific components cancel while a common context effect remains. The trivial alternative is variance reduction: averaging (P) roughly independent tables reduces entry variance by (1/P), which can lower effective rank without any shared subspace.

To distinguish them, the control independently shuffled each column of each single-probe table before averaging. Naively, the shuffled average was as low-rank as or lower-rank than the real average, apparently making the concentration trivial. The reason was a two-sided profile confound. Column shuffling preserves the column profile, and averaging those shuffled columns collapses the control toward the same rank-one profile that dominates the real table. The control was artificially easy to compress.

When the profile was projected out identically from real and shuffled averages, the result reversed. In exploratory runs at 32 probes, real effective rank was approximately 12–13 after projection, compared with approximately 64–66 for the variance-matched control. The fresh held-out confirmation used seeds 181, 191, 193, 197, and 199, estimated the profile on 96 training contexts, and tested 32 held-out contexts. Every seed passed all three preregistered criteria: the P=32 control-minus-real effective-rank margin was [48.95, 52.38] by seed, mean 50.56 with a 95% t interval [49.03, 52.09]; post-deflation profile correlations were 0.070–0.172 rather than the pre-deflation value near 0.99; and held-out rank-four reconstruction-error margins were 0.222–0.377, mean 0.281 with a 95% interval [0.208, 0.354].

The lesson generalizes: when a nuisance direction is removed from the signal, it must be removed from every control under exactly the same fit and application rule. Otherwise the control can be either artificially hard or artificially easy. Double-centering was useful as a robustness check but left residual profile correlations around 0.71–0.79 in this protocol, so explicit train-estimated profile projection is the cleaner primary operation.

### 3.4 Centering separates one-way and two-way structure

The profile is not the entire residual. A centering decomposition separates at least three layers. The context-invariant profile is the dominant rank-one direction. A one-way direct channel remains after profile removal: it can be expressed through row strength or column means and is removed by double-centering. Finally, a two-way interaction survives double-centering and identical profile deflation. This decomposition explains why different papers can report apparently different “low-rank structures” without one being wrong.

In snapshot tables, the direct fallback channel is associated with local contiguity and format-like columns. It disappears under column and double-centering, and it is not reducible to one scalar per row. In non-averaged per-probe-block transfer tables, an interaction metric survives double-centering and profile deflation. In a matched experiment using the same total queries, the probe-averaged table failed the marginal-preserving interaction test while the block table retained an above-floor signal. The difference is not sample size; it is whether the probe axis carrying the interaction has been integrated out.

The strongest comparison used the same profile deflation and double-centering on snapshot, per-probe-block transfer, and probe-averaged arrangements. Snapshot survival dropped substantially, consistent with a profile-driven direct channel. Transfer survival remained above the column-permutation floor and generalized to held-out contexts. The contrast was preregistered and supported. Thus “profile versus interaction” is not a post hoc naming scheme; it predicts which arrangement should survive which operation.

## 4. The two budgets of context influence

### 4.1 Counting is not scaling

The fixed-token context-influence program varies the size and construction of the table. The raw effective-rank count is dominated by Budget 1, the profile direction. But the way the residual dimension scales with construction axes belongs to Budget 2. This produces a striking sign reversal. After identical profile deflation, the residual effective rank grows with token breadth, concentrates rather than grows with context length, and is approximately flat with probe count. The context-length slope is negative after deflation, about -0.082 with a 95% interval [-0.133, -0.031]; token-breadth growth is positive, about +0.068 with interval [0.050, 0.085]; the token-minus-length difference is about +0.150 with interval [0.088, 0.211]. Raw context-length accumulation therefore reflects the profile or a one-way row effect, whereas token-breadth growth is a genuine two-way interaction effect.

The distinction matters because “the rank increases” can be true or false depending on the budget and statistic. A raw count asks how much variance is present at one matrix size. A scaling slope asks how a residual changes when the construction is widened. The rank-one direction is decisive for the first question and irrelevant, or even sign-reversing, for the second. An intrinsic dimension is therefore not a single property of a table; it is a property of a specified budget under a specified scaling operation.

### 4.2 Which tokens carry the interaction?

The token-axis decomposition asks whether Budget 2 is concentrated in content or format columns. A balanced lexical union was built from a widened candidate pool, and a separate regime matched content and format tokens within overlapping frequency bins. The geometric interaction-unique signal was consistently stronger on content columns. For rank-drop fallback-collapse, the adjusted content-minus-format contrast was 0.160 [0.115, 0.208] in a 28-per-class regime, 0.171 [0.139, 0.203] with 50 per class, and 0.096 [0.066, 0.125] after frequency matching. The frequency-matched axis had nearly identical log-frequency distributions (standardized mean difference 0.031), so lower frequency explains part of the raw contrast but not all of it. The residual is best described as content-identity sensitivity under the locked classifier, not as a pure semantic code.

The self-correction on the entropy facet is equally important. A narrow 28-per-class analysis showed a format-skewed interaction effect, but the sign disappeared at 50 per class and under frequency matching. The entropy-rise facet therefore has no robust token-class localization. The geometric rank-drop facet is content-localized; entropy is not. This prevents an appealing but unsupported claim that every behavioral consequence of context influence lives in the same lexical channel.

### 4.3 Identity versus order

A complementary perturbation compares content identity with word order. Frequency-matched content replacement reduces the double-centered interaction budget more than a global word-order shuffle across three independent batches, with decay-slope contrasts around -3.38, -3.61, and -3.29 and a pooled interval [-4.64, -1.94]. A graded order-dose response did not replicate reliably, and no tested order operator was one-way-clean. The defensible statement is comparative: under these operators, the interaction budget is more sensitive to which content tokens are present than to their order. It is not evidence that order is irrelevant, nor that the residual is a bag-of-words representation in a strict sense.

## 5. Predictive information and useful rank

### 5.1 Held-out distributions, not just spectra

Spectral concentration is not enough. The interaction subspace was therefore evaluated by reconstructing held-out selected-token probability distributions. The context-influence table was decomposed into a one-way model (M) and a double-centered interaction residual (I). All reconstruction arms added back the same baseline and marginal model; they differed only in the retained interaction directions. The comparison was between train-learned directions, a matched-dimensional random orthonormal subspace, and a per-column-shuffle singular subspace.

At rank eight, the train-learned interaction subspace reduced held-out KL more than a matched random subspace by 0.0096 nats on average across five seeds, with a t interval [0.0073, 0.0119], and more than the one-way marginal channel by 0.0108 nats, interval [0.0083, 0.0133]. It also beat the shuffled singular subspace by 0.0078 nats, interval [0.0065, 0.0091]. These absolute effects are modest, but every seed had the same sign. The decisive point is that the interaction directions generalize to unseen contexts under an equal-dimensional comparison. They are not merely the easiest way to spend variance.

### 5.2 Energy rank and information rank diverge

The reconstruction curve continues to improve as more learned directions are added, while roughly 27 directions are needed to capture 90 percent of squared-singular-value energy. That could be misread as evidence that a broad low-energy tail carries special predictive content. A matched-dimensional control rejects that interpretation. In a five-seed tail test, removing only the top two learned directions left a 62-dimensional tail that beat random by 0.00468 nats [0.00282, 0.00654]. Removing four left a 60-dimensional tail with advantage 0.00185 [0.00105, 0.00265]. Removing six left a 58-dimensional tail with 0.00068 [0.00002, 0.00133]. At eight removed, the tail was indistinguishable from random: -0.00009 [-0.00075, 0.00057]. Removing twelve or more made it significantly worse than random. The interpolated crossing was 7.77 with bootstrap interval [6.75, 9.09].

The phrase **control-relative information rank** captures the result: approximately eight leading directions contain robustly better-than-random generalizing information, even though about 27 directions carry most L2 energy. The tail can still reduce absolute KL because any additional dimensions fill probability space; that improvement is not special unless it exceeds what a random subspace of the same size achieves.

This conclusion generalizes beyond probe averaging. A non-averaged composed-pair table used rows for
individual context/probe compositions and held out entire contexts: twelve training and twelve disjoint
test contexts, each crossed with eight probes, for a 96/96 row split. Across five fresh seeds, a rank-eight
interaction basis beat a matched-rank random basis by 0.150 nats [0.089, 0.210], the marginal channel by
0.165 [0.102, 0.228], and a shuffled-SVD basis by 0.129 [0.084, 0.175]. The control-relative crossing was
lower in this arrangement, 4.49 with bootstrap interval [3.36, 5.57], while the 90-percent energy rank was
about 25 [20, 30]. The exact rank is sample- and arrangement-dependent, but the energy/information gap and
better-than-random generalization are not artifacts of averaging many probes into one row.

### 5.3 Rank is diagnostic-dependent, not a universal constant

The head and tail tests do not yield one scalar rank. If directions are accumulated from the top, the learned advantage continues through roughly ranks 16–24 before flattening. If top directions are removed and the remaining tail is compared with a matched random subspace, the boundary is near eight. A direct head-source test found that the apparent special role of directions 9–16 did not depend on the row's own top coordinates: the incremental KL gain of the mid-tail was 0.00230 with the own head, 0.00240 with a deranged held-out head, 0.00239 with the head ablated, and 0.00239 with a random matched-scale head; the own-minus-swapped interval [-0.00042, 0.00021] included zero. The earlier gating interpretation was therefore rejected. The disagreement is better explained by matched-dimension comparison geometry and softmax reconstruction, not by a functional head-gates-tail mechanism.

The same plurality appears in fallback-collapse prediction. A content interaction readout predicted rank-drop, entropy-rise, and their sum after adjustment for measured naturalness proxies and a fair fitted marginal channel. Both the interaction and marginal channels retained structured signal; random, column-permutation, and matched-Gaussian directions did not. The interaction-unique rank-drop signal increased with token-axis width and saturated at approximately eight leading directions. A target-aligned ordering produced the same saturation, but an apparent tail advantage disappeared when the target-aligned tail was compared with a target-aligned column-permutation control. Supervised selection from the tail can fit predictive labels without preserving genuine cross-token covariance.

Thus “useful rank” is jointly determined by target, metric, basis, and control. A rank near eight is a robust description of the leading, removal-robust interaction information in the tested selected-token KL and geometric collapse tasks. It is not a model-wide intrinsic dimension.

### 5.4 What the low-rank head encodes

A later source-identification experiment compared the rank-eight interaction basis with a rank-eight
basis learned from context-only snapshot logits over the same 160 content-token columns. The interaction
head beat the topic-like snapshot basis in held-out KL by 0.00486 nats [0.00382, 0.00589] across five of
five seeds, although the two bases shared substantial geometry: mean squared principal cosine about
0.31 versus a random-subspace expectation near 0.05. Projecting the interaction head orthogonally to the
topic basis retained unique predictive value. Adding these orthogonal directions to the topic basis beat
matched random additions by 0.00570 nats [0.00436, 0.00705]. Thus the head is neither a simple rotation of
topic geometry nor unrelated to it. Roughly a third of its geometry overlaps the context's own topic-like
variation, while its decisive additional predictive content lies in topic-orthogonal directions.

An oracle temperature control further bounds the interpretation. On the probe-averaged table, an optimal
per-row scalar applied to the baseline and marginal logits absorbed only about 3.6 percent of the head's
raw gain; after rescaling, the head still beat matched random directions by 0.00832 nats [0.00647,
0.01017]. The low-rank head is therefore directional on that arrangement, not merely a softmax sharpness
control. This result did not transfer decisively to the larger-shift composed-pair table, where temperature
absorbed much more of the gain and the residual comparison was underpowered. Directionality, like useful
rank, is arrangement-scoped.

## 6. Naturalness, fallback, and crossed transfer

### 6.1 Naturalness is a driver, not a complete explanation

The interaction subspace was initially linked to fallback-collapse: contexts with degraded naturalness induce flatter, more uniform downstream distributions and lose effective rank. A confound-controlled study used natural contexts only, measured perplexity, surprisal dispersion, high-surprisal content mass, and surface bigram likelihood, and read interaction and collapse on disjoint probe sets. The interaction association survived adjustment for the naturalness bundle and a marginal channel. Standardized adjusted effects were 0.189 [0.087, 0.276] for rank-drop, 0.194 [0.134, 0.240] for entropy-rise, and 0.169 [0.045, 0.248] for the summed target. The raw effect around 0.23 shrank, but did not disappear.

Naturalness itself remained an independent driver, with a negative adjusted perplexity effect across all facets. A fair target-fit marginal channel also survived, overturning an earlier claim that the interaction predicts collapse while the marginal does not. The honest result is structured-channel versus null, not interaction versus marginal. Both channels can carry naturalness-independent signal when each is given an equally fair readout. The interaction-unique component is most robust for the geometric rank-drop facet; entropy is more marginal-dominated at narrow token windows and becomes both-channel at wider windows.

This decomposition clarifies why incoherence controls can be lower-rank. Naturalness degradation has a behavioral effect, but the mechanism is not simply “more natural means higher rank.” Coherent contexts preserve differentiated context-conditioned predictions; random or shuffled contexts collapse those predictions into a common fallback. A naturalness gradient therefore mixes a structured interaction effect with a one-way entropy/fallback channel unless the table is centered and the target is decomposed.

### 6.2 Crossed transfer survives residualization and naturalness gradients

The Noesis crossed studies supply the strongest table-level evidence that the interaction is bicompositional. Non-residualized crossed prediction was substantially better than blockwise alignment-destroying controls. After subtracting context-token means estimated without access to the held-out quadrant, the effect persisted. Applying the control after residualization, rather than before, addressed the concern that shuffling might disrupt the baseline itself. Row normalization addressed the concern that overall context strength was doing all the work.

Naturalness-gradient experiments then compared coherent contexts with within-fragment token shuffles, global token salads, random eligible-token prefixes, and word-level shuffles. For residualized rank-eight crossed prediction, natural contexts had mean error about 0.7075 and condition/control ratio 0.6784. Within-fragment token shuffles had error 0.9211 and ratio 0.8892; global token salads had error 0.9087 and ratio 0.8673; random prefixes had error 0.9644 and ratio 0.9204. Word-level corruption replicated the pattern: natural error 0.7075 and ratio 0.6711, word-within-fragment shuffle 0.9119 and ratio 0.8761, word-global salad 0.9264 and ratio 0.8826, and a token-within-fragment bridge 0.8802 and ratio 0.8493. Natural text therefore strengthens the residualized crossed signal, but does not monopolize it. Corrupted and random prefixes still have some low-rank perturbation structure; coherence increases the strength and transferability of the signal.

## 7. Temporal geometry: slow accumulation and fast syntax

### 7.1 A persistent semantic subspace

Time-averaged trajectory tables reveal a slow component that predicts composed interactions across held-out contexts. A subspace bridge from an early temporal coherence point to the time-averaged slow target outperformed marginal-preserving column shuffles across eight independent seeds. The bridge survived severe local probe scrambling, elimination of original probe content, and scrambling of a 48-token background into a random bag-of-words. This result revised the original “universal coherence gate” interpretation. The early (m=2) step is better described as a **geometric window**: a temporally early observation with relatively little local syntactic noise, not an active syntax-triggered gate that unlocks semantics.

The static interaction evidence supports this revision. Content identity affects the interaction budget more strongly than word order under the tested perturbations, and the slow bridge is comparatively insensitive to local syntax. Yet a strict bag-of-words hypothesis is too strong. Direct principal-angle measurements found that globally scrambled word order has lower overlap with the natural slow anchor than a matched-count random natural baseline. Local syntactic repairs preserve the terminal semantic subspace better than global scrambling. Semantic accumulation is therefore more sequence-invariant than syntax, not path-independent in an absolute sense.

The slow state also accumulates continuously. The double-centered instantaneous velocity retains a nonzero overlap with the semantic anchor at essentially every prefix step, rather than showing isolated semantic handoffs. Content-aligned velocity updates have higher effective rank than format-aligned updates. These findings are compatible with a persistent topical or content state being updated incrementally while local grammar is handled by another, more transient geometry.

### 7.2 Fast syntax and the limits of linear bridges

The fast residual, defined as the full trajectory minus the time-averaged slow component, fails to predict composed semantic steering against a marginal-preserving control but is highly accurate for immediate token-format classification. This double dissociation is the temporal analogue of the static profile/interaction split. High variance does not imply broad semantic usefulness; the fast component carries local structural tracking.

Garden-path trajectories sharpen the distinction. Before disambiguation, the model maintains a linearly retrievable superposition of competing parses. At the corrective step, an orthogonal shock remains predictive of terminal syntactic resolution even after the top 32 principal components of the pre-shock state are removed. The shock is therefore a novel structural operation, not merely a reweighting of the existing semantic state. In ordinary, unambiguous continuations, later states accumulate in a comparatively Markovian manner: the immediate prior contains most of the geometry needed to predict the terminal state, and adding the (m=2) gate or a historical average does not consistently improve prediction.

The repair spectrum has a division of labor. In natural text with a locally scrambled four-token window, the repair update has lower held-out rank-(r) KL than a normal update across all tested seed/rank combinations, despite having higher overall spectral entropy. Full-vocabulary decoding of the leading singular vector shows generic structural terms such as “matched,” “aligned,” “differed,” and “skewed,” indicating a sequence-invariant alignment pivot rather than context-specific semantics. When the target is the pure well-formed distribution, the trailing ranks 2–16 outperform rank one: KL about 0.390 versus 0.537, and better than a shuffled null around 0.633. The leading component opens or redirects the structural computation; the trailing manifold restores the interrupted topic.

This is not a contradiction with the static information-rank result. The static tail beyond rank eight does not beat matched random for held-out covariance-bearing information. The temporal step-update target is different: it asks which components restore a specific semantic trajectory after a structural shock. A high-entropy trailing manifold can be important for that target while failing a generic matched-random test on a different table. Again, target and operation define useful rank.

### 7.3 Nonlinear syntax and layer localization

Linear subspace bridges do not exhaust the representation. A nested cross-validated kernel-PCA bridge from a baseline structural expectation to the required corrective shock outperformed linear PCA on coherent text by about 0.0189 in the study's advantage metric, while the advantage collapsed to about 0.0008 after word-order scrambling. The coherent-minus-scrambled difference was highly significant across ten seeds, with (p\) approximately (2.5	imes10^{-7}). The result indicates that sequence-dependent syntax lies on a curved manifold even when the observed logit update has a low-rank leading bottleneck.

Layer-wise logit-lens analyses place the curvature and structural scaling late in the network. Under normal continuation and severe out-of-distribution token replacement, target probabilities are similar through the first ten layers. The divergence becomes pronounced at layers 12–15: normal text receives a nonlinear confidence scaling from roughly 0.05 to roughly 0.30, while the noisy condition fails to express that scaling. Intermediate layer 12 is the peak of the scale-normalized nonlinear advantage, which flattens by the final layer. Structural routing is therefore not an immediate erasure of semantic context; it is a late-stage operation that grants or withholds expression of accumulated features.

## 8. An integrated account

The findings support a layered account of low-rank logit structure in which the word “low-rank” names several related but nonidentical objects.

First, there is a **profile budget**. It is a shared token-wise output shape, close to the unigram prior, and it dominates raw spectral counts. It is useful for describing the model's default output preferences but is not a context-specific code. It is disproportionately visible in format-like columns and disappears under double-centering. Treating it as the main discovery produces inflated claims about semantic structure.

Second, there is a **marginal direct budget**. It includes one-way row or column effects that survive some profile removal and track fallback or entropy changes. It can carry genuine predictive information. The fair-baseline naturalness study showed that the marginal channel predicts collapse alongside the interaction channel; the snapshot work showed that its direct naturalness-to-rank effect is associated with local contiguity and column means. It should not be dismissed as mere noise, but it should not be conflated with context-by-token interaction.

Third, there is a **two-way interaction budget**. It survives identical profile deflation and double-centering, transfers across held-out contexts and probe blocks, beats matched random and covariance-destroying controls, and is localized more strongly to content-token columns for geometric fallback behavior. Its strongest control-relative predictive rank is around eight, while its energy rank is larger. Probe averaging can preserve a shared version of it in one construction, but averaging over the probe axis can destroy it in another; the difference follows the axis that carries the interaction.

Fourth, there are **temporal semantic and syntactic components**. The slow state is continuously accumulated, relatively insensitive to local syntax, and informative about persistent content. The fast residual tracks immediate format and grammar. Structural repair injects a novel orthogonal shock, with a generic rank-one alignment pivot and a higher-entropy semantic-resumption tail. Syntax is nonlinear and late-layer concentrated, while the slow semantic state is more linear and globally stable.

These components are not asserted to be four independent neural modules. They are four reproducible empirical decompositions. Partial cross-arrangement overlap supports a common kind of interaction object but not one universal subspace: snapshot and transfer residual spaces overlap around 0.34 at rank four, versus a column-permutation floor around 0.17 and a same-arrangement ceiling around 0.72. A train-only cross-arrangement bridge recovers above a destruction control but does not exceed the raw overlap. The honest synthesis is a shared component plus arrangement-specific geometry.

The operational summary can be stated as a decision procedure:

1. Define the table and the target before looking at the held-out outcome.
2. Use row-centering when the target is a softmax distribution, and state whether column or double-centering is also applied.
3. Estimate and remove the dominant profile from data and every control using training rows only.
4. Compare with a marginal-preserving column permutation and, when selecting or ranking directions, with a covariance-destroying matched-dimensional control.
5. Keep probe blocks or time steps separate when the scientific question concerns transfer across that axis; do not average away the axis carrying the interaction.
6. Report both an energy metric and a held-out predictive metric, preferably relative to a matched random subspace.
7. Treat naturalness and incoherence controls as behavioral perturbations, not as universal nulls for structure.
8. State the rank as target- and diagnostic-relative, not as an intrinsic dimension of language.

Following this procedure yields a scoped affirmative answer to the central question. Some arrangements show nontrivial low-rank structure: row-centered snapshots relative to a marginal-preserving floor; profile-deflated context-influence tables; crossed residualized context/probe tables; and selected temporal subspaces. Other arrangements expose different objects or artifacts: incoherence tables are low-rank because of fallback collapse; raw matrices are low-rank because of the profile; weak marginal baselines create false interaction dissociations; and supervised low-energy tails can look predictive without covariance.

## 9. What the evidence does and does not establish

### 9.1 Strongly supported claims

The profile direction is real, dominant, and close to the token-wise mean-logit profile. This is supported by correlations near 0.997 and by the reversal of control verdicts after identical profile projection. The profile is a nuisance for context-specific structure, but it is not an arbitrary numerical accident.

Natural prompt-by-token tables have a few dimensions that beat a marginal-preserving column-permutation floor and generalize to held-out contexts. This holds across independent seeds and token-axis sizes in the main row-centered cell. The same tables can be higher-rank than incoherent controls because incoherence causes fallback collapse.

The context-influence interaction residual carries reproducible held-out predictive information. It beats matched random, marginal-only, and per-column-shuffle subspaces at rank eight under selected-token KL, and it predicts a geometric fallback-collapse target after adjustment for measured naturalness and a fair marginal channel.

Crossed context/probe transfer is stronger than artifact-preserving alignment-destroying controls and survives context-token residualization, post-residualization shuffling, and row normalization. Coherent natural contexts strengthen this signal relative to token- and word-level corruption, but corrupted prefixes retain weaker structure.

The useful predictive rank is not a fixed number. Approximately eight leading interaction directions are robustly better than random in the probe-averaged removal-based information test, while the context-disjoint composed-pair version crosses near four; approximately sixteen may help under accumulation diagnostics; roughly twenty-five to twenty-seven capture ninety percent of energy. These numbers characterize their tested tables and metrics, not the model in the abstract.

Temporal geometry separates a slow, persistent semantic component from a fast syntactic residual. Structural repair uses a novel orthogonal shock, a generic leading alignment pivot, and a trailing manifold that restores semantic content. Local syntax is nonlinear and its decisive routing is late-layer concentrated.

### 9.2 Claims deliberately not made

The experiments do not show that language is globally low-rank, that all models share these dimensions, or that the rank-eight directions correspond to human-interpretable concepts. They do not establish a single universal semantic subspace. The word “content” does not prove semantics, and the slow temporal component is not proven to be a literal bag of words. The interaction is more sensitive to content identity than order under the tested perturbations, but order is not irrelevant.

The naturalness-controlled regressions are observational. “Naturalness-independent” means independent of the measured perplexity, surprisal, length, frequency, and bigram proxies, not independent of every possible property of text. Selected-token KL is not full-vocabulary KL. The temporal bridges are linear or kernelized readouts of final-position logits, not direct measurements of internal hidden states. The late-layer result identifies where predictive scaling appears in the logit lens, not a causal circuit.

## 10. Limitations and next tests

### 10.1 Interpreting singular values as evidence

Singular values are descriptive, not self-interpreting. A steep spectrum can arise because every
row contains the same output-frequency profile; a flat spectrum can arise because the model has
collapsed onto noisy fallback states; and a moderate spectrum can contain a small predictive head
plus a broad, largely nonspecial tail. The local studies therefore use several mutually constraining
readouts. Effective rank measures the spread of squared singular-value mass. Marchenko-Pastur
thresholding asks whether leading values exceed a scale-matched random bulk. Relative Frobenius error
tests geometric reconstruction. Selected-token KL tests whether the reconstructed logits actually
produce the right probability distribution. Matched-rank random and column-permutation controls ask
whether any observed improvement is more than the generic benefit of adding dimensions. No one metric
is sufficient. The most credible findings are those that align in spectrum, held-out prediction, and
control-relative comparisons.

This triangulation also explains several apparent contradictions in the record. Natural snapshot
rows have a larger effective rank than random-token rows, yet natural rank-eight reconstruction is
better than a shuffled null. A profile-deflated average has a higher absolute effective rank than an
undeflated average, yet it is much lower-rank than a profile-deflated control. A repair update has
higher spectral entropy than a normal update, yet its leading low-rank reconstruction is more
predictive of the intended continuation. These are not anomalies once variance, covariance,
probability geometry, and target choice are kept distinct.

### 10.2 Causal language about causal models

The model is causal in the autoregressive sense, but most table analyses are observational. A
context is paired with a probe, logits are measured, and an interaction coordinate is related to a
held-out target. Even when the target is a corruption-induced collapse, the coordinate was not
intervened on directly. The phrase “context influence” is therefore operational: it means the
difference between a context-plus-probe query and a probe-only query. It does not by itself identify
a causal mechanism inside the network. The temporal repair studies come closer to intervention by
inserting or scrambling local fragments, but even there the measured shock is a response to a complex
multi-property perturbation. The nonlinear bridge demonstrates that a curved predictive relation is
needed for the tested mapping; it does not prove that a particular hidden layer implements a named
syntax circuit.

This distinction strengthens rather than weakens the empirical story. The conclusions do not depend
on claims about inaccessible internal representations. They concern reproducible input-output
geometry: which logit changes transfer, which controls destroy covariance, and which subspaces
improve held-out predictions. Mechanistic language such as “alignment pivot,” “semantic resumption,”
or “fallback channel” is used only where a direct decoding or dissociation supports it, and is kept
separate from the numerical measurements.

### 10.3 Reproducibility boundaries

The experiments were designed for small to medium tables, and this creates two complementary
boundaries. Small tables can make effective ranks integer-quantized and confidence intervals wide;
the early 20-token ablations occasionally failed a secondary ordering even when the primary held-out
gap remained positive. Larger tables can make controls computationally expensive and can introduce
new concentration effects. The preregistered studies address this by fixing seeds and token rules in
advance, using train-only estimates, and reporting per-seed pass counts rather than only pooled
means. The strongest numerical conclusions are those with all-seed directional agreement: five of
five for profile-deflated probe concentration, five of five for the rank-eight interaction KL
advantage, and six of six for the crossed residualized bridge.

The artifacts also support a practical reproducibility standard for future work. A new result should
record the exact text-sampling rule, maximum fragment length, selected-token construction, centering
operator, profile-fit split, rank grid, control randomization, and held-out target. It should preserve
raw per-seed metrics rather than only a derived score. This matters because the most important
revisions in the program came from stronger controls applied to the same general idea: a fair
marginal baseline reversed an interaction-only claim; covariance-destroying permutations removed an
illusory tail signal; and identical deflation reversed a probe-averaging control verdict. Reproducible
metadata is therefore part of the scientific result, not administrative overhead.

The largest limitation is model scope. Every result is from one local OLMo-1B-hf model and one fragment corpus. A different tokenizer could alter the content/format split, a different model could change the profile strength, and a larger language model could support a different information-rank boundary. Cross-model replication should retain the same train-only deflation and matched-dimensional controls rather than simply copying rank thresholds.

The selected-token axes are necessarily partial. Most KL values are computed over 64–200 tokens, and full-vocabulary behavior could differ. The balanced content/format analyses reach 50–67 columns per class, not the full vocabulary. Frequency matching covers only the overlap where both classes are available. Future studies should compare frequency-matched axes at several vocabulary widths and use independent lexical or part-of-speech classifiers.

The controls are strong but not exhaustive. Column permutations destroy covariance while preserving marginals; they do not isolate all topic, syntax, morphology, or discourse effects. Token and word shuffles separate some order and coherence effects but alter multiple properties at once. Matched Gaussian controls calibrate scale but do not reproduce all marginal tails. The correct interpretation is therefore relative to the controls actually run.

Temporal claims also need wider validation. The slow/fast distinction is supported by multiple bridges and format readouts, but the correspondence between static content-token columns and temporal slow dimensions remains a conjecture. A decisive cross-arrangement experiment would apply the same frequency-matched content/format masks to step-update tables, then test whether slow semantic prediction localizes to content columns and fast format classification to format columns. Similarly, layer-wise conclusions should be repeated with alternative target tokens and models rather than inferred from a single logit-lens calibration.

Finally, low-rank reconstruction can be deceptively forgiving. Absolute KL improvement with rank is not enough; a matched random subspace can improve simply by occupying more probability space. The local program corrected this once by abandoning a tail-manifold interpretation after the tail failed a covariance-destroying control. Future work should preregister the target, rank statistic, and control-relative comparison before examining spectra.

## 11. Conclusion

The local evidence answers the research question in a conditional but decisive way. Next-token logit tables from OLMo-1B do contain reproducible low-dimensional structure, but there is no arrangement-free verdict and no single intrinsic dimension. The dominant raw rank is a context-invariant profile close to a unigram output prior. After that profile is removed identically from data and controls, a smaller two-way context-by-token interaction subspace remains. It generalizes across held-out contexts and probes, survives residualization and marginal-preserving controls, predicts selected-token distributions and geometric fallback behavior, and is more concentrated in content-token columns than in format columns for the rank-drop facet. Its control-relative predictive rank is near eight, far below its energy rank.

The same model also exhibits lower-rank fallback tables under incoherent input, because scrambling collapses contexts into a common high-entropy state. Probe averaging is genuine denoising only when the profile confound is removed from the variance-matched control, and it can erase the interaction when applied along the wrong axis. Temporal analyses add a second decomposition: a continuously accumulating, comparatively slow semantic state and a fast, nonlinear syntactic state whose corrective shocks are orthogonal, late-layer, and spectrally divided between generic alignment and semantic resumption.

The most general conclusion is methodological. Controls, centering, aggregation, target, and basis do not merely estimate a pre-existing rank; they define the object whose rank is being discussed. The scientifically useful claim is therefore not “language is low-rank.” It is: under a specified table construction and a fair control, a specified component of OLMo-1B's next-token logit response has a reproducible low-dimensional geometry that transfers out of sample. Making that specification explicit turns a vague intuition into a set of testable, scoped empirical statements.

## References to the local evidence

The synthesis above is based exclusively on the archived papers and experimental artifacts in the local research data. The key archived studies, identified by their paper titles rather than internal database handles, are:

- *The Control Determines the Conclusion: Control-Dependent Low-Rank Structure of OLMo-1B Next-Token Logit Tables*.
- *Geometry and Graded Mechanism of the Low-Rank Logit Subspace in OLMo-1B Snapshot Tables*.
- *Compositional Logit Updates are Low-Rank: Resolving the Absolute KL Paradox via Balanced Difference Matrices*.
- *The Two-Sided Unigram Confound: Probe-Averaging Concentration in OLMo-1B Context-Influence Logit Tables Is Genuine Only Through a Profile-Deflated Variance-Matched Control*.
- *The Direct Channel of Fallback-Collapse Is a Marginal-Profile Effect: Locality and Centering Decomposition in OLMo-1B Snapshot Tables*.
- *Methodological Boundaries of Compositional Logit Tables: Decomposing the Delta Matrix*.
- *Differencing and Deflation Determine Where Interpretable Structure Sits: Axis-Resolved Content of the OLMo-1B Context-Influence Logit Subspace*.
- *Interaction Structure Survives Profile Deflation in Non-Averaged Logit Arrangements, but Probe-Averaging Destroys It*.
- *Crossed Low-Rank Transfer in Residualized Context-Effect Logit Tables*.
- *The Context-by-Token Interaction Subspace Predicts a Graded Fallback-Collapse Dose-Response, While the Marginal Direct Channel Does Not*.
- *Naturalness Does Not Explain It Away, but Neither Is the Interaction Subspace Alone: A Naturalness-Controlled Decomposition of Logit-Table Subspaces Predicting Fallback-Collapse in OLMo-1B*.
- *Where the Interaction-Unique Fallback-Collapse Signal Lives: Content-Token Localization of the Geometric Facet in OLMo-1B Logit Tables*.
- *Identity over Order: The OLMo-1B Context-Influence Interaction Budget Is More Sensitive to Content Identity than to Word Order*.
- *Operations Define the Object: A Profile-vs-Interaction Account of Low-Rank Structure in OLMo-1B Logit Tables*.
- *Two Budgets: How a Single Marginal Direction and an Axis-Dependent Content Residual Organize the Low-Rank Structure of OLMo-1B Context-Influence Logit Tables*.
- *Information Is Not Energy: A Held-Out KL Decomposition of the OLMo-1B Context-Interaction Budget*.
- *How Many Dimensions of Context Actually Generalize? The Information Rank of the OLMo-1B Interaction Budget*.
- *Plural Low-Rank Structure in OLMo-1B Logit Tables: Operations Define the Object, Targets and Controls Define the Useful Rank*.
- *The Fast-Slow Geometric Decomposition of Context: Unveiling the Semantic Subspace in Logit Trajectories*.
- *Orthogonality of the Fast Syntactic Residual: Why High-Variance Trajectory Noise Fails Semantic Transfer*.
- *Universal Coherence Gating: The m=2 Temporal Subspace is a Deflation-Robust, Cross-Syntactic Interaction Code*.
- *The Universal Coherence Gate as the Geometric Entry Point to the Slow Semantic Subspace*.
- *The Triple Invariance of Semantic Subspaces: Why the Fast-Slow Projection Bridge Bypasses Syntax*.
- *The Intrinsic Dimensionality and Path-Dependence of Semantic Integration: A Falsification of the Path-Invariant Bag-of-Words Hypothesis*.
- *Milestone: The Orthogonal Control of Syntax over Semantic Integration*.
- *The Geometry of Syntactic Superposition: Why Garden-Path Trajectories Do Not Shatter*.
- *The Non-Linear Syntax Manifold: A Geometric Double Dissociation of Language*.
- *Milestone: The Non-Linear Geometry of Syntactic Repair*.
- *The Step-Update Bottleneck: Isolating the Geometry of Syntactic Repair in Logit Tables*.
- *Milestone: Spectral Decomposition of Semantic Integration in Natural Text*.
- *The Geometric Window: Why the Universal Coherence Gate is a Passive Filter, Not an Active Syntactic Mechanism*.
- *The Fast-Slow Orthogonality Theorem: Geometric Dissociation of Syntax and Semantics in Autoregressive Trajectories*.
- *The Limits of Structural Alignment: How Out-of-Distribution Noise Broadens the Step-Update Spectrum*.
- *The Depth Topography of Structural Alignment: Out-of-Distribution Shattering is a Late-Layer Phenomenon*.
