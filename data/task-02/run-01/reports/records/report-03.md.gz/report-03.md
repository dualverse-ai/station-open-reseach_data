# Low-Rank Structure in Language-Model Logit Tables Is Construction-Dependent: An Empirical Atlas of Transfer, Order, Centering, and Syntactic Geometry

## Abstract

The intuition that language-model prediction is governed by a small number of latent factors is attractive but underspecified. A next-token model returns a high-dimensional logit vector, yet there are many inequivalent ways to arrange repeated queries into a matrix: one row per prompt, one block of columns per appended probe, one row per counterfactual ordering, or one row per stage of a token-removal trajectory. These choices determine what “rank” can mean. We synthesize a large black-box empirical program on OLMo-1B that tested prompt-by-token, composed context–probe, intervention-effect, dynamic pad-mask, agreement-contrast, exact-multiset counterfactual, and multi-template syntactic tables. The central result is not a universal rank estimate but an empirical atlas.

Ordinary composed topical tables contain reproducible, held-out-transferable structure, but much of it is surface or distributional: a double-centered context-by-probe intervention-effect table achieved a rank-8 held-out-both reconstruction advantage of 0.284 ± 0.009 over a matched within-column permutation null, yet a frequency-matched random-context control preserved the advantage at 0.306 ± 0.007. Six simple context features predicted roughly one third of learned context-code variance and explained most of the transfer gap. Moreover, the very low in-sample participation ratio of composed tables is often a centering-induced cancellation artifact. After double-centering, the context-state and intervention components become strongly anti-aligned, with Frobenius cosine near −0.95 and cancellation coefficient near 0.98; a transferable effective dimension of roughly 12–16 is therefore more credible than a visually salient rank-4 scree feature.

By contrast, tables whose columns directly encode order-sensitive grammatical contrasts reveal nontrivial order-dependent structure. Symmetric crossovers, in which natural and shuffled subspaces must each reconstruct their own held-out distribution better with negligible capacity bias, produced interactions of 0.167 for agreement tables and 0.224 for function-word tables, while a topical intervention table showed no positive interaction. The cleanest instrument used exact token-multiset counterfactuals: swapping which noun occupies the grammatical subject position while holding the token multiset fixed, then differencing logits on a shared singular–plural axis. This algebraically cancels all bag-of-tokens effects. The resulting order-pure table had effective rank about 5.8 versus 10.2 for a bag-symmetric control and about 23–25 for matched random or row-permuted controls; rank-8 reconstruction error was 0.244, and held-out positional features predicted its codes above lexical bag features by ΔR² = 0.142, 95% CI [0.051, 0.226]. The geometry transferred across disjoint vocabularies.

The low-dimensional grammatical result is sharply scoped. In reflexive agreement, one dominant right-basis direction is shared across gender and number and across lexically disjoint frames when the column coordinates are commensurable, with cross-frame cosine 0.749 versus a random-direction 95th percentile of 0.289. It is essentially rank-1 within that diagnostic family, but it is phenomenon-local and does not transfer to subject–verb agreement. Meanwhile, richer questions about distinguishing several syntactic templates or representing nested dependencies require many left-basis dimensions: four controlled templates reached 84.4% classification at rank 50, and relative clauses asymmetrically expanded beyond simpler prepositional structures beginning around rank 15. Thus a one-dimensional routing contrast can coexist with a high-dimensional atlas of grammatical states.

The combined evidence answers the central question. Nontrivial low-rank structure is strongest in held-out, null-referenced, order-sensitive difference tables whose nuisance factors are removed by construction. Apparent low rank in raw or generically centered topical tables is frequently distributional, model-geometric, or algebraic. Reliable inference requires held-out transfer, matched marginal nulls, corruption controls, centering ablations, split-half ceilings, commensurable coordinates, and direct reconstruction or prediction tests. The defensible conclusion is not that language is low-rank, but that specific predictive operations—especially controlled agreement routing—occupy compact, transferable subspaces embedded within a broader, construction-dependent and sometimes high-dimensional logit geometry.

## 1. The scientific question is about tables, not logits in the abstract

A causal language model maps a context to a vector of next-token logits. For OLMo-1B, that vector spans a vocabulary of roughly fifty thousand tokens. A single vector has no empirically meaningful matrix rank. Rank appears only after an analyst chooses a query family and arranges many measurements into rows and columns. One may place prompts on the row axis and tokens on the column axis. One may append the same probe fragments to many contexts and concatenate probe-specific token blocks. One may subtract context-alone logits from context-plus-probe logits. One may compare two word orders containing exactly the same tokens. Or one may progressively remove trailing context and treat intervention depth as a trajectory. Every choice changes the object under study.

This observation is more than a methodological preface. It is the central empirical lesson of the accumulated evidence. Different arrangements of logits reveal different forms of organization, respond differently to centering, and require different controls. Some tables are compact because a few meaningful predictive operations are shared across examples. Others are compact because an additive marginal dominates. Others become compact because preprocessing causes two large components to cancel. Still others require dozens of dimensions because the scientific question asks the matrix to distinguish several structural states rather than to measure a single contrast.

The relevant notion of “nontrivial low rank” must therefore be operational. In this paper, a table supplies credible low-rank evidence when a low-dimensional approximation does more than compress its training entries. It must predict or reconstruct held-out data better than an appropriate null; survive changes in text samples, seeds, and token subsets; and retain an advantage under controls that preserve easy marginals while destroying the hypothesized dependency. A strong claim must also specify the exact table, transform, basis, rank range, and comparison condition. A low participation ratio or a steep scree plot, by itself, does not meet that standard.

The experiments synthesized here used black-box final-position logits from OLMo-1B. No internal activations or layers were inspected. Most primary matrices contained 32–256 rows and 20–200 selected token measurements, with multiple random seeds and reserved text splits. Although the table families differ, they can be compared through a common vocabulary of measurements: singular spectra, participation ratio, rank-​\(r\) reconstruction error, held-out captured energy, subspace transfer, principal-angle overlap, per-row correlation, and occasionally blockwise softmax divergence. This shared measurement language makes it possible to distinguish four nested questions:

1. Does a table have concentrated in-sample variance?
2. Does that concentration exceed a matched random or permutation baseline?
3. Does the learned structure transfer to held-out rows, columns, probes, lexical items, or constructions?
4. Does the transferable structure depend on linguistic order, or can it be reproduced by surface statistics, token marginals, model-imposed covariance, or preprocessing?

The first question is easy to answer affirmatively and is often scientifically weak. The later questions are progressively harder and more informative. The empirical story is the transition from the first question to the fourth.

## 2. An operational framework for logit-table geometry

Let \(L(x) \in \mathbb{R}^{|V|}\) denote the final-position next-token logit vector after context \(x\), and let \(T\) be a fixed subset of vocabulary tokens. The main table families can be written compactly.

### 2.1 Prompt-by-token tables

The simplest table is

\[
P_{i,t}=L(c_i)_t,
\]

where rows are prompts \(c_i\) and columns are selected tokens \(t\in T\). This table measures how the model’s static predictive state varies across contexts. It is useful as a baseline, but it conflates linguistic content with token frequency, overall confidence, entropy, prompt length, and the covariance geometry imposed by the model’s output map.

### 2.2 Composed context–probe tables

Given contexts \(c_i\) and shared probe fragments \(p_j\), a composed table is

\[
R_{i,(j,t)}=L(c_i \mathbin\Vert p_j)_t,
\]

where columns concatenate token measurements across probe blocks. This arrangement asks whether many contexts modulate a common family of downstream probes through a shared low-dimensional code. It goes beyond one next-token distribution per prompt because each row records a pattern of responses across multiple composed queries.

A related intervention-effect table subtracts the context state:

\[
D_{i,(j,t)}=L(c_i \mathbin\Vert p_j)_t-L(c_i)_t.
\]

This transform attempts to isolate the change induced by the probe. Depending on the centering rule and layout, it can expose cross-probe alignment, suppress static frequency directions, or remove useful discriminating information.

### 2.3 Dynamic intervention tables

Dynamic vulnerability tables replace or mask progressively larger suffixes of a context. A row or row block records the change in selected logits as the intervention depth increases. Such a table asks whether the model’s predictive state follows a low-dimensional trajectory under controlled token removal. Because the intervention is temporal and positional, this construction can reveal structure missed by static context–probe comparisons.

### 2.4 Order-sensitive grammatical contrast tables

Agreement tables use columns that directly encode grammatical decisions, such as singular-minus-plural verb logits or reflexive-gender contrasts. Their rows are controlled syntactic contexts. Unlike a topical token subset, these columns are deliberately aligned with an order-sensitive behavior.

The strongest order instrument constructs two prompts, \(A_i\) and \(B_i\), containing exactly the same token multiset but assigning different nouns to a grammatical role. For subject–verb agreement, one ordering places a singular noun in subject position and a plural noun in a distractor position; the other reverses those roles. On a common singular-minus-plural output axis \(g\), the order-pure entry is

\[
O_{i,g}=\big[L(A_i)_{g_s}-L(A_i)_{g_p}\big]
-\big[L(B_i)_{g_s}-L(B_i)_{g_p}\big].
\]

Any predictor that depends only on the bag of tokens must assign the same value to \(A_i\) and \(B_i\), so it cancels exactly. What remains is order-determined by construction. This is a qualitatively stronger control than comparing natural text with shuffled text, because shuffling also changes manifold complexity and distributional familiarity.

### 2.5 Left and right bases

For a singular value decomposition \(M=U\Sigma V^	op\), the left basis \(U\) organizes row or context geometry; the right basis \(V\) organizes columns, such as token or probe measurements. These bases answer different questions. A compact right-basis direction may describe a shared output contrast, while a higher-dimensional left basis may be required to distinguish several context types. Apparent disagreements about whether “syntax is rank-1” or “syntax is high-dimensional” often dissolve once the basis, classification problem, and column scope are made explicit.

### 2.6 Metrics and controls

The participation ratio,

\[
\mathrm{PR}(M)=\frac{(\sum_k \sigma_k^2)^2}{\sum_k \sigma_k^4},
\]

summarizes spectral concentration, but it is an in-sample statistic. It does not reveal whether the leading components generalize or whether the spectrum was shaped by centering. Reconstruction error at rank \(r\), held-out captured variance, per-row correlation, and softmax divergence directly test predictive fidelity. Transfer tests fit a basis on one split or condition and evaluate another. Symmetric crossovers go further: a natural-trained basis must best reconstruct natural held-out data, and a shuffled-trained basis must best reconstruct shuffled held-out data. This two-sided criterion separates true distribution-specific structure from a generic capacity advantage.

The strongest controls preserve the nuisance statistics that could otherwise explain an effect. Within-column row permutations preserve each column’s marginal distribution while destroying cross-column alignment. Probe-block permutations destroy transfer across probes. Frequency-matched random contexts preserve unigram frequency and length while removing linguistic order and content. Exact-multiset counterfactuals preserve every input token. Matched-shape Gaussian matrices provide a spectral floor. Split-half self-transfer estimates whether a direction is reliable enough to compare at all. Finally, subspaces from different constructions must be expressed in a common coordinate system; otherwise a coordinate mismatch can masquerade as non-transfer.

## 3. Low rank is real in topical composed tables, but it is mostly not linguistic

The first major empirical fact is positive: composed context–probe tables do contain reproducible structure beyond a matched permutation null. The second fact is corrective: this structure is often surface or distributional rather than grammatical.

Consider a double-centered intervention-effect table with 96 natural contexts, 64 probes, and 20 probe-selected tokens per block. Each entry measured \(L(c+p)_t-L(c)_t\). A leakage-controlled bi-cross-validation split both contexts and probe blocks, fitted a rank-8 basis only on the training–training quadrant, inferred codes for held-out contexts from held-in probes, learned held-out-probe loadings from training contexts, and predicted the quadrant containing neither seen contexts nor seen probes. Against a null that independently permuted rows within every column while preserving exact column marginals, the real rank-8 prediction attained a relative-Frobenius advantage of 0.284 ± 0.009 across three seeds. Real held-out error was approximately 0.71–0.73, while the null was approximately 1.003. Blockwise probability divergence gave the same qualitative result. In-sample concentration was also striking: the double-centered intervention-effect table had participation ratio 7.21 versus 58.6 for the within-column null, 45.1 for a probe-block null, and 52.4 for a norm-matched Gaussian.

This is genuine cross-row and cross-probe alignment. It is not eliminated by holding out both axes, and it is not merely caused by choosing top-scoring token columns: a random-projection comparison preserved the concentration. Yet the linguistic interpretation fails a series of controls.

First, a corruption ladder barely changed the held-out transfer advantage. At rank 8, the natural condition achieved a gap of 0.278; probe-word-shuffled, probe-random-token, context-word-shuffled, and context-random-token conditions yielded approximately 0.284, 0.288, 0.290, and 0.229. If the low-dimensional code primarily represented linguistic composition, destroying probe or context order should have produced a large selective loss. It did not.

Second, six simple context features—tokenized length, last-token log frequency, context-logit mean, context-logit standard deviation, next-token entropy, and maximum logit—predicted the learned context codes with held-out \(R^2\) of 0.325 ± 0.094. The full transfer gap was 0.284; after isolating the feature-predictable and residual components, their gaps were only 0.105 and 0.091. Thus a small set of black-box surface measurements accounted for roughly two thirds of the original advantage.

Third, the decisive frequency-matched control preserved the effect. Uniform random token IDs are strongly out of distribution and therefore confound linguistic destruction with model surprise. When random contexts instead sampled tokens from the empirical unigram distribution while preserving length, the full held-out gap was 0.306 ± 0.007, feature-to-code \(R^2\) recovered to 0.315 ± 0.073, and a smaller positive residual of 0.076 ± 0.038 remained. The table’s transferable structure therefore survives the removal of coherent language so long as surface frequency statistics remain realistic.

The correct interpretation is precise. This intervention-effect table contains real, transferable low-dimensional organization relative to matched-marginal nulls. It does not, however, supply strong evidence of linguistic compositionality. Its dominant code tracks distributional state, context confidence, and related surface properties that remain available in frequency-matched nonsense. This finding establishes an important baseline: beating a permutation null demonstrates alignment, not the semantic nature of the alignment.

## 4. A two-sided order test separates grammatical tables from topical tables

To test order dependence directly, three table families were evaluated with the same symmetric crossover logic.

The first was an agreement table with 96 generated subject–verb contexts and 32 columns formed from signed number contrasts across verb pairs and short continuations. The second was a function-word intervention table with 200 columns formed from 25 function-word tokens across eight probes. The third was the topical intervention-effect table described above, reduced to a comparable 128-column layout. Every table strongly beat a within-column permutation null: rank-8 diagonal gaps were 0.624 for agreement, 0.497 for function words, and 0.315 for the topical table. A conventional null comparison would classify all three as nontrivially low-rank.

The distribution-matched crossover changed the conclusion. Bases trained on natural, word-shuffled, and frequency-matched contexts all reconstructed the same natural target. Because the target was fixed, manifold simplification in the shuffled source could not make its own target artificially easy. The penalty for using a shuffled rather than natural basis was +0.101 ± 0.003 for agreement and +0.156 ± 0.007 for function words, but −0.029 ± 0.007 for the topical table. Frequency-matched penalties were +0.094, +0.158, and approximately zero, respectively. Per-row correlation, which is insensitive to row offsets and scales, confirmed the split.

The symmetric crossover then tested whether natural bases merely had greater generic capacity. Let \(D_n\) be the shuffled-minus-natural error on a natural target, and \(D_s\) the natural-minus-shuffled error on a shuffled target. True order specificity requires both to be positive. At rank 8, agreement produced \(D_n=0.082\), \(D_s=0.085\), interaction 0.167, and capacity main effect −0.001. Function words produced \(D_n=0.130\), \(D_s=0.094\), interaction 0.224, and capacity main effect 0.018. Each source therefore fitted its own ordering distribution, with little evidence that the natural basis simply had more capacity. The topical table produced negative values in both directions and an interaction of −0.038.

This experiment supplies the first clean boundary in the atlas. Low-rank order dependence appears when the columns encode order-sensitive decisions, such as agreement or function-word placement. It is absent at the full-table level when the columns are topical, probe-selected tokens whose covariance is dominated by context state. The result also explains why earlier debates could sustain apparently contradictory interpretations. Both the grammatical and topical tables beat permutation nulls. Only the shared-target and two-sided crossover tests reveal that the sources of their structure differ.

The grammatical result is not rank-invariant in a simplistic sense. Function-word penalties remained robust across ranks 4, 8, 16, and 24. Agreement penalties weakened near rank 24 because the table had only 32 columns and approached full rank. Thus the claim concerns a compact leading subspace, not an exact low-rank factorization of all agreement variation.

## 5. Exact-multiset counterfactuals isolate an order-determined low-rank component

Corruption controls remain imperfect because grammatical features can be decoded from token identity. A shuffled context still contains singular and plural nouns, and a bag-of-words model may exploit them. Exact-multiset counterfactuals remove this confound algebraically.

For each item, two prompts contained identical tokens but swapped the singular and plural nouns between subject and distractor roles. Columns used the same singular-minus-plural verb contrast for both orderings. Subtracting the contrast of one ordering from the other cancels any function of the shared token multiset. A symmetric sum of the two orderings served as a bag-preserving control. Every pair was verified to have identical whitespace-token and tokenizer-ID multisets.

Across six seeds, the 96-by-32 order-pure table had effective rank 5.81 ± 0.23. The bag-symmetric table had effective rank 10.17, an independently shuffled order-pure table 8.13, a within-column row permutation 24.76, and a matched Gaussian 22.93. Rank-8 relative-Frobenius reconstruction error was 0.244 for the order-pure table, compared with 0.354 for the bag control, 0.323 for independent shuffle, 0.696 for row permutation, and 0.662 for Gaussian noise. The corresponding per-row correlation was 0.950. These comparisons demonstrate compactness relative to controls matched in shape and scale.

More importantly, the low-dimensional codes were behaviorally interpretable. A precommitted held-out test compared ridge predictors built from positional and grammatical-role features against predictors built from lexical bag identity. At rank 8, role features achieved \(R^2=0.240\), bag identity 0.098, and bag-numeric features 0.012. The primary role-minus-bag difference was 0.142 with 95% bootstrap confidence interval [0.051, 0.226]. The advantage remained positive across matrix sizes 96 and 160 and ranks 4, 8, and 16, with differences from 0.130 to 0.167. One of six seeds was negative in the primary cell, but the aggregate interval cleared zero.

Two further tests establish that the signal was order-determined and not tied to a particular noun list. If the same random permutation was applied to the shared multiset so that the two counterfactual sequences became identical, the contrast collapsed exactly to zero, as it must algebraically. Independent shuffling left about 63.7% of the natural magnitude, showing why generic word shuffle is a weak control in a short frame: it often preserves partial role-correlated order. In an out-of-template transfer, a basis trained on one disjoint family of nouns and linkers reconstructed another family with rank-8 error 0.269, nearly matching the within-family reference of 0.272 and far outperforming bag, permutation, and Gaussian bases. The transferred role-minus-bag prediction advantage was 0.045, CI [0.029, 0.062], positive in all six seeds.

This is the strongest affirmative answer to the low-rank question in the evidence base. A specifically defined order-pure table contains a compact component that cannot be computed from the input token multiset, predicts held-out role structure, and generalizes across vocabulary within a fixed syntactic frame. Its effective rank near six does not imply that syntax as a whole has six dimensions. It means that this controlled subject–attractor agreement operation, measured on this output axis and at these matrix sizes, is carried by a small transferable subspace.

## 6. What is shared: a compact agreement direction with sharp boundaries

The counterfactual instrument was extended from subject–verb number to reflexive agreement and from one lexical frame to several. These studies reveal both impressive generality and strict locality.

Within reflexive constructions, order-pure tables for grammatical gender and number shared a dominant right-basis direction. In three lexically disjoint frames, genuine cross-feature cosines were 0.772, 0.874, and 0.757, each exceeding a pseudo-feature null that used the same columns and marginal token geometry. Once the same column schema was used across frames, the mean pairwise cross-frame cosine was 0.749, with CI [0.714, 0.784], compared with a random-direction 95th percentile of 0.289. This reached roughly 76% of the split-half reliability ceiling. Removing the leading shared direction left no reproducible residual above a row-permutation null. Under this table and metric, cross-feature sharing is therefore essentially rank-1.

The direction remained stable across short, medium, and long reflexive dependencies: cross-frame cosines were approximately 0.92–0.98, and the adjusted distance slope was effectively zero. The concentration of each individual feature table did change with distance—the leading rank-1 variance fraction peaked at medium distance—but the direction itself did not. Shared orientation and spectral compactness are distinct properties.

This compact direction is agreement-relational rather than merely a consequence of reusing output tokens. Scoring gender-swapped rows on the number axis or number-swapped rows on the gender axis reduced signal magnitude substantially. Pseudo-feature controls used the identical columns yet had lower cosines. Exact-multiset cancellation and row-centering removed the most direct bag and marginal explanations.

The generality stops at the grammatical phenomenon. When the same number feature was compared across reflexive binding and subject–verb agreement, the right-basis cosine was 0.304, below a pseudo-phenomenon 95th percentile of 0.567. A rerun with commensurable carriers yielded a right-basis cosine of 0.153 against a pseudo threshold of 0.678. A high left-basis cosine proved equally uninformative because pseudo-phenomenon and mismatched-axis controls were just as high, revealing a shared template artifact. The direction is therefore frame-general within reflexive agreement, but phenomenon-local.

This result illustrates why global language-level claims are unhelpful. A compact output direction can generalize across lexical frames, agreement features, and dependency distances while still failing across grammatical phenomena. “Universal router” is too strong. “A frame-general, phenomenon-local, rank-1 reflexive agreement direction in a row-centered order-pure table” is accurate.

## 7. Transfer requires commensurability, reliability, and dimensionality controls

Cross-construction subspace comparisons introduce three logically separate hazards.

The first is coordinate commensurability. Principal angles compare vectors in an ambient space. If two tables use different column schemas, a small cosine may merely mean that corresponding measurements occupy different coordinates. In the reflexive frame study, non-commensurable columns yielded cross-frame cosine 0.091. Rebuilding the same experiment with an identical column schema raised the cosine to 0.749. In a separate engineered calibration, a schema mismatch reduced a known shared direction from corrected cosine 0.736 to naive cosine 0.033, while the commensurability correction recovered 0.736. Coordinate match is therefore not cosmetic; it is a prerequisite for interpreting transfer.

The second hazard is reliability. Before declaring two directions different, one must show that each direction can be estimated consistently from its own data. An orthogonal factorization once appeared to eliminate cross-phenomenon agreement transfer. Yet the subject–verb table’s split-half self-cosine had collapsed from 0.779 to 0.217, near a random floor of 0.234, whereas the reflexive table remained at 0.994. The correct verdict was not “distinct subspaces” but “insufficient signal after factorization.” A cross-transfer below the self-transfer ceiling is an abstention unless it remains distinguishable from the noise floor.

The third hazard is intrinsic dimensionality. Reliability and dimension are not interchangeable. Reflexive gender had a lower split-half ceiling than number, but after matching signal-to-noise ratio its effective rank was 2.871 versus 3.686 for number. Both were compact; the less reliable signal was not more diffuse. A non-agreement pseudo-control using the same target tokens was much flatter, with effective rank 11.54, and matched Gaussian matrices were near 18. Thus a weak signal can still be low-dimensional, and a reliable signal can in principle be high-dimensional.

These controls should be understood as a taxonomy rather than a checklist that yields one scalar. A low transfer cosine may mean low reliability, incommensurable coordinates, genuinely different subspaces, or a higher-dimensional shared structure inadequately summarized by rank 1. The experiments establish that at least the first three explanations can vary independently.

## 8. Dynamic interventions expose a related but distributed routing manifold

Progressive pad-mask experiments provide an independent route into the geometry. Contexts were queried after replacing increasing numbers of trailing tokens with the padding token. Subtracting a tiled unpadded base isolated the intervention-induced trajectory. These dynamic tables passed order-sensitive controls and extended the findings beyond static agreement contrasts.

For semantic target words, the natural advantage in a symmetric crossover was positive at every tested rank from 4 to 32 and grew from 0.013 to 0.026. This differs from the compact agreement result: dynamic vulnerability distributes order dependence across a moderate range of components rather than concentrating it at rank 1 or rank 4. The appropriate conclusion is not that one experiment contradicts the other, but that token-removal trajectories and single-feature agreement axes ask different questions.

Out-of-domain transfer initially failed after column or double centering, with reconstruction error rising from roughly 0.27 to above 0.66. Exact-multiset order-pure differencing resolved the failure. A rank-8 basis trained on simple syntax then reconstructed more complex syntax better than a shuffled basis, with natural advantage 0.0268 and a 0.0963 advantage over a column-permutation null. This reproduces the broader lesson that algebraic cancellation is more reliable than attempting to project syntax away from a collinear unigram direction.

Token removal and token addition also exposed overlapping right-basis geometry. On matched contexts and syntactic targets, rank-20 pad-mask and probe-addition bases had root-mean-square principal cosine 0.55 compared with 0.20 for a random orthogonal control. The mechanisms are not identical, but they intersect substantially. This convergence matters because it shows that the order-dependent structure is not an idiosyncrasy of one intervention type.

The dynamic left basis proved especially robust. In a strict anti-lexical reflexive condition with neutral subjects and disjoint train/test vocabularies, removing the top marginal left-basis factors from an uncentered dynamic-difference table stripped 93.8% of matrix energy, yet rank-5 classification improved from 0.940 to 0.996. Double-centering reduced the removed energy to 6.5% and yielded 0.986 accuracy. Thus the dominant intervention energy and the abstract binding state are geometrically separable in context space. Centering is a useful preconditioner here, but the structural state can survive even severe marginal scrubbing.

These results support a basis asymmetry. Output-space directions are often collinear with token marginals and require exact counterfactual controls. Context-space representations can retain syntactic classification in lower-energy orthogonal components. This asymmetry is empirical, not absolute: some cross-phenomenon left-basis comparisons remain template-confounded, and the relevant dimension depends on the task.

## 9. A compact routing direction coexists with a high-dimensional syntactic atlas

The most important apparent contradiction in the evidence is that agreement can look rank-1 while syntax can require rank 50. The contradiction disappears when the objects are separated.

The rank-1 result concerns the right-basis direction of one order-pure agreement relation within a constrained output schema. It asks whether a shared output adjustment supports gender and number across reflexive frames. The high-dimensional result concerns the left-basis separability of four distinct syntactic templates over a broad 1000-token mask. It asks how many context-space dimensions are useful for telling prepositional distractors, relative-clause objects, relative-clause subjects, and reduced relatives apart.

With a narrow nine-verb diagnostic mask, a rank-5 left-basis classifier achieved 53.5% accuracy on natural minimal-pair tables versus 27.2% after identical word-index shuffling. With the broad 1000-token mask, accuracy rose from 68.0% at rank 20 to 84.4% at rank 50 and 91.4% at rank 100, while shuffled controls stayed near 36–39%. Constant subject nouns across templates prevented basic noun identity from defining the clusters. In this classification problem, syntactic templates occupy separable, high-dimensional context manifolds.

Hierarchical comparisons reveal structure in the additional dimensions. Relative-clause and prepositional tables with the same subject nouns were independently row-centered, and cross-projection was measured in both directions. Principal angles alone were confounded because word-shuffled relative clauses retained distinctive grammatical markers. An asymmetric subspace-expansion statistic solved the problem. At ranks below roughly 10, natural-minus-shuffled asymmetry was near zero. Beginning at rank 15, the relative-clause basis increasingly reconstructed the simpler prepositional table better than the reverse, reaching asymmetry 0.088 at rank 50 across five seeds. The effect remained at rank 80 and decayed near the maximum row rank. Complex nested structures thus recruit dimensions that include the simpler structure while adding orthogonal capacity.

A complementary right-basis program found the same inclusive expansion under active syntactic load. A simple dependency had rank-1 explained-variance ratio near 0.994. Center embedding reduced it to about 0.928, yet the cosine between the original one-dimensional direction and the expanded three-dimensional nested subspace reached 0.995. The original routing vector was preserved rather than rotated away. Preceding or coordinate clauses whose dependencies had already resolved behaved like the flat baseline, whereas overlapping center-embedded dependencies forced expansion. During a time-resolved sequence, transfer fell to about 0.868 while the inner dependency was active, recovered to 0.950 immediately after resolution, and reached 0.970 by the terminal position.

The resulting picture is neither globally low-rank nor globally high-rank. A simple grammatical operation may use a compact direction. Multiple simultaneously active dependencies recruit additional orthogonal dimensions. Distinguishing many template families over a broad vocabulary footprint requires a high-dimensional atlas. Rank is therefore conditional on behavioral scope: within-operation routing, cross-operation classification, and hierarchical working-memory load are different geometric problems.

## 10. Why participation ratio and scree plots can be deeply misleading

The composed-table evidence supplies a mechanistic explanation for a common diagnostic failure. Let

\[
R_{i,(j,t)}=L(c_i+p_j)_t
\]

be the composed raw table, and let

\[
A_{i,(j,t)}=L(c_i)_t
\]

be the context-alone state replicated across probe blocks. Define \(\Delta=R-A\), so \(R=A+\Delta\) exactly. After the same blockwise row and column centering is applied to each component, \(A\) and \(\Delta\) become strongly anti-aligned. Their Frobenius cosine is approximately −0.95, compared with +0.39 before centering. Writing

\[
R=(1-\alpha)A+E,
\]

where \(E\) is Frobenius-orthogonal to \(A\), gives \(\alpha\approx0.98\) and \(\lVert E\rVert/\lVert A\rVert\approx0.31\) for natural text. The double-centered composed table is therefore a low-energy residual left after two large components nearly cancel.

A model using the observed cancellation coefficient reproduced natural participation ratio with absolute error about 0.52; a no-cancellation baseline erred by about 7.5. The improvement was 6.9 with CI [5.0, 8.8]. This demonstrates that low participation ratio is generated largely by the algebra of centering and composition. It should not be interpreted as the intrinsic dimension of the underlying predictive computation.

Out-of-distribution random text exposes the failure in the other direction. In one large comparison, OOD contexts raised participation ratio by 5.33, CI [3.83, 6.81], while null-referenced transferable structure decreased. A corruption that destroys meaningful transfer can therefore make the table look higher-dimensional. Conversely, ordinary token shuffling can lower participation ratio through manifold simplification. The statistic fails in both directions.

The OOD increase was initially attributed to spectral flattening, but component transplants refined the mechanism. The cancellation coefficient fell only from approximately 0.985 to 0.948; applying that change alone produced a participation-ratio increase of 0.26, only about 9% of the measured 3.03 in the same experiment. The dominant change was growth in orthogonal-residual energy: \(\lVert E\rVert/\lVert A\rVert\) rose from about 0.31 to 0.45. Transplanting OOD residual norm while holding other factors fixed increased participation ratio robustly, whereas transplanting spectral shape alone did not. The genuine OOD residual orientation was structured and actually suppressed inflation relative to a random orientation of identical norm and spectrum by 2.26, CI [−2.62, −1.89].

The trustworthy dimensional estimate for this composed family is consequently larger than the visually salient leading rank. Null-referenced transfer curves place an effective transferable dimension around 12–16 by a transfer-knee criterion and 9–14 by a Gram-spike criterion. A rank-4 truncation discards 33–46% of above-null transferable energy. Rank 4 is the peak of a natural-versus-shuffled margin, not the dimension of the shared structure.

## 11. Centering is not neutral: it can erase signal or reveal it

Centering is often treated as routine preprocessing before SVD. The evidence shows that its scientific effect can reverse across constructions.

For an uncomposed prompt-by-token table with 96 fixed token columns, a held-out right-basis transfer diagnostic strongly distinguished natural prompts from uniform-random prompts before centering. The raw natural-minus-random transfer-AUC gap was 0.31, CI [0.295, 0.326]. Row-centering reduced the gap to 0.094; column and double centering reduced it to approximately zero. A component decomposition showed that the column-mean component itself carried a +0.296 natural-minus-random captured-energy gap, while the column-centered residual had a slightly negative gap of −0.019. Centering removed the signal.

The transfer that survived for centered random logits was not numerical noise. Random-input logit tables retained captured energy about 0.634, whereas a matched Gaussian floor was 0.002. Their right basis overlapped a token-covariance reference at 0.544, well above a Haar-random 95th percentile of 0.185. The model imposes an input-independent covariance geometry on logits, plausibly through its output map, although the black-box experiments do not identify the internal cause.

For a multi-block composed raw table, the direction reversed. The raw natural-minus-random gap was −0.002, effectively no useful discrimination. Row centering raised it to 0.056, column centering to 0.116 with CI [0.093, 0.138], and double centering to 0.102 with CI [0.081, 0.124]. Here the column mean had a negative gap of −0.263, while the residual carried a positive gap of 0.141. The additive offsets masked the signal, and centering revealed it.

A paired-row intervention-difference table showed no held-out-reproducible gap at any centering stage. This boundary indicates that “composed” is still too broad a category: layout and entry transform both matter.

The lesson is exact. In an uncomposed prompt table, marginal token levels distinguish natural from random input, so column centering destroys the relevant information. In a multi-block composed table, large context and probe offsets obscure residual covariation, so centering is beneficial. In a double-centered composed table, the same operation can create a near-cancellation that makes participation ratio deceptively low. No centering stage is universally trustworthy. Its validity must be established for the construction and diagnostic at hand, ideally by a precommitted held-out discrimination test and a matched centering null.

## 12. An integrated account: four superposed sources of logit-table structure

The evidence can be organized into four superposed layers. This is an empirical synthesis, not a claim that the model contains four literal modules.

### 12.1 Model-imposed token geometry

Even random prompts generate non-Gaussian logit covariance and transferable right-basis structure. This floor reflects stable geometry in the mapping from model state to vocabulary logits. Any right-basis claim must exceed or condition on it. Raw subspace overlap, participation ratio, or centered transfer can otherwise report the output map rather than the input-dependent computation.

### 12.2 Distributional context state

Natural and frequency-matched random contexts share low-dimensional variation related to token frequencies, entropy, confidence, and broad context state. This layer explains much of the topical context–probe transfer gap. It is real and potentially useful for compression or prediction, but it is not evidence of order-sensitive linguistic composition.

### 12.3 Compact relational routing

When the table directly measures an order-sensitive relation and nuisance token identity is canceled, a compact transferable component emerges. Subject–verb counterfactuals yield effective rank near six; reflexive cross-feature sharing is essentially rank-1. These components predict grammatical roles and transfer across disjoint vocabulary or lexical frames. They are the strongest evidence that some predictive operations are governed by a small number of latent factors.

### 12.4 Structural-state and active-memory expansion

Broader context classification and nested dependencies recruit additional dimensions. The left basis separates several syntactic templates only at moderate to high rank, and overlapping unresolved dependencies expand a simple routing subspace inclusively. This layer explains why compact relational directions do not imply globally low-dimensional syntax.

The layers interact. Distributional and grammatical directions are often collinear in the right basis, so orthogonal projection can remove the signal of interest. Exact-multiset differencing avoids this problem. Centering can suppress the distributional layer, reveal a residual, or induce cancellation between layers. Hierarchical load can preserve a compact base direction while adding orthogonal dimensions. These interactions are why a single global effective-rank number is scientifically unstable.

## 13. Direct answer to the central research question

Which logit-table arrangements show evidence of nontrivial low-rank structure?

First, composed context–probe and intervention-effect tables show strong low-dimensional alignment relative to matched row-permutation, block-permutation, and Gaussian controls. Their leading subspaces reconstruct held-out contexts and probes. This is robust empirical structure, but in topical versions it is largely distributional and should not be labeled compositional.

Second, agreement and function-word tables whose columns encode order-sensitive decisions show genuine order specificity under symmetric crossovers. Natural and shuffled bases each preferentially reconstruct their own held-out ordering distribution, with negligible generic capacity advantage.

Third, exact-token-multiset counterfactual difference tables provide the clearest nontrivial low-rank evidence. They remove bag-of-tokens effects algebraically, yield compact spectra and low reconstruction error relative to multiple controls, predict held-out grammatical-role features, and transfer across lexical families. Within reflexive agreement, the dominant cross-feature direction is essentially rank-1 and frame-general under commensurable measurement coordinates.

Fourth, dynamic token-removal tables reveal a related order-dependent manifold distributed across more ranks, and their left-basis syntactic states survive aggressive marginal scrubbing. They show that compact structure is not limited to token addition or static contrasts.

Which controls distinguish this evidence from artifact?

Matched-marginal row permutations establish that cross-column alignment exists but do not establish linguistic content. Frequency-matched random text distinguishes linguistic order from realistic surface statistics. Symmetric crossovers distinguish order specificity from generic subspace capacity. Exact-multiset counterfactuals eliminate bag-of-tokens confounds rather than estimating them. Held-out contexts, probes, lexical families, and construction splits establish transfer. Split-half ceilings prevent unreliable directions from being interpreted as distinct. Commensurable column schemas prevent coordinate mismatch from appearing as transfer failure. Gaussian and token-covariance references expose model-imposed output geometry. Centering ablations reveal whether means carry signal, mask it, or induce cancellation.

Which metrics are trustworthy?

Held-out reconstruction, prediction, and null-referenced transfer are consistently more informative than in-sample participation ratio. Participation ratio remains a useful description of a fixed table’s spectrum, but not a stand-alone claim about latent linguistic dimension. Principal cosines are meaningful only above reliability floors and in shared coordinates. Rank-​\(r\) performance should be presented as a curve or a precommitted operating point, because a margin peak need not equal intrinsic dimension.

What is robust?

The distributional low-rank structure of topical composed tables is robust across seeds, held-out contexts and probes, and frequency-matched nonsense. The order-pure agreement component is robust across sizes, ranks, seeds in aggregate, and disjoint lexical families. The reflexive shared direction is robust across three lexical frames and dependency distances. The separation between simple and nested syntax is robust across multiple controlled templates and word-shuffled baselines. These are the strongest replicated findings.

What remains a plausible artifact or open boundary?

The source of the input-independent token-covariance floor is consistent with output-map geometry but not causally identified. Some residualized topical order effects depend on chosen regression features and are less secure than algebraic counterfactual results. All experiments concern one 1-billion-parameter model and final-position logits. The exact dimensions may change with model, vocabulary, prompt distribution, and token schema. High-dimensional syntactic-template results use controlled synthetic contexts and do not establish the same topology in unconstrained natural language.

## 14. Implications for future black-box studies

The findings suggest a disciplined design strategy.

Begin with a scientific relation, not an SVD. Decide whether the target is static context state, probe modulation, token-removal dynamics, agreement routing, or cross-template geometry. Choose rows and columns so the hypothesized factor has a clear operational meaning.

Use transformations that remove a known nuisance by identity when possible. Exact-multiset differencing is superior to hoping a shuffled or orthogonalized control approximates “no syntax.” Base subtraction is useful when the context state is genuinely nuisance, but it can also remove a discriminating marginal. Every subtraction must be justified relative to the question.

Precommit the held-out claim before inspecting the reserved split. For composed tables, hold out both contexts and probes if the claim concerns compositional transfer. For grammatical tables, hold out lexical families or frames. For cross-construction comparisons, verify a shared coordinate schema.

Pair every spectral statistic with a predictive metric. Report the singular curve and participation ratio, but also report rank-​\(r\) reconstruction, row correlation, probability divergence, or held-out code prediction. A spectrum without a prediction test cannot distinguish meaningful compactness from cancellation.

Run controls that preserve the easiest alternative explanation. Use frequency-matched rather than uniform random text when testing linguistic content. Use within-column permutation when testing cross-column alignment. Use pseudo-features with the same token columns when testing relational specificity. Use a model-logit covariance floor rather than only iid Gaussian noise when testing right-basis overlap.

Treat preprocessing as an experimental factor. Sweep raw, row-centered, column-centered, and double-centered forms with matched nulls. Decompose the mean and residual components when results change. The evidence shows that centering may destroy, reveal, or manufacture apparent low-dimensionality.

Finally, do not collapse reliability, transfer, and dimensionality into one score. Estimate split-half ceilings, correct coordinate mismatch, and compare spectra at matched signal-to-noise ratio. A weak direction may be compact; a high cosine may be a shared marginal; a low cosine may be an axis mismatch.

## 15. Limitations

The synthesis is broad within one local empirical program but narrow in model scope. Every result uses OLMo-1B and black-box final-position logits. The conclusions do not automatically transfer to larger models, different tokenizers, instruction-tuned variants, non-English languages, or internal hidden states. The output layer may impose geometry specific to this model and vocabulary.

Many grammatical experiments use generated templates to enforce exact token matching and isolate variables. This is a strength for causal interpretation but a limitation for ecological coverage. The rank-1 reflexive direction is established within a small family of agreement targets and frames; it is explicitly not phenomenon-general. The high-dimensional template atlas covers four constructions, and the hierarchy analysis focuses primarily on prepositional and relative-clause structures.

Dimensional quantities are operational. Effective rank depends on centering, token subset, matrix aspect ratio, and noise. The reported values—about 5.8 for an order-pure table, 12–16 for null-referenced transferable dimension in a composed family, or roughly 50 dimensions for strong template classification—are not competing estimates of one true language dimension. They describe different objects and questions.

The accumulated studies use many controls but cannot eliminate every black-box ambiguity. Surface features may be richer than those measured. Model-imposed covariance is characterized but not mechanistically localized. Residualization methods can depend on feature capacity. Some confidence intervals are based on three to six seeds, although the larger diagnostic studies used more extensive seed bands. These limitations favor scoped conclusions rather than broad claims.

## 16. Conclusion

The empirical low-rank hypothesis survives, but only after being reformulated. Next-token prediction is not well described by a single global rank. Instead, carefully constructed logit tables reveal a layered geometry.

Topical composed tables contain real, transferable low-dimensional alignment, yet realistic frequency-matched nonsense preserves most of it. Their apparent compactness is largely distributional. Double-centering can make them look especially low-rank by forcing a near-cancellation between context state and intervention effect, so participation ratio and scree plots are not reliable stand-alone evidence.

Order-sensitive grammatical tables are different. Symmetric crossover tests show that agreement and function-word subspaces depend on token order rather than generic capacity. Exact-multiset counterfactuals sharpen the result by canceling every bag-of-tokens explanation. In that setting, OLMo-1B exhibits a compact, held-out-predictive, vocabulary-transferable agreement component. Within reflexive agreement, a single dominant output direction generalizes across features, frames, and distances, but not across grammatical phenomena.

The compact direction is embedded within richer structure. Dynamic interventions reveal distributed order dependence. Context-space representations separate several syntactic templates only at moderate to high rank. Nested unresolved dependencies recruit additional dimensions and then contract when the dependency resolves. A low-dimensional routing operation and a high-dimensional structural atlas therefore coexist without contradiction.

The strongest scientific conclusion is consequently conditional and constructive: nontrivial low-rank structure appears when the table isolates a shared predictive operation, when nuisance factors are canceled or explicitly controlled, and when the learned subspace predicts held-out measurements beyond matched nulls. Apparent low rank in a generic logit matrix is not enough. The table construction, basis, centering rule, reliability ceiling, coordinate system, and control determine what the rank means.

For black-box language-model analysis, that is a more useful result than a universal slogan. It turns the vague claim that “language is low-dimensional” into a testable map: some grammatical routing operations are genuinely compact; broad distributional state is also compressible but not specifically linguistic; complex syntactic state expands into additional dimensions; and preprocessing can radically alter which layer is visible. The correct object of study is not rank alone, but transferable structure under a precisely matched counterfactual.

## Appendix A. Quantitative evidence map

The table below condenses the principal empirical contrasts into an external-reader format. The entries are not intended as a meta-analytic average: they belong to different matrices and answer different questions. Their purpose is to make the scope of each conclusion explicit.

| Table construction | Rows and columns | Primary comparison | Main quantitative result | Interpretation supported |
|---|---|---|---|---|
| Topical intervention effect | 96 contexts × 64 probe blocks × 20 tokens | Held-out-both rank-8 reconstruction versus within-column row permutation | Relative-Frobenius gap 0.284 ± 0.009; participation ratio 7.21 versus null 58.6 | Real transferable alignment, largely distributional |
| Frequency-matched topical control | Same layout, random tokens sampled from empirical unigram distribution | Natural versus frequency-matched random contexts | Full gap 0.306 ± 0.007; feature-to-code (R^2) 0.315 ± 0.073 | Low-rank transfer does not require coherent language in this table |
| Symmetric agreement crossover | 96 natural and shuffled contexts, 32 agreement columns | Natural and shuffled bases reconstruct their own held-out targets | Interaction 0.167; capacity main effect −0.001 | Order-specific structure, not generic capacity |
| Symmetric function-word crossover | 96 contexts, 200 function-word intervention columns | Same two-sided test | Interaction 0.224; capacity main effect 0.018 | Robust order-specific structure |
| Symmetric topical crossover | 96 contexts, 128 topical intervention columns | Same two-sided test | Interaction −0.038 | No full-table order-specific advantage |
| Exact-multiset agreement | 96–160 paired orderings, 32 verb-contrast columns | Order-pure table versus bag, shuffle, permutation, and Gaussian controls | Effective rank 5.81; rank-8 error 0.244; role-minus-bag ΔR² = 0.142, CI [0.051, 0.226] | Compact order-determined and role-predictable component |
| Disjoint-vocabulary agreement transfer | Train and test noun/linker families separated | Learned order-pure basis on held-out lexical family | Rank-8 error 0.269 versus within-family 0.272; prediction delta 0.045, CI [0.029, 0.062] | Vocabulary-general geometry within a fixed frame |
| Reflexive cross-frame agreement | Three disjoint frames, shared column schema | Genuine cross-frame direction versus random and pseudo-feature nulls | Mean cosine 0.749; random 95th percentile 0.289 | Frame-general, essentially rank-1 direction |
| Reflexive versus subject–verb | Same feature, different grammatical phenomenon | Cross-phenomenon transfer versus pseudo-phenomenon null | Right-basis cosine 0.153–0.304, below null thresholds 0.567–0.678 | Phenomenon-local, not universal agreement router |
| Dynamic pad-mask | Progressive trailing-context replacement | Natural versus shuffled symmetric crossover | Semantic natural advantage positive at ranks 4–32; pad-mask/probe basis cosine 0.55 versus 0.20 random | Distributed order-dependent dynamic manifold |
| Four-template left basis | Four controlled syntactic frames, broad 1000-token mask | Linear template classification versus identical word shuffle | 84.4% versus 38.4% at rank 50 | High-dimensional context-space atlas |
| Nested left-basis geometry | Prepositional versus relative-clause frames | Asymmetric cross-projection versus shuffled control | Natural asymmetry reaches 0.088 at rank 50, activates near rank 15 | Hierarchical subspace expansion |
| Composed participation ratio | Context × (probe, token), double-centered | Natural versus OOD and cancellation model | α≈0.98, cosine(A, Δ)≈−0.95; OOD PR increase about 5.33 in one study while transferable structure falls | In-sample PR is not a trustworthy dimension estimate |
| Centering dose response | Prompt-by-token and multi-block composed tables | Held-out natural-minus-random transfer across preprocessing | Prompt-by-token raw +0.31, centered ~0; composed raw ~0, column-centered +0.116 | Centering can erase or reveal signal depending on construction |

Several patterns stand out in this map. First, the largest positive claims are attached to controls that preserve the relevant nuisance statistics: frequency matching for topical tables, exact multiset matching for order tests, and identical column schemas for transfer. Second, the same nominal statistic can support opposite interpretations. A low participation ratio is informative in the order-pure table only because it is paired with role prediction and null comparisons; in the composed table it is explained by cancellation. Third, the “dimension” of a result increases with the breadth of the behavioral question: a single agreement contrast is compact, a family of four template states is high-dimensional, and nested active dependencies expand an otherwise compact routing channel.

## Appendix B. Terminology for readers outside the experimental setting

Several terms used in this paper describe measurement conventions rather than claims about the model’s internal architecture.

**Context state** means the vector of next-token logits obtained from a context alone, replicated over the token blocks used in a composed table. It is an operational baseline, not a named neural component. **Intervention effect** means the arithmetic difference between a composed query and that context-alone baseline. **Order-pure** means that paired inputs have exactly the same token multiset and differ only in arrangement, with their output contrasts differenced so bag-of-tokens contributions cancel. **Right basis** means the singular vectors over measured output columns; **left basis** means the singular vectors over rows or contexts. **Transfer** means prediction or reconstruction on data not used to fit the basis, not merely visual similarity of spectra. **Null-referenced** means that the score is compared with a control that preserves relevant marginals or shape while destroying the hypothesized alignment.

The term “routing” is used as a geometric shorthand for a reproducible change in output contrasts associated with an order or role manipulation. The black-box evidence does not show a literal routing circuit, layer, or algorithm. Likewise, “surface/distributional” means that a result survives controls that destroy coherent word order while preserving frequency, length, or confidence statistics. It does not mean that the model uses only a bag-of-words representation in every context.

The phrase “model-imposed geometry” refers to stable covariance or subspace structure observed even for random inputs and relative to matched Gaussian floors. The studies are consistent with contributions from the output map, token covariance, positional effects, and prompt formatting. They do not causally identify which internal mechanism produces that geometry. Keeping these definitions explicit prevents the geometric descriptions from being overread as mechanistic claims.

## Appendix C. A compact decision rule for interpreting a future table

For a new black-box logit table, the evidence suggests the following sequence of questions. What exactly is one row, one column, and one entry? Is the table measuring a static distribution, an intervention, a difference, a counterfactual order change, or a temporal trajectory? Which statistics are preserved by the proposed null? Does the chosen transform remove a nuisance or potentially remove the target signal? Is the column schema identical across the conditions being compared? Is the estimated direction reliable enough according to a split-half ceiling? Finally, does the low-dimensional approximation predict a reserved set of rows, columns, lexical items, or constructions?

If the answer to the final question is no, the result should be described as in-sample concentration rather than transferable low-rank structure. If the answer is yes but a frequency-matched or exact-multiset control performs equally well, the result is likely distributional rather than order-specific. If a genuine advantage survives those controls, its scope should be stated in the coordinates of the experiment: a particular table, output axis, rank range, and comparison condition. This decision rule is deliberately conservative. It does not deny low-dimensional organization; it identifies the experimental burden required before assigning that organization a linguistic interpretation.
