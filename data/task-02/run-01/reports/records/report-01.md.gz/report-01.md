# Low-Rank Structure in Black-Box Language-Model Logit Tables: Construction, Controls, and the Geometry of Transferable Prediction

## Abstract

The question addressed here is not whether a language model can be represented in a
low-dimensional hidden state space—its architecture already guarantees such a bound—but
whether empirically constructed tables of black-box next-token logits contain reproducible,
nontrivial low-rank structure, and whether that structure is linguistic, distributional, or an
artifact of the measurement. We synthesize the completed experiments in a local research program
using final-position logits from OLMo-1B, with all claims restricted to the table constructions,
token rules, centering operations, nulls, and sample sizes actually tested.

The evidence supports a layered answer. First, a double-centered intervention-effect table,
whose rows are contexts and whose columns are probe-by-token logit changes, has genuine held-out
structure. In a strict bi-cross-validation test holding out both contexts and probe blocks, a
rank-eight reconstruction beat a matched-marginal row-permutation null by a relative-Frobenius gap
of about 0.284 across three seeds; a separate cross-intervention test found a rank-ten held-out
captured-energy advantage of 0.298 over an incoherent row-alignment null across five seeds. This
is not a top-token-selection accident and survives random projection. Yet the same table is not
evidence that language as such is low-rank: a six-feature black-box surface model explained about
two-thirds of its transferable gap, and a frequency-matched random-token control preserved the
full gap (0.306). Uniform random corruption failed mainly because it was out of distribution.

Second, the often-cited rank-four “elbow” is not the dimension of the transferable subspace. It
is the peak of a natural-versus-word-shuffled transfer margin. A null-referenced transfer-knee
was 12–16 dimensions, the Gram-spike estimate was 9–14, and truncating at rank four discarded
roughly 33–46% of above-null held-out transferable energy across raw and baseline-subtracted
composed tables, matrix sizes, and token widths. The additive decomposition of the composed
table showed that order-specific interaction was distributed across the intervention effect and
the context-state readout rather than localized in one term.

Third, order can nevertheless produce a genuinely distinct low-rank object when it is isolated by
construction. Token-multiset-matched subject-attractor counterfactuals yielded an order-pure
table with effective rank about 5.8, held-out role/position prediction above a bag-identity
baseline (R2 difference 0.142, 95% interval [0.051, 0.226]), exact collapse under a canonical
same-permutation control, and transfer across disjoint vocabularies. Controlled Left-Basis
experiments similarly separated syntactic templates, with broad 1,000-token tables reaching
84.4% four-way frame accuracy at rank 50 and 91.5% at rank 100, while matched shuffles remained
near 38.5%. Dynamic prefix trajectories retained order-dependent clustering under exact token-
multiset controls, and entropy-drop alignment separated template states, although natural-text
entropy labels remained near chance under a stricter frequency-matched classifier.

Finally, out-of-distribution residuals reveal why in-sample participation ratio is dangerous as a
general dimensionality measure. In a cancellation decomposition of the composed table, OOD
participation-ratio inflation was carried by orthogonal residual energy. Independent random-token
OOD residuals shared a right-singular orientation with overlap about 0.70, above both a Haar null
near 0.29 and the natural/token-covariance floor near 0.585; the excess was replicated on held-out
seeds. That orientation was only mildly suppressive, so it should not be confused with predictive
transfer. The resulting scientific conclusion is precise: black-box logit tables do show
reproducible low-rank structure, but “low rank” is a property of a measurement regime. The most
credible claims are table-specific, null-referenced, held-out, and explicit about whether they
measure transfer, order dependence, left-basis geometry, or merely in-sample spectral shape.

## 1. Introduction: from a slogan to a measurement problem

The intuition that language has low-dimensional structure is compelling but underspecified. A
language model maps a context to a vector of next-token logits. If those vectors are stacked into
a matrix, singular-value analysis seems to offer a direct test: perhaps a small number of latent
directions explain a large fraction of predictive behavior. But several different questions are
hidden inside that sentence. What is a row? Which logits become columns? Are we measuring absolute
next-token preference, the effect of an intervention, or a contrast between counterfactuals? Are
the singular vectors evaluated on the same rows used to fit them, on held-out contexts, or on a
second family of probes? What null preserves the marginal variance while destroying the structure
of interest? And does a low effective rank indicate syntax, token frequency, positional regularity,
or simply a cancellation produced by centering?

The local research program examined these questions using only black-box final-position logits
from OLMo-1B. The central task specification required at least three candidate tables, explicit
row and column semantics, a stated logit transform, low-rank and reconstruction metrics, controls,
ablations, and held-out validation. The completed work went substantially beyond a single baseline.
It constructed prompt-by-token tables, composed context-by-probe tables, intervention-effect
tables, dynamic deletion and padding trajectories, token-multiset-matched order-pure agreement
tables, and Left-Basis representations of controlled and natural-text trajectories. The papers
and experiments were developed by several research lineages, but their results can be integrated
into one scientific story.

That story has two parts. The first is a methodological correction. A table can be low-rank in
one sense and not in another. A participation ratio can be low because a context-state component
nearly cancels an intervention component. A natural-versus-shuffled margin can peak at rank four
even while transferable signal continues to rank sixteen. A permutation-null gap can be robust
while a natural-versus-corrupted comparison says nothing about linguistic order because corruption
also changes the model's distributional regime. These are not contradictions; they are different
instruments.

The second part is a substantive map of the geometry. Broad composed and intervention-effect
tables contain real, reproducible cross-context coupling, but much of that coupling is explained by
surface and distributional features. When order is isolated algebraically by holding the complete
token multiset fixed, a smaller and more interpretable order-pure component emerges. In controlled
Left-Basis tables, syntactic frames occupy separable context-space regions, and dynamic trajectories
show order-dependent phase structure. Under random-token distribution shift, the model imposes a
reproducible right-basis orientation on residuals, but that orientation is not the same thing as
held-out predictive structure.

The goal of this paper is therefore not to declare that “language is low-rank.” It is to answer the
task's narrower question: which arrangements of next-token logits show nontrivial low-rank structure,
which controls distinguish that structure from artifacts, and what claims survive the controls?
The answer is a construction-dependent hierarchy:

1. **Broad intervention-effect tables:** robust held-out low-rank transfer beyond matched-marginal
   nulls, predominantly surface/distributional in the tested regime.
2. **Composed tables with null-referenced transfer:** a moderate-dimensional transferable subspace,
   not a rank-four object; its effective dimension is roughly 10–16 under the tested estimators.
3. **Order-pure counterfactuals:** a lower-dimensional, role-predictable component that is genuinely
   order-determined because bag-of-tokens effects cancel by construction.
4. **Left-Basis trajectories:** dynamic and template-specific context geometry, strongest in controlled
   settings and at middle-to-high ranks.
5. **OOD residuals:** reproducible in-sample orientation under distribution shift, separable from
   predictive transfer and from the fixed-token covariance floor.

The remainder of the paper defines these objects, follows the evidence from broad tables to
controlled constructions, and states the resulting claims and limits.

## 2. Evidence base and scope

All evidence summarized here comes from the provided local snapshot. No new model queries,
experiments, external search, or internet sources were used for this paper. The model is
OLMo-1B; “logit” means the final-position next-token logit returned by the model before softmax.
The primary text source for broad experiments is a local OLMo wiki mixture. Controlled experiments
use generated minimal-pair templates whose tokenization and lexical inventories are recorded in
the corresponding artifacts. The numerical values below are therefore not universal properties of
language models; they are measurements of OLMo-1B under the named constructions.

The paper gives priority to completed papers and their underlying experiment reports. Running or
unfinished submissions are not used as positive evidence. In particular, a late natural-text
entropy-aligned asymmetry extension was unfinished; its completed precursor calibrations are
discussed, but the extension is not treated as a result. Source-specific identifiers have been
translated into descriptive experiment names.

## 3. A common measurement language

### 3.1 Logit tables

Let `L(x)[t]` denote the model logit for token `t` after context `x`. A logit table is a
matrix `M` whose rows and columns have an explicit experimental meaning. The program used several
families.

**Prompt-by-token table.** Rows are text contexts `c_i`; columns are a selected set of token ids
`T`; entries are `L(c_i)[t]`. The simplest version uses the top-`k` active tokens from each
context or a shared high-variance vocabulary. It is useful as a baseline, but because one row is
one next-token distribution it mainly measures local predictive state.

**Composed context-by-probe table.** Rows are contexts (c_i), columns are intervention blocks
(p_j) crossed with selected tokens (t). The raw table is

\[
 M^{RAW}_{i,(j,t)}=L(c_i+p_j)[t].
\]

The intervention-effect or delta table subtracts the context baseline:

\[
 M^{DELTA}_{i,(j,t)}=L(c_i+p_j)[t]-L(c_i)[t].
\]

In the main held-out studies, `m` was usually 96–128 contexts, 32–64 probes, and `k=20` selected
tokens per probe, giving widths from 400 to 1,280. Token ids were selected from probe-alone logits
and held fixed across natural, shuffled, random, and held-out conditions. This fixed-column rule is
essential: otherwise a condition could change the measurement axis as well as the text.

**Dynamic intervention table.** Rows index contexts and a sequence of controlled interventions,
such as progressively deleting or padding trailing tokens. Columns are selected target logits.
These tables ask whether the model's response to a structured intervention follows a low-dimensional
trajectory, not merely whether one static next-token distribution is compressible.

**Order-pure counterfactual table.** Each item has two prompts with exactly the same token multiset
but different order, for example a singular noun and a plural noun exchanged between subject and
attractor positions. On a common singular-minus-plural verb axis, the order-pure value is the
contrast for ordering A minus the contrast for ordering B. Any bag-of-tokens contribution shared by
the two orderings cancels algebraically. This is stronger than asking whether a shuffled prompt has
lower rank.

**Left-Basis trajectory table.** Rows are prefixes or phase-aligned contexts; columns are a shared
active vocabulary. After optional unigram orthogonalization, the left singular coordinates `U S`
represent context-space trajectories. These experiments compare distances, classification, and
directional subspace reconstruction in the row axis.

### 3.2 Centering is part of the scientific object

The program repeatedly found that centering changes the claim. For intervention-effect tables, the
main double-centering operation subtracts the mean across selected tokens within each row and probe
block, then subtracts the context mean of each resulting column within the block. Fit-only variants
estimate offsets on training quadrants and apply them to held-out data. Single-centering and row-only
centered versions were retained as ablations rather than silently mixed with the primary object.

This is not cosmetic preprocessing. In the cross-intervention alignment studies, the rank-ten
empirical-minus-alignment gap was about 0.298 with double-centering but only about 0.055 under
single-centering. In a separate dimension experiment, a rank-ten gap of 0.312 under double-centering
fell to 0.063 under single-centering. A later synthesis across three constructions found opposite
signs: centering could increase concentration for one table while erasing a natural-versus-random
discrimination for another. The correct conclusion is not that one centering convention is
universally right; it is that centering defines which component is being measured and must be
reported as part of the table definition.

### 3.3 Metrics and nulls

The work used several complementary metrics.

* **Singular spectrum and effective rank.** Participation ratio is
  `(sum sigma_i^2)^2 / sum sigma_i^4`. It is descriptive and in-sample unless paired with
  a transfer test.
* **Rank-`r` reconstruction.** Relative Frobenius error compares `M` with its projection onto
  a learned rank-`r` singular subspace. For logit blocks, KL divergence between softmax distributions
  was used as a predictive metric when appropriate.
* **Held-out captured energy.** A right or left subspace is fit on one set of contexts, probes, or
  intervention blocks and evaluated on a disjoint set. This is the central test of reproducibility.
* **Bi-cross-validation.** Context rows and probe blocks are split into four quadrants. The strict
  held-out-both quadrant is reconstructed using a subspace learned without reading its entries.
* **Crossover penalties.** Natural, shuffled, and frequency-matched training tables reconstruct
  the same held-out target. A positive shuffle penalty means the natural subspace transfers better
  to a fixed target; a symmetric crossover additionally tests whether the effect is order-specific
  rather than a capacity difference.
* **Asymmetric subspace expansion.** For two left subspaces, cumulative variance explained is
  measured in both directions. A positive difference means one class's context-space subspace
  encapsulates the other more efficiently at that rank.
* **Subspace overlap.** For right bases `V_a` and `V_b`, overlap is
  `||V_a^T V_b||_F^2 / r`. It is meaningful across samples only when the column axis is fixed.

The controls are equally important. Within-column row permutation preserves every column's marginal
distribution while destroying cross-row coupling. Probe-block permutation destroys cross-probe
transfer. Word-order shuffling preserves much of the token inventory but changes order. Frequency-
matched random tokens preserve unigram statistics while destroying content and order. Exact token-id
multiset permutation preserves each row's token multiset. Haar subspaces provide geometric nulls.
Matched Gaussian controls preserve shape and scale. No single null answers every question.

## 4. The first result: broad tables are low-rank beyond nulls, but not thereby linguistic

The earliest landscape study built three candidate objects: a context-alone table, a composed raw
table, and the intervention-effect table. With 64 contexts, 48 probes, and 20 selected tokens per
probe, the strongest in-sample concentration occurred in the double-centered intervention-effect
table. Its participation ratio was 7.21, versus 58.6 for a within-column row-permutation null,
45.1 for a probe-block shuffle, and 52.4 for a matched-norm Gaussian. The raw composed table also
showed concentration, with participation ratio 19.1. A random-projection version of the raw table
had participation ratio 18.97, nearly identical to the top-token version, ruling out the simplest
top-`k` selection artifact. Row-centered controls removed the intervention-effect gap, localizing
the measured structure to the context-dependent, double-centered component.

Those numbers are not yet a scientific claim because they are in-sample. The decisive confirmation
used leakage-controlled bi-cross-validation. For each seed, 96 contexts and 64 probes were split
into fit and test sets, producing four quadrants. The rank-eight subspace was learned on the fit-fit
quadrant; held-out contexts and held-out probe blocks were reconstructed without using the strict
held-out quadrant. Across three seeds, the real rank-eight strict-held-out error was roughly
0.708–0.730, while the matched-marginal null was about 1.003. The relative-Frobenius gap was
0.284 ± 0.009, and every seed beat the null's fifth percentile. Held-out-context transfer and
held-out-both transfer were similar, and block-level KL gave the same qualitative conclusion.

A second cross-intervention experiment changed the split. It held the context rows fixed, split the
intervention blocks into fit and test pools, and estimated a context subspace from one set of blocks.
At rank ten, held-out captured energy was 0.377 ± 0.038 above an independent row-alignment null
of 0.079, for a gap of 0.298 ± 0.038 across five seeds. Per-block whitening retained a gap of
0.283 ± 0.029, showing that heteroscedastic blocks were not the entire explanation. Pairwise left
subspace overlap also exceeded the null by 0.100 ± 0.012. These experiments answer the task's
first evidentiary question positively: the composed intervention-effect table contains reproducible
coupling that is not explained by independent column marginals.

The table is, however, moderate-dimensional. A rank-eight reconstruction still leaves roughly
38% of the Frobenius energy in the principal intervention-effect study, and transfer curves rose
through ranks well above eight. The low-rank claim is therefore “excess concentration and transfer
beyond nulls,” not “almost everything lies in two or four dimensions.”

The more difficult question is what that concentration means. A corruption ladder compared natural
contexts with word-shuffled, random-token, and frequency-matched random contexts. Natural, shuffled,
and probe-randomized conditions all retained a held-out gap near 0.28–0.29; uniform random-token
contexts fell to about 0.229. The natural gap was therefore not specifically dependent on intact
word order. Six simple black-box context features—tokenized length, last-token unigram log
probability, context-logit mean and standard deviation, next-token entropy, and top-1 logit—predicted
about 32.5% of held-out context-code variance. The surface-predicted component retained a gap of
0.105, while the residual retained 0.091, compared with the full 0.284.

The decisive control sampled random tokens from a frequency-matched unigram distribution. It
destroyed linguistic content and order without moving the input far outside the model's learned
distribution. The full low-rank gap remained 0.306 ± 0.007, feature predictability returned to
about 0.315, and a positive residual remained at 0.076 ± 0.038. Uniform random tokens had instead
made the six-feature regression fail, with feature R2 around –1.42. The correct interpretation is
that much of the apparent linguistic robustness under corruption is a distributional regime effect.
The structure is real, but in this broad table it is primarily a transferable surface/context-state
geometry. A small residual is possible, but the experiment did not identify it as linguistic.

This conclusion was tested against a natural-versus-frequency-matched crossover. Natural, shuffled,
and frequency-matched training tables were each evaluated on the same held-out target. Within-
distribution diagonal cells beat row-permutation nulls strongly, but the natural subspace did not
universally dominate: word-shuffled training often had the lowest Frobenius error on both natural
and frequency-matched targets, while block KL favored the matching distribution. The result is
mixed rather than a proof of a linguistically special natural subspace.

## 5. The second result: rank four is a contrast peak, not the transferable dimension

An earlier subspace-transfer study reported a familiar-looking result: the natural-minus-shuffled
held-out margin peaked at rank four, with aggregate margin 0.06697. Natural beat shuffled at every
rank from one through 64, but the margin at rank 64 was still 0.04538, 67.8% of its peak. The
rank-four number therefore describes the maximum difference between two transfer curves, not the
point at which the natural table runs out of transferable structure.

A null-referenced dimension study made the distinction explicit. It used double-centered raw and
delta composed tables, split intervention blocks into fit and test pools, and compared held-out
captured energy with an independent per-block row-alignment null. The primary dimension estimator
was a transfer knee: the smallest rank reaching 90% of the asymptotic above-null gap. A second
estimator counted per-block-whitened context-Gram eigenvalues above the 95th-percentile null edge.

The transfer knee was 16 in the initial five-seed study; Gram-spike counts were [16, 13, 12, 13,
12], median 13. A broader study across raw and delta constructions, (m\in\{96,128,192\}), and
(k\in\{10,20,40\}) found transfer knees 12–16 and Gram-spike medians 9–14. The fraction of
above-null held-out energy lying beyond rank four ranged from 0.328 to 0.445 for raw tables and
0.383 to 0.459 for delta tables. On a preregistered fresh-text split, both constructions passed:
raw beyond-rank-four fraction 0.363 [0.323, 0.397], delta 0.343 [0.309, 0.378], with transfer
knee 12 in both.

Why can a margin peak at four while transfer continues to rank sixteen? Consider a nested spectrum.
The leading directions may be high-variance and shared by natural and shuffled contexts. A second,
broader band may be lower-variance but genuinely transferable in natural text and largely incoherent
under shuffling. The natural-minus-shuffled difference grows when that band begins to contribute,
then peaks once both subspaces have accumulated additional noise. The natural subspace's own
above-null captured energy can continue to grow through the broader band. The margin peak marks a
contrast boundary; the transfer knee marks the extent of reproducible energy.

This distinction matters for reporting. A rank-four reconstruction can be useful for a particular
contrast, but calling it “the dimension of language” discards one-third to one-half of the measured
above-null transfer in the same table. The program's recommended diagnostic set now has four axes:
(i) matched-marginal null gap, (ii) shuffled-basis orthogonality, (iii) order-specific crossover,
and (iv) null-referenced transferable dimension. They need not agree.

The additive decomposition also corrected a tempting mechanistic story. For matched columns,

\[
L(c+p)=\underbrace{[L(c+p)-L(c)]}_{	ext{DELTA}}+\underbrace{L(c)}_{	ext{context state}}.
\]

At rank twelve, symmetric crossover interactions were approximately +0.253 for RAW, +0.196 for
DELTA, and +0.199 for the context-state component; capacity main effects were near zero. Thus the
order-specific interaction was distributed across both components, with a small RAW-minus-DELTA
superadditivity of about +0.057. A preregistered attempt to localize the effect entirely to the
context-state readout failed. Removing a low-dimensional surface span reduced rather than unmasked
the interaction. The lesson is again construction-specific: a broad composed table should not be
reduced to one semantic “syntax channel.”

## 6. The third result: when order is isolated, a distinct low-rank component appears

The broad-table controls show why word shuffling alone is insufficient. Shuffling can preserve
unigram statistics, destroy order, and simultaneously simplify the model's manifold. Agreement
number is also often decodable from the bag of tokens: a prompt containing a plural noun can signal
plurality even when word order is destroyed. A more decisive construction holds the bag fixed.

### 6.1 Token-multiset-matched subject-attractor contrasts

Each item used two orderings with exactly the same token multiset. In one ordering the singular noun
occupied subject position and the plural noun was an attractor; in the other, the plural noun was
the subject and the singular noun the attractor. The response axis was a common singular-minus-
plural verb contrast. Subtracting the two responses cancels bag-of-tokens effects and leaves only
the order-sensitive component. Rows were items, columns were 32 verb-pair and continuation
contrasts, and the main tables had 96 rows and were evaluated at ranks four, eight, and sixteen.

The order-pure table had effective rank 5.81 ± 0.23, versus 10.17 for the bag-symmetric sum,
8.13 for independent word-shuffle controls, 24.76 for row permutations, and 22.93 for matched-
Gaussian controls. Rank-eight relative-Frobenius error was 0.244, with row correlation 0.950,
compared with 0.354 for the bag-sum and 0.696 for row permutation. A held-out role/position
predictor explained 0.240 of rank-eight code variance, versus 0.098 for a bag-identity baseline
and 0.012 for a bag-numeric baseline. The preregistered role-minus-bag R2 difference was 0.142,
95% interval [0.051, 0.226].

The algebraic controls are especially informative. A canonical same-permutation operation makes
the two members of each pair identical, and the order-pure magnitude collapses exactly to zero.
Independent within-context word shuffling leaves about 64% of the natural magnitude, so arbitrary
shuffle is not a perfect order null for this short frame. The correct claim is not that all
shuffling erases the component; it is that the component is order-determined by construction and
is predictable from grammatical role and position above bag controls.

The result generalized across disjoint noun and linker families within the same frame. The rank-
eight role-minus-bag prediction difference remained positive at 0.045 [0.029, 0.062] across six
seeds, and an order-pure basis trained on one vocabulary family reconstructed the other with error
0.269, essentially matching the within-family reference 0.272 and substantially beating bag-sum,
row-permutation, and Gaussian bases. The smaller prediction delta under vocabulary transfer shows
that the geometry is more invariant than the exact feature-to-code map.

This is the cleanest positive evidence for a genuinely order-dependent low-rank component in the
program. It does not imply that the broad intervention-effect table is linguistic, nor that all
syntactic phenomena share rank six. It shows that a carefully designed table can remove the dominant
bag confound and expose a small, role-predictable, vocabulary-generalizable structure.

### 6.2 Controlled Left-Basis syntax

A separate set of experiments represented minimal-pair differences (D=L(A)-L(B)) in a shared
left singular space. Four template families were generated with constant item-indexed subject nouns,
so frame labels could not be reduced to a changing head noun. Under a strict nine-token diagnostic
mask, rank-five frame classification reached 53.6% versus 27.2% for identical shuffles. With a broad
empirical 1,000-token vocabulary mask, rank-50 accuracy reached 84.44% versus 38.48%, and rank-100
reached 91.47% versus 38.54%. The control remained above chance, so the table contains residual
template information, but the natural gap is large and grows with rank.

Topology was more complicated. Principal-angle distances weakly suggested that two relative-clause
frames were closer to each other than to a prepositional distractor, but centroid and projection
metrics disagreed, and a three-seed topology study did not support a strong hierarchy claim. A
five-seed asymmetric-subspace experiment did find a robust rank-dependent effect: natural
relative-clause bases reconstructed prepositional-distractor matrices more asymmetrically than
shuffled controls from rank 15 onward. Natural-minus-shuffled asymmetry means were –0.010 at rank
five, –0.0005 at rank ten, +0.0475 at rank fifteen, +0.0705 at rank twenty, +0.0793 at rank thirty,
and +0.0882 at rank fifty, positive in all five seeds at ranks 15–50. This is evidence for
middle/high-rank Left-Basis expansion in this controlled setup, not proof of a universal syntactic
hierarchy.

A marginal-variance scrubbing experiment strengthened the geometric interpretation. After projecting
away a dominant marginal-variance direction, Left-Basis frame separation survived, supporting the
claim that the controlled syntactic state is not simply a unigram amplitude effect. Other experiments
found that right-basis factorization can fail because syntax and marginal token variance are
collinear, while Left-Basis purification can preserve or improve held-out classification. The basis
therefore matters: context-space geometry and token-space geometry answer different questions.

### 6.3 Dynamic trajectories and exact multiset controls

Dynamic vulnerability studies progressively deleted or padded trailing tokens and built intervention-
delta trajectories. Early experiments found nontrivial low-rank positional vulnerability profiles,
but also discovered that word-shuffled contexts can collapse into a simpler “informational” regime.
Matrix-level nulls and exact token controls separated these effects. In a controlled nine-word
template, natural progressive prefixes had an inter-step/intra-step Left-Basis distance ratio of
2.035, while exact token-id multiset permutations had ratio 1.151; the difference was 0.884 across
three seeds. Every control row preserved its exact prefix token multiset and changed order whenever
possible. A matched-length two-template study found natural cross-template separation ratio 2.506
over nondegenerate lengths, with all 24 seed-length cells positive; the exact multiset control
collapsed to about 1.148 after excluding a degenerate shortest prefix.

These results show that sequential structure can be present in the Left Basis even when cumulative
token content is fixed. They also expose a recurring failure mode: fixed first words and very short
prefixes create near-zero within-class distances and inflate ratios. The scientifically useful
claim is therefore the robust nondegenerate trend, not the largest raw ratio.

## 7. Entropy alignment: useful as an instrument, not a universal structural label

Predictive entropy offers a way to align natural text without a parser. In a controlled calibration,
the model's entropy trajectory was computed over progressive prefixes, and the prefix after the
largest adjacent entropy drop was selected as a phase-aligned state. Two syntactic template families
then formed separate Left-Basis clusters: the phase-aligned cross/intra ratio was 1.601, minimum
seed ratio 1.389, and positive in all three seeds. Exact token-id permutation reduced the ratio to
1.162, with natural-minus-control gaps of 0.441, 0.622, and 0.255 across seeds. The selected prefix
lengths were genuinely asynchronous: one template averaged 6.78 words and the other 3.58, with
nonzero within-template variation.

This is a useful proof of concept for phase alignment, but not evidence that entropy is a clean
syntactic coordinate. A prior natural-text split had found the opposite of the naive hypothesis:
low-entropy contexts reconstructed high-entropy trajectories better than the reverse. Exact token
permutation collapsed most of that asymmetry, indicating dependence on order rather than token
multiset. Syntax/function-word targets showed a stronger effect than semantic targets, but semantic
targets retained about 60% of the syntax magnitude.

The stricter test was a classifier. Exact 40-token natural contexts were split into low- and high-
internal-entropy classes using mean predictive entropy over target positions 5–39. With 50 selected
token columns, a frequency-matched replacement null, and left-basis classifier ranks 2, 5, 10, and
20, natural accuracies were 0.509, 0.500, 0.518, and 0.502; residual accuracies after null projection
were 0.498, 0.476, 0.489, and 0.504. All were near chance, and no rank approached 0.65. Thus entropy
can be a productive alignment signal for dynamic reconstruction in controlled settings while being
geometrically unrecoverable as a general natural-text class label under a stricter semantic-null
design. That boundary should be part of any future natural-text claim.

## 8. Out-of-distribution residuals: why participation ratio alone misleads

The broad-table story becomes more mechanistic when the composed table is decomposed. Let
(A[c,(j,t)]=L(c)[t]) be the context-state table replicated over intervention blocks,
(DELTA=RAW-A), and double-center all three identically. The identity (RAW=A+DELTA) holds to
less than (10^{-5}). The natural context-state and interaction terms were strongly anti-aligned,
with Frobenius cosine near –0.95. Defining

\[
\alpha=-\langle A,DELTA\rangle_F/\|A\|_F^2,
\qquad R=RAW-(1-\alpha)A,
\]

gave natural \(\alpha\approx0.98\). The raw table is therefore a near-cancellation residual, not a
direct measure of one underlying low-dimensional object.

This explains a striking diagnostic dissociation. Uniform-random OOD contexts increased the
in-sample participation ratio, but null-referenced held-out transferable structure did not increase;
indeed it often fell. The residual analysis showed that OOD participation-ratio inflation was
carried by orthogonal residual energy. A fixed-alpha synthetic model and a spectrum-only carrier
did not reproduce the measured inflation, so no one-parameter cancellation story sufficed. The
strong OOD effect required the joint norm, spectrum, and orientation of the residual.

The orientation itself was reproducible. Two independent uniform-random OOD residuals had right-
subspace overlap about 0.701, compared with a Haar null near 0.288. Their overlap with a natural
residual was about 0.585. Crucially, the natural-OOD overlap matched the right covariance basis of
the natural raw table at about 0.585, identifying a fixed-token/unembedding covariance floor. The
OOD-OOD overlap exceeded that floor by 0.116 [0.099, 0.132] in the primary band and 0.124 [0.111,
0.136] in held-out seeds; the ordering remained positive in a second table shape. The shared OOD
orientation was therefore not reducible to the common selected-token axis.

The connection to participation ratio was modest. In a fixed-carrier, matched-norm experiment,
cross-sample OOD orientation suppressed PR relative to a Haar orientation by about –0.018, similar
to the same-sample –0.022 in the primary band, with a transfer fraction near 0.83. Held-out
self-suppression was near zero, and orientation-only suppression was tiny compared with the roughly
–2.26 full effect in the parent residual study. The safe interpretation is that OOD residuals have
a reproducible geometric orientation, not that this orientation carries predictive language
structure or alone explains the PR change.

This section supplies a general warning. An in-sample participation ratio is sensitive to
cancellation, residual energy, and orientation. It can rise under gibberish even while transferable
structure falls. Effective rank should therefore be reported with held-out reconstruction and
null references, never as a standalone claim about linguistic dimensionality.

## 9. An integrated model of the observed geometry

The experiments support a multi-component picture rather than one latent “language rank.” A broad
context-by-probe table can be represented schematically as

\[
M^{RAW}=M^{state}+M^{interaction},
\]

with a large cancellation between terms after centering. The transferable part of the resulting
table has a nested spectrum: a few dominant directions, a broader moderate-variance band extending
to roughly 10–16 dimensions, and residual directions whose reproducibility depends strongly on
the input distribution and the chosen null. Surface features and context-alone predictive PCs
explain much of the broad table's transfer. This is why frequency-matched random contexts preserve
the main gap.

Within that broad geometry, controlled order manipulations reveal a more specific component. The
order-pure agreement construction removes bag statistics algebraically, leaving a compact, role-
predictable direction. Controlled Left-Basis syntax experiments show that context-space states can
separate templates and expand asymmetrically at ranks 15–50. Dynamic prefix controls show that these
states trace trajectories whose grouping depends on order rather than cumulative token inventory.
These are not all the same object: the order-pure table uses common agreement contrasts, the Left
Basis tables use broad selected-token axes, and dynamic tables use intervention sequences. Their
convergence is therefore best read as evidence for a family of context-space order effects, not a
single universal matrix rank.

OOD residuals add a third layer. When text leaves the natural distribution, the model can impose a
shared right orientation on the residual even though held-out predictive transfer collapses. This
is a model-generated geometric response to distribution shift, not recovered syntax. It explains
why “structure” and “useful structure” must be separated.

The practical decomposition is:

* **Marginal structure:** token-frequency and unembedding covariance; visible in many axes and in
  frequency-matched controls.
* **Context-state structure:** predictable from context-alone logits and surface features; often
  transferable but not necessarily linguistic.
* **Order-specific structure:** isolated most convincingly by exact multiset counterfactuals and
  matched order controls; lower-dimensional and role-predictable in the tested agreement frame.
* **Distribution-shift structure:** reproducible OOD residual orientation, strong in-sample geometry
  but weakly connected to predictive transfer.

No single singular-value curve separates these components. The table definition and null do.

## 10. What the controls establish—and what they do not

Several controls are especially decisive.

**Matched-marginal row permutation.** It establishes that a table contains cross-row coupling beyond
each column's marginal distribution. This is the basis for the robust positive claims about broad
intervention-effect and composed tables. It does not establish word-order dependence.

**Probe-block shuffle.** It tests whether coupling transfers across intervention blocks. The broad
table's excess concentration survives some but not all variants; it is a useful axis-specific null,
not a universal baseline.

**Word-order shuffle.** It changes order but also changes the model's trajectory through input space.
It is informative only when evaluated on a common target, with distributional simplification
measured, or paired with exact multiset controls. A shuffled table can be easier to reconstruct
because it has collapsed into a simpler manifold.

**Frequency-matched random tokens.** This is the strongest broad-table linguistic control in the
program. It preserves unigram statistics while destroying order and semantics. The survival of the
intervention-effect gap under this control is why the broad claim is surface/distributional rather
than linguistic.

**Exact token-multiset permutation.** This is the strongest order control for the controlled
agreement and trajectory experiments. It preserves each row's token inventory and length, so a
remaining natural-versus-control difference is attributable to sequence order within the tested
construction. It does not guarantee that every arbitrary permutation is a good null; the short-frame
shuffle residual demonstrates that some permutations accidentally preserve role cues.

**Held-out validation.** It distinguishes descriptive spectral shape from reproducible structure.
The strongest claims in this paper use held-out contexts, held-out probe blocks, held-out vocabulary
families, or held-out seeds. In-sample participation ratio results are reported only as diagnostics.

**Ablations of centering, token selection, rank, and matrix size.** The main conclusions are not all
equally robust. Broad null-referenced transfer survives random projection and several sizes, but
depends strongly on double-centering. Left-Basis asymmetry turns on near rank 15. Entropy classifier
results remain negative through rank 20. OOD orientation survives a second table shape, while its
PR-suppression bridge is weak. These ablations define the scope of each result rather than being
decorative robustness checks.

## 11. Implications for experimental design and interpretation

The combined results imply a practical workflow for future black-box logit studies. The first
decision should be conceptual rather than numerical: is the experiment about compression,
transfer, order, or mechanism? Compression asks how quickly singular values decay on a fixed
sample. Transfer asks whether a subspace learned from one set of rows, probes, or intervention
blocks predicts another. Order asks whether changing sequence arrangement changes the response after
bag statistics are controlled. Mechanism asks whether an observed component can be localized in an
additive or predictive decomposition. The same matrix can answer one of these questions well and
another poorly.

For a compression question, participation ratio and explained variance are appropriate descriptive
statistics, but they should be accompanied by a scale-matched null. The early landscape result is a
good example: a participation ratio of 7.21 looks striking until it is compared with a row-
permutation value of 58.6, a probe-block shuffle of 45.1, and a matched Gaussian of 52.4. The
comparison establishes concentration, but it does not establish what generated it. Conversely, an
OOD participation ratio can be larger even when the OOD table is less useful for prediction. A
descriptive rank should therefore be reported as “effective rank of this centered table under this
condition,” never as the dimension of a linguistic faculty.

For a transfer question, the split must respect the table's axes. Holding out only contexts is
insufficient for a context-by-probe table because a right singular basis can memorize the probe
axis. Holding out only probes is also insufficient because context rows can be reused. The strict
quadrant test solves this by fitting on one context set and one probe-block set, then reconstructing
the quadrant whose rows and columns were both unseen. Its value is not that it makes the estimate
unbiased in every statistical sense; it makes the scientific claim legible. A positive result means
that the measured coupling survives a deliberately hostile split. The 0.284 rank-eight gap in the
intervention-effect table and the 0.298 rank-ten cross-intervention gap are persuasive precisely
because they use different held-out axes and agree.

For an order question, the null should preserve the information that an order-insensitive model
could exploit. A word shuffle alone does not do this reliably. It can create unusual contexts,
change local tokenization statistics, and lower the effective complexity of the model's response.
The frequency-matched random-token condition demonstrated the danger: random tokens sampled from a
matched unigram distribution preserved the broad held-out low-rank gap, while uniform random tokens
made the feature model fail. Thus the phrase “corruption destroys linguistic structure” is not a
measurement result unless the corruption is distribution-matched.

The order-pure counterfactual is a stronger instrument because it removes the confound before
analysis. Its common-axis subtraction is an algebraic identity: any response depending only on the
shared multiset cancels. This does not require a model of the null and does not depend on a rank
threshold. The cost is scope. The instrument is valid for the exact pairing and contrast that were
constructed; it cannot silently be generalized from subject-attractor agreement to all syntax.
This tradeoff—strong identification at narrow scope versus weak identification at broad scope—runs
through the entire evidence base.

For a mechanism question, additive decomposition and feature prediction should be treated as
diagnostic, not as proof of internal circuitry. Predicting delta-table context codes from
context-alone principal components is informative because it links the composed response to a
measurable black-box state. The rank-ten combined surface-plus-PC8 model explained about 73.1% of
held-out code variance, while PC8 alone explained 72.4% and surface features alone 21.2%; PC16 alone
reached 86.5%. This is strong evidence that context predictive state organizes the table, but it
does not show that a particular neuron or attention head implements the code. Similarly, the exact
identity (RAW=DELTA+A) permits a clean accounting of components, but the labels “interaction” and
“context state” remain algebraic descriptions.

The results also suggest how to choose ranks. A single rank should be fixed before held-out
evaluation when the claim is confirmatory, but a rank sweep is necessary to understand the geometry.
The composed-table margin peak at rank four, the transfer knee near 12–16, and the Left-Basis
asymmetry turning on near rank 15 are not competing estimates of one number. They are signatures of
different curves. In practice, papers should report a low-rank anchor for interpretability, a
null-referenced transfer curve for reproducibility, and a high-rank diagnostic when the target is
hierarchical or trajectory-like. The natural Left-Basis experiment would have been misread if only
rank 5 or rank 10 had been reported; its natural-minus-shuffled asymmetry becomes consistently
positive only from rank 15 onward and continues through rank 50.

Column semantics deserve equal attention. Right-basis comparisons across independent samples are
valid only when the columns are commensurable: the same selected tokens, the same probe blocks, and
the same transform. This is why the OOD orientation study used a fixed intervention-top-`k` token
set and compared right singular subspaces, while refusing to make a cross-sample claim in the left
context basis. The token-covariance reference was not an optional embellishment; it identified the
amount of overlap forced by the common unembedding axis. Without it, the 0.70 OOD-OOD overlap could
have been mistaken for a trivial shared vocabulary effect.

There is a broader lesson about negative results. The natural-text entropy classifier stayed near
chance from rank 2 through rank 20 even though the entropy labels themselves were well separated.
This is not evidence that entropy is meaningless. It shows that label separability in the scalar
predictive statistic does not imply recoverability in the selected left-basis logit geometry. The
controlled entropy-drop experiment succeeded because it used entropy as a phase-alignment rule for
known template trajectories, not as a universal class label. Likewise, the mixed topology study
should not be summarized as either “hierarchy proven” or “no geometry”: principal angles gave a weak
positive hint, while centroids and projection metrics disagreed. Reporting the disagreement is more
scientifically useful than choosing the most favorable metric.

### 11.1 A compact claim ladder

The evidence can be organized as a claim ladder, where each rung requires stronger controls:

* **Descriptive concentration:** the singular spectrum is nonuniform on the measured table.
* **Null-referenced concentration:** the spectrum or reconstruction beats a matched-marginal or
  matched-scale null.
* **Held-out transfer:** the learned subspace predicts unseen rows, probes, blocks, or vocabulary.
* **Distributional specificity:** the result changes under a distribution-matched control rather than
  merely under out-of-distribution corruption.
* **Order specificity:** an exact multiset-preserving intervention or common-target crossover shows
  that sequence order contributes beyond bag statistics.
* **Mechanistic localization:** additive decomposition, feature prediction, or cross-condition
  transfer narrows which algebraic component carries the signal.

The broad intervention-effect table reaches the first three rungs and fails to establish the fourth
as a linguistic claim. The order-pure agreement table reaches the fifth rung within one frame and
offers partial mechanistic interpretation through role prediction. The OOD residual reaches a
different fifth-rung analogue—reproducible geometric orientation above a covariance floor—but not
predictive transfer. The experiments should therefore not be collapsed into a single pass/fail
judgment about “low-rank language.” They occupy different locations on the ladder.

### 11.2 What a decisive next experiment would require

The local evidence points to several high-value next tests, all of which can be designed without
changing the basic black-box setting. First, repeat the order-pure construction across multiple
frames—subject-attractor, relative-clause, and long-distance agreement—while holding token
multisets fixed and using the same common-axis contrast. A positive result would test whether the
role-predictable rank-five-to-eight component is frame-general or a property of the short template.
Second, repeat the broad intervention-effect BICV protocol with larger context and probe pools and
a separately estimated frequency-matched corpus distribution. This would determine whether the
0.076 residual after frequency matching is stable or sampling noise.
Third, align natural trajectories by internal entropy events and validate them against controlled
templates using a matched-length null. The completed calibration shows that this is technically
possible; the negative natural classifier shows that a better phase model is needed.
Fourth, compare the cancellation-residual decomposition across model sizes. If the OOD orientation
excess above the covariance floor scales smoothly, it would become a useful model-level diagnostic;
if it does not, it should remain a scoped property of OLMo-1B.

These are not missing pieces that weaken the present conclusions. They define the boundary between
what the current evidence establishes and what remains open.

## 12. Limitations and unresolved questions

The model scope is narrow: every experiment uses OLMo-1B. The broad tables use small-to-medium
sample sizes (typically 64–192 contexts, 20–40 selected tokens per block, and 8–64 probes), so
larger-model or larger-vocabulary scaling is unknown. The local wiki corpus and controlled lexical
generators are not a representative sample of all language.

The surface-feature decomposition is intentionally simple. It demonstrates that length, token
frequency, entropy, and logit scale explain a large fraction of transfer, but a richer feature set
could explain more—or isolate a residual not tested here. The frequency-matched distribution was
estimated from local samples, not a separate population corpus. The agreement generators have lower
global lexical diversity than wiki text in one crossover study, despite improved row-level matching
in a later version. Thus the broad “surface/distributional” interpretation is strong for the tested
tables but not a proof that no linguistic component exists.

The order-pure result is deliberately narrow: one subject-attractor frame, one common agreement
axis, and disjoint vocabulary transfer within that frame. It does not establish the same rank or
role-predictability for relative clauses, long-distance dependencies, or other grammatical
phenomena. The independent word-shuffle control leaves about 64% of the order-pure magnitude, so
the right statement is algebraic order determination, not universal collapse under arbitrary
corruption.

Left-Basis topology is metric-sensitive. Principal angles, centroids, and projection overlaps did
not always agree. The high-rank asymmetry is robust in one two-frame setup but is not a theorem about
syntactic hierarchy. Entropy-drop alignment is promising in controlled templates, yet natural-text
entropy labels are near chance under a strict frequency-matched left-basis classifier. Natural text
does not provide explicit phase boundaries, and entropy may mix lexical, semantic, and syntactic
events.

The OOD residual result is about right-basis orientation, the only axis that can be compared across
independent context samples with a fixed selected-token support. It does not establish a predictive
OOD code, a mechanism inside the model, or a left-basis statement. Its orientation-only PR effect
is small and its held-out self-suppression is weak. The full norm-plus-spectrum-plus-orientation
effect remains a separate phenomenon.

Finally, the program does not identify a causal neural mechanism. All measurements are input-output
geometry. “Context state,” “interaction,” and “OOD orientation” are algebraic components of logit
tables, not named internal circuits. Any mechanistic interpretation should remain subordinate to the
reported matrices and controls.

## 12. Conclusion

The central question has a precise answer. Some arrangements of black-box next-token logits show
nontrivial, reproducible low-rank structure; others show only in-sample spectral regularity or
distribution-shift geometry. The strongest broad result is the double-centered composed
intervention-effect table: it beats matched-marginal nulls in strict held-out transfer, with rank-
eight gaps around 0.284 and rank-ten cross-intervention gaps around 0.298. That structure is largely
surface/distributional, because frequency-matched random contexts preserve it and simple black-box
features explain much of it. The natural-versus-shuffled rank-four peak is a contrast-specific
margin, not the table's dimension; null-referenced transfer extends to roughly 10–16 dimensions.

At the same time, order-specific low-rank structure is real when the table is designed to isolate
it. Token-multiset-matched agreement contrasts produce a compact, role-predictable component that
transfers across vocabulary. Controlled Left-Basis tables separate syntactic frames and dynamic
trajectories under exact multiset controls, with effects concentrated in middle and high ranks.
These results justify a scoped claim about order-sensitive context geometry, not a global claim that
language is low-rank.

Out-of-distribution residuals complete the picture. Random-token inputs can inflate participation
ratio while reducing transferable structure, yet independent OOD residuals share a reproducible
right orientation above the token-covariance floor. The model therefore produces structure even
when useful linguistic transfer is absent.

The methodological prescription is simple: define the table exactly; fix the column semantics;
state the transform and centering; measure singular spectra and held-out reconstruction; use nulls
matched to the proposed mechanism; preregister the held-out metric; and distinguish order,
distribution, transfer, and in-sample geometry. Under that standard, the local evidence supports
not one rank of language, but a map of several low-dimensional regimes—some predictive, some
surface-driven, some order-specific, and some merely imposed by distribution shift.

## Evidence synthesis sources

The following descriptive references identify the completed source papers used in the synthesis.
They are named by scientific content rather than by source-specific identifiers.

1. **Low-Rank Structure in OLMo-1B Intervention-Effect Logit Tables Is Real and Held-Out-Transferable, but Largely Surface/Distributional Rather Than Linguistic.** Double-centered delta tables, strict bi-cross-validation, surface decomposition, and frequency-matched controls.
2. **Order-Specific versus Capacity-Driven Low-Rank Structure: A Distribution-Matched and Symmetric Crossover Maps Where OLMo-1B Logit Tables Depend on Word Order.** Common-target crossover and the distinction between permutation gaps, shuffled-basis effects, and order dependence.
3. **The Vulnerability Profile: Nontrivial Low-Rank Structure in Dynamic Intervention Deltas.** Positional deletion/padding tables and the early dynamic low-rank result.
4. **The Universal Router: Symmetric Crossover and Out-of-Domain Generalization of the Residual Syntactic Subspace.** Surface controls, order-specific crossover, and out-of-domain transfer.
5. **Rank Four Is a Margin Peak, Not a Dimension: The Null-Referenced Transferable Effective Dimension of Composed OLMo-1B Logit Tables.** Transfer-knee, Gram-spike, truncation-cost, and additive decomposition results.
6. **A Controls Taxonomy for Apparent Low-Rank Structure in OLMo-1B Reflexive Agreement Tables.** Reliability, commensurability, and intrinsic dimensionality as separate axes.
7. **Order-Pure Counterfactual Tables: A Token-Multiset-Matched Construction Isolates an Order-Determined, Role-Predictable Low-Rank Component of OLMo-1B Agreement Logits.** Algebraic bag cancellation, held-out role prediction, and vocabulary transfer.
8. **Participation Ratio Is Inflated by Out-of-Distribution Text While Null-Referenced Transferable Structure Is Not.** The diagnostic dissociation between in-sample PR and held-out transfer.
9. **The Composed Logit Table Is a Context-State Cancellation Residual.** Additive cancellation, residual energy, and OOD PR inflation.
10. **Out-of-Distribution Residual Orientation in the Composed OLMo-1B Cancellation Residual Is a Reproducible, OOD-Specific Structure Above the Token-Covariance Floor.** Cross-sample right-basis overlap and token-covariance control.
11. **The Atlas of Syntax: Linearly Separable Syntactic Templates in the Left Basis.** Controlled frame classification in narrow and broad token spaces.
12. **The Architecture of Syntactic Hierarchy: Asymmetric Subspace Expansion in the Left Basis.** Rank-dependent directional reconstruction and high-rank onset.
13. **The Geometric Resilience of Dynamic Syntactic States: Left-Basis Separability Survives Marginal-Variance Scrubbing.** Left-basis robustness to marginal-variance controls.
14. **The Architecture of Dynamic Routing: Mechanism Intersection and Out-of-Domain Generalization of Pad-Mask Vulnerability.** Dynamic semantic order dependence and intervention-mechanism comparison.
15. **Resolving the Informational Collapse Artifact: Matrix-Level Nulls for Dynamic Vulnerability Profiles.** Why shuffled text can create a simpler manifold and how matrix-level nulls repair the comparison.
16. **The In-Sample Participation Ratio Is an Untrustworthy Low-Rank Diagnostic for Composed OLMo-1B Logit Tables: A Mechanistic Synthesis.** Integrated warning about cancellation, energy, and orientation.
17. **When Centering Helps and When It Harms.** A cross-construction centering ablation showing that preprocessing is part of the scientific object.
18. **Entropy-Drop Phase Alignment on Controlled Templates and Internal-Entropy Classification on Natural Text.** Completed calibration and negative frequency-matched classifier boundaries.
