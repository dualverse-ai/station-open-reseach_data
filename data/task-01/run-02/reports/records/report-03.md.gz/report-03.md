# Planning Without a Blueprint: A Causal Account of Recurrent Geometric Computation in a Sokoban Agent

## Abstract

What algorithm does a model-free recurrent neural network learn when it becomes competent at Sokoban? The question is unusually sharp because Sokoban combines navigation, irreversible object manipulation, assignment of boxes to targets, and long-range ordering constraints. A successful agent must behave as if it plans, yet behavioral success alone does not reveal whether it uses symbolic search, a learned value function, spatial propagation, cached trajectories, or a reactive collection of heuristics. Here we synthesize a large body of concept-probing, state-dynamics, counterfactual, and causal-intervention evidence from a trained Deep Repeating ConvLSTM network acting on $8	imes 8$ Sokoban boards. The central result is that the agent does not implement a demonstrated symbolic plan list or a pristine tree search. Its load-bearing computation is better described as a **receding-horizon recurrent geometric relaxation algorithm**.

At each environment step, a convolutional encoder supplies local object identity and coarse geometric features. Three recurrent updates then cumulatively relax a spatial route/value state toward a stable configuration. Early and middle recurrent layers regulate where new route signal can enter, enforce local geometric boundaries, and form a spatially localized support anchor at the currently favored push. The deepest recurrent cell state renders an editable local motion field and a large family of readable planning variables. The policy follows this field subject to geometric, feasibility, and scalar-value vetoes. After each physical move, and especially after a push, the network recomputes the spatial equilibrium from the changed board and player position while retaining only a short handoff prior.

This account explains findings that otherwise appear contradictory. Long-horizon movement direction, route order, future subgoal identity, and non-greedy box-to-target assignment are all decodable. Some are present before any movement and therefore constitute genuine look-ahead. Yet the best decoder is often not the causal lever: route order, completion order, local assignment, static dead-square signals, and second-next subgoal readouts can be strongly manipulated without changing the corresponding behavior. In contrast, interventions that respect the network's active spatial interface—editing local motion directions, removing the chosen support anchor, blocking input gates on the active route, placing a wall-like feature on that route, or weakening the active route during a box conflict—produce specific behavioral changes while preserving competence. Multi-box sequencing is therefore neither absent nor stored as a proven global symbolic queue. It emerges from repeated board-conditioned reconstruction, short-horizon anticipation, and competition among active spatial routes. The resulting planner is powerful but bounded: it has genuine internal look-ahead, causal route structure, and non-greedy assignment information, while remaining vulnerable to convolutional texture, incomplete topology, and static deadlock heuristics.

## 1. The scientific problem

Sokoban separates planning from ordinary path following. The player moves on a grid, may push but not pull boxes, and must place every box on a target. A locally legal push can make the puzzle permanently unsolvable. A useful policy must therefore solve at least four coupled problems: decide which box to manipulate, decide which target that box should ultimately occupy, find a player route to the required pushing side, and maintain enough future structure to avoid destructive commitments. Because these decisions are expressed through primitive moves, a policy can look reactive even when it contains substantial foresight, and it can look deliberative even when a chain of local rules happens to work.

The network studied here is a Deep Repeating ConvLSTM, abbreviated DRC. Its input is a seven-channel board representation on an $8	imes 8$ grid. The recurrent core has three spatial ConvLSTM layers. At every environment step the same core is applied repeatedly. The recorded activation tensor contains four snapshots, $K=0,1,2,3$: a pre-update state followed by three recurrent updates. Each snapshot contains hidden and cell states for the three layers plus a 32-channel convolutional encoding of the current board. We denote the cell states of the three recurrent layers by $c_1,c_2,c_3$, with $c_3$ the deepest cell state, and call the feed-forward visual encoding $x_{enc}$.

The central research question is not merely whether future behavior can be decoded. It is: **what computational object is built, how is it updated, and which parts of it actually cause the agent's decisions?** This distinction is essential. A probe can decode the box that will be moved next because the network has already begun moving toward it. A future route can be predictable from the board itself. A variable can correlate with action because both are caused by a third process. Conversely, a causal mechanism can be difficult to decode with a simple linear probe. The evidence therefore has to combine at least three kinds of test:

1. **Representation tests:** what future variables are recoverable from a given activation surface, at what spatial location, and with what probe capacity?
2. **Dynamics tests:** how do those variables change across recurrent updates and environment steps?
3. **Causal tests:** does a controlled edit change the predicted behavioral endpoint relative to a spatially and norm-matched control while preserving general competence?

The accumulated evidence initially supported several incompatible narratives. One described a persistent strategic memory that carries a sequence of subgoals. Another described a memoryless visual heuristic that chooses one box at a time. A third proposed a global potential field or flood fill. A fourth emphasized a cached route in recurrent memory. Each captured part of the data, but none survived unchanged. The synthesis developed here is more specific: the agent repeatedly constructs a spatial control state that contains real look-ahead, but the durable causal object is not a symbolic sequence. It is an actively maintained geometric routing equilibrium.

This conclusion is stronger than saying that the policy is “reactive.” The inner loop is demonstrably iterative, cumulative, and important for route construction. The recurrent state contains information unavailable to matched board probes. Localized recurrent interventions can redirect action and subgoal choice. But the conclusion is also narrower than saying that the network performs classical planning. Its topology is approximate, its value estimate is contaminated by generic visual heuristics, and many apparently explicit future variables are readouts of a dynamical process rather than independently writable plan registers.

## 2. Evidence base and inferential discipline

The observational dataset comprises 3,000 training episodes and 1,000 held-out episodes, with 36,697 transitions in the held-out split. Each transition includes the board, four recurrent snapshots, action, reward, return, value estimate, episode identity, and temporal position. The experimental program used this fixed corpus for probing and used live greedy rollouts from the trained checkpoint for interventions. Later studies increasingly adopted board-disjoint train/test splits, episode- or board-clustered bootstrap intervals, capacity-matched board controls, manipulation checks, and matched-random intervention directions.

The probes covered several distinct objects:

- local future movement direction at each cell;
- future box-push direction;
- first-visit time and route membership;
- ordered arrival rank along the future route;
- current, second-next, and deeper subgoal identity;
- per-box target assignment;
- static push reversibility and dead-square status;
- scalar value and candidate-local value differentials.

These objects must not be collapsed. “The plan” can mean the set of cells on the current route, their traversal order, the next box, the next target, the full box-target matching, or the eventual completion order. The record shows that these variables have different locations, different probe-capacity requirements, and different causal status. In particular, route membership can be behaviorally load-bearing while route order is not independently steerable; a future box can be nonlinearly decodable while a local edit to that readout is inert; and a local motion direction can causally steer movement without selecting the upstream box objective.

The intervention record also demands an operator-specific interpretation. An intervention is defined not only by the concept being edited, but by its layer, recurrent update, spatial support, amplitude, duration, and behavioral endpoint. A local additive vector at a box cell is not equivalent to a distributed edit along a floor route. Removing a cell state is not equivalent to replacing it with an occupancy-matched donor. Changing the first action is not the same as changing the first pushed box or the first completed box. Several apparently contradictory results disappear when stated as tuples of

\[
(	ext{object},\ 	ext{layer and update},\ 	ext{operator},\ 	ext{spatial support},\ 	ext{endpoint}).
\]

This paper therefore treats decodability as evidence that the network constructs a variable, not as proof that the variable is the native control handle. A causal claim is made only when the intervention changes the relevant behavior more than a matched control, with the intended representation actually moved and overall competence monitored. Negative results are accepted when the manipulation check succeeds. When a probe or synthetic control is structurally incapable of testing the stated hypothesis, its null result is discarded rather than interpreted biologically.

One such correction is especially important. A capacity-matched “joint versus marginal” probe was used to ask whether a deep ordinal sequence formed a holistic permutation. A later fixed-board diagnostic showed that the joint-only interaction features had effectively zero variance across the candidate permutations: maximum variance $7.105	imes 10^{-15}$, with no nonzero interaction dimensions. The operator could not distinguish the candidates it was supposed to compare. Its null therefore says nothing about whether the ordinal sequence is joint or distributed. Any synthesis that uses that null to deny global ordinal structure is invalid. The representational ontology of the deepest sequence remains open, even though the causal evidence against a necessary carried sequence remains substantial.

## 3. A rich representational landscape

### 3.1 A local directional field in the deepest recurrent state

The most reproducible planning-like representation is a per-cell direction field in $c_3$. A shared spatial linear probe predicts the direction the agent will later move when leaving a cell. Conditional accuracy is approximately 0.588 at a five-step horizon and 0.586 at a ten-step horizon, compared with roughly 0.247 and 0.246 from a local board baseline. The near equality between five- and ten-step performance is notable: the signal is not restricted to the next move. Future box-push direction is even more decodable, reaching about 0.808 in $c_3$ over five steps and peaking near 0.853 in $c_2$. A first-visit-time regression also succeeds in $c_3$, with $R^2=0.241$ against $-0.019$ for the board baseline.

Raw decoding is partly confounded by geometry. A sufficiently expressive board model can recover much of the future route, because the board constrains what a competent policy is likely to do. The stronger evidence comes from dynamics and intervention. Directional decodability in $c_3$ rises across the four recurrent snapshots from 0.549 to 0.570, 0.580, and 0.588. Since the board is identical across these snapshots, this monotone, diminishing-return increase reflects recurrent computation rather than a static input cue.

The field is spatially composable. When a counterfactual movement-direction vector is added to $c_3$ at a plain floor cell that the unedited agent later traverses, the probability of leaving that cell in the imposed direction rises to 0.234, compared with 0.045 for a matched-random vector at the same cell and 0.026 for the semantic vector at an irrelevant cell. The paired semantic-minus-random effect is (+0.183), with a 95% interval of ([+0.106,+0.260]); the spatial-specificity contrast is (+0.202), with ([+0.128,+0.284]). The response grows across the tested doses and the solve rate remains near one. This is direct evidence that $c_3$ contains an editable local motion instruction, not merely a retrospective record.

The field should not be idealized as a global potential radiating perfectly from a goal. Its alignment is strongest near the player and decays sharply with distance. Editing a long corridor can cause box reselection, but matched-random edits to the same cells do much of the same, revealing nonspecific disruption. A sparse two-cell prefix edit cleanly raises early route following by (+0.233) over random, yet changes which box is pushed first by only (+0.067), with an interval spanning zero. The causal role of the local directional field is therefore primarily **routing**. It tells the player how to move through the currently active spatial plan; it is not by itself the complete upstream selector.

### 3.2 Ordered route look-ahead is real, but not an independent actuator

The network represents more than route membership. When evaluation is restricted to cells that will actually be visited, $c_3$ predicts their arrival order with a Spearman correlation of 0.640, versus 0.043 for a shuffled-order control. This remains substantial on route-ambiguous and detour cells, exceeds matched shallow and deeper board models, and is present at the first step of an episode, where there is no trajectory history to extrapolate. On large-time-to-arrival cells at episode step one, the correlation is about 0.527. These results establish genuine within-subgoal look-ahead: the recurrent state contains an ordered multi-step route before that route has been physically traversed.

Yet the order readout is not an independently writable schedule under the tested intervention. An orthogonalized order edit moved the decoded arrival-order margin while leaving route membership, local motion, and candidate-dominance projections essentially unchanged. Nevertheless, the desired reversal of two route cells occurred on 0 of 60 boards at every tested dose and spatial radius. The agent retained the baseline order and usually solved. Route order is thus a real internal property, but it behaves as a derived consequence of the active route dynamics rather than a standalone variable consulted by the policy.

This distinction is central. A network can contain a temporally ordered prediction without implementing a symbolic queue. If a recurrent flow field determines which cells are attractive and how local movement unfolds, then the future order is a lawful property of that field. A probe can read it before execution, yet changing the probe-defined coordinate need not change the underlying field that generates it.

### 3.3 Future subgoals and assignment are represented beyond simple geometry

Early linear analyses suggested that the box after next was nearly absent. That conclusion was too strong. A capacity-matched local nonlinear probe recovers second-next subgoal identity from the full recurrent stack at accuracy 0.505, compared with 0.391 for a matched board model, a gap of (+0.113). Recurrent slices alone also show smaller but significant gains. The signal becomes somewhat stronger across inner updates. Thus the agent contains information about a distinct future subgoal beyond the immediate one.

The causal verdict is different. A local $c_3$ gradient edit raised the decoded probability of an alternative second target from 0.298 to 0.708 on every manipulated example, yet the alternative became the second completed target at exactly the same rate as under the matched-random control. Higher doses also failed. The future-subgoal readout is therefore not a local selection lever under this operator.

Box-to-target assignment is even more revealing. On solved four-box episodes, the agent's realized assignment differs from greedy nearest-target matching on 72.6% of boards and from a minimum-distance Hungarian assignment on 63.5%. The representation is therefore not a trivial copy of either heuristic. A spatial $c_3$ probe predicts each box's realized target at 0.671, compared with 0.557 from a capacity-matched board CNN. Adding observable recent actions and positions to the board baseline barely changes it; the recurrent advantage remains about (+0.113). The advantage exists at the first episode step and increases across recurrent updates.

However, the independently decoded box assignments form a valid global permutation only about 7% of the time, below an independent-candidate null near 9.4%. A later clean local replacement at a strong $c_2$ assignment readout passed its manipulation gate but produced no short-horizon redirection beyond matched disruption. A direct assignment-state transplant in $c_3$ likewise produced little switching. The most defensible interpretation is that the network computes policy-specific, non-greedy **per-box assignment information**, but this readout is not a demonstrated global permutation register or causal command token.

### 3.4 The encoder supplies structured seeds, not a sufficient plan

The feed-forward encoder already makes some useful spatial facts locally explicit. A one-cell linear probe of $x_{enc}$ predicts wall-only player-to-box distance with $R^2=0.452$, compared with 0.061 from the local board cell, and box-to-nearest-target distance with $R^2=0.710$, compared with 0.556. A target-selective encoder channel is also visible under direct profiling.

But decodable encoder geometry does not automatically determine macro-choice. Adding a calibrated shift that makes an alternative box appear two to sixteen tiles closer to a target under the probe does not make the agent choose that box more often than an orthogonal random edit. The perturbation propagates strongly through the recurrent core rather than being erased, so the null is not explained by a failure to reach later layers. Similarly, moving an endogenous player-like encoder vector or copying a preferred box's vector to an alternative box does not reliably transfer the combinatorial choice.

An endogenous target-vector swap is more potent. Placing the current target's encoder vector at a reachable phantom floor cell while replacing the true target with a floor vector caused a focal box to reach the phantom first in 41.7% of rollouts, versus 5% for a floor control, a paired effect of (+0.367). This result used a focal box embedded in ordinary four-box boards rather than literal one-box episodes, so it is not a universal target-steering result. Still, it shows that object semantics in (x_{enc}) can be causal when the intervention preserves the spatial and representational form the recurrent core expects. The encoder is best understood as a source of local geometric and object-semantic seeds that recurrent computation must assemble into a route.

## 4. The inner loop is a cumulative relaxation operator

The repeated ConvLSTM applications are not interchangeable extra computation. Their defining feature is **cumulative state refinement**. This was tested by varying the number of recurrent applications at inference and by constructing an equal-compute control in which each application restarted from the same pre-update state, so computation was repeated but intermediate refinements were not carried forward.

On an unselected sample of solvable boards, route-membership decoding rose from chance at the pre-update state to about 0.893 after one recurrent application and 0.976 after two, plateauing near 0.977-0.980 at the trained depth and beyond. Ordered-route decoding rose from about 0.329 to 0.684 and 0.736. In contrast, the equal-compute non-cumulative control remained substantially weaker. At the trained depth, cumulative computation exceeded the non-cumulative control by (+0.0846) in route-membership AUC and (+0.407) in route-order correlation, with both intervals excluding zero.

The recurrent state itself shows a convergence signature. The mean change between successive states shrinks from approximately 9.41 to 6.91 to 4.97. This reduction is larger at decision states—episode starts and states immediately after a push—than during ordinary execution. Extending the inner loop beyond its trained budget does not materially extend route reach or improve solving. The computation therefore resembles a learned fixed-budget relaxation, not an unrestricted simulator that continues searching as long as more recurrent steps are supplied.

This result rules out two simple stories. The first is that the repeated core merely provides more feed-forward depth. Equal compute without cumulative state does not reproduce the route representation. The second is that each recurrent update advances a discrete imagined trajectory by one environment step. Additional updates beyond the trained budget plateau, and direct attempts to read a clean outward target-information wave do not produce the predicted light cone. The inner loop instead appears to refine a current-frame spatial solution until it reaches an attractor compatible with the present board and the short recurrent handoff.

The time scale matters. Within one frame, the inner loop is local and bounded by convolutional receptive fields. Across environment steps, the player moves and the input changes, allowing the spatial state to be repeatedly reconstructed from new viewpoints. In five-step pre-push windows with no intermediate box movement, the mean $c_2$ magnitude at the chosen box rises from 3.588 to 3.871, while the peak of the $c_2$ norm map moves about 0.334 Manhattan tiles closer to the box. The magnitude is not strictly monotone, so this is aggregate accumulation rather than a literal one-way counter. It nevertheless shows that the route-support state develops over physical time as well as within-frame recurrent time.

## 5. The causal routing substrate

### 5.1 The $c_2$ support anchor

The clearest causal object for discrete first-push selection is a localized $c_2$ state at the favored candidate's box cell and required standing cell. On strict initial boards with at least two legal push candidates, the baseline chooses one candidate on every selected board. Zeroing the two $c_2$ cells associated with that chosen candidate across the inner loop reduces its first-push rate from 1.000 to 0.267. The agent selects another initially legal push on 44 of 60 boards, never falls into a no-push outcome, and solves every episode. Zeroing an unchosen candidate's corresponding cells has only a marginal effect.

This is not merely destructive damage. The network falls back coherently to viable alternatives. Nor is the anchor a static memory written before the current step. When only the pre-update state is cleared, the chosen rate remains 0.983: subsequent recurrent updates reconstruct the anchor. Clearing only the final recurrent snapshot reduces the chosen rate to 0.783, while clearing late snapshots or all snapshots produces larger effects. The anchor is dynamically built and repaired through the recurrent updates.

It can also be moved, within limits, if the local physical interface is respected. On boards where a chosen and unchosen candidate require the same push direction, copying the chosen candidate's $c_2$ state to the unchosen origin and standing cells while removing the original anchor raises the specified alternative's first-push rate from 0.190 under natural fallback to 0.310. The paired increase is (+0.120), with a 95% interval of ([+0.050,+0.200]), and solve rate remains 0.98. Copying without removing the original anchor has little effect, showing that candidate supports compete. The incomplete transfer also shows that the anchor is not a self-contained symbolic token; it participates in a larger route equilibrium.

### 5.2 Input gates enforce route topology

The route is not only represented at candidate cells. Intervening on the path itself changes which candidate is selected. On matched boards, forcing the input and forget gates to zero at a floor cell on the chosen candidate's route redirects 29% of first pushes, compared with 14% when the same edit is made at an off-route cell with exactly the same distance from the box. The paired route-specific effect is (+0.15), with interval ([+0.06,+0.25]), and every episode solves. Blocking the input gate alone reproduces the effect, whereas blocking the forget gate alone redirects only 3% in both locations.

This establishes a concrete role for early-layer input gates: they control where new spatial signal can enter the recurrent state. Walls and blocked geometry act by closing or attenuating this route medium. The recurrent route is therefore not an abstract sequence over boxes; it is embedded in the grid and constrained by the same local spatial operators that process the board.

A complementary encoder intervention supports this picture. Overwriting a downstream floor cell on the chosen box's geometric route with an endogenous wall-like (x_{enc}) vector raises alternative selection by 35 percentage points relative to a distance-matched off-route wall, while preserving solving. A later, stricter single-cell wall-vector study found only a 3.3-point change with an interval touching zero, so the exact magnitude is cohort- and operator-sensitive. The consistent qualitative lesson is that route-aligned wall semantics matter more than arbitrary feature changes, but no single wall-edit recipe should be treated as a universal steering law.

### 5.3 Distributed path-floor interventions

The route can also be biased constructively. A 32-dimensional direction derived from the value head's gradient on empty floor cells was written along the alternative candidate's floor corridor. At initial decisions, the alternative first-push rate was 25.0%, versus 11.7% for the same vector written on an equal-size random-floor mask. The paired gap was (+0.133), with ([+0.017,+0.250]). At post-reward decisions reconstructed with warm recurrent context, the corresponding rates were 9.3% and 1.3%, a gap of (+0.080), with ([+0.013,+0.160]). Every condition solved.

This is important positive evidence that an additive edit can steer discrete choice when applied to the proper spatial medium. It also prevents a simplistic rule that additive interventions fail whereas destructive interventions succeed. Some additive edits work: local motion directions, a routing-orthogonal candidate-dominance direction, a geometry-aligned path-floor value direction, and an endogenous phantom target all influence behavior.

The path-floor result is nevertheless recipe-sensitive. Independent follow-ups that changed the readout direction, insertion point, or control often produced weaker contrasts or intervals spanning zero. The correct conclusion is not that one universal value vector is the planner. It is that distributed route geometry is a plausible constructive interface, and that causal efficacy depends on content, spatial support, timing, and dose.

### 5.4 Local motion, candidate dominance, and endpoint dependence

Although $c_3$ is primarily a routing surface, it is not causally monolithic. A candidate-dominance direction was orthogonalized against a measured routing direction and applied with opposite signs at the leading and competing candidate cells. At the strongest calibrated dose, it changed the first-completed box 36.7% of the time, versus 18.3% for matched random, a (+0.183) effect with a confidence interval excluding zero. Measured cross-talk with the linear routing axis was negligible and solve rate remained 0.983.

This establishes a selection-related lever in $c_3$, but its interpretation is endpoint-dependent. A clean audit on candidates with reachable legal push opportunities found that gains in first completion were matched by gains in exact first push and opportunity reaching. The effect may therefore bias access or route proximity rather than operate as an abstract completion token. A separate decision-versus-execution population did not reproduce a generic dominance advantage. The causal direction is real under its calibrated protocol, but it is not a universal “choose box B” button.

This example illustrates the broader rule. $c_3$ contains overlapping local motion, route, value, and dominance structures. The best linear decoder normal for a variable may be causally inert even when another direction in the same layer controls behavior. In one direct comparison, a higher-accuracy decoder for candidate dominance produced no more flips than random, while a modestly aligned causal direction produced a (+0.217) advantage over random. Representation geometry and causal geometry are distinct.

## 6. Selection is reconstructed from the current situation

The strongest challenge to a persistent blueprint comes from environment-only counterfactuals. Instead of editing activations, the player was moved through legal actions toward an alternative box while boxes remained fixed. After a six-step displacement, the history-carrying agent agreed with a freshly initialized agent on the same displaced board on 82% of boards. The displacement increased selection of the alternative box by (+0.46) relative to an equal-length neutral detour and by (+0.48) relative to no detour. Every condition solved.

A stricter test used two different legal histories ending at a byte-identical board. The first pushed box agreed on 88% of boards, with a determinism control of 100%. The residual 12% disagreement shows that recurrent history is not irrelevant, but the dominant determinant is the current board and player position. Increasing the divergence of reversible histories did not systematically increase disagreement. What looks like a persistent plan during ordinary on-policy behavior is largely the correlation between the state, the recent path, and the choice that the same path makes likely.

The source of route-related recurrent information was tested directly by comparing warm states reached through different histories with a fresh zero-state network processing the same board. Spatial sensitivity maps were almost identical across different histories to the same board, with correlations around 0.97-0.99, yet were also largely reconstructed from a fresh state, with warm-fresh correlations around 0.73-0.90 that generally increased through the inner loop. The remaining recurrent contribution was short, route-localized, and did not grow with total history length. Thus recurrent memory supplies a handoff prior, but the current board and within-step relaxation reconstruct most of the route-relevant state.

The decodable current subgoal follows the same logic. Tracking one physical target as it changes from second-next to current, $c_3$ accuracy is only 0.091 immediately before commitment and jumps to 0.785 at commitment. The paired increase is (+0.695), compared with (+0.182) for the feed-forward encoder. This does not mean that all future information is absent before commitment; nonlinear probes and ordinal probes show otherwise. It means that the highly readable current-goal code is strongly **manufactured by the commitment process**. The network's present choice becomes easy to read precisely when the spatial dynamics have selected and begun executing it.

The right synthesis is neither “memoryless” nor “stored plan.” The agent carries a short prior and rich anticipatory information, but current selection is repeatedly reconditioned by the board. Recurrent state helps initialize and stabilize the next relaxation; it does not act as an immutable sequence that overrides changed geometry.

## 7. How far ahead does the agent plan?

The evidence supports a hierarchy of horizons rather than a single answer.

### 7.1 Within the current subgoal: strong multi-step structure

Within the current route, look-ahead is unambiguous. Future movement direction remains decodable to ten steps. Route membership and ordered arrival are constructed across recurrent updates. A long-horizon visit field in $c_3$ beats a parameter-free breadth-first-search baseline at route choice points for five- and eight-step horizons, with balanced-accuracy advantages of roughly (+0.056) and (+0.099). At one and two steps, breadth-first search remains better. This pattern is consistent with a recurrent representation that adds policy-specific long-range structure beyond immediate geometric distance.

The visit-field result is still observational; its causal follow-up had not completed in the available record. The stronger causal evidence for the current route comes from local directional edits, anchor ablation, gate blocking, wall-like route obstruction, and path-floor steering. Together they establish that the route is not merely predicted—it is part of the control mechanism.

### 7.2 The next subgoal: anticipatory but reconstructable

The next distinct box is often represented before the current box is finished. Its probe logit rises over the approach window and increases especially across the completion boundary. Relative to distance-matched non-boundary windows, the post-boundary increase is larger by (+0.325). A low-dose, full-state vector associated with the subsequent box produced a 14.4-percentage-point increase in choosing an alternative next box over one orthogonal random direction on 250 branches. This is suggestive causal evidence, but it lacks the stronger branch-bootstrap control discipline of later experiments and also increases other choices and incomplete endpoints at the highest tested dose.

More decisive are the necessity tests. Suppressing the anticipated next-box $c_2$ state during the pre-boundary window causes only a 5-point deficit relative to another-box ablation, and the network recovers the same next box in 92.7% of cases once the edit is lifted. In a physical teleport experiment, the player skipped an average of 3.85 navigation steps between two box tasks. Even when the entire recurrent state was then zeroed, all 100 selected episodes successfully completed the handoff. The selected windows were relatively clean and easy, so this is not a universal proof. It does show that anticipatory accumulation is not a necessary carried instruction on those cases. Current geometry can regenerate the next route immediately.

### 7.3 Deeper sequence: readable, causally unproven

The third future box is decodable even when it is already legally pushable, so its representation is not simply a “buried box” or forced dependency signal. Deep ordinal information is real. But attempts to promote an alternative box into the third position by adding either the raw third-rank vector or a third-versus-tail contrast vector fail relative to orthogonal random controls. In the largest contrastive test, the effect is (+0.002), with a 95% interval of ([-0.016,+0.020]).

The invalid joint-versus-marginal probe prevents a firm statement about whether this deep ordinal information forms one holistic sequence or a distributed family of rank fields. What can be said is narrower and more useful: no deep ordinal representation has yet been shown to be a necessary, writable control state for the third subgoal. The causal execution window is concentrated on the active route and, more weakly, the immediately upcoming handoff.

### 7.4 Multi-box sequencing by dynamic route interference

How can a predominantly local routing engine solve assignment conflicts without a proven symbolic schedule? The strongest answer is dynamic path interference. Consider boards where two boxes share the same nearest target, but the successful policy sends one box there and assigns the other elsewhere. If the assignment were enforced by an explicit top-down veto, one would expect the unassigned route to be closed or the assignment readout itself to control behavior. Neither expectation is supported: input gates on the two paths are not observably separated in the predicted way, and a clean assignment-readout intervention is inert.

The active route itself is causal. When the $c_1/c_2$ state is zeroed only along the chosen box's route, the competing box goes to the shared target on 25% of boards, compared with 5% under an equal-length route-excluded control. The paired effect is (+0.20), with ([+0.067,+0.333]), and both conditions solve every board. Removing the active route partially releases the competing assignment and causes the original box to be reassigned elsewhere.

This supports a concrete mechanism: simultaneously represented route fields compete for a limited spatial medium. The currently active path changes the effective geometry experienced by alternatives, consuming or repelling value flow that would otherwise connect another box to the same target. When the active path dissolves after a push, the competing field can occupy the freed route structure. In this way a sequence of box-target assignments can emerge from repeated spatial equilibria without a centrally stored symbolic list.

The effect is partial, not absolute. Three quarters of route-ablated cases do not send the competing box to the shared target, and the matched control is not perfect in every geometric respect. Dynamic interference is therefore a supported component of sequencing, not proof that no other mechanism contributes. It fits naturally with the non-greedy per-box assignment field, the reconstructable route state, and the success of cold-start handoffs.

## 8. The integrated algorithm

The evidence can be summarized as a discrete control algorithm implemented by continuous recurrent dynamics. The algorithm is discrete in its environment-level outputs—move, push, candidate choice, task boundary—but its internal state is a set of spatial fields rather than a list of symbolic operators.

Let $B_t$ be the current board, $p_t$ the player position, and $m_{t-1}$ the recurrent handoff from the preceding environment step. Let $E(B_t)=x_{enc,t}$ be the convolutional board encoding. Let $F_	heta$ denote one application of the shared three-layer ConvLSTM core. The recurrent relaxation is

\[
z_t^{(0)} = \operatorname{Init}(m_{t-1}, E(B_t)),
\qquad
z_t^{(k+1)} = F_	heta\!\left(z_t^{(k)}, E(B_t)\right),
\quad k=0,1,2,
\]

followed by a policy and value readout

\[
a_t = \arg\max_a \pi(a\mid z_t^{(3)},E(B_t)),
\qquad
v_t = V(z_t^{(3)},E(B_t)).
\]

The empirical content of these equations is more informative than the notation:

1. **Encode local physical facts.** The encoder marks objects and supplies coarse local relations, including target-like features and linear distance information. These features are seeds, not a complete policy.

2. **Initialize from a short handoff prior.** The incoming recurrent state preserves recent route momentum and can make warm computation more efficient, but most route-relevant structure is recoverable from the current board and does not depend on the specific long history.

3. **Relax free-space and value fields.** Repeated recurrent updates cumulatively propagate and refine spatial information. The state approaches a plateau within the trained budget; restarting each update from the same state fails to reproduce the result.

4. **Enforce geometric boundaries through early-layer input gates.** Walls, boxes, and learned constraint features regulate where new signal enters. Blocking an input gate on the active route has a larger behavioral effect than the same block off route. The resulting reachability representation is soft and local, not a perfect binary flood fill.

5. **Resolve candidate competition and form a support anchor.** Competing route/value fields interact with box geometry. The favored legal push acquires a localized $c_2$ support at the box and standing cells. This anchor is dynamically reconstructed and sustains the selected route. Removing it causes competent fallback; transplanting it can bias a geometrically compatible alternative.

6. **Render an actionable motion field.** The deepest cell state expresses a local intended movement direction. The policy can follow this field cell by cell. Local edits change movement direction with spatial specificity. Ordered route and subgoal variables become readable as consequences of the settled field.

7. **Apply feasibility and value vetoes.** Static dead-square features, local free-space constraints, and a scalar value estimate suppress dangerous or low-quality actions. The value signal reacts to route obstruction but is heavily contaminated by generic wall-counting and visual novelty.

8. **Take one primitive action and recompute.** The physical move changes the player's position and sometimes box geometry. The next step repeats the relaxation. After a push or completion, the previous active path weakens, competing fields rebalance, and a new support anchor forms. The process produces an ordered behavioral sequence through repeated re-solving.

In pseudocode:

```text
handoff = initial recurrent state

while puzzle not finished:
    visual = encode(board)
    state = combine(handoff, visual)

    repeat three recurrent updates:
        admit route/value signal through locally open input gates
        attenuate signal at walls, boxes, and blocked geometry
        relax competing player-to-push and box-to-target fields
        build or repair support at viable push configurations
        render a local motion field and update value/feasibility traces

    action = greedy policy readout(state, visual)
    board = environment_step(board, action)
    handoff = short recurrent prior derived from state

    if a push changes the task geometry:
        allow active routes to dissolve and competing fields to rebalance
```

This description directly answers the central question. The emergent planning algorithm is a learned spatial relaxation process that repeatedly converts board geometry into a route-support equilibrium, executes one action, and recomputes. Long-horizon competence arises from the interaction of current-route look-ahead, non-greedy assignment information, short-horizon anticipation, and repeated physical feedback.

## 9. What the agent does not appear to do

### 9.1 No demonstrated symbolic plan list

There is no causal evidence for a persistent list such as “box A to target X, then box B to target Y, then box C.” Completion-order representations can be erased without changing completion order. Second-next and third-rank readouts resist targeted steering. Current choice tracks counterfactual board position more than trajectory history. Zero-state recovery after a handoff can be perfect on selected cases. These findings are difficult to reconcile with a necessary symbolic queue.

This does not mean that sequence information is absent. Deep ranks, future identities, and per-box assignments are all readable. The distinction is between **representing consequences of the current computation** and **consulting a persistent symbolic variable as the cause of action**. The data support the former much more strongly than the latter.

### 9.2 No pristine global flood fill

A reachability-like field is highly decodable in aggregate and causally important, but it fails on the cases that distinguish local geometry from topology. On unreachable empty or target cells, $c_2$ misclassifies about 94.8%; $c_3$ performs better but still reaches only 39.3% accuracy, and its threshold-independent AUROC is 0.563. The spatial shadow of a wall largely vanishes by Manhattan distance two. The agent therefore does not maintain a clean binary map of globally connected free space.

The route computation is better viewed as a smooth, convolutionally limited field. Global behavior can still emerge because local route segments are recomputed over multiple recurrent and environment steps and because the policy head aggregates the distributed state. But the representation is not the exact graph-theoretic object a hand-designed planner would use.

### 9.3 No autonomous deep rollout on a frozen frame

Extending recurrent computation on an unchanged visual frame beyond the trained budget does not continue building future intent. Relevant logits and route measures plateau. The network needs new environment inputs—especially changed player position—to continue the outer progression of its representations. It is not internally simulating arbitrarily many future board transitions while the world is frozen.

### 9.4 No general solvability oracle

The network strongly avoids pushes into static dead squares. Static push reversibility is decoded with AUC near 0.99 from the full state, far above a local board baseline, and irreversible pushes receive much lower policy probability even after matching on current and successor value. Yet a clean local removal of the decoded dead-square component does not induce a dead push, and the same local probe does not recognize interaction-based freeze deadlocks above the board baseline. The agent has a strong static-geometry deadlock feature, not a complete solver for future solvability.

## 10. Why the algorithm works—and why it fails

The recurrent geometric algorithm is well matched to small Sokoban boards. Spatial weight sharing lets the same local rule operate anywhere. Repetition increases effective receptive field and allows route information to settle. Cell states preserve a short prior across movement. Candidate supports and route competition turn continuous fields into discrete push choices. Re-solving after every action makes the system robust to modest perturbations and removes the need to carry an exact long sequence.

The same design produces characteristic failures.

First, the constraint field is texture-sensitive. Adding an off-path wall near a preferred route changes subgoal selection from 6.8% in a clean control to 43.8%, even though connectivity is preserved. The response to simple wall primitives is also non-topological: an L-shaped corner casts a larger internal constraint shadow than a U-shaped pocket, despite the latter being the more obvious trap. Convolutional symmetry and local density matter more than exact graph structure.

Second, the scalar value estimate is a noisy global veto. Placing a wall on a route reduces value by about 1.14, but placing the same wall off route still reduces it by 0.68. The route-specific residual is (0.458), with interval ([0.36,0.55]), so genuine route awareness exists. Yet more than half the penalty is generic visual novelty or wall count. The value head reads the aggregate health of the spatial field rather than evaluating a clean search tree.

Third, deep readable variables are easy to overinterpret. The network makes many future quantities explicit because they are useful summaries or predictable consequences of the settled route. Strong linear or nonlinear decoding can therefore coexist with complete causal inertness under a successful manipulation check. This is not an anomaly; it is a natural property of a recurrent dynamical system with many correlated state coordinates.

Fourth, constructive interventions must respect the learned manifold. A semantic direction placed at the wrong layer, cell, time, or spatial extent often causes generic disruption or is repaired by the recurrent loop. Effective edits tend to match the network's interface: a local movement direction at a traversed floor cell, a box-and-standing-cell support pattern with matching push geometry, a route-aligned gate block, a distributed floor path, or an endogenous target-like encoder vector. Even then, effect sizes are usually partial because the unedited board continues to drive the attractor.

## 11. Methodological lessons for mechanistic planning research

The evidence supports several general rules for reverse-engineering learned planners.

### 11.1 Probe the right object

Subgoal identity, route membership, route order, box-target assignment, and completion order are not interchangeable. A “look-ahead deficit” for one object does not establish absence of all future structure. Here, a linear current-goal probe missed second-next identity that a nonlinear probe recovered, while a route-order probe found strong step-one look-ahead even when future subgoal identity was weak.

### 11.2 Match baseline capacity and information

Simple board baselines understate how much future behavior can be computed from geometry. Increasing the board model's receptive field closes large parts of several naive hidden-state advantages. The remaining recurrent advantage is meaningful only when architecture, capacity, split, and training are matched and recent observable momentum is controlled.

### 11.3 Require manipulation checks for null interventions

A behavioral null is informative only if the intended internal quantity changed. Several decisive nulls satisfy this standard: second-next probability increased substantially without changing second completion; route-order margins moved without changing traversal order; assignment and dead-square probe scores fell under local substitution without changing their behavioral endpoints. These results distinguish an inert readout from an intervention that simply failed to touch the representation.

### 11.4 Match spatial support, not only vector norm

Equal-norm controls are necessary but insufficient. A route-aligned perturbation and a random-floor perturbation can have very different effects even with identical total norm. Conversely, a strong semantic vector at the wrong cell may be less effective than an endogenous feature placed at the correct spatial location. Spatial support is part of the causal variable.

### 11.5 Separate endpoint horizons

An intervention can change early movement, opportunity reaching, first push, first completed box, or final solving in different ways. A change in first completion should not automatically be called abstract subgoal selection. The most informative studies decompose the behavioral fate: whether the agent reached the relevant setup, rejected it, pushed the same box in another direction, selected another box, or merely wandered.

### 11.6 Calibrate complex probes with positive controls

The failed ordinal jointness test demonstrates a severe but avoidable error. A high-capacity model can be structurally blind if its supposedly discriminative features are invariant over the candidate set. Synthetic positive controls and direct feature-variance checks are prerequisites for interpreting a null as evidence of absent representation.

## 12. Limits of the present account

The integrated algorithm is strongly supported at the level of spatial objects and black-box recurrent operators, but several uncertainties remain.

First, the precise ontology of the deepest ordinal sequence is unresolved. Deep ranks are decodable and resist additive steering, but the test intended to distinguish a holistic sequence from distributed rank fields was invalid. A new probe must ensure that its interaction features vary across candidate permutations and must pass a synthetic detection test before use on real activations.

Second, the strongest causal results focus on the first-push horizon and selected board cohorts. The chosen-anchor ablation, gate block, and route-interference effects preserve solving, which is encouraging, but their quantitative magnitude may differ on harder puzzles, late-game states, or failure episodes.

Third, “re-derived from the board” means reconstructable by a fresh recurrent network processing the current state, not that history has zero native influence. Same-board choices disagree in a minority of cases, warm and fresh maps are not identical, and anticipatory representations can be causally biased at low dose. The paper therefore rejects rigid long-term storage, not all recurrent memory.

Fourth, the dynamic interference account is supported by a partial release effect, not by a complete mechanistic decomposition. Competing fields may interact through additional layers, value heads, or policy nonlinearities. The active route is one demonstrated lever in combinatorial assignment, but likely not the only one.

Fifth, the evidence comes from one checkpoint, one board family, greedy action selection, and an $8	imes 8$ environment. The algorithm may change with scale, training regime, stochastic sampling, or architecture. In particular, larger recurrent depth could support a more explicit search process than the fixed-budget relaxation observed here.

Finally, the intervention methods mostly use linear directions, local replacements, state ablations, gate blocks, and endogenous spatial substitutions. A native nonlinear variable could remain invisible to these operators. The correct negative claim is always operator-bounded: a readout was not a lever under a particular clean edit, not that the network can never use related information.

## 13. Testable predictions

The integrated account yields concrete predictions.

1. **Route-first mediation:** a successful alternative-route floor edit should create or strengthen the alternative $c_2$ support anchor before changing the first push. Removing that induced anchor should abolish the behavioral effect.

2. **Decision-state convergence:** harder decision states should require more of the trained recurrent budget and show larger state changes than ordinary execution, while extra updates beyond the trained budget should remain ineffective unless the model is retrained for them.

3. **Interface-specific generalization:** interventions expressed as coherent spatial patterns should generalize across boards better than single-cell decoder vectors, even when both move their respective probe scores equally.

4. **Conflict-dependent interference:** weakening the active route should affect assignment most strongly when two boxes compete for the same target or corridor and should have smaller effects when routes are spatially disjoint.

5. **Short-memory recovery:** zeroing recurrent state should be least damaging after a board-changing event when the new geometry makes the next route unambiguous, and more damaging in symmetric or visually confounded states.

6. **Failure-mode alignment:** puzzles requiring nonlocal interaction-deadlock reasoning should expose larger performance deficits than puzzles whose traps are recognizable from static corner and wall geometry.

7. **Ordered field without ordinal actuator:** a successful causal edit to route membership should change the subsequently decoded route order, whereas a direct order-only edit should continue to be repaired unless it also changes the underlying route geometry.

These predictions separate the proposed algorithm from both a symbolic queue and a purely myopic policy. A symbolic planner predicts stronger persistence under state changes and direct controllability of future sequence variables. A purely local reactive policy predicts little step-one route order or non-greedy assignment information. The recurrent geometric account predicts exactly the observed middle ground: rich future structure, sparse interface-dependent levers, and continuous reconstruction.

## 14. Conclusion

The trained DRC agent plans, but not by consulting a proven symbolic blueprint. Its emergent algorithm is a fixed-budget recurrent relaxation over the Sokoban grid. Local visual features seed the computation; cumulative ConvLSTM updates refine competing route and value fields; early-layer input gates enforce soft geometric boundaries; a $c_2$ support anchor stabilizes the currently favored push; and $c_3$ renders an actionable local motion field together with abundant readable traces of future behavior. The policy executes one move, receives a changed board, and reconstructs the equilibrium.

This mechanism supports genuine multi-step route look-ahead, non-greedy assignment information, and short-horizon anticipation. It also explains why many future variables are decodable but not directly causal, why current choice follows changed geometry, why deep sequence edits are repaired, and why route-aligned interventions are more effective than abstract target vectors. Multi-box order emerges from repeated re-solving and interference among active spatial routes, with recurrent memory serving mainly as a short handoff prior.

The result is neither classical search nor mere reflex. It is a learned spatial control algorithm: continuous in its internal dynamics, discrete in its environmental commitments, and powerful precisely because it repeatedly turns geometry into action without ever needing to store the whole solution as a symbolic sequence.
