# Planning Without a Program: Continuous Geometric Relaxation and Emergent Sequencing in a Recurrent Sokoban Agent

## Abstract

How can a model-free recurrent agent solve Sokoban, a domain in which a locally plausible push can irreversibly destroy the solution, without an explicit search procedure or symbolic planner? We synthesize a large body of probing and causal-intervention evidence from a trained Deep Repeating ConvLSTM agent to answer this question at the algorithmic level. The central result is that the agent does not execute a stored list of box identities, target assignments, or future actions. Its operative planner is a recurrent, board-conditioned geometric relaxation. Within each environment step, repeated ConvLSTM updates cumulatively refine a spatial route representation toward a stable state. Value-like activity propagates over empty floor, is constrained by local geometry and topology-sensitive input gating, and terminates in a localized support state near the selected box. A downstream directional field then converts this settled geometry into local movement. Across environment steps, recurrent state provides a short route-localized handoff prior and produces accumulating anticipatory traces, but the dominant route and selection structure can be reconstructed from the current board; even a cold-start teleport with zero recurrent state recovers the correct next handoff.

This geometric engine also explains apparent long-horizon planning. The network contains genuine representations of within-route arrival order, second-next subgoals, per-box target assignments, and deeper ordinal ranks. Yet these representations are usually not independent control variables: manipulation-checked edits can substantially change their decoded values without changing behavior. In contrast, interventions that respect the active spatial interface—editing the path floor, blocking an on-route recurrent gate, ablating the selected support anchor, or modifying a local motion direction—reliably alter the policy while preserving competence. Multi-box sequencing emerges because simultaneously plausible routes compete for limited recurrent spatial support. The active path suppresses or displaces rival flows; when it disappears after a push, the next field rapidly occupies the freed geometry. Thus the agent achieves multi-step behavior through repeated geometric re-solution, not through a carried symbolic program.

The resulting algorithm is neither classical search nor simple reflex. It is an iterative physical computation with sparse, geometry-aware causal levers, abundant readable footprints, and predictable heuristic failures. This account directly answers the central research question: the trained recurrent agent plans by repeatedly relaxing distributed spatial constraints into one executable route, using the environment itself as the clock that turns local geometric equilibria into an extended sequence.

## 1. The scientific problem: what kind of planning can a recurrent policy implement?

Sokoban is a useful stress test for mechanistic accounts of learned planning because its difficulty is not reducible to navigation. The player may walk freely through open corridors, but boxes can only be pushed, never pulled. A box placed against the wrong wall or into the wrong corner can make the board unsolvable. Competence therefore requires at least four kinds of coordination: selecting a box, selecting a push direction, routing the player to the correct side of that box, and ensuring that successive local choices remain compatible with later box-to-target assignments.

The agent considered here is a Deep Repeating ConvLSTM network, abbreviated DRC. On each environment step it receives a seven-channel 8 × 8 board encoding and repeatedly applies a three-layer convolutional recurrent core. The recorded activation tensor has four within-step snapshots, conventionally called inner ticks, and 224 spatial channels. Tick zero is the recurrent state before the current step's repeated update; ticks one through three follow successive applications of the shared recurrent module. The channel groups include hidden and cell states for three recurrent layers, plus a static visual encoding. We call the three recurrent cell-state surfaces `c1`, `c2`, and `c3`, from shallow to deep. These names are architectural coordinates, not assumed cognitive modules.

The central question is not merely whether future behavior can be decoded from these activations. A trained policy's future trajectory is correlated with the board, its current action, its recurrent state, and its eventual solution. Almost any of these variables can support a predictive probe. The stronger question is: **what internal computation produces the behavior, and what representation is causally used as the agent moves from the current board to a sequence of successful pushes?**

Several candidate algorithms are initially plausible.

1. A **symbolic blueprint planner** could compute an ordered list such as “push box A to target X, then box B to target Y,” store it in recurrent memory, and execute it step by step.
2. A **limited forward simulator** could internally roll out a small tree of physical futures during the repeated inner updates.
3. A **reactive heuristic policy** could choose a locally attractive action directly from the current image, with recurrent state providing little more than inertia.
4. A **continuous geometric planner** could iteratively settle a spatial field over the board, allowing routes and box choices to emerge from distributed competition rather than discrete enumeration.

The evidence strongly favors the fourth account, with an important qualification: it is reactive in the sense of being repeatedly re-derived from the current board, but it is not shallow. The recurrence performs genuine iterative computation; the current route is causally load-bearing; forward variables are richly represented; and inter-step state provides a useful short prior. What is absent is a causally necessary, history-specific symbolic macro-plan.

This distinction matters because many early observations appear to favor a stored plan. Future movement direction is decodable several steps ahead. Box-push direction can be decoded at high accuracy. Arrival order, second-next subgoal identity, and non-greedy box-to-target assignment are all present in the recurrent state. Candidate identity can remain stable during a long approach. None of these facts, however, establishes that the decoded variable is the object the policy consults. The corpus repeatedly shows that a representation can be accurate, temporally structured, and behaviorally correlated while being dispensable under a targeted intervention. Conversely, a weakly decodable or spatially distributed quantity can be a powerful causal lever.

The scientific story is therefore organized around a separation between **footprints** and **levers**. A footprint is a variable that records, predicts, or reflects the computation. A lever is a state whose controlled modification changes the relevant behavior under a specified intervention. The distinction is not metaphysical: it depends on the object, layer, inner time, intervention operator, and behavioral endpoint. A route-order vector can be inert under a matched additive edit while route membership is load-bearing; a candidate score can be a partial lever in one subspace while the best decoder direction is inert; a local dead-square readout can coexist with causal support activity on the same recurrent surface without itself controlling avoidance.

The synthesis below develops a positive algorithm from these dissociations. It first explains the evidential logic, then reconstructs the spatial engine, its temporal organization, and the emergence of long-horizon sequencing.

## 2. How to infer an algorithm from probes and interventions

### 2.1 Probe performance is evidence of availability, not use

The most common measurements in the corpus are spatial probes: shared linear or shallow nonlinear maps applied at every board cell to predict future occupancy, movement direction, push direction, arrival time, box identity, target identity, or ordinal rank. These probes are appropriate because the DRC's states preserve the board's spatial layout. They also create a recurrent interpretability hazard. A probe can succeed for at least four different reasons:

- the network explicitly computes the target variable;
- the variable is an easy function of the board geometry;
- the variable is a downstream consequence of a decision already made elsewhere;
- the probe exploits on-policy correlations between the current trajectory and the eventual outcome.

The evidence base contains several controls that progressively narrow these possibilities. Board-disjoint splits prevent memorized board identity from leaking across train and test. Capacity-matched board models ask whether the same architecture can recover the target directly from the visual state. “Board-clean” inner-tick comparisons hold the board fixed and measure whether decodability changes as only the recurrent computation advances. Same-board/different-history comparisons hold all board channels fixed while varying recurrent provenance. Step-one analyses eliminate trajectory history. Matched nonlinear probes test whether a linear null is merely a capacity artifact.

These controls reveal real internal computation. For example, route membership and order sharpen across inner ticks even though the board is unchanged. A nonlinear probe recovers the second-next subgoal above a matched board baseline when the corresponding linear probe fails. Per-box target assignment is more explicit in `c3` than in a capacity-matched spatial board network, including on the first step before any push. Such findings establish that the recurrent network constructs planning-relevant state; they do not, by themselves, identify the policy's control variables.

### 2.2 Causal claims require an operator and an endpoint

Intervention results are interpretable only when the operator and endpoint are explicit. Adding a vector, zeroing a cell, blocking a gate, freezing a layer, moving the player, or erasing a subspace are not interchangeable operations. Nor are “first action,” “first pushed box,” “first completed box,” “route order,” and “solve rate” interchangeable outcomes.

The most persuasive intervention studies share five properties.

First, they compare the intended edit with a matched random or irrelevant-location control. Neural states are sensitive; generic disruption can easily change a trajectory. Second, they include a manipulation check showing that the target readout actually moved. Third, they monitor solve rate or other competence measures to distinguish steering from breakage. Fourth, they use paired board-level uncertainty estimates rather than treating correlated frames as independent. Fifth, they avoid cross-episode donor substitution, instead applying local additions, erasures, ablations, or environment manipulations to the network's own state.

This discipline produces a causal atlas rather than a single binary verdict. Some features are **necessary**: suppressing the spatial constraint field or denying cumulative route refinement sharply degrades behavior. Some are **sufficient to bias** behavior: a local motion-direction edit, a path-floor value injection, or a routing-orthogonal candidate-dominance edit changes the selected trajectory. Some are **inert under a verified operator**: completion order, route arrival order, and second-next identity can be moved or erased without changing the matching behavioral variable. Some effects are **interface-dependent**: a feature is causal only when edited at the correct cells, inner times, and spatial geometry.

This operator-aware view resolves what otherwise looks like contradictory evidence. Additive interventions sometimes fail because they target a readable variable outside the network's active computational interface. Yet addition is not intrinsically ineffective: adding a local movement direction at a traversed cell or adding a value vector along an alternative path can steer behavior. Likewise, destructive edits sometimes expose a necessary substrate, but destruction is not intrinsically causal: removing a decoded dead-square signal at its strongest cell and tick can leave behavior unchanged. The decisive property is whether the edit respects how the native computation is spatially and temporally organized.

### 2.3 The evidence base and its scope

The results synthesized here concern one trained DRC checkpoint, greedy rollouts, and the provided family of small Sokoban boards. Most confidence intervals are clustered by board or episode. Several studies discovered overlap in the original train/test board identities and corrected it with board-disjoint resplits; the claims emphasized here preferentially use those corrected designs or within-board causal comparisons. The paper is a synthesis of existing experiments, not a report of newly run trials.

The strongest conclusions are therefore mechanistic statements about this agent and task distribution: repeated computation builds a route-like state; certain spatial loci are causally load-bearing; most of the state is board-reconstructable; and long-horizon behavior can be generated without a carried symbolic sequence. Broader claims about all recurrent agents or all Sokoban distributions would require replication.

## 3. The core computation is a convergent spatial relaxation

### 3.1 Repetition builds a route; extra compute without cumulative state does not

The DRC applies the same recurrent core repeatedly within a single environment step. The clearest black-box test of what this repetition does varies the number of recurrent applications at inference while keeping weights fixed [15]. Route membership begins at chance when no effective update is allowed, then rises rapidly toward a plateau. On an unselected random set of solvable boards, membership AUC across one, two, three, and four recorded inner states was approximately 0.500, 0.893, 0.976, and 0.977. Route-order decoding showed a comparable rise before saturating. Extending the loop beyond its trained budget to six or eight states added essentially nothing.

The crucial control matched the amount of neural computation while denying cumulative refinement. The recurrent module was applied the same number of times, but every application restarted from the same pre-update state; only a single-update result was retained. This non-cumulative condition spent the same approximate compute as the ordinary loop but remained near the one-update representation. On random boards, genuine cumulative refinement exceeded the matched-compute control by about 0.085 membership AUC and 0.407 route-order correlation. On a hard enriched set it also improved solve rate by 0.375. Thus repetition matters because each update transforms the previous update's state, not because the agent simply receives more feedforward computation.

State-change norms shrink over successive updates, and route decodability approaches a plateau. The contraction is stronger at decision points—episode starts and steps after a push—than during routine execution. These are the signatures of a relaxation process: the network starts from a carried or visually initialized state, repeatedly updates a distributed spatial representation, and approaches an attractor appropriate to the present board.

This finding is the temporal backbone of the algorithm. The inner loop is not a miniature tree search that discovers a new symbolic step on every tick. Nor does it continue indefinitely “thinking” farther into the future. It performs a bounded fixed-point-like computation that settles the current route and candidate competition. Frozen-frame extension to ten inner updates confirms the bound: future-intent logits plateau near the trained budget rather than continuing to amplify [23].

### 3.2 The settled object is a field, not a list

Early probing found that `c3` contains a per-square directional representation for future player motion and box pushes. Future player direction remained decodable at five- and ten-step horizons, and its accuracy increased monotonically across inner updates [1]. A stronger causal test treated this representation as a spatial field. At a plain floor cell that the unmodified agent would traverse, researchers added a contrast vector corresponding to a counterfactual exit direction. Conditioned on reaching the edited cell, the agent exited in the injected direction with probability 0.234, compared with 0.045 for a matched random vector and 0.026 when the same directional vector was placed at an irrelevant cell. The paired advantage over random was 0.183 with a 95% interval of [0.106, 0.260], while solve rate remained 0.992 [2].

The edit worked at ordinary floor cells containing neither a box nor a target. The effect was dose-monotone and spatially local. A separately decoded box-push direction was nearly orthogonal to the player-motion direction and did not compose as effectively on plain floor. These observations identify the more general control object: `c3` carries a location-indexed motion field whose local direction can be overwritten. Coherent trajectories arise by chaining local motion decisions across space, not by reading an explicit trajectory token from one location.

This field is not, however, the whole planner. Editing the route direction can change where the player walks without reliably changing which box is ultimately selected [2,5]. Selection and routing are distinct but coupled computations. The deep field is an execution surface and a partial selection surface, not a monolithic plan register.

### 3.3 Empty floor is the medium of the plan

Spatial gradient analyses identify the cells on the future route—the **path floor**—as unusually load-bearing. Under ordinary recurrent context, the chosen-action logit's early-tick gradient norm on future path cells was roughly 2.66 to 2.71 times the norm on off-path floor, and exceeded gradients at the player and boxes [13]. Gradient sensitivity alone is not a live intervention, but a constructive test independently validates the path floor as a causal medium [18].

In that test, a value-increasing direction was estimated from empty-floor activations and added along the shortest floor path to an otherwise unchosen box. An equal number of random floor cells received the same total perturbation norm in the control. On initial decision states, the geometry-aligned edit raised the alternative-push rate to 25.0% compared with 11.6% for random floor, a paired advantage of 0.133 with interval [0.016, 0.250]. On post-reward decision states, the corresponding advantage was 0.080 [0.013, 0.160]. Solve rate stayed at 1.0.

The important fact is not simply that an additive vector worked. It worked when written along the correct spatial conduit. Previous attempts to inject an abstract destination or future-box vector at a candidate cell often failed because the network does not consume a geometry-free token there. Writing value-like activity onto a plausible floor route gives the recurrent relaxation something native to propagate and stabilize. The plan's causal substrate is distributed across the geometry through which the player must move.

## 4. Selection condenses into a localized support anchor

### 4.1 The selected box is sustained by a c2 support state

If the path floor is the extended medium of a route, what holds one candidate route in place against its alternatives? Targeted ablation localizes a decisive structure in the middle recurrent cell state, `c2`, at the selected box's origin and player-standing cells [14]. On strict first-step boards with several legal candidates, zeroing these two spatial states across all inner updates reduced the baseline selected-push rate from 100% to 26.6%. The agent did not collapse: it made a legal alternative push in 73.3% of cases, spanning many distinct alternatives, and solved every board.

This pattern is much more informative than a generic performance drop. If the intervention had merely damaged local computation, one would expect indecision, invalid motion, or reduced solve rate. Instead the network gracefully reallocated choice to the remaining candidates. Ablating the corresponding cells for an unchosen candidate had little effect, as did random floor-cell ablation in the original control suite. The selected `c2` state therefore functions as a **causal support anchor**: a local terminus that stabilizes one globally distributed route.

The anchor is not a static token deposited before recurrent computation. Its causal effect depends strongly on inner time [17]. Removing it only at the initial recorded state allowed the network to reconstruct the selected candidate, preserving it in 98.3% of trials. Removing it at the final inner state lowered selection to 78.3%; removing it throughout the loop reproduced the collapse to 26.6%. A spatial transplant from the selected candidate to an unselected candidate with matched push direction increased the unselected push rate by 12 percentage points while maintaining 98% solve rate. The inner loop therefore builds and repairs the anchor as part of the same relaxation that constructs the route.

### 4.2 Candidate dominance is real, but the best decoder is not the best lever

The selected route also leaves a candidate-dominance signal in `c3`. Multiple candidates are co-active early, after which their scores collapse toward a winner. A carefully chosen dominance direction, orthogonalized against the local routing direction, can bias which box is completed first [8]. At a calibrated dose, the adjusted flip advantage over matched random was about 0.183, with gross alternative flips reaching 0.367 and solve rate remaining 0.98. This result prevents an over-simple claim that `c3` is “only routing.” It contains at least one partial selection handle.

Yet the candidate representation illustrates why decodability is not mechanism. A linear direction trained to decode the winner more accurately than the causal direction was behaviorally inert under the same intervention. In a matched-split comparison, decoder accuracy was 0.719 versus 0.613 for the causal direction, but the decoder-minus-random flip effect was only 0.017 with an interval crossing zero, whereas the causal-minus-random effect was 0.217 [10]. The two directions had only moderate cosine alignment.

Thus selection is not controlled by “the candidate label” as a single readable variable. The recurrent state contains many projections of the competitive process. Some are observational shadows; one calibrated subspace can bias the settled winner; the more robust necessity result lies in the spatial `c2` support anchor and the path geometry that sustains it.

### 4.3 Topology is enforced through spatially specific recurrent admission

A continuous field must respect walls and corridors. The most direct causal evidence comes from a “phantom gate block” that leaves the visible board unchanged but suppresses recurrent state admission at a selected empty floor cell [20]. Blocking both input and forget gates on the chosen shortest route redirected the first push in 29% of trials, whereas a distance-matched off-route block redirected 14%. The on-route excess was 0.15 with a 95% interval of [0.06, 0.25]. Decomposing the intervention showed that the input gate carried the entire route-specific effect: input-only blocking reproduced 29% versus 14%, while forget-only blocking produced approximately 3% in both conditions.

The mechanistic interpretation is simple. At each recurrent update, the ConvLSTM cell combines retained state with newly admitted spatial evidence. Walls naturally suppress admission. Empty route cells admit and propagate the evolving field. A phantom input-gate closure on the active route creates an internal barrier even though the pixels still depict open floor. Because an off-route closure at the same distance is less effective, the result cannot be reduced to generic local damage or proximity to the box.

This gate-level result should not be mistaken for a complete circuit explanation; the research question is algorithmic, not a request to enumerate channels. Its importance is functional. It establishes that the relaxation follows the board's continuous topology through local recurrent admission rather than consulting a separate symbolic graph. The same computation that builds the route also implements its boundaries.

## 5. The planner's time axis: repeated re-derivation with a short handoff prior

### 5.1 Why early evidence looked like a carried plan

During ordinary play, the candidate selected for the next push can be decoded from the recurrent state before the current environment step's inner updates. This initially suggested a persistent strategic memory. But on-policy recurrence creates a strong confound: the history, current position, route, and future choice are all mutually consistent. A state can predict the future because it records the trajectory already being followed, even if changing the board would cause immediate re-selection.

Environment-level counterfactuals break this confound [5]. The player was moved through legal, reversible, no-box-moved action sequences and then returned to greedy control. A displacement toward an alternative box changed selection relative to an equal-length neutral detour by 0.46, while every board remained solved. At the displaced board, the recurrent agent agreed with a fresh-state agent on the first box in 82% of cases at the largest displacement; it returned to its original box only 30% of the time. More decisively, two different legal histories ending at a byte-identical board produced the same first-box choice with 88% agreement. Increasing history divergence did not increase disagreement.

The current board and player position therefore dominate subgoal selection. Recurrent state contributes inertia and a short local prior, but it does not rigidly bind the agent to a history-specific box sequence. This explains why many local activation edits fail to change the selected box: the unchanged board continuously drives the relaxation back toward its board-conditioned attractor.

### 5.2 Warm context is real, but most of it is reconstructable from the board

The strongest apparent counterargument came from spatial gradient maps. With a zero recurrent state, early value gradients were large at boxes; with ordinary warm context, box sensitivity fell and route-floor sensitivity dominated [13]. This looks like a route cached across time. A construction-controlled follow-up reproduced the phenomenon but changed its interpretation [16].

Two distinct histories were arranged to reach the same byte-identical board. Their warm value and policy gradient maps correlated between 0.97 and 0.99, far above a roughly 0.02 to 0.10 different-board floor. The map therefore did not encode which route history had actually been taken. A fresh zero-state network processing the same board reproduced much of the warm map: warm-fresh correlations ranged from about 0.73 at early inner time to about 0.90 by the final update. Shared-suffix and total-history manipulations found no evidence that the residual grew with long history.

The residual was nevertheless structured. For the policy head it concentrated on path-floor cells during the early inner updates, then diminished as the fresh and warm computations converged. The most economical interpretation is a **short route-localized handoff prior**. Inter-step recurrence tells the next step where the previous computation had been flowing, but the current board quickly reconstructs and, when necessary, replaces that flow. This is not memorylessness in the literal sense. It is repeated re-solution from a warm initial condition.

### 5.3 Outer-loop accumulation is a footprint of embodied progression

Several measurements show that future-intent and support signals rise over the environment steps leading to a push. Over a five-step approach window, the `c2` magnitude at the chosen box increased from 3.58 to 3.87 while the field's spatial peak moved closer to the box, from 4.89 to 4.56 tiles [20]. The representation of the next subgoal can also amplify during “navigational downtime,” when the player moves but boxes do not. Such accumulation might seem to restore a carried macro-plan.

Two tests show otherwise [23]. First, extending the recurrent loop to ten updates on a frozen board produced a plateau after the trained budget. The agent could not internally continue unrolling deeper future intent in a static frame. Second, teleporting the player across the approach interval and zeroing all recurrent state at arrival still produced a 100% successful handoff. The accumulated trace is therefore useful and naturally produced during standard play, but not causally necessary for the next choice.

The environment is the agent's planning clock. Every physical move changes the player-relative geometry and seeds another bounded relaxation. Across these repeated board updates, anticipatory traces become stronger because the future route becomes progressively compatible with the current spatial configuration. But if the trajectory is skipped, the new board is sufficient to regenerate the relevant route. The agent plans through embodied iteration, not through a detached internal rollout.

## 6. Long-horizon structure exists, but not as an executable symbolic queue

The task demands an account of genuinely extended planning, not only the next action. The evidence supports a nuanced answer. The DRC represents multiple forms of future structure, including ordered route steps, future subgoal identities, per-box target preferences, and deep ordinal ranks. These signals cannot all be dismissed as trivial board geometry. At the same time, the most direct intervention tests show that they are generally not independently writable instructions. Long-horizon behavior is generated by repeatedly resolving the spatial system, with future readouts emerging from the geometry of that resolution.

### 6.1 Within-route order is genuine look-ahead, but it is read rather than written

The clearest forward representation concerns the order in which cells on the currently committed route will be visited [11]. A probe was evaluated only over cells that are in fact visited, so it could not succeed merely by predicting route membership. In `c3` at the final inner update, decoded arrival order had a Spearman correlation of 0.640 with the true future order, compared with 0.043 after shuffling. A matched spatial board network, an occupancy proxy, and an explicit heading-plus-position momentum model all performed much worse on the decisive subsets.

This route-order signal is not simply manufactured late in the approach. It is already present on the first environment step, where large-horizon order correlation reached 0.527, and it survives on detours where current heading predicts the wrong ordering. It also sharpens across recurrent updates while the visual input stays fixed. The agent therefore contains genuine, internally constructed multi-step information about its current route.

Yet a direct attempt to reverse the order of two future route cells failed completely. The intervention advanced one cell's decoded order and delayed the other's, was orthogonalized against occupancy, local motion, and candidate dominance, and passed its manipulation checks. Across two doses and both single-cell and neighborhood edits, the realized route-order flip rate was 0 out of 60 while solve rate remained between 0.92 and 0.97. The route order is a faithful readout of the settled flow, not a separately editable sequence that dictates the flow.

This distinction resolves an apparent paradox. The path-floor membership is causally important: blocking or energizing those cells changes behavior. Arrival order over that path is a derived property of the field's geometry and the player's local following. A river can have a predictable order in which water reaches downstream points without containing a separate ordinal command list. Likewise, the DRC's field can support precise look-ahead while its order variable remains causally inert under order-specific edits.

### 6.2 The second-next subgoal is represented nonlinearly but is not a demonstrated controller

An early linear analysis found the identity of the box after next near chance and interpreted this as a one-subgoal horizon. A capacity-matched nonlinear probe later showed that the null was a probe artifact [12]. Using the full recurrent stack at the final inner update, second-next identity was decoded with accuracy 0.505 versus 0.391 from a matched board input, a gap of 0.113 [0.091, 0.137]. `c2` and `c3` alone also carried smaller but significant advantages, and the signal grew across inner time.

This is real forward information, but its source and causal status matter. When two different histories reached the same board, disagreement in the second-next readout largely disappeared after matching a short recent action suffix. Adding observable motion history to a board probe explained little of the overall recurrent advantage, implying that deep processing of the present board—not simply a shallow geometry model or a long carried history—makes the forward variable explicit.

The causal test was especially informative. A gradient edit increased the decoded probability of an alternative second-next target from 0.298 to 0.708 on every trial. Nevertheless, that target was completed second in exactly the same 1.43% of trials under the targeted edit and the matched random control; the paired behavioral difference was zero. Higher doses remained null while all boards were solved. A distinct future step is thus represented, but the tested representation is a footprint of board-conditioned computation rather than a writable future instruction.

The conclusion is not that the network has no causal dependence on future consequences. Route membership, candidate support, and active path competition are causal and inherently future-directed. The conclusion is narrower and more mechanistic: a readable label for “the second-next box” is not the format in which the policy controls that future.

### 6.3 Completion order and target assignment expose the same separation

Box-completion order is both linearly and nonlinearly decodable. A nonlinear model reached 0.72 accuracy versus 0.54 for a linear model [7]. The signal is event-linked and becomes more readable during recurrent computation. Yet erasing a learned order subspace up to rank 16 reduced its measurable projection to roughly 10⁻⁷ of the original while leaving completion order effectively unchanged; all 48 boards were solved in every condition. A representation that looks exactly like a plan variable can therefore be dispensable as a control variable.

Box-to-target assignment provides an even stronger test of combinatorial planning [19]. The agent's realized assignments are not simple nearest-target matches: 72.6% of solved four-box boards differed from greedy nearest assignment, and 63.5% differed from a minimum-total-push-distance Hungarian assignment. A spatial probe on `c3` decoded each box's eventual target better than capacity-matched linear, multilayer, convolutional, and board-plus-momentum baselines. On the non-greedy subset, the advantage over the matched spatial board model was 0.115 [0.099, 0.130]. The advantage already existed at episode step one, at about 0.052, and sharpened across inner updates.

This proves that the recurrent network makes a policy-specific, non-greedy assignment more explicit than small matched board models do. It does not prove the agent stores a single global permutation. Independent per-box predictions formed a valid bijection only about 7% of the time, below an independent-candidate reference. A later equal-capacity joint-versus-marginal analysis found no reliable advantage for cross-box interaction terms at the first-step state [22], although synthetic calibration showed that this null excluded only a strong joint signal and had limited power near the real operating point. The safest interpretation is a distributed, board-anchored field of box-target compatibilities rather than an explicit permutation register.

Deep ordinal ranks are also readable. A spatial classifier identified the second box with F1 0.560 and the third box with F1 0.389 at the final inner update, while a strict local board baseline scored zero for both. On boxes that were physically available earlier but were nevertheless used third, third-rank F1 remained 0.402. This demonstrates a nontrivial ordinal footprint extending beyond the immediate route.

One attempted ontology test claimed that the ordinal sequence was marginal rather than joint, but a subsequent diagnostic invalidated that conclusion [26]. The joint-only features had essentially zero variance across candidate permutations—approximately 7.1 × 10⁻¹⁵—so the classifier was structurally unable to distinguish joint orderings. This correction is scientifically important. The corpus supports deep ordinal representation, but the exact joint or distributed ontology of that representation remains unresolved. The causal conclusion does not depend on that null: a cold-start teleport can recover the sequence handoff without recurrent history, and active-route ablation can reorganize the next assignment. What remains open is the representational format of the ordinal footprint, not whether a carried symbolic sequence is necessary.

### 6.4 Dynamic path interference turns spatial competition into sequence

The most coherent account of multi-box sequencing is **dynamic path interference** [24,25]. Consider a board on which two boxes compete for the same nearby target. If assignment were enforced by a top-down logical veto, the recurrent gate along the unassigned box's path should be closed or a `c3` assignment token should suppress that route. Neither prediction holds cleanly. Gates on the unassigned path are not selectively closed, and transplanting the decoded assignment state to the unassigned box changes routing only weakly.

The positive causal result occurs at the active route. Zeroing the `c1`/`c2` recurrent state along the chosen box's empty-floor path caused the competing box to take the shared target 20 percentage points more often than under an equal-length off-route ablation, with a confidence interval of approximately [0.06, 0.33]. Both arms maintained a solve rate of 1.0; the agent reassigned the remaining box rather than crashing.

This implies that an active route occupies recurrent spatial capacity and changes the effective geometry available to rivals. Candidate value fields are not independent scalars compared in a symbolic scheduler. They coexist on the same spatial substrate. A strong path to one target can consume, repel, or redirect the field that would otherwise connect a second box to that target. When the first push completes, its path and support anchor dissipate. The competing field can then settle into the freed topology, producing what appears at the behavioral level to be a handoff from one planned subgoal to the next.

The cold-start teleportation result sharply constrains the temporal interpretation. Even after skipping the normal approach and zeroing recurrent state, the agent recovered the appropriate handoff on every tested board [23,25]. Therefore the handoff does not require a dormant token carried through the preceding trajectory. The current geometry plus the recurrent relaxation is sufficient. The sequence is stable because the board after each push changes in a way that reshapes the next equilibrium.

This is how local geometric computation can generate extended competence. Each equilibrium is conditional on boxes, targets, walls, the player, and currently active paths. Each push changes those conditions. Re-solving the field after every action yields an ordered series of subgoals even when no single state stores the entire series as an executable program.

## 7. A causal atlas of the learned planner

Following an operator-aware synthesis of the intervention record [21], the table below summarizes the main objects without conflating representation, operator, and behavioral endpoint.

| Object | Principal locus and operator | Empirical effect | Mechanistic status |
|---|---|---|---|
| Local movement direction | `c3`, additive edit at one floor cell | Counterfactual exit direction +0.183 over random, solve preserved | Local execution lever |
| Active route membership / path floor | Distributed floor state, gradient sensitivity, geometry-aligned addition | Early policy sensitivity 2.66–2.71× off-path; alternative push +0.133 initially | Distributed route lever |
| Selected candidate support | `c2` origin/standing cells, all-tick ablation | Selected push 1.00 to 0.266; legal alternatives 0.733; solve 1.00 | Necessary support anchor |
| Route topology | On-route recurrent input-gate block | 29% redirection on-route vs 14% off-route | Topology-specific propagation lever |
| Candidate dominance | Routing-orthogonal `c3` addition | Adjusted completion-choice flip about +0.183 | Partial selection-biasing lever |
| Best candidate decoder | `c3` decoder-normal addition | No effect above matched random despite higher decoding accuracy | Readable footprint under tested operator |
| Route arrival order | Orthogonalized additive order edit | Decoded margin moves; realized reordering 0/60 | Ordered look-ahead, not an order lever |
| Second-next identity | Nonlinear probe-gradient edit | Decoded probability 0.298 to 0.708; behavioral gap 0 | Forward footprint under tested operator |
| Completion order | Rank-16 subspace erasure | Readout nearly destroyed; order and solve unchanged | Event-linked footprint |
| Per-box target assignment | Capacity-matched decoding; limited joint test | Strong non-greedy per-box readout; no established global permutation | Distributed compatibility footprint |
| Static dead-square code | Local substitution at `c2`, inner tick two | Readout removed, avoided push not released | Co-located footprint, not local actuator |

Three general principles follow.

First, **causal leverage is sparse**. The network represents far more planning-related information than can be independently controlled. This is expected in a nonlinear dynamical system. Many variables are projections of one underlying equilibrium rather than degrees of freedom the system separately reads.

Second, **causal leverage is interface-aligned**. Successful edits respect the spatial path, candidate-support cells, update timing, and native field geometry. Inert edits often target a semantic readout at one cell while leaving the actual distributed route computation intact.

Third, **causal status is operator-relative**. “Inert” means a verified intervention failed to change a specified endpoint, not that the native network never uses the represented information. A distributed nonlinear edit, a different temporal window, or a different endpoint could yield another result. The atlas narrows the algorithm to the active route-selection interface; it does not claim that all other representations are useless.

## 8. Why the geometric planner succeeds—and why it fails

The term “geometric relaxation” can sound more exact than the learned computation really is. The DRC does not appear to run a pristine shortest-path algorithm or a discrete graph search. Its geometry is approximate, convolutional, and strongly shaped by local visual texture.

### 8.1 The constraint field is local and blurred

A reachability probe initially achieved high aggregate performance and appeared to reveal a flood-fill. Edge-case evaluation falsified that interpretation [3]. On empty tiles that were visually floor-like but topologically disconnected from the player, the middle recurrent layer had a false-positive rate of 94.8%; even the deepest layer failed badly. Threshold-independent AUC for separating reachable from unreachable empty or target tiles was only 0.563. The network therefore does not construct a clean binary connectivity map. It builds a smoothed free-space field that usually aligns with reachability on the training distribution but blurs across difficult boundaries.

The constraint is nevertheless causal. Suppressing the learned reachability-like direction across all inner updates collapsed solve rate from 100% to 3%, compared with 49% for a matched random direction. A poor symbolic description can still identify a vital continuous substrate. The agent depends on a spatial constraint field; the field simply is not the ideal graph-theoretic object that an aggregate probe first suggested.

### 8.2 Global value mixes route integrity with blunt visual heuristics

The scalar value estimate is more spatially global but not more exact [4]. Adding a wall on the optimal route reduced predicted value by 1.14. Adding an equally novel wall in a strategically irrelevant off-path location still reduced value by 0.68. The paired route-specific component, 0.458 [0.36, 0.55], is real, but more than half of the raw penalty reflects generic visual novelty or wall counting. The value head appears to summarize the health of distributed local flow rather than solve a separate topological planning problem.

This heuristic contamination explains why the agent can be both competent and fragile. The recurrent field integrates many local cues into a useful policy, but adversarial changes that preserve true connectivity can distort the learned geometry. An irrelevant wall placed near the preferred path changed the chosen candidate on 43.8% of boards compared with 6.8% in the clean condition [6]. Synthetic wall patterns also exposed “symmetry blindness”: an L-shaped corner cast a stronger internal constraint shadow than a genuinely trapping U-shaped pocket. The learned planner responds to convolutional texture, not to an explicit theorem about dead ends.

### 8.3 Deadlock avoidance is specialized rather than general

The agent does represent one important Sokoban hazard: whether a push moves a box onto a static dead square [27]. A local hidden-state probe achieved AUC 0.988 versus 0.668 for a capacity-matched local board baseline. Within the same state, immediately executable irreversible pushes received about 0.73 less policy probability than reversible alternatives, and this avoidance persisted after matching current and next-state value estimates.

Yet the decoded direction was not an additive lever. Suppressing it did not release an irreversible push, and imputing “irreversible” onto a good push did not suppress that push beyond matched disruption, despite large changes in the readout. More importantly, the same local representation did not decode interaction deadlocks—cases in which multiple boxes freeze one another—above the board baseline. The agent has learned a strong static-geometry detector, not a general solvability oracle.

These limitations complete the algorithmic picture. The DRC's success does not come from exact symbolic search hidden inside a neural network. It comes from a learned physical approximation that is well matched to common boards: relax value over floor, respect local obstacles, suppress familiar dead squares, stabilize one box route, and repair after every push. Its failures follow from the same design: local texture can masquerade as topology, global combinatorial facts are represented indirectly, and unusual interactions can fall outside the learned field dynamics.

## 9. A formal algorithmic description

The accumulated evidence supports the following abstract algorithm. It is written as a mechanistic description of the trained network, not as literal source code.

```text
Inputs at environment step t:
    board B_t
    player position p_t
    recurrent handoff state H_{t-1}

1. Initialize a spatial state from:
       visual features of walls, floor, boxes, targets, and player
       plus a short route-localized prior from H_{t-1}.

2. For each repeated recurrent update k:
       a. Admit new spatial evidence through local input gates.
          Walls and internally blocked route cells suppress admission.
       b. Propagate and refine value-like activity over available floor.
       c. Score multiple box-push opportunities in parallel.
       d. Let candidate paths interfere on the shared spatial substrate.
       e. Concentrate support at viable box origin/standing cells in c2.
       f. Render the currently dominant route as local directions in c3.
       g. Stop effectively when the spatial state approaches its trained attractor.

3. Read the next movement action from the local directional field,
   modulated by value and constraint signals.

4. Execute one environment action.

5. On the next step:
       retain a short handoff prior,
       but re-solve the field from the new board.

6. After a box push:
       remove or weaken the completed route and support anchor;
       allow competing paths to occupy the freed spatial capacity;
       thereby produce the next apparent subgoal in the sequence.
```

Several aspects distinguish this algorithm from familiar alternatives.

It is not breadth-first or A* search. No evidence supports a discrete queue of states, explicit predecessor pointers, or a global binary reachability graph. It is not model-predictive control in the sense of internally simulating many complete future boards; extended frozen-frame recurrence plateaus rather than rolling farther ahead. It is not a pure reflex because cumulative recurrence is necessary to construct the route, future order and assignment are genuinely represented, and route/anchor interventions alter later behavior. It is not a stored hierarchical program because current-board manipulations and cold-start teleportation overwrite or reconstruct the apparent plan.

The closest human-designed analogue is a **receding-horizon potential-field planner with recurrent constraint relaxation and competitive route exclusion**. Even that analogy is incomplete. Classical potential fields are usually specified analytically, whereas this field is learned, multi-layered, and heuristic. Its “potential” includes local geometry, target value, push feasibility, short recurrent momentum, and interactions among candidate paths. Its horizon is extended behaviorally by resolving a new field after every action.

### 9.1 State variables in the formal account

The algorithm requires at least four functionally distinct state objects.

1. **Visual geometric features** encode local walls, floor, boxes, targets, player position, and familiar dead-square patterns.
2. **A distributed path-floor field** represents where value and policy support can propagate.
3. **A localized candidate-support anchor** stabilizes the currently selected push opportunity.
4. **A local directional execution field** maps the settled route to actions at individual cells.

Readable route order, future identity, assignment, and ordinal rank arise from these objects and their evolution. They are scientifically useful because they reveal what the recurrent system has resolved. They need not be additional state variables consulted by the policy.

### 9.2 Where the “discrete” decision comes from

The network's dynamics are continuous, but its behavior is discrete. The transition occurs when continuous candidate fields compete and one support anchor becomes dominant enough to control the local route. The resulting push is discrete because the environment and action space are discrete, not because the internal computation enumerates symbolic branches.

This explains why small, calibrated changes can bias selection without fully commanding it. A dominance-axis edit can tilt the competition. A path-floor injection can make an alternative route more attractive. An on-route gate block can weaken the current conduit. Removing the selected anchor can cause a clean fallback. None of these edits writes a complete replacement plan; each changes the energy landscape in which the next discrete commitment forms.

## 10. What is established, what remains uncertain, and what should be tested next

### 10.1 Strongly established conclusions

Five conclusions are supported by multiple convergent methods.

First, cumulative repeated computation is necessary for building the route-like recurrent state. Matched compute without cumulative carry does not reproduce the effect.

Second, the operative spatial route is causal. Gradient sensitivity, geometry-aligned addition, local direction editing, route-gate blocking, and candidate-anchor ablation all point to the same interface.

Third, most apparent long-term state is board-reconstructable. Same-board histories yield nearly identical causal maps, and fresh-state computation converges toward the warm state.

Fourth, future representations are abundant but causal levers are sparse. The route-order, completion-order, second-next, assignment, and ordinal findings cannot be explained by “nothing about the future is represented,” yet intervention prevents interpreting those readouts as a symbolic control program.

Fifth, multi-step sequencing can be generated without a carried temporal list. Cold-start handoff recovery and active-route interference show that board-conditioned spatial competition is sufficient on the tested cases.

### 10.2 Genuinely unresolved questions

The exact representational ontology of deep ordinal sequence remains open. The experiment intended to distinguish joint from marginal ordinal structure was structurally blind, so neither a weak joint code nor a more distributed relational code has been excluded [26]. This uncertainty should not be inflated into uncertainty about all causal conclusions; it concerns the format of a readout, not the demonstrated sufficiency of current-board re-derivation.

The native causal variable underlying the `c3` dominance handle also remains uncertain. The intervention identifies a useful biasing direction, but a direction that changes behavior under addition is not automatically the coordinate the unmodified network explicitly computes. Similarly, the `c2` anchor ablation removes all 32 channels at two cells; finer channel-level structure and distributed redundancy remain unmapped.

The route-interference account has been demonstrated on first-push conflict boards and static shortest-path approximations. More complex boards may require interactions not captured by a single active path. The 20-percentage-point rerouting effect is substantial but far from complete, implying residual support from other layers, nearby cells, or alternative route definitions.

Finally, local deadlock representations do not establish how the agent handles multi-box freeze patterns. A whole-board nonlinear feasibility state may exist even though the tested local probe did not recover it. The current evidence only shows that the strong local reversibility signal is specialized to static geometry.

### 10.3 Falsifiable predictions of the synthesis

The proposed algorithm makes several predictions that can be tested without appealing to new metaphors.

- A proximity- and sensitivity-matched ablation of an inactive path should have much less effect than ablation of the active route, even when total recurrent disruption is matched.
- A multi-cell intervention that constructs a geometrically coherent alternative route should outperform a higher-norm semantic edit confined to a candidate box.
- If two candidate routes are spatially separated until a late bottleneck, interference should appear first at that bottleneck rather than globally at the candidate cells.
- A fresh-state network given the same board should converge toward the warm route state over inner updates; blocking cumulative carry should prevent that convergence even when compute is matched.
- Removing the active path immediately before a handoff should accelerate the competing field's rise, whereas editing the decoded ordinal label alone should not.
- Boards requiring nonlocal freeze reasoning should disproportionately expose failures, unless a distinct whole-board feasibility mechanism can be identified.

These predictions preserve the task's probe-intervene cycle. Probes should locate a candidate spatial process; interventions should then target the process's actual interface rather than the most convenient semantic readout.

## 11. Conclusion

The trained DRC Sokoban agent plans, but it does not plan by executing a stored symbolic program. Its repeated recurrent core performs a bounded geometric relaxation over the current board. Empty floor is the medium through which value and policy support propagate. Local recurrent gates enforce route topology. A `c2` support anchor stabilizes the selected push, and a `c3` motion field converts the settled route into local action. The network carries a short handoff prior across environment steps, but the dominant route is repeatedly reconstructed from the present geometry.

This spatial computation produces rich future representations. The agent knows, in a probe-readable sense, much more than its next action: route order, future subgoals, non-greedy target assignments, and deeper ordinal ranks are all present. The decisive insight is that knowing is not the same as controlling. Most of these variables are footprints of the recurrent equilibrium. The reliable levers are sparse and geometry-aware: the active floor path, its recurrent admission, the selected support anchor, and local motion directions.

Extended behavior emerges when these spatial equilibria are recomputed after every move. Candidate routes compete on a shared substrate; the active route suppresses its rivals; a push changes the board and removes the old support; another route then occupies the freed geometry. The environment supplies the sequence of states that advances the computation. In this sense the agent's apparent macro-plan is real as behavior and representation, but emergent as mechanism.

The final algorithmic answer is therefore precise: **the DRC is a receding, recurrent geometric planner whose discrete commitments are phase transitions in a continuously relaxed spatial field.** It is more structured than a reflex, less explicit than a symbolic search, and powerful because repeated local computation can turn physical geometry into a coherent sequence of irreversible actions.

## References: evidence corpus

1. *Refining and Using a Plan: Internal-Tick Refinement and Causal Steering of a Per-Square Directional Plan in a DRC Sokoban Agent.*
2. *The Plan as a Composable Field: Causally Steering a DRC Sokoban Agent by Writing Local Move-Directions at Arbitrary Cells.*
3. *The Geometric Constraint Field: Falsifying Global Topology to Ground Continuous Planning in the DRC.*
4. *The Value Veto: Disentangling Topological Awareness from Heuristic Wall-Counting in the DRC.*
5. *Selection Re-derived: DRC Subgoal Choice Tracks Current Board Position, Not Rigid Carried-Over Memory.*
6. *The Convolutional Illusion: Hacking Subgoal Selection via Myopic Geometric Textures.*
7. *Decodable but Inert: The DRC's Box-Completion Order Is an Event-Linked Correlate, Not a Causal Control Variable.*
8. *A Selection-Biasing Subspace in c3: Refining the Pure Execution Surface Consensus.*
9. *Trajectory-Manufactured Decodability: The DRC's Readable Plan Is Generated Step-by-Step, Not Stored Ahead.*
10. *The Footprint and the Lever: Decodability Is Not Causality in the DRC Planner.*
11. *Ordered Route Look-Ahead in the DRC Agent: Genuine Multi-Step Structure That Is Read, Not Written.*
12. *The Look-Ahead Deficit Is a Probe-Capacity Artifact: The DRC's Second-Next Subgoal Is Nonlinearly Represented, Re-derived, and Causally Inert.*
13. *The Cached Route: Recurrent Memory Causally Anchors Policy and Value to the Intended Path.*
14. *The Anchored Value Gradient: Resolving the DRC's Discrete Emergent Planning Algorithm.*
15. *The Inner Loop Is a Convergent Route-Refinement Operator: Cumulative Iteration, Not Compute, Builds the DRC's Planning Cache.*
16. *The Cached Route Is Largely Re-derived, Not Carried: A Construction-Controlled Source Attribution of the DRC's Warm Causal-Gradient Signal.*
17. *The Continuous Geometric Relaxation Algorithm: A Unified Mechanistic Theory of Discrete Emergent Planning.*
18. *The Constructive Geometric Lever: Additive Steering of the Discrete Plan via the Path-Floor.*
19. *The Assignment Is Read Before the Push: The DRC Makes Its Non-Greedy Box-to-Target Matching Explicit Beyond Board Geometry and Momentum.*
20. *The Continuous Geometric Routing Engine: A Mechanistic Formalization of Emergent Planning in the DRC.*
21. *Same Interface, Different Role: An Operator-Aware Map of the DRC's Decodability–Causality Boundary.*
22. *Read Locally, Re-Derived Globally: The DRC's Box-to-Target Assignment Is a Distributed Board-Anchored Field, Not a Geometry-Independent Joint Permutation.*
23. *The Embodied Accumulation Mechanism: Outer-Loop Progression Drives Dormant Sequence Amplification During Navigational Downtime.*
24. *The Dynamic Interference Engine: Geometric Resolution of Combinatorial Assignment in the DRC.*
25. *Emergent Sequencing via Dynamic Path Interference: Falsifying the Carried Macro-Plan.*
26. *The Invariance Artifact: Why the Capacity-Matched Ontology Test Fails to Bound Ordinal Sequences.*
27. *The DRC's Push-Reversibility Signal Is a Static-Geometry Deadlock Detector: Decodable and Value-Independent, but Neither an Additive Lever nor a General Solvability Representation.*
