# Planning as Board-Conditioned Geometric Relaxation in a Recurrent Sokoban Agent

## Abstract

Deep recurrent reinforcement-learning agents can solve Sokoban while offering no explicit symbolic plan to inspect. The central scientific question is therefore not merely whether future behavior can be decoded from their activations, but what algorithm the network actually implements and which internal variables causally control it. We synthesize a large body of probing and intervention evidence for a trained Deep Repeating ConvLSTM agent on 8×8 Sokoban. The resulting account rejects two simple extremes. The agent is neither a classical search procedure that stores and executes a discrete sequence of box moves, nor a memoryless reflex that recomputes an action from raw pixels without persistent spatial organization. Its best-supported algorithm is a **board-conditioned geometric relaxation process**.

A shallow visual encoding supplies local object and geometry seeds. Repeated ConvLSTM updates cumulatively relax a spatial route/value field toward a stable configuration. Early recurrent layers carry the principal causal topology: propagation through empty floor is controlled by input gates, the selected push is supported by a localized candidate anchor, and simultaneously viable routes interact through the shared spatial substrate. The deepest recurrent cell state exposes an actionable local motion field and a weaker selection-biasing subspace. The policy follows the resulting field, changes the board, and repeats the relaxation. This repeated process produces competent multi-box sequencing without requiring a stored symbolic queue.

The agent nevertheless contains genuine multi-step information. Future route order is decodable at the first environment step and beyond strong geometry and momentum controls; second-next subgoal identity is nonlinearly decodable above matched board baselines; non-greedy box-to-target assignments are more explicit in recurrent state than in capacity-matched board models; and a long-horizon visit field exceeds a global shortest-path baseline at choice points. Yet these readable objects usually fail causal tests even when interventions demonstrably move or remove the decoded signal. In contrast, geometry-aligned edits to route floor, candidate support, input-gated topology, and a routing-orthogonal dominance direction alter behavior while preserving competence. Same-board history controls and cold-start teleportation further show that most route and sequence structure is re-derived from the current board, with only a short recurrent handoff prior. The emergent planning algorithm is thus rich in predictive representations but sparse in causal levers: it plans by repeatedly constructing and executing a geometry-coupled spatial equilibrium, while many apparently symbolic variables are readable consequences of that computation rather than its command state.

## 1. The mechanistic question

Sokoban is a stringent planning problem because the player may push boxes but cannot pull them. A locally legal action can irreversibly destroy the solution, and successful play requires coordination over routes, approach positions, box order, target assignment, and deadlock avoidance. A competent agent must therefore do more than react to the immediately adjacent tile. The difficult question is what kind of planning computation can emerge in a model-free recurrent policy without an explicit search tree or symbolic state representation.

The agent studied here is a Deep Repeating ConvLSTM network, or DRC. At each environment step it encodes the current 8×8 board into a 32-channel spatial map and applies the same three-layer ConvLSTM core repeatedly. The recorded activation tensor contains four snapshots: a carried-in state before the current inner computation and three successive recurrent updates. Each spatial location therefore has a local recurrent state in each layer, conventionally denoted `c1`, `c2`, and `c3`, together with corresponding hidden states and the visual encoding `x_enc`. Repetition gives the model an opportunity to refine a spatial computation before selecting an action.

The task is to infer the algorithm implemented by this repeated computation using two complementary tools. **Concept probes** ask what variables can be read from activations: future movement directions, route membership, arrival order, subgoal identities, candidate dominance, assignment, value, or constraints. **Causal interventions** ask whether changing a representation changes behavior in the predicted way. A satisfactory algorithmic description must explain both. A variable that is easily decoded but behaviorally inert cannot by itself be the control state of the planner; conversely, a spatial state that is difficult to name but whose targeted disruption reliably changes action may be central to the algorithm.

This distinction matters because executed trajectories create powerful observational correlations. If an agent is already walking toward a box, its recurrent state will predict that box even if the representation is merely a consequence of motion. Board geometry is another confound: a sufficiently capable external model can infer much of the eventual route from the current walls, boxes, targets, and player location. A probe that beats a weak linear board baseline may therefore reveal only that the recurrent network has already computed an ordinary geometric feature, not that it carries an independent plan. The strongest studies in the corpus address these problems with matched-capacity board models, board-disjoint splits, same-board/different-history comparisons, within-step changes while the board is fixed, intervention manipulation checks, and spatially matched random controls.

Across these tests, several initially plausible theories were successively revised. Early work treated the deep recurrent state as a long-horizon plan field. Later work separated local routing from discrete box selection and showed that box-completion order could be erased without changing behavior. This motivated a “reactive committer” view in which readable plans were manufactured during execution. Still later experiments showed that this view had become too strong: ordered routes, second-next subgoals, and non-greedy assignments are genuinely represented, sometimes before any trajectory history exists. The decisive resolution is not to choose between “planning exists” and “planning is an illusion,” but to separate representational content from causal role and to identify the spatial interfaces at which interventions succeed.

The conclusion of this paper is that the DRC implements a **board-conditioned geometric relaxation algorithm**. It repeatedly constructs an active spatial solution over the current board; this solution includes route membership, local movement directions, candidate support, and competition between routes. The recurrent state provides a short handoff across environment steps, but most of the spatial solution is recoverable from the current board through the inner relaxation. Multi-step variables are often explicit enough to decode, yet only a small subset of geometry-aligned states are effective levers. The distinction between a readable **footprint** and a causal **lever** [4] is therefore not a peripheral methodological caution. It is central to the algorithm itself.

## 2. Experimental setting and standards of evidence

### 2.1 Activations, layers, and timescales

The observational dataset consists of solved and attempted Sokoban episodes with board states, chosen actions, rewards, values, and recurrent activations. The board has seven binary channels identifying walls, floor, boxes, boxes on targets, the player, the player on a target, and target locations. The activation at each environment transition has shape 4 × 224 × 8 × 8. The first axis indexes the carried-in state and the three recurrent updates. The channel axis contains hidden and cell states for three ConvLSTM layers plus the visual encoding.

Two timescales must be kept distinct. An **environment step** changes the Sokoban state by moving the player or pushing a box. An **inner update** changes only the network state while the board input remains fixed. This distinction provides a useful control: if a representation becomes more decodable across inner updates, that increase cannot be attributed to a newly observed board. It is evidence that the recurrent computation constructed or sharpened the representation.

The layer names are functional rather than purely anatomical. The deepest cell state `c3` is especially rich in local motion, value, dominance, assignment, and future-route readouts. The middle cell state `c2` is repeatedly implicated in candidate support and route geometry. The lowest recurrent layer `c1` also participates in spatial propagation and route interference. These labels should not be interpreted as perfectly modular compartments: each layer is spatially distributed and multiplexed, and several studies show that a variable may be most decodable in one layer but most causally effective in another.

### 2.2 Probe targets and baseline discipline

The most informative targets fall into four classes.

First, **local execution targets** describe the route currently being followed: the future direction of motion from each cell, whether a cell will be visited within a horizon, and its first-arrival order. These targets test whether the recurrent state contains a spatial plan rather than a single next action.

Second, **subgoal targets** describe discrete future events: which box will be acted on next, which target will be completed next or second-next, and the relative dominance of alternative candidates. These are closer to a symbolic macro-plan, but are also vulnerable to trajectory and geometry confounds.

Third, **assignment and constraint targets** describe the relation between objects: which target a box will eventually reach, whether a push is reversible, or whether a square is a static dead location. Such variables can be highly planning-relevant even if they are not direct action commands.

Fourth, **causal sensitivity objects** do not require a semantic decoder. Gradients of policy or value with respect to spatial recurrent state identify where the output is sensitive, while direct gate blocks, zero-ablations, and geometry-preserving substitutions test the causal role of those locations.

Every decoding result must be interpreted relative to an appropriate baseline. A co-located linear board probe controls for immediately visible local features but is weak against multi-cell geometry. A matched spatial CNN over the board controls for a receptive field and substantially narrows several naive hidden-state advantages. A board-plus-momentum model controls for recent actions, headings, player locations, and box movements. A parameter-free breadth-first-search baseline controls for global shortest-path distance. Same-board history contrasts go further: if two legal histories reach a byte-identical board, differences in recurrent readout can be attributed to history, while agreement indicates board-based reconstruction.

### 2.3 What counts as causal evidence

The intervention record makes clear that a behavioral change is not automatically a semantic effect. Large edits can lengthen trajectories, lower solve rate, or induce generic rerouting. A credible causal test therefore uses some combination of the following:

1. A **matched-norm control** at the same cells, so the semantic direction is compared with equally large random disruption.
2. A **spatial control**, such as an irrelevant cell or an equally distant off-route cell.
3. A **manipulation check** showing that the intended decoded quantity actually changed.
4. **Cross-talk checks** showing that orthogonalized edits did not simply alter a known routing or occupancy direction.
5. **Competence monitoring**, usually solve rate, to separate targeted steering from breakdown.
6. A behavioral endpoint matched to the hypothesis: local movement for a motion-field edit, first-completed box for a dominance edit, or route-order reversal for an order edit.

This operator-relative standard is essential. “Causally inert” in this paper means that a specified intervention, at a specified surface and time, changed the decoded variable but not the specified endpoint. It does not mean that the native network never uses related information, or that every possible nonlinear and distributed intervention would fail. Conversely, positive effects are strongest when they survive geometry- and disruption-matched controls.

## 3. Future structure is genuinely represented

The first part of the story is positive: the recurrent network represents far more than the immediate action. Several independent probe families reveal spatial and combinatorial future structure, and the best-controlled results cannot be dismissed as simple board geometry or accumulated motion.

### 3.1 A refined directional route field

The foundational directional-field study trained translation-equivariant per-cell probes to predict the direction in which the agent would later leave each square [1]. At a five-step horizon, conditional direction accuracy in `c3` rose from 0.549 in the carried-in state to 0.570, 0.580, and 0.588 across the three recurrent updates. The successive gains became smaller, a pattern consistent with iterative convergence rather than a one-shot code. Accuracy barely declined at a ten-step horizon, indicating that the representation was not limited to the next move.

Box-push direction was even more strongly decodable, reaching 0.853 in `c2` and 0.808 in `c3` at a five-step horizon. A time-to-visit regression also exceeded its board baseline, showing that the representation contained temporal ordering rather than only a set of relevant cells. These early results were later qualified by stronger board CNNs, which can recover much of an executed route from geometry. The robust contribution is therefore not simply the size of the hidden-versus-linear-board gap. It is the monotonic within-step refinement and the causal steerability described below.

The field is spatially local rather than a global potential radiating cleanly from a distant subgoal. Alignment with the eventual box is strongest near the player and decays with distance. This matters conceptually. The deepest layer does not look like an explicit global path stored as a list of coordinates. It looks like a local policy field that becomes coherent through repeated spatial computation and chained execution.

### 3.2 Ordered within-route look-ahead

The strongest evidence for genuine multi-step look-ahead comes from an arrival-order target that removes route membership as a confound [5]. Each future-visited cell is labeled by its first-arrival time within a horizon, and performance is measured by rank correlation only over cells that are truly visited. A probe that knows which cells belong to the route but not their order therefore cannot succeed.

At the final recurrent snapshot, `c3` achieved an arrival-order Spearman correlation of 0.640, compared with 0.043 after shuffling order. An occupancy proxy performed negatively on the order metric, confirming that route membership alone was insufficient. The within-step increment in `c3` was approximately +0.112 while the board was fixed. Against a capacity-matched shallow board CNN, the recurrent advantage on geometrically underdetermined or detouring route segments was about +0.414; even a deeper board CNN remained behind by about +0.256.

Several controls show that this is not merely a trace of already executed motion. On far cells near the start of a route segment, the recurrent state exceeded both shuffle and deep-board baselines. At the very first environment step, with no trajectory history, large-horizon order correlation was 0.527, and it remained strong on cells where the executed route departed from the shortest-path order. A heading-plus-position momentum model failed badly on such detours, while `c3` retained the ordered signal. The agent therefore represents an ordered sequence of future route locations within its current subgoal.

This result directly answers one part of the research question: the network does map out a continuous sequence of distinct future steps. But whether that sequence is an independent control object is a separate question. As shown later, order-specific interventions changed the decoded order margin without changing the realized traversal order.

### 3.3 Nonlinear information about the second-next subgoal

An influential early result found that the identity of the second-next completed target was approximately at chance under a linear spatial probe. A later capacity sweep showed that this “look-ahead deficit” was a limitation of the probe family [6]. A local nonlinear (1	imes1\) readout on the full activation stack reached accuracy 0.505, compared with 0.391 for a capacity-matched board readout, a gap of +0.113 with a 95% confidence interval from +0.091 to +0.137. The same advantage remained on boards where geometry was ambiguous or where the board model predicted a different target. Recurrent surfaces alone also carried smaller but reliable nonlinear advantages, including about +0.044 in `c3`.

The full-stack gap grew from +0.097 in the carried-in state to +0.113 after recurrent refinement. Thus a distinct subgoal beyond the current one is not merely recoverable; part of its representational explicitness is constructed across the inner computation. The scientific correction is important: failure of a linear probe did not imply absence of forward-subgoal information.

At the same time, history controls constrain what kind of information this is. Two different legal player-only histories reaching the same board produced imperfect agreement in the nonlinear readout, but the difference shrank as the recent action suffix was matched. The history-dependent component tracked recent momentum rather than a long-carried plan. A board-plus-momentum model absorbed little of the overall recurrent advantage, suggesting that the remaining signal reflects deeper present-board processing that a local shallow baseline cannot perform. This is forward information, but not strong evidence for a stored queue.

### 3.4 Non-greedy box-to-target assignment

Sokoban planning also requires assigning boxes to targets. The realized assignment in the analyzed four-box episodes was highly nontrivial [7]. It differed from greedy nearest-target matching on 72.6% of solved boards and from a minimum-total-push-distance Hungarian assignment on 63.5%. The probed object was therefore the agent’s policy-specific matching, not a trivial restatement of nearest geometry.

Across linear, pointwise nonlinear, and spatial CNN probe families, the recurrent state made each box’s realized target more explicit than a capacity-matched board model. With the strongest matched spatial comparison, `c3` achieved 0.674 accuracy on the non-greedy subset versus 0.562 for a board-plus-observable-momentum model, a gap of +0.113 with a confidence interval excluding zero. Recent observable momentum added only about +0.008 to the raw board baseline and did not explain the hidden-state advantage. At the first environment step, where history is absent, the recurrent advantage remained +0.057.

The assignment signal sharpened early across recurrent updates. However, independent per-box predictions rarely formed a valid global bijection: only about 7% of argmax assignments were valid permutations, below an independent-candidate reference near 9.4%. A later capacity-matched joint-versus-marginal study did not find a strong geometry-independent joint permutation at the first step, although its synthetic calibration showed limited power near the real operating point. The defensible conclusion is therefore that the network exposes a distributed per-box assignment field. It does not establish a single global permutation token.

The ontology of a deeper ordinal sequence remains even less settled. One study concluded that future box ranks were marginal rather than joint, but a later structural diagnostic showed that the “joint-only” interaction features had essentially zero variance across candidate permutations: maximum variance 7.105 × 10⁻¹⁵ [19]. The operator was mathematically unable to discriminate the alternatives. That null cannot be used to rule out a global ordinal structure. The evidence does rule out treating the earlier null as decisive.

### 3.5 A long-horizon visit field at choice points

The latest probing analysis targeted whether each cell would be visited within horizons of 1, 2, 3, 5, or 8 future steps [22]. It compared co-located linear probes on recurrent surfaces with both a local board probe and a global breadth-first-search distance predictor. The shortest-path baseline was stronger at very short horizons, as expected. At choice points, however, `c3` overtook the strongest baseline as the horizon lengthened: the balanced-accuracy gap was approximately +0.056 at five steps and +0.099 at eight steps, with clustered confidence intervals excluding zero. This graded improvement is consistent with a recurrent route representation whose value lies especially in longer-horizon disambiguation.

The binary predictions were mostly nested across horizons, but raw scores were not monotonically calibrated as visit time. Thus the experiment supports a long-horizon route field, not a precise scalar countdown at every cell. Together with ordered-route probing, it indicates that the DRC contains both which-cells and in-what-order information over a meaningful future window.

## 4. Readable future variables have sharply different causal roles

The second part of the story is a causal sorting. Variables with similar decoding accuracy can be necessary, sufficient, partially effective, or inert. The pattern cannot be predicted from readability alone.

### 4.1 The local motion field is a genuine lever

The most reproducible positive intervention writes a decoded motion direction into `c3` at a chosen cell [2]. On boards where the baseline agent would leave a plain floor cell in another direction, adding the counterfactual motion contrast across all inner updates increased the probability of exiting in the written direction to 0.234, compared with 0.045 for a matched-norm random vector, 0.026 when the same direction was written at an irrelevant cell, and zero in the unedited baseline. The paired effect was +0.183 against random and +0.202 against the irrelevant-location control. It grew monotonically with dose while solve rate remained about 0.99–1.00.

The effect works at ordinary floor cells with no box, so the causal primitive is not an object-specific push token. It is a location-indexed movement field. A separate box-push direction code is nearly orthogonal to the motion code and does not compose as effectively at plain floor. Multi-step behavior can therefore arise by repeatedly following local directions, rather than by reading a symbolic trajectory list.

### 4.2 Routing is not the same as subgoal selection

When the motion field is rewritten along the first two cells of a corridor toward an alternative box, early trajectory following increases by +0.233 relative to a matched random field at the same cells [3]. Yet the probability of actually selecting that box increases by only +0.067, with a confidence interval crossing zero. A larger full-corridor edit appears to reselect boxes more often, but an equally large random field at the same corridor does nearly as well and causes substantial delay. The apparent selection effect is mostly nonspecific disruption.

This dissociation localizes the function of the `c3` directional field. It determines how the agent moves through the currently active route, but is not by itself the upstream selector of which box should define that route. A route can be steered without cleanly rewriting the macro-choice.

### 4.3 A distinct dominance direction partially biases selection

The deepest cell state is not causally uniform. A candidate-dominance direction, orthogonalized against the known routing direction, can bias which box is completed first [9]. At a calibrated dose, the gross flip-to-alternative rate was 0.367, and the effect above matched random was +0.183. The manipulation moved the dominance projection by roughly 27 units while leaving linear routing cross-talk near (10^{-6}), and solve rate remained 0.98.

This is an important counterexample to any claim that deep decoded representations are universally epiphenomenal. It also illustrates why the exact intervention geometry matters. The best linear decoder normal for the same completion choice was more accurate observationally but causally inert, whereas a differently oriented dominance direction altered behavior. A representation can therefore contain a readable decision axis and a distinct effective axis within the same layer.

The effect is partial rather than commanding. Board geometry remains the dominant determinant, and aggressive doses eventually make random perturbations equally disruptive. The dominance direction is best understood as a selection-biasing handle embedded in a larger spatial process, not as a discrete symbolic command token.

### 4.4 Order, later-subgoal identity, and assignment are usually footprints

Several of the richest future variables fail strong causal tests.

The box-completion order signal in `c3` is event-linked, decision-predictive, and more decodable with a nonlinear probe than a linear one [8]. Nevertheless, removing a learned order subspace up to rank 16 reduced the readable signal by roughly seven orders of magnitude while leaving completion order and solve rate essentially unchanged; all 48 tested boards were solved. Additive order injection also failed to change which box was completed first.

The ordered route field gives an even cleaner manipulation check [5]. An orthogonalized order edit moved the decoded arrival-order margin by about +1.04 at a single-cell radius and +0.72 over a neighborhood, with negligible occupancy, motion, or dominance cross-talk. Yet it caused zero route-order reversals on 60 boards at every tested dose and coverage radius, while preserving solve rates near 0.92–0.97. The network genuinely represents the order, but that decoded direction is not an editable ordinal control knob.

The nonlinear second-next-subgoal intervention similarly increased the decoded probability of an alternative future target from 0.298 to 0.708 on every trial, but the target was completed second at exactly the same rate under semantic and random edits, 0.0143 in each condition [6]. Higher doses did not change the conclusion, and solve rate remained 1.0. The forward subgoal is readable but not a causal selector under this local probe-gradient operator.

Finally, a clean local substitution removed an assignment readout in `c2` at a geometrically ambiguous box while preserving an unrelated box feature [25]. The manipulation gate passed, but short-window redirection was 0.180 both for semantic ablation and matched disruption. The per-box assignment signal is therefore not demonstrated as a local causal lever at that interface.

These nulls are not failures of the research program. They constrain the algorithm. The recurrent network makes many planning-relevant variables explicit, but the policy does not behave as if it consults each decoded variable as an independent register. Instead, these variables often summarize or predict the evolving spatial state produced by the causal engine.

### 4.5 Causal leverage is interface-dependent

The intervention record rules out a simple additive-versus-destructive dichotomy. Additive edits can succeed, as with the local motion direction, the dominance direction, and the geometry-aligned value vector discussed below. Destructive edits can also fail, as with clean removal of static dead-square or assignment readouts. What separates positive from null interventions is whether the edit respects the spatial and temporal interface used by the active computation [18].

| Planning object | What probing establishes | Result of the strongest targeted intervention | Mechanistic status |
|---|---|---|---|
| Local motion direction | A per-cell intended movement is readable in `c3` | Direction writing changes movement at the edited cell above matched controls | Direct execution lever |
| Route membership / Path-Floor | Future route cells are readable and policy/value-sensitive | Route-floor injection, gate block, and active-route ablation alter choice | Causal routing substrate |
| Candidate support | Chosen origin/standing geometry is concentrated in `c2` | Chosen-anchor ablation causes competent fallback to alternatives | Necessary selection support |
| Candidate dominance | Relative candidate strength is readable in `c3` | A routing-orthogonal direction partially flips the completed box | Partial selection lever |
| Within-route arrival order | Genuine ordered look-ahead is present before motion | Manipulation-checked order edits produce no route-order flips | Readable footprint under tested operator |
| Box-completion order | Event-linked order is linearly and nonlinearly readable | Rank-16 subspace erasure leaves order and solving intact | Readable footprint under tested operator |
| Second-next subgoal | Nonlinearly decodable above matched board models | Large decoded-probability shift leaves second completion unchanged | Forward footprint under tested operator |
| Per-box assignment | Non-greedy target assignment is explicit beyond board and momentum | Clean local readout removal does not redirect above matched disruption | Distributed footprint under tested operator |

The most reliable levers act on active routing geometry: route-floor cells, candidate origin-and-standing support, input gates on a route, local motion directions, or a dominance axis isolated from routing. Inert edits tend to target an abstract label at a single decoded locus—completion order, second-next identity, static deadness, or assignment—without reconstructing the distributed spatial relations through which the network acts. This observation motivates the positive mechanistic account in the next section.

## 5. The causal engine is an iterative spatial routing process

The positive results converge on a specific computational object: a route- and value-bearing spatial state that is repeatedly built over traversable geometry, supported at a candidate box, translated into a local motion field, and reshaped by competing routes. Five lines of evidence establish this engine.

### 5.1 Cumulative recurrence, not raw compute, builds the route

The repeated core behaves like an iterative operator rather than a stack of interchangeable computations [10]. When the number of stored inner states was varied at inference, decoded route membership rose from chance, approximately 0.50 with only the carried-in state, to about 0.90 after one update and roughly 0.98 at the trained budget. Ordered-route decoding rose in parallel. On a deliberately enriched set of difficult boards, solve rate increased from 0.625 with two stored states to 1.00 with four.

The critical control matched the number of ConvLSTM applications while denying cumulative within-step carry. Each application restarted from the same pre-update state, and only a one-update product was passed to the next environment step. This non-cumulative condition used the same weights and nominal compute as the normal recurrent loop, yet it remained at the shallow representation. Normal cumulative processing exceeded it by +0.105 in route membership and +0.590 in route order; on the enriched hard set, solve rate was higher by +0.375. Thus the benefit is not simply more module evaluations. It is the iterative reuse of the updated spatial state.

The state dynamics also show a relaxation signature. The norm of the recurrent change shrank from about 9.38 to 6.92 to 4.99 across the three updates. Shrinkage was greater at decision states—initial states and states following a consequential push—than during ordinary route execution. Extending computation beyond the trained budget produced little further improvement. These results identify the inner loop as a **convergent route-refinement operator**: it moves the spatial state toward a stable solution within the available update budget.

This finding explains why so many probes sharpen across inner computation. Direction, order, assignment, and later-subgoal information need not correspond to separate algorithms. They may be different readouts of a common spatial state becoming more internally consistent as the recurrent operator converges.

### 5.2 A localized candidate-support field is necessary for the selected push

The middle recurrent cell state contains a strong causal support locus at the origin and standing cells associated with the selected candidate box [11]. Zeroing all 32 `c2` channels at the chosen candidate across inner updates reduced its selection from 1.00 to 0.266. The remaining 73.3% of trials did not simply fail; the agent redirected across 27 different alternative coordinate pairs while maintaining a 1.00 solve rate. Ablating the analogous cells of an unchosen candidate changed behavior only marginally.

This is a necessity result rather than a decoder injection. It shows that the chosen route is physically supported at a localized relational geometry: the box and the cell from which it can be pushed. The support is dynamically constructed. Removing it only at the carried-in state was mostly repaired, with chosen selection recovering to 98.3%; removing it at the final update had a larger effect, and removing it throughout the recurrent computation produced the full collapse. A same-direction transplant from the chosen candidate to an unchosen one increased the unchosen push rate under geometry-matched conditions, although the effect was partial and direction-sensitive.

The natural interpretation is not that `c2` stores an abstract “choose box B” symbol. The support field is a spatial terminus where route feasibility, approach geometry, and value accumulation meet. Its relational dependence explains why arbitrary semantic vectors at a candidate often fail, while deleting or transplanting a geometry-matched anchor can reroute the agent.

### 5.3 Input gates enforce route topology

The strongest direct test of route topology intervened on the ConvLSTM gates at empty floor cells [12]. On each selected board, one cell lay on a shortest route associated with the chosen candidate, while a control cell had the exact same Manhattan distance from the box but was excluded from all relevant shortest-route unions. Blocking both the input and forget gates at the on-route cell redirected 29% of first pushes to alternatives, compared with 14% at the matched off-route cell. The difference of +0.15 had a 95% confidence interval from +0.06 to +0.25, and every condition retained a 1.00 solve rate.

Gate decomposition was especially informative. Blocking only the input gate reproduced the full 29% versus 14% contrast. Blocking only the forget gate produced 3% redirection in both locations. Under this intervention, new state written through the input gate is the route-specific causal process; simply preventing retention through the forget gate is not.

This result makes the geometric metaphor precise. Empty floor is not merely represented as an inert map. The recurrent update writes route-supporting state through a spatially organized interface, and disrupting that write on the active path has a larger effect than equally distant disruption elsewhere. Walls and obstacles can therefore bound the relaxation by suppressing or redirecting where new spatial state is accumulated.

### 5.4 The route floor is a constructive additive lever

Spatial gradient analyses showed that policy and value are especially sensitive to the empty floor cells the player will traverse before the next push. During contextual execution, policy sensitivity on this **Path-Floor** exceeded off-path floor by factors around 2.7 at early updates. Gradient concentration alone is not a causal intervention, but it motivated a constructive test [13].

A universal value-gradient direction was extracted from empty floor and additively written along the off-path floor leading to an unchosen candidate. The same vector, total norm, and number of cells were used for a random-floor control. At the strongest calibrated dose on initial decision states, the geometry-aligned edit induced the alternative push on 25.0% of branches, compared with 11.7% for random floor. The paired gap was +0.133, with a 95% confidence interval from about +0.017 to +0.250, and solve rate remained 1.00. A post-reward replication produced a smaller but positive +0.08 effect.

This is a crucial positive result because it shows that additive steering is possible when the edit is applied to the medium the computation uses. The effective intervention does not write an abstract target identity at the box. It creates a spatially coherent value-bearing corridor through empty floor. The policy then treats that corridor as part of a viable route.

The effect is not deterministic, and the random-floor control becomes active at high dose. Nevertheless, the spatially matched difference demonstrates that topology matters over and above perturbation magnitude. A fake route can partially compete with the endogenous route if it is written in a geometry-consistent form.

### 5.5 Active routes interfere to resolve multi-box conflicts

The most direct evidence about sequencing comes from boards where two boxes compete for the same geometrically attractive target [15]. Several top-down hypotheses failed. Copying the deep assignment state from the assigned box to the unassigned box rarely redirected the unassigned box and reduced solve rate. Hiding the assigned box at its visual encoding did not release the competitor: the unassigned box still reached its original target in 76–78% of trials and the shared target in only 12–14%. The recurrent input gates on the two potential paths were not simply closed by an abstract assignment label.

A route-level intervention produced a different result. Zeroing (c_1/c_2) only along the active empty-floor route of the assigned box caused the competing box to reach the shared target on 25% of boards, compared with 5% when an equal-length path outside the relevant route topology was ablated. The paired effect was +0.20 with a confidence interval from +0.067 to +0.333, and both conditions solved every board. The agent did not merely become confused; it reassigned the original box elsewhere and completed the puzzle.

This supports **dynamic path interference** as a mechanism for combinatorial resolution. Active routes occupy a shared recurrent spatial substrate. A strong route toward one box-target pairing changes the effective field available to other pairings, suppressing or deflecting their gradients. Removing that route releases a competitor. What appears at a symbolic level as “box A is assigned to target 1, therefore box B must use target 2” can emerge from the equilibrium of interacting spatial routes without a separately stored logical veto.

Dynamic interference also explains why the agent may look sequential even when most state is re-derived. Only one route can dominate the action interface at a time. Once a push changes the board or completes a subgoal, the active route collapses or reconfigures, freeing spatial capacity for another route. Re-running the relaxation on the new board yields the next macro-action. A sequence of discrete choices is produced by repeated spatial symmetry breaking.

### 5.6 Visual encoding supplies seeds, not the finished plan

The non-recurrent visual encoding is a single local map that remains fixed across the inner updates. It contains strong local geometric information: at a box cell, a linear readout from `x_enc` predicted player-to-box distance with R² = 0.452, compared with 0.061 for a local raw-board readout, and box-to-nearest-target distance with R² = 0.710, compared with 0.556 [21]. Channel profiling identified a particularly target-selective feature, while wall selectivity was less cleanly dedicated [23].

These decoders are not themselves the causal seed. Directly compressing the decoded box-to-target distance at an unchosen box failed across raw and exactly calibrated doses. Even a least-norm change corresponding to a 12-tile reduction yielded zero semantic selections of the desired box and slightly more selections under the random control. Swapping the visual player vector toward the competing box was similarly nonspecific. The perturbations propagated strongly through the recurrent core rather than being suppressed, so their failure cannot be explained by simple downstream erasure. They changed the state but did not instantiate the right spatial relation.

A more natural target-feature transplant produced a strikingly different outcome [20]. In a four-box environment where one focal box-target pair could be isolated, the true target’s full 32-dimensional `x_enc` vector was copied to a reachable phantom floor cell, while the true target was replaced with a floor vector. The focal box reached the phantom location first on 41.7% of trials, compared with 5.0% for the floor-control condition, a paired increase of +0.367 with a confidence interval from +0.25 to +0.50. Solve rate remained 93.3% under the latent swap and 100% under control.

This experiment is limited because literal one-box boards were unavailable; other boxes remained as obstacles, and the focal pair was selected from a solved four-box trajectory. Even so, the contrast suggests that **object-type semantics at the visual interface can seed routing**, whereas scalar geometric readouts such as distance are not independently sufficient. The recurrent engine appears to require a coherent local target-like boundary condition, not merely a number saying that a box is closer.

The visual encoding therefore occupies the beginning of the algorithm. It supplies local wall, target, box, player, and geometric features through both a direct policy/value skip and a recurrent input. The recurrent path has the larger measured gain contribution, but the full encoding outperforms any small high-gain subspace. The inner loop transforms these local seeds into the spatially extended route and support structure that controls action.

## 6. Memory, re-derivation, and the planning horizon

The positive spatial engine might still implement one of two very different algorithms. It could cache a route or macro-plan from the specific history and consult it during execution. Alternatively, it could reconstruct the route from the current board at each step, carrying only a small dynamical prior. Construction-controlled experiments favor the second account while preserving a limited role for recurrent handoff.

### 6.1 Warm route signals are nearly independent of the path taken

Gradient-based route maps initially appeared to show a cached plan: in warm recurrent context, sensitivity concentrated on future route floor and distal-box sensitivity was much smaller than after a cold start. But warm-versus-cold changes both board context and recurrent state. A more decisive experiment constructed two distinct legal player-only histories that reached a byte-identical current board [14].

The resulting warm causal-gradient maps were almost identical across histories. Correlations ranged from about 0.97 to 0.99 for value and policy, while correlations between different boards were near zero. The route signal therefore did not encode the specific route history that had produced the board.

Starting from a zero recurrent state on that same board reconstructed most of the warm map. For value, warm-versus-fresh correlation rose from about 0.73 at the earliest snapshot to 0.90 after recurrent refinement. Path-Floor-restricted policy maps became similarly board-reconstructable by the final update under magnitude-sensitive metrics. The recurrent state contributes something, especially early, but the inner loop can recover most of the spatial solution from the current board.

Shared-suffix and total-history controls further narrowed the residual. Agreement recovered when only a short recent action suffix was matched and did not grow with longer padded history. The residual behaves like a short movement or handoff prior, not a plan accumulated over a long trajectory. In ordinary rollouts, that prior can make execution smoother and reduce the need to recompute distal candidates immediately, but it is not the sole source of the route.

### 6.2 Cold-start teleportation shows that accumulated sequence state is not necessary on clean handoffs

An especially direct test bypassed the walking interval between completing one box and beginning the next [24]. The player was teleported to the end of a clean no-box-movement handoff window, and in the strict condition the entire recurrent state was zeroed. On 100 selected solved episodes, both continuous-state and cold-start teleport conditions succeeded in 100% of cases and brought the next box to a target in every case. The skipped walking window averaged 3.85 steps.

This result does not prove that memory is irrelevant on every difficult board. The cohort was selected for clean successful handoffs, and the intervals were short. It does show that the representation accumulated during normal walking is not generally necessary for those continuations. The board after teleportation contains enough information for the recurrent computation to rebuild a competent route from scratch.

### 6.3 Embodied accumulation is a footprint of repeated re-solving

During normal execution, representations of the next subgoal often strengthen while the player walks and boxes remain stationary [16]. Extending the inner loop to ten updates on a frozen visual frame does not continue this amplification; the signal plateaus after the trained budget. Across successive environment steps, however, the plateau itself rises. The physical movement of the player provides a sequence of changed boards, and the network repeatedly relaxes each one.

This phenomenon is best described as **embodied accumulation**: future-relevant signals become clearer as the agent advances through the environment. Yet the cold-start teleport result shows that the accumulated trace is causally redundant in the tested windows. The apparent warm-up need not be a hidden planner thinking farther into the future. It can arise because repeated board-conditioned relaxation produces increasingly decisive predictions as geometry changes and uncertainty resolves.

### 6.4 What planning horizon is supported?

The evidence supports several horizons with different status.

- The **current route** is strongly represented and causally load-bearing. Route membership, candidate support, input-gated topology, and local movement form the immediate control state.
- The **ordered current route** is genuine multi-step look-ahead and is present before movement, but its decoded order direction is not independently causal under the tested edits.
- The **next subgoal across a completion boundary** is represented, sometimes before the boundary [17], and can be weakly influenced by certain full-vector or anchor interventions. It is also readily reconstructed after suppression or cold start.
- The **second-next subgoal and broader assignment** are decodable beyond matched baselines, but the tested local representations are largely re-derived and causally inert.
- A **global ordinal sequence object** has not been established or ruled out. The strongest negative ontology test was structurally blind, so the correct conclusion is unresolved rather than absent.

This hierarchy reconciles apparently contradictory findings. The agent has meaningful foresight, but its causal horizon is narrower than its representational horizon. It predicts more of the future than it can be made to execute by editing a single decoded variable. Planning is distributed across the evolving spatial state rather than concentrated in a discrete sequence register.

## 7. A unified algorithmic description

We can now state the best-supported algorithm in operational terms. The description is intentionally at the level of represented objects and causal computations, not individual neurons or gates beyond what the interventions establish.

### 7.1 Board-conditioned geometric relaxation

Let $B_t$ be the current Sokoban board and $R_{t,0}$ the recurrent state carried into environment step $t$. Let $E(B_t)$ be the spatial visual encoding. The repeated core applies a shared update operator $F$:

\[
R_{t,k+1}=F\bigl(R_{t,k},E(B_t)\bigr),\qquad k=0,1,2.
\]

Empirically, the update sequence approaches a stable spatial configuration within the trained budget. The final configuration contains at least four interacting components:

1. A distributed route/value field over empty floor.
2. Local support at box-origin and standing-cell geometry for the selected push.
3. A deep local motion field mapping relevant cells to intended movement directions.
4. Competitive or interfering spatial structures associated with alternative routes.

The policy reads the final hidden state together with the visual skip and selects an action. The environment changes to $B_{t+1}$, the recurrent state is handed forward, and the process repeats. The carried state supplies a short prior, but the new route is largely reconstructed from $B_{t+1}$.

In pseudocode:

```text
input: current board B, short recurrent handoff R

X = local_visual_encode(B)

for each recurrent refinement update:
    propagate route/value support through traversable floor
    enforce walls and route boundaries through spatial input gating
    strengthen geometrically consistent candidate support in middle layers
    let competing route fields interact on the shared spatial substrate
    sharpen the deep local motion and candidate-dominance fields

choose an action from the refined spatial state and visual skip
execute the action in Sokoban
carry a short recurrent prior to the next board
repeat
```

The algorithm is “discrete” only at its behavioral output: one movement or push is chosen at a time. Its internal planning computation is continuous and spatial. Discrete box choices emerge when a continuous field settles around one geometrically supported route more strongly than its competitors.

### 7.2 Why this algorithm looks symbolic from the outside

A settled spatial field determines a box, approach direction, route, target, and probable continuation. Those consequences are highly correlated and therefore jointly readable. A probe can recover completion order, assignment, later subgoal identity, or arrival sequence because the recurrent state is already shaped by the same geometry that will produce those events. Repeated execution further strengthens the correlations.

This creates the appearance of an explicit symbolic plan. But causal tests show that many decoded summaries can be moved or removed without changing behavior. They are often **sufficient statistics for an observer**, not **control registers for the policy**. The actual levers are the distributed spatial conditions that make one route dynamically stable: floor propagation, gate topology, candidate support, local motion, and route competition.

### 7.3 How sequencing emerges without a queue

Suppose two boxes are plausible candidates. Visual features seed multiple partial route/value patterns. Cumulative recurrent updates propagate those patterns through the same finite spatial substrate. Routes compatible with walls, standing positions, targets, and current player access gain coherent support. Incompatible or competing routes are weakened by blocked propagation and interference with the active field. A candidate-support anchor stabilizes the winning route; a deep dominance component biases the final competition; the motion field executes the approach.

After a push, three things happen simultaneously. The board geometry changes, the current route may disappear, and previously suppressed routes may become viable. The next recurrent relaxation therefore settles into a new equilibrium. What an external observer describes as “first push box A to target 1, then push box B to target 2” can be generated by a sequence of equilibria without a stored list containing both instructions. Forward assignment and order remain decodable because the current equilibrium constrains likely later equilibria, not because the later commands are necessarily stored as independently executable tokens.

### 7.4 What is carried between steps

The recurrent handoff is not empty. Warm and fresh states differ, policy sensitivity contains an early route-localized residual, and ordinary execution benefits from continuity. The carried content is best described as a short, spatially organized prior—recent movement direction, current route momentum, and partially settled support—not a long history-specific blueprint. It reduces the work required during ordinary execution but can be overwritten or reconstructed when the board demands it.

This middle position avoids two errors. Calling the agent memoryless ignores genuine recurrent persistence and the causal route state. Calling it a cached symbolic planner ignores same-board history invariance, cold-start recovery, and the repeated success of board-based reconstruction. The agent is recurrent because relaxation has state, not because it stores a complete discrete program.

## 8. Explanatory reach and falsifiable predictions

The geometric-relaxation account earns its value by explaining diverse results with one mechanism and by making new predictions.

### 8.1 Why all-update interventions matter

Single-update semantic edits are often washed out, whereas repeated edits across all inner updates can steer behavior. Under the proposed algorithm, every recurrent update reintroduces board-consistent structure. A one-time perturbation is corrected as the field relaxes back toward its attractor. Sustained edits or changes to the boundary conditions can shift the attractor itself.

Prediction: an intervention’s efficacy should depend less on its raw norm than on whether it is maintained through the updates in which the targeted route is being constructed. Timing sweeps should show narrow windows around decision and repair states, with smaller effects during settled execution.

### 8.2 Why geometry-matched edits outperform semantic vectors

The network acts through spatial relations. A vector that says “future target B” at one cell may move a decoder without supplying the floor corridor, approach geometry, and competing-route changes required for action. In contrast, a target-like visual seed, a route-floor value corridor, a candidate-support transplant with matched push direction, or an on-route gate block changes the relational object the recurrent dynamics consume.

Prediction: distributed interventions that preserve local feature correlations and route continuity should outperform equally decodable point edits. The strongest comparison would hold decoded target probability constant while varying whether the intervention creates a coherent path through adjacent cells.

### 8.3 Why deep look-ahead is readable but weakly controllable

Later subgoals and assignments are constrained by the current spatial equilibrium and board topology. They can therefore be predicted from the recurrent state, sometimes nonlinearly and before execution. But because they are not the only determinants of the next equilibrium, editing their readout alone does not necessarily alter the active route.

Prediction: later-subgoal interventions should become more effective when coupled to the route interface at the boundary where that subgoal becomes current. The same semantic direction may be inert during the present route but effective after the current anchor is removed or the competing Path-Floor dissipates.

### 8.4 Why hard boards benefit more from recurrence

Easy boards often contain a strongly preferred local route that can be found after one update or even from feed-forward geometry. Difficult boards require more rounds of constraint propagation and competition. This explains why the reach-building effect is robust across random boards while the solve-rate benefit is largest on an enriched hard subset.

Prediction: the number of updates needed for convergence should scale with route ambiguity, detour length, candidate conflict, and distance between the player and the relevant support geometry. State-change norms should decay more slowly on such boards, and premature action should correlate with unresolved route competition.

### 8.5 How to test dynamic interference more strictly

The active-route ablation effect is compelling but partial, and its off-route control was matched for length and topology rather than every distance statistic. A stronger test would construct parallel corridors matched for target proximity, local wall texture, length, and distance to both boxes, while differing only in whether they carry the endogenous active route. Selective release of the competitor only on the active corridor would further isolate interference from generic local shock.

Prediction: the competitor’s route/value gradient should increase immediately after active-route ablation, before the first changed action, and the increase should propagate along the shared-target corridor. This would connect the behavioral reroute to a measured field redistribution.

### 8.6 A valid test of global sequence ontology

The invalid ordinal interaction probe illustrates a general lesson: a complex readout must be shown capable of detecting the hypothesized structure. Any renewed joint-sequence test should verify nonzero candidate-wise variation in its interaction features, recover synthetic joint structure over the same candidate-generation process, and compare against strong marginal and board baselines.

Prediction: if a global sequence object exists, a properly calibrated relational probe should add information beyond independent per-box ranks and should preserve that advantage on step-one states and geometry-matched alternatives. If no such advantage appears under a demonstrably powered operator, the repeated-relaxation account would be strengthened.

## 9. Limitations

All conclusions concern one trained checkpoint, one family of 8×8 Sokoban boards, greedy action selection, and the available activation and intervention interfaces. A different policy, stochastic sampling, or a larger board distribution may use memory and look-ahead differently.

The intervention evidence is heterogeneous. Studies use different board cohorts, endpoints, doses, and operators, so effect sizes should not be compared as if they came from one factorial experiment. The synthesis rests on qualitative convergence and on a few especially strong matched-control results: local direction steering, cumulative-versus-non-cumulative recurrence, candidate-support ablation, on-route versus off-route input-gate block, Path-Floor versus random-floor injection, same-board history controls, and active-route versus excluded-route ablation.

Several causal nulls remain operator-specific. A decoded variable can be inert under a linear local edit yet participate in the native nonlinear computation. The order, assignment, dead-square, and later-subgoal results show that the tested readouts are not simple steering handles; they do not prove that related information is unused everywhere. Conversely, gradient sensitivity identifies where outputs depend locally on state but does not by itself prove that the gradient direction is a natural intervention. The strongest mechanistic claims therefore combine gradients with live edits.

The visual target-transplant result is promising but incomplete. It used a focal box-target pair embedded in a four-box board because literal one-box boards were unavailable. Other boxes remained as obstacles, and target replacement was maintained for the full episode. The result supports causal sufficiency of a target-like visual seed in that bounded setting, not a universal account of target encoding.

The exact mathematical objective of the relaxation is not known. “Value gradient,” “flow field,” and “geometric relaxation” describe empirically supported functional structure: repeated convergence, route-sensitive gates, causal floor paths, and support anchors. They do not establish that the network minimizes an explicit scalar energy or computes a textbook shortest-path algorithm. Indeed, the agent’s realized assignments are often non-greedy, its local heuristics can be fooled by visual texture, and its route field is more local than a global potential.

Finally, the ontology of the deepest macro-sequence remains open. Existing evidence supports ordered within-route look-ahead, nonlinear second-next information, anticipatory next-subgoal signals, and per-box assignment fields. It does not establish a carried global symbolic sequence; nor does it decisively rule one out, because the strongest ordinal jointness null was generated by a structurally invariant operator.

## 10. Conclusion

The DRC Sokoban agent plans, but not by storing and executing a symbolic script. Its emergent algorithm is a recurrent, board-conditioned geometric relaxation process. Local visual features seed a spatial computation; cumulative inner updates propagate and refine route/value support through empty floor; input gates enforce topology; a middle-layer support field stabilizes the selected push; competing routes interfere; and a deep local motion field drives execution. The resulting action changes the board, after which the process is repeated.

This mechanism represents more of the future than it causally commands in a directly editable form. Ordered routes, later subgoals, assignments, and constraints are often richly decodable. Yet the strongest causal levers are sparse and relational: the active route, its candidate support, its gate-mediated topology, a local motion field, and a calibrated dominance component. Most plan-like readouts are footprints of the spatial computation rather than independent instructions.

The central research question can therefore be answered with a concrete algorithmic description. The agent maps out multi-step structure by iteratively settling a spatial routing state, not by expanding a symbolic search tree. It sequences boxes by repeatedly re-solving the current board and allowing active routes to compete in a shared recurrent geometry. Short recurrent memory carries a handoff prior, but the current board reconstructs most of the solution. The sophistication of the behavior comes from the repeated interaction of geometry, recurrence, and causal route support—not from a hidden list of moves.

## 11. Evidence provenance

The numerical and methodological claims in this paper are traceable to the following corpus documents. Titles are given in full so that each claim can be located without relying on internal database handles.

1. *Refining and Using a Plan: Internal-Tick Refinement and Causal Steering of a Per-Square Directional Plan in a DRC Sokoban Agent.* Source for the directional-field probe, monotonic within-step refinement, layer localization, and early causal steering.
2. *The Plan as a Composable Field: Causally Steering a DRC Sokoban Agent by Writing Local Move-Directions at Arbitrary Cells.* Source for plain-floor direction writing, dose response, motion-versus-box code dissociation, and local composability.
3. *Routing without Selection: The DRC c3 Flow Field Causally Steers Trajectory Direction but Does Not Select the Sokoban Subgoal.* Source for sparse routing-versus-selection dissociation and the local rather than global field geometry.
4. *The Footprint and the Lever: Decodability Is Not Causality in the DRC Planner.* Source for the decoder-versus-causal-direction dissociation, the necessary/inert/sufficient taxonomy, and operator calibration principles.
5. *Ordered Route Look-Ahead in the DRC Agent: Genuine Multi-Step Structure That Is Read, Not Written.* Source for route-order probing, step-one and detour controls, and the manipulation-checked causal null.
6. *The Look-Ahead Deficit Is a Probe-Capacity Artifact: The DRC’s Second-Next Subgoal Is Nonlinearly Represented, Re-derived, and Causally Inert.* Source for nonlinear second-next-subgoal decoding, history and momentum controls, and the semantic intervention null.
7. *The Assignment Is Read Before the Push: The DRC Makes Its Non-Greedy Box-to-Target Matching Explicit Beyond Board Geometry and Momentum.* Source for realized assignment reconstruction, non-greedy rates, matched board and momentum comparisons, and step-one assignment decoding.
8. *Decodable but Inert: The DRC’s Box-Completion Order Is an Event-Linked Correlate, Not a Causal Control Variable.* Source for order-subspace erasure and preserved behavior.
9. *A Selection-Biasing Subspace in c3: Refining the Pure Execution Surface Consensus.* Source for the routing-orthogonal dominance intervention and partial box-selection leverage.
10. *The Inner Loop Is a Convergent Route-Refinement Operator: Cumulative Iteration, Not Compute, Builds the DRC’s Planning Cache.* Source for the cumulative-versus-non-cumulative comparison, reach construction, solve effects, and shrinking state-change norm.
11. *The Anchored Value Gradient: Resolving the DRC’s Discrete Emergent Planning Algorithm.* Source for the `c2` candidate-support ablation and competent fallback to alternatives.
12. *The Continuous Geometric Routing Engine: A Mechanistic Formalization of Emergent Planning in the DRC.* Together with the study report *Topology-Specific Gate Block: Disentangling Route Routing from Generic Local Destabilization*, source for route-matched gate interventions and input-gate specificity.
13. *The Constructive Geometric Lever: Additive Steering of the Discrete Plan via the Path-Floor.* Source for geometry-aligned value-vector injection and matched random-floor controls.
14. *The Cached Route Is Largely Re-derived, Not Carried: A Construction-Controlled Source Attribution of the DRC’s Warm Causal-Gradient Signal.* Source for same-board/different-history agreement, fresh-state reconstruction, and short handoff attribution.
15. *The Dynamic Interference Engine: Geometric Resolution of Combinatorial Assignment in the DRC.* Together with the study report *Dynamic Path Interference: Ablating the Active Route to Release Combinatorial Conflict*, source for the active-route competition result.
16. *The Embodied Accumulation Mechanism: Outer-Loop Progression Drives Dormant Sequence Amplification During Navigational Downtime.* Source for the frozen-frame plateau and outer-step amplification analysis.
17. *The Anticipatory Single-Subgoal Engine: Disentangling Intent from Spatial Heuristics in the DRC.* Source for anticipatory next-subgoal readouts, bounded steering, and reactive recovery after pre-boundary ablation.
18. *Same Interface, Different Role: An Operator-Aware Map of the DRC’s Decodability–Causality Boundary.* Source for the interface-relative synthesis and the within-`c2` dissociation between a readable constraint and a causal support anchor.
19. *The Invariance Artifact: Why the Capacity-Matched Ontology Test Fails to Bound Ordinal Sequences.* Source for the structural invalidation of the ordinal joint-versus-marginal null.
20. *The Latent Visual Swap: Mapping the Visual Seeds of the Geometric Routing Engine.* Source for the target-vector phantom-location intervention and its four-box focal-pair limitation.
21. *The Visual Seed: Causal Steering of the Sequence via x_enc Distance Compression*; *Calibrated Causal Steering: Resolving the Visual Seed via Unit-Distance Compression in x_enc*; and *The Visual Seed: Decoding Static Geometric Heuristics from the Non-Recurrent x_enc Layer*. Sources for local visual distance decoding and the null distance-compression interventions.
22. *Decoding a Temporally-Ordered Agent-Visit-Time Field in DRC Sokoban Activations.* Source for the multi-horizon visit-field comparison with board and breadth-first-search baselines.
23. *Unboxing x_enc: Channel-Wise Profiling of Visual Seeds for the Routing Engine.* Source for target-selective and wall-versus-floor visual-channel profiles.
24. *Player Teleportation: Bypassing Navigational Downtime to Test Causal Necessity of Embodied Accumulation.* Source for the continuous-state and cold-start handoff comparison.
25. *Does the c2@tick2 Assignment Readout Have a Causal Interface? Clean Interface-Respect Intervention.* Source for the passed assignment manipulation gate and matched-disruption behavioral null.
