# Planning Without a Search Tree: A Receding-Horizon Continuous Spatial Constraint Solver in a Recurrent Sokoban Agent

## Abstract

Sokoban appears to demand discrete, long-horizon planning: boxes can be pushed but not pulled, apparently good moves can create irreversible deadlocks, several boxes compete for a finite set of targets, and the player must navigate to the correct side of the correct box before any strategic push can occur. A trained Deep Repeating ConvLSTM (DRC) agent solves this problem without an explicit search module. The central question is therefore not merely whether future states are decodable from its activations, but what algorithm those activations implement and which represented variables are causally used.

The accumulated evidence supports a precise answer. The DRC is best described as a **receding-horizon, memory-stabilized continuous spatial constraint solver with discrete input and output interfaces**. At every environment step, a convolutional encoder supplies the physical boundary conditions of the board. Recurrent state supplies a predictive cache and, on difficult ambiguous states, a hysteretic symmetry-breaking tilt. Across four observed recurrent snapshots, a stack of local convolutional updates and a learned board-wide pooled communication pathway relax several spatial variables toward mutual consistency. The principal product is a box-indexed, deadlock-aware push-direction field constrained by reachability, target capacity, and multi-box interactions. The immediately relevant box is represented together with its destination as a selectively bound object-file, while the player's navigation route occupies a largely separable subspace and is computed at a more local spatial scope. A player-centered, push-manifold-selective read operator then admits whichever variable is currently action-binding and serializes the continuous field into one discrete action.

This account differs sharply from chronological tree search, a stored action queue, or a fresh goal-seeded value-iteration wave. Deep future coordinates and later box priorities can be decoded, but most such representations fail controlled causal-use tests. Cross-step recurrent memory is highly useful as a stabilizing cache yet is not generally required: resetting all recurrent state at mid-episode preserves solving on 99 of the 100 longest baseline-solved boards, and related solver-stratified tests retain 98–100% success depending on reset phase. Long-horizon behavior instead emerges through repeated re-solving, immediate next-box priority, branch-conditional destination use, and spatial capacity conflicts that create “make room” subgoals and occasionally cascade to a second obstacle. Natural failures are correspondingly dominated by under-formation of the admissible field during the recurrent update, not by ordinary readout mistakes.

The resulting algorithm is discrete in its board symbols, capacity constraints, object selection, and final action, but its internal planning dynamics are primarily continuous. This hybrid character explains both the agent's competence and the central interpretability paradox of the corpus: rich future information can be present without constituting an executable future program.

## 1. The scientific problem

Sokoban is a small-grid puzzle with an unusually unforgiving action structure. The player moves through free floor and pushes boxes onto targets, but cannot pull them back. A push can be locally legal while making the puzzle globally unsolvable. The solution must therefore coordinate at least four kinds of information: the geometry of walls and corridors; the set of places the player can reach; the assignment and ordering of boxes relative to targets; and the irreversible consequences of filling narrow spaces or targets too early.

The agent considered here is a model-free DRC network. Its observation is an (8	imes 8) board encoded by seven binary channels: walls, empty floor, boxes off target, boxes on target, player off target, player on target, and target cells. Its recorded internal state has shape (4	imes224	imes8	imes8). The four slices are recurrent snapshots (K0,ldots,K3), with (K0) the pre-update state for the current environment step and (K3) the state immediately before action readout. The 224 channels concatenate three ConvLSTM hidden states, three cell states, and a 32-channel visual encoding. Thus the representation remains explicitly registered to board coordinates while also carrying recurrent memory and globally communicated summaries.

The research objective was to discover the agent's planning algorithm through two complementary operations. **Concept probing** asks what variables can be decoded from fixed activations and where they are represented. **Causal intervention** asks whether manipulating a candidate variable changes internal computation or behavior in the predicted way. The second operation is indispensable. A sufficiently rich recurrent network can encode correlates of many future events without using them as control variables. In this corpus, that distinction is not a philosophical subtlety; it separates the successful algorithmic account from several initially plausible but ultimately false interpretations.

The central conclusion can be stated compactly:

> At each environment step, the DRC reconstructs and relaxes a spatially registered field of admissible box intentions, uses recurrent state to preserve or break ties when necessary, computes a separable local navigation route to the selected manipulation, and reads the currently binding content through a player-centered selective gate. It does not normally execute a prewritten chronological sequence.

The rest of this paper develops that statement as an integrated scientific argument. It first explains the evidentiary strategy, then rules out the principal alternatives, derives the spatial solver from the representation and intervention results, and finally gives a formal phenomenological algorithm with a clearly marked boundary between established mechanism and open circuitry.

## 2. Evidence base and standards of inference

The evidence consists of a fixed train/test activation corpus, live or replayed interventions on the trained checkpoint, fifty archived scientific papers, 230 experiment reports, and ten retrospective surveys used to locate overlaps, negative precedents, and unresolved seams. The retrospective surveys were treated as navigation aids rather than primary evidence. Important claims were checked against the full archived papers and, where interpretation depended on details such as cohort construction, control registration, or confidence intervals, against the underlying experiment reports and raw-result descriptions.

Three methodological principles recur throughout the strongest work.

First, a hidden-state decoder must be compared with an appropriate board-only baseline. A weak linear board probe can make ordinary geometric information look “internal.” Stronger comparisons used deep whole-board convolutional networks, sometimes augmented with breadth-first-search or solver-distance features. Hidden-state advantage over such a baseline is evidence that recurrence computed something not easily available from the current board, although it remains correlational.

Second, causal claims require a manipulation audit. If an intervention is intended to change a decoded priority or destination, the experiment must first verify that the relevant internal readout actually moved. A behavioral null after a failed internal manipulation is uninterpretable. This point became especially important for destination variables: an early activation-vector experiment did not move its own destination readout and therefore could not establish destination non-use, whereas a later faithful target-relocation experiment achieved full registration and produced a large, specific behavioral effect.

Third, a semantic intervention must be compared with a matched nonsemantic control. Equal-norm random or orthogonal vectors, wrong-location edits, shuffled bindings, same-branch physical edits, and non-active-object edits were all used to separate content-specific causation from generic disturbance. This control discipline repeatedly changed the interpretation. High-dose vectors often alter behavior simply because the final policy is sensitive to large off-manifold activity. Conversely, real board edits travel through the network's native encoder and recurrent dynamics and often provide the cleanest counterfactual test.

These principles motivate an evidence ladder used in this synthesis:

1. **Decodable:** a variable is recoverable above a serious board baseline.
2. **Dynamically computed:** its representation changes across recurrent snapshots in a manner predicted by the hypothesis.
3. **Manipulable:** an intervention reliably moves the intended internal variable.
4. **Causally used:** the semantic intervention changes a downstream policy or behavior more than matched controls.
5. **Mechanistically localized:** timing, spatial scope, or pathway ablation restricts where and how the causal computation occurs.

No single experiment establishes the complete algorithm. The conclusion follows from converging constraints across this ladder.

## 3. Why the obvious algorithms are wrong

### 3.1 The agent does not unroll a chronological action queue

Early probes found that future player positions, future box pushes, intermediate parking coordinates, and even second or third turns of the same box could be decoded from recurrent activity [1–4]. It was tempting to infer a stored sequence. That interpretation failed several increasingly stringent tests.

The first decisive observation concerned representational format. A probe trained only on the source cells of the first future push transferred with macro-F1 0.932 to disjoint cells whose boxes would be pushed only later. A single box-indexed probe predicted each current box's own next push direction with F1 0.966 and performed nearly as well as rank-specific heads at the first three global push ranks [2]. The apparent “first, second, third push” code was therefore largely supplied by selecting different box cells at evaluation time. What the network represented was mostly a parallel field: at every current box location, a direction indicating how that box should next move.

Ordered information was not entirely absent. Later ranks showed a small residual heterogeneity, and probes could decode deep turns of a specific box above static-board baselines [4]. But the causal tests were negative. Steering an orthogonalized second-turn direction produced the forged second push in only 1.17% of cases, compared with 0.54% for a matched random control. Steering an intermediate parking coordinate reached the forged location in 6 of 96 cases but disrupted the original behavior so severely that normal solving collapsed. These are not the signatures of a modular executable queue. They are signatures of correlated future structure embedded in a richer dynamical state.

The newest priority experiments sharpen this conclusion. Strict spatial probes strongly decoded the first future box, peaking at PR-AUC 0.497 versus a board baseline of 0.241, but second- and third-priority spatial maps remained below the board baseline. Global average pooling did recover modest information about later priorities: the best pooled hidden PR-AUC was 0.0463 for the second box versus 0.0280 for pooled board, and 0.0540 versus 0.0333 for the third. Thus later priorities exist as weak distributed correlates in early memory, not as clean spatial object selections at the final readout.

Their causal status is more revealing. On a balanced two-candidate cohort, a pooled (c2\)-at-(K0) classifier identified the second future box only modestly above a pooled-board classifier: 53.85% versus 49.21%, a paired advantage of 4.64 percentage points. Broadcasting its learned concept vector across the board drove the probe's native-label accuracy all the way to zero, proving that the internal classifier had been decisively crossed. Yet the non-native second-box rate was 5.43%, below the 6.96% produced by an equal-norm orthogonal random vector. Moving the same perturbation later increased behavioral leverage, but the semantic-minus-random flip difference was only 0.43 percentage points with a confidence interval spanning zero. The correct conclusion is not that later priorities are absent. It is that the tested distributed representation is not a specific executable queue command.

Physical counterfactuals reach the same verdict from a different direction. When a wall was inserted at a tile decoded as the player's position three steps ahead, the (K3) representation avoided the blocked tile on 98.4% of 500 matched states, showing strong obstacle sensitivity. But independently decoded positions for the next five horizons formed a fully adjacent, wall-free path in only 4.27% of the successful blocks. This coherence metric is stringent and partly limited by independent argmax decoding, so it should not be read as proof that no path representation exists. It does, however, refute the simple hypothesis that the five decoded coordinates are the entries of a clean symbolic path list [47].

### 3.2 The recurrent loop is not fresh goal-seeded value iteration

A second appealing analogy was classical value iteration: seed value at targets, diffuse it backward around walls, and read a gradient at boxes or the player. The DRC does perform diffusion-like spatial relaxation, but the characteristic goal-outward wavefront is absent.

Using a fixed final-state decoder across recurrent snapshots, 88.3% of box cells already had their final within-step push direction at (K0) [5]. If a new field were seeded at goals each environment step, cells near targets should settle first and distant cells later. The data showed the opposite pattern. Target cells were settled at (K0) less often than cells one to four steps away, and after controlling for decoder confidence, distance from the player was a much stronger predictor of refinement than distance from a target. A separate analysis found no decrease in intent-field accuracy with final target distance. The field is maintained and locally corrected, not recreated by a target-originating breadth-first wave.

The update is nevertheless spatial. A single-cell perturbation creates a steep local response whose reach expands across recurrent computation, and walls alter that response. But it is coupled to board-wide communication, so “value diffusion” is best understood as a phenomenological metaphor for relaxation, not an identification with a hand-coded dynamic-programming algorithm.

### 3.3 The plan is not latched across environment steps

The third alternative is a plan that is computed once, stored, and then autonomously executed. Transient edits to a decoded route representation argue against this. A one-step concept-vector injection left a probe-readable trace for roughly three subsequent environment steps, and longer injection pulses extended that trace toward five steps. Behavior, however, changed mainly while the injection remained active. After removal, post-pulse visitation returned to control levels even though the internal perturbation could still be decoded [1]. The network has inertia, but it continually re-anchors its state to the current board.

State-reset experiments provide a stronger causal bound. Zeroing the complete recurrent tuple at the midpoint of the 100 longest baseline-solved episodes preserved 99% solving; five extra forward passes on the unchanged board did not improve this result [9]. On cohorts selected by A* difficulty rather than length, early, middle, and late resets retained 98–100% success [13]. Cross-step memory is therefore not normally an accumulating search tree. It is a cache that improves stability and resolves some ambiguous cases, not the sole carrier of the algorithm.

### 3.4 The policy is not a purely local reactive heuristic

Rejecting chronological search does not imply that the agent is myopic. Its push field converges toward minimum-push admissible directions precisely where greedy and admissible choices disagree. Across all 1,000 held-out boards, agreement with the admissible direction rose from 0.27 at (K0) to 0.84 at (K3), while agreement with the greedy direction fell from 0.32 to 0.13; the admissible-minus-greedy margin grew by 0.74 with a 95% interval of [0.67, 0.82] [10]. A complete single-box dead-square avoider also failed to explain the effect. On cells where that avoider was wrong by construction, the recurrent field agreed with full multi-box admissibility at 0.775 versus 0.200 for the shallow rule, with a gap-growth estimate of 0.477 [0.324, 0.630] [15].

Distant constraints matter as well. A real wall edit at least four cells from the player's local route produced a trained global-admissibility shift of 0.712 [0.511, 0.920] and moved the box field by 0.111 [0.045, 0.193], even though the local route stayed within a predeclared equivalence band [42,46]. Hallucinated distant deadlocks also suppressed the active local push more than orthogonal controls. The agent is reactive in time but global in the constraints it integrates.

## 4. The primary state variable: a maintained admissible push field

The most stable empirical object in the corpus is a spatially registered, box-indexed push-direction field. At each cell occupied by a box, a linear decoder can recover the direction in which that particular box will next be pushed. The field is approximately order-free, remains stable across pushes of other boxes, and is stronger in recurrent state than in whole-board convolutional baselines [2]. Low- and medium-dose interventions at the box's own location steer its eventual push direction while preserving solving, whereas the same content at an empty location does not. This establishes more than correlation: the representation is spatially addressed and participates in behavior.

The field should not be imagined as four independent arrows. Its direction at one box reflects global feasibility. At difficult diagnostic cells it distinguishes full multi-box admissibility from greedy motion and from a complete single-box deadlock avoider [10,15]. Removing a wall representation from the encoder at a deadlock trap shifts the recurrent field toward the naive deadlocking push by 0.465 [0.407, 0.521], larger than a remote-wall control [8]. Deleting a target produces a soft redistribution of the orphaned box's intent toward the remaining capacity, and directly imposing an inconsistent capacity state is rapidly corrected by recurrence [11,16].

The field is also continuously maintained. Most cells are already close to their final within-step direction at (K0), while the remaining ambiguous cells are refined over the recurrent snapshots [5]. When an incorrect direction is injected and released, both semantic and random perturbations are pulled back toward the board-consistent state with roughly 0.96–0.98 recovery by (K3). The equal recovery of semantic and random edits matters: it identifies a general attractor-like relaxation operator, not a special concept-specific repair circuit.

This maintained-field view resolves an apparent contradiction. The network contains rich information about distant future actions, but its causal core can still be immediate. A spatial solution field for the current board necessarily correlates with many later events. If a box is presently assigned a direction that avoids a corridor trap, that choice constrains where the player and boxes will appear several steps later. Linear probes can recover those consequences without the network storing them as ordered commands. The causal unit is the current constraint-consistent field, not the future labels that an external analyst can decode from it.

## 5. How the field is updated: local relaxation plus global communication

### 5.1 Four recurrent snapshots define a staged computation

The most defensible temporal decomposition uses four observed states rather than four entirely separate algorithmic modules.

- **K0: predictive initialization.** The recurrent state already contains most of the maintained push field and a predictive capacity cache. Strict spatial probes at action-conditioned candidate targets show that (K0) recurrent state predicts the next target-occupancy state better than the current raw board [28].
- **K1: local geometric response.** Physical or activation perturbations first produce a bounded response consistent with stacked (3	imes3) convolutions. Obstacles and local reachability begin reshaping the field.
- **K2: board-wide semantic integration.** A learned pooled mean/max pathway makes the perturbation visible beyond the local convolutional reach, allowing distant capacity and deadlock constraints to influence local intent [7,25].
- **K3: serialization or continued stabilization.** On ordinary converged states, late structural injections are poorly assimilated globally and (K3) behaves mainly as a readout boundary [25]. On rare tied or unstable states, however, the final transition remains active and can materially alter logits [30,37]. Thus “readout” is a regime, not an unconditional architectural fact.

This staging avoids two overstatements in the earlier literature. The first is that (K0) is blank; it is not. The second is that (K3) is always passive; it is passive only after the relaxation has approached a stable field.

### 5.2 The pooled pathway extends the information horizon

The strongest pathway-level experiment replaced the projected global mean/max input to every ConvLSTM layer with zeros while leaving the local gate computations unchanged. Native replay was exact before ablation. At the next diagnostic state, perturbation influence at Manhattan distance seven or more was nonzero in the intact network and exactly zero in the ablated network. Distances four to six retained some response because the stacked local convolutions can reach them. The same hard boundary appeared for matched random perturbations, demonstrating that the pooled path is a property of the recurrent transport operator rather than a dedicated carrier for one semantic vector [5].

The behavioral effect was dramatic: solve rate fell from 96.88% [94.53%, 98.83%] to 13.67% [9.77%, 17.97%], a paired difference of 83.20 percentage points [78.52, 87.89]. Mean episode length rose from 37.66 to 109.93 steps. The trained policy therefore depends on this board-wide coupling for competent planning.

Yet the pooled output should not be equated with a single explicit capacity multiplier. In a later same-state conflict replay, the pooled tensors recorded from the non-conflict baseline were spliced into a branch where one box's cell-state vector had been overwritten with another's. The field still recovered toward the valid alternative target: the final decoded margin was 0.97708 under normal pooled outputs and 0.97688 under the splice, with the difference interval touching zero. This falsifies the narrow hypothesis that the conflict-specific pooled output is the unique dual variable that performs capacity correction. The board-wide pathway is necessary at the operator level, while semantic capacity information is distributed across local states, hidden routing, recurrent gates, and pooled communication.

### 5.3 Geometry supplies boundary conditions, not a complete plan

The visual encoding acts as a physical boundary-condition map. Replacing a blocking wall's encoding with an open-floor encoding permits relaxation to leak into a deadlock trap and shifts the push field toward a greedy error [8]. Conversely, inserting real walls causes route and priority representations to change only after recurrent processing, with far stronger shifts at (K3) than at (K0) [47]. The encoder therefore supplies the immediate geometry, while the recurrent loop interprets its planning consequences.

This distinction is crucial. A raw board can reveal that a wall exists, but deciding which box becomes inadmissible or which target-capacity conflict follows from that wall requires integrating geometry with box identities, player access, destinations, and other boxes. The recurrent state is where those constraints become a plan.

## 6. What the solver represents

The DRC does not maintain a single undifferentiated “plan vector.” The evidence supports several partially separable variables with different spatial scopes and causal roles.

### 6.1 Multi-box admissibility and target capacity

The push field encodes more than static dead-square avoidance. On diagnostic states where a complete single-box avoider recommends a direction that fails only because of other boxes, the recurrent field moves toward the full solver's admissible direction [15]. The effect is durable across subsequent environment steps and specific to box identity. Distant structural edits and deadlock hallucinations alter local push decisions, demonstrating global interconnection [32].

Targets behave as capacity-limited resources. Deleting a target, hallucinating occupancy at a free target, or creating a destination overlap repels competing intentions and changes both policy and value [11,25,39]. The response is graded with intervention dose rather than a binary symbolic rejection, which is one reason “continuous constraint solver” is a better description than “rule engine.” The constraint itself is discrete—one box per target—but its internal enforcement is a continuous pressure on spatial intent.

### 6.2 Immediate next-box priority

The agent also represents which box should be completed next. On full held-out data, hidden-state decoding of next-box identity reached 0.838 versus 0.685 for a strong board model, an advantage of 0.154 [0.129, 0.178]. On non-greedy states, where geometry alone favors the wrong box, the advantage was 0.179 [0.121, 0.236] [31]. Later priorities become more decodable as earlier boxes are resolved, implying that the ranking is greedily recomputed rather than fixed at episode start.

Priority is distinct from the global value scalar: removing linear value, return, and remaining-step directions from the features did not reduce priority decoding. It is also causally used, although not as a dictatorial switch. On 80 geometry-matched boards with a native next box A and alternative box B, a low-dose (c3) priority intervention made B finish before A on 5 boards, compared with 0 under matched-random, shuffled-axis, and wrong-location controls. The paired effect was 0.0625 [0.0125, 0.125], while every branch retained a solve rate of 1.0 [41]. The small but specific effect is exactly what an additive integrator predicts: priority is one bias among several constraints, capable of tipping close decisions without overriding feasibility.

Physical encasement gives a larger but coarser causal result. When the probe-identified priority box was surrounded by walls, the (K3) priority representation shifted to another box on 36.8% of 250 matched states, versus 13.6% when a non-priority box was encased. The first pushed box changed on 44.8% versus 3.6%, although many priority-box encasements produced no push within the 30-step window. At (K0), the representational shift was only 0.4%, below the 1.6% sham shift, even though behavior after recurrent processing still changed. The priority consequence of the physical constraint is therefore computed during the inner loop, not simply read from the encoder [47].

### 6.3 Destination and selective object binding

The intended destination of a moved box is a native variable of the recurrent state [27]. More importantly, destination is not represented uniformly for all boxes. When two boxes were matched on geometry, remaining pushes, and distance to destination, the next box's destination was more accessible than the non-next box's destination by 0.135 [0.076, 0.190] in (h3) and 0.090 [0.028, 0.144] in (c3). A shuffled-priority control was null [36].

The pairing has functional content. A model given the joint interaction between next-box identity and its destination predicted immediate push direction better than a model given the two independent marginals. Relative to a marginal-preserving shuffled binding, the gain was 0.040 [0.018, 0.061] in (h3) and 0.049 [0.027, 0.071] in (c3). The recurrent state therefore contains a selectively bound **object-file**: roughly, “this is the box currently selected, and this is where it is going.”

Destination use is conditional rather than constant. Activation-vector steering at (c3) initially produced an uninterpretable null because it failed its own registration audit. A later intervention moved the actual target tile through the native input pipeline. On 48 solver-verified forced-choice boards, relocating the selected box's target across a geometric fork changed the first active-box push on 39 boards, a rate of 0.8125 [0.708, 0.917]. A distance-matched relocation within the original branch changed 0 of 48, and moving another box's target changed 0 of 48. The destination decoder registered all 48 edits, and the observed target-consistent rate exceeded a permutation null with (p=0.0004) [48]. Destination is thus read when it resolves a currently binding branch. In ordinary greedy states, priority and local geometry can already determine the move, so destination can remain present but behaviorally silent.

### 6.4 Player route as a separable local-scope variable

The route taken by the player to reach the next push is not merely a reflection of the box field. Against a deep whole-board model augmented with geometric features, a tiny linear recurrent probe retained a long-horizon route-occupancy advantage of 0.044 AUC [0.034, 0.051] at horizon eight [29]. The advantage concentrated on geometrically ambiguous states and vanished where the board forced a unique route. Metric time-to-arrival and future box occupancy did not show the same hidden advantage. The representation is therefore best understood as a choice among feasible navigation routes, not a generic future-occupancy map.

On equal-cost, fixed-subgoal states, route and box-subgoal axes had absolute cosine near 0.09. Steering the route changed realized navigation by 0.125 [0.05, 0.24] while preserving the intended push on 96% of cases and retaining a 0.925 solve rate, equal to baseline [34]. This is a causal double dissociation: the player can choose a different way to reach the same committed manipulation without rewriting the box plan.

Across recurrent computation, the route moves from an obstacle-blind or naive candidate toward an obstacle-admissible detour [40]. Its spatial scope, however, is much more local than the box field. A wall placed on the route changed route relaxation by 0.741 [0.556, 0.937]. A distant wall that strongly moved a global-admissibility decoder left route change at -0.049, within a predeclared \(\pm0.10\) equivalence band, while the box field moved +0.111 [0.045, 0.193]. The paired scope gap was +0.160 [0.091, 0.238] [42,46]. A later live-versus-sham experiment matched rollout length exactly and found that even a 180-fold difference in global-decoder movement produced a route contrast of only -0.0041 [-0.0137, 0.0061].

The simplest integrated reading is that the network applies a common relaxation motif to different variables at different scopes. Box manipulation integrates board-wide capacity and deadlock constraints. Player navigation integrates the local obstacles relevant to reaching the chosen push position. They interact through the selected subgoal and final action, but they are not the same field.

## 7. From fields to actions: the selective read gate

Representing a board-wide plan is not enough. Sokoban demands one discrete action at a time, so the network must serialize parallel spatial intentions. The evidence supports a read operator with three properties: it is player-centered under natural activity, selective for the native push manifold, and conditional on which variable is currently binding.

### 7.1 Global architectural support, local endogenous leverage

An early intervention found that adding a strong signed action direction to the final hidden state could control the action from the player's cell, a distant cell, or a random cell with similar success [6]. This result is real but easy to misinterpret. The policy head flattens the spatial (h3) map, so a large artificial direction anywhere can contribute to its logits. That establishes **global architectural support**, not uniform endogenous use.

Gradient and ablation analyses revealed the natural weighting. Policy-gradient density was highest at the player, about 0.820, and declined with distance to about 0.577 at distance five. Replacing activity within radius two of the player with a mean background produced KL divergence 0.846 and preserved the top action on only 55% of states; ablating remote cells outside the same radius produced KL 0.052 and 94% top-action retention [8]. The head can receive every cell, but ordinary action-relevant content is concentrated near the player and the next interaction locus.

Tick-resolved (c2\)-to-(h3) interventions made this transfer function causal. Push-direction content injected near the player propagated into the hidden action axis and policy logit, whereas identical content at distant cells produced essentially no transfer at the readout tick [14]. This resolves the apparent disagreement: the architecture is globally connected, but the recurrent system routes native content into a player-local aperture before action.

### 7.2 The gate selects content, not just location

A purely spatial aperture would read any signal near the player. It does not. In a factorial test, sustained box-push content at the future interaction cell produced an arrival-locked logit increase of 0.575 [0.246, 0.919] relative to a one-shot control, while equally local content placed on an arbitrary player-path cell produced -0.027 [-0.404, 0.333]. The box-minus-path interaction was 0.602 [0.138, 1.101] in logit and 0.117 [0.026, 0.213] in action probability [19].

The selector is best described as manifold-sensitive. Within the learned push-direction subspace, the gate is robust to magnitude: a wrong push direction at eight times its natural norm does not simply capture action, and correctly aligned content at natural norm can dominate it. Content orthogonal to the push manifold, however, becomes disruptive as its norm grows, despite sometimes creating a smaller total activation displacement [23]. Thus the gate is not a perfect semantic classifier, nor is it a raw-energy detector. It is a soft filter adapted to the directions normally produced by the solver and vulnerable to sufficiently unnatural activity outside that subspace.

The causal importance of admissible content was demonstrated by using decoder-aligned pairwise contrasts rather than crude class means. Injecting an admissible-over-greedy direction at the diagnostic box preserved solving, whereas the opposite direction degraded it. At twice the natural scale, the solve-rate separation was +0.309 [0.242, 0.375], replicated on a larger cohort at +0.297 [0.244, 0.353]. An empty-floor location control was null. One-shot transfer was stronger when the box was adjacent to the player than when far away, while sustained interventions lost that distance dependence because the player eventually walked to the box [20]. The push field is therefore genuinely load-bearing, but its content is consumed when it reaches the appropriate spatial and semantic aperture.

### 7.3 Different variables enter the gate in different regimes

The next-box priority result and the destination-fork result show that “causally used” is not a single global property. Priority exerts a modest bias during ordinary play: it occasionally changes which box is completed first without reducing solve rate. Destination exerts a very large effect in constructed forks, but matched same-branch edits are inert. Route controls navigation within a fixed box subgoal. Deep second and third priorities remain decodable yet causally nonspecific. These results suggest a **binding-constraint read rule**:

> A represented variable affects the immediate policy only when its value distinguishes among actions that remain feasible under the other currently active constraints.

At a simple corridor, destination is redundant because local geometry fixes the push. At a fork, destination becomes the branch-resolving variable and is read strongly. When two boxes are nearly tied, priority can tip selection. Once a box is selected, the route variable chooses how the player reaches its stand cell. Deep future priorities do not distinguish the current move and are attenuated before final readout.

### 7.4 Policy and value read the shared state differently

The policy and value heads do not interpret perturbations identically. Signed structural interventions show that the value head responds to global geometric consequences: both hallucinating a fatal deadlock and erasing a real boundary reduce value. The policy, by contrast, can be attracted to a large local structural feature even when value correctly judges the resulting board as poor [21]. This divergence is not evidence for two separate planners. It means the same recurrent state supports a global outcome estimate and a local action selector with different sensitivity profiles.

Under natural failures, this magnitude-capture pathology is rare. Detailed inspection of 24 apparent “field correct, action wrong” cases reclassified nine as local decoding errors, eleven as reachability or dead-square errors, and three as capacity or identity errors, leaving only one genuine readout-misfire candidate among 101 failed boards [24]. The gate can be broken by artificial off-manifold interventions, but the agent's ordinary competence boundary lies upstream in field formation.

## 8. Long-horizon planning without a symbolic queue

The spatial-solver account must explain genuine long-horizon behavior, not merely immediate correctness. Three mechanisms provide that explanation: receding-horizon recomputation, capacity-induced subgoals, and selective recurrent hysteresis.

### 8.1 Receding-horizon recomputation

After each action, the board changes. The network observes the new geometry, combines it with recurrent carry, and solves again. Because each solve incorporates multi-box admissibility, target capacity, immediate priority, destination, and route, a succession of locally serialized actions can remain globally coherent. This is analogous to model-predictive control in one limited sense: the system repeatedly recomputes a structured plan and executes only its first action. The analogy should not be pushed too far, because the DRC does not expose an explicit forward model or optimize a visible finite-horizon objective. The empirically justified point is the repeated re-solving and first-action execution.

This repeated computation explains why a transient route edit does not produce persistent commitment, why resetting recurrent state is usually recoverable, and why later priorities emerge as earlier boxes are completed. The future is not absent; it is compressed into constraints on the present field and regenerated after each transition.

### 8.2 Capacity collisions generate immediate subgoals

Suppose a box's intended destination path is occupied by another box. A chronological planner might create the explicit instruction “move the obstructing box first.” The DRC can produce the same behavior spatially. When a destination-intent vector was imposed on a cell occupied by another legal but initially disfavored box, the occupying box's push logit increased by 0.671 at moderate dose, compared with 0.236 for an orthogonal control; the semantic contrast was +0.435 [39]. The overlap creates continuous pressure at the obstacle's location, and the readout turns that pressure into a discrete “make room” subgoal.

The field can superpose several such constraints. Increasing independent collisions from one to three did not saturate the local subgoal signal; at a fixed dose the three-collision condition produced a +0.400 push-logit shift compared with +0.160 for one collision. Four simultaneous conflicts, the maximum box count in the environment, still preserved an absolute semantic signal, although the high-dimensional orthogonal control became severely off-manifold and could no longer support a clean relative claim [43]. The important result is not unlimited linear superposition. It is that the network can represent multiple geometric tensions without converting them into a symbolic list.

### 8.3 Spatial tension can cascade, but the evidence is bounded

A stricter test asked whether a forced intent on box A could increase the priority of a distinct box C that physically blocked A's only route. Across 50 selected states, an early semantic collision increased C's push logit relative to an orthogonal control by +0.316 at high dose, with a 95% interval [0.069, 0.582] and an exact sign-test (p=0.0066) [43]. Moving the same collision one recurrent stage later attenuated or reversed the secondary effect. This supports limited within-loop cascading: spatial tension requires time to propagate from one obstruction to another.

The scope must remain precise. The selected boxes were adjacent, so local convolutional smearing and topological propagation are not fully separable. At maximal multi-box interventions the orthogonal controls became destructive. The evidence establishes a causal semantic contribution to a second obstacle's priority, not an arbitrary-depth planning chain. The strongest formulation is that the continuous solver can generate at least one level of secondary spatial dependency under suitable geometry.

### 8.4 Recurrent memory is a hysteresis cache, not a search tape

Although full state resets are usually harmless, a small subset of bottleneck states fails without carry. On reset-failed states, action confidence drops sharply while the spatial box field remains comparatively coherent [12]. Extended recurrence on the unchanged board can partially resolve some ties, and layer-selective and signed-symmetry interventions suggest that shallow recurrent state provides a structural tilt that is integrated by later relaxation [26,30,33]. Recurrent memory therefore matters most where the current board admits nearly symmetric fields and a previous commitment prevents oscillation.

This is a classic role for hysteresis: retain just enough of the previous solution to select one branch of a near-degenerate current solution. The cache is distributed rather than localized to one cell-state tensor. Zeroing (c1), (c2), (c3), or even all three cell states preserved perfect recovery on one A*-hard cohort; the small early-phase failure returned only when hidden states were removed as well [18]. Hidden routing and cell-state semantics jointly support the stabilizing prior.

Observation changes are not simply overwritten. Cross-step analyses show structured assimilation: box identity, the location of a change, and semantic transition features predict how the admissible field resets and recovers beyond local-change baselines [17]. The recurrent state is therefore neither a static memory nor disposable noise. It is a warm start for the next constraint solve.

### 8.5 Deep-future representations are horizon context, not executable instructions

The later-priority results suggest a nuanced interpretation. Long-horizon training causes early recurrent layers to carry distributed correlates of second and third future boxes. These signals may summarize the basin of likely future solutions, help condition value, or simply arise because the current field constrains the future. As recurrence approaches the action-facing state, their clean decodability weakens. Direct manipulation either has no specific effect or behaves like generic perturbation [49].

It is tempting to say the network “actively suppresses a symbolic queue.” The current evidence does not identify a dedicated suppressor. What it establishes is an **effective horizon filter**: immediate priority survives as a localized, causally used variable; deeper priorities remain distributed and fail to gain specific behavioral control at the tested loci. Whether that attenuation is implemented by forget gates, destructive mixing, manifold mismatch, or simple lack of a downstream read path remains open.

## 9. Natural failure reveals the algorithm's limiting step

A mechanistic theory earns credibility by predicting not only success but failure. The continuous-solver account makes a clear prediction: if solving depends on forming a deep-admissible field and then reading it, failures should usually arise because the field never becomes sufficiently admissible, not because a correct field is routinely mistranslated into action.

Matched natural-failure studies support this. The failed-minus-solved difference in the (c2) admissible-over-shallow margin was near zero at (K0), -0.226 by (K2), and -0.299 by (K3), with the final interval excluding zero [24,35]. The deficit grows during the recurrent update. Field degradation predicts worse executed actions across threshold choices, and case-level inspection leaves approximately one ordinary readout error among 101 failures.

The next question is whether the late deficit is already predictable from a bad initialization. Low-capacity models trained on solved controls used topology, (K0) push margins, current-board geometry, and probe-derived capacity and destination variables to predict (K3) field quality. On the original matched cohort, the observed-minus-predicted residual remained -0.288 [-0.518, -0.072] even after adding the probe-derived priors. On a fresh cohort of 64 failures, a fixed all-source model predicted no negative gap, yet the residual was -0.521 [-0.858, -0.217] [35]. Source decomposition attributed most of the modest predictive improvement to the current board or encoder rather than to a recurrent destination cache.

The scientifically appropriate claim is stage localization, not circuit proof. Under the measured variables and model families, failed boards lie below the solved-board (K0\)-to-(K3) update relation. Their problem is best described as a **residual inner-loop relaxation shortfall**. An unmeasured (K0) variable or more powerful predictor could explain part of the residual, and no experiment has yet causally rescued natural failures by repairing a specific gate. Nonetheless, the failure data strongly favor computation under-formation over a general serialization defect.

This result also clarifies the meaning of “planning depth.” The DRC's limitation is not mainly that it lacks a longer explicit queue. It is that three recurrent updates sometimes fail to bring a difficult globally constrained field into the basin from which the read gate can extract the right action. More iterations, better initialization, or improved constraint communication could help even without adding symbolic search.

## 10. A formal phenomenological algorithm

The evidence can be summarized as an algorithm operating once per environment step. This formulation reconciles the successive macro-algorithmic, quantitative, object-file, and navigation syntheses in the corpus [22,37,38,44,45,46]. It is a representational and dynamical description, not a claim that each mathematical term corresponds to a single neuron or weight matrix.

Let (B_t) be the current board, (M_t) the carried recurrent memory, and (p_t) the player location. Let (E(B_t)) be the spatial visual encoding. Let (F_t^k(c,d)) denote a continuous score at cell (c) for pushing the box there in direction (d) at recurrent snapshot (k). Let (Q_t^k(b)) be immediate priority for box (b), (D_t^k(b,g)) its destination affinity for target (g), and (R_t^k(c)) the player's route field. These symbols name decoded variables; they need not occupy disjoint physical channels.

### 10.1 Initialization

The pre-update state combines carried memory with current geometry:

\[
S_t^0 = \mathrm{Init}\big(M_t, E(B_t)\big).
\]

(S_t^0) contains a mostly formed push field, predictive target-capacity information, and any hysteretic tilt preserved from the prior step. It is not a blank state and not a frozen previous plan.

### 10.2 Recurrent relaxation

For recurrent stages (k=0,1,2), the state is updated by a learned operator with local and global terms:

\[
S_t^{k+1}(c) = \Phi_{\mathrm{local}}\!\left(S_t^k, E(B_t); c\right)
 + \Phi_{\mathrm{global}}\!\left(\operatorname{mean}_c S_t^k,
 \operatorname{max}_c S_t^k, E(B_t); c\right),
\]

where the plus sign is phenomenological: the actual ConvLSTM gates combine these inputs nonlinearly. The local term respects spatial geometry and supports obstacle-admissible relaxation. The global term broadcasts board summaries that allow distant capacity, deadlock, and object interactions to affect local fields within the short recurrent horizon.

At the level of decoded content, the relaxation can be written schematically as

\[
F_t^{k+1}
 = \mathcal{A}\Big(
F_t^k;
	ext{walls},	ext{player reachability},	ext{deadlocks},
	ext{target capacity},	ext{box identity},	ext{destination},	ext{hysteresis}
\Big).
\]

The operator moves candidate directions away from greedy deadlocks and toward full multi-box admissibility. Capacity conflicts create repulsive pressure. If a destination path is occupied, pressure at the obstructing box raises its immediate priority. In ambiguous navigation regions, a separate route field relaxes from naive geometry toward an obstacle-admissible local path.

### 10.3 Selective binding and variable scope

During relaxation, the currently selected box and its intended destination become preferentially bound:

\[
O_t = \big(b_t^\*, g_t^\*\big), \qquad
b_t^\* = \arg\max_b Q_t^3(b).
\]

The object-file (O_t) does not absorb every planning variable. Global value remains separable, and the player route (R_t) is approximately orthogonal to the box-subgoal axis. The box field has global computational scope; the route has primarily local, variable-bound scope.

### 10.4 Binding-constraint readout

The action-facing representation is a selective projection of the final state. A useful phenomenological form is

\[
z_t = \sum_c w\big(\|c-p_t\|\big)
\left[
\Pi_{\mathcal{M}} S_t^3(c)
+ \epsilon\big(\|S_t^3(c)\|\big)
(I-\Pi_{\mathcal{M}})S_t^3(c)
\right],
\]

where (w) is a player-centered spatial weighting, (Pi_{\mathcal{M}}) projects onto the learned action-relevant manifold, and (epsilon) captures the gate's vulnerability to very large off-manifold activity [44]. The exact policy head is globally connected, so (w) is not literally zero at distant cells. It represents the endogenous transfer observed under ordinary content.

Which semantic variables contribute to (z_t) depends on the regime. Priority matters when boxes are close competitors. Destination matters when a fork makes target identity determine the correct push. Route matters when multiple player paths reach the same subgoal. Deep priorities normally do not resolve the current action and therefore fail to reach specific causal control.

The action is then discrete:

\[
a_t = \arg\max_a \; \mathrm{PolicyHead}(z_t, E(B_t)).
\]

The environment transitions to (B_{t+1}), the recurrent state becomes (M_{t+1}), and the entire process repeats.

### 10.5 Algorithm in words

An external researcher can implement the conceptual algorithm as follows:

1. Encode walls, floor, player, boxes, and targets as spatial boundary conditions.
2. Warm-start a box-indexed push field from recurrent memory and predicted near-future capacity.
3. Relax locally around obstacles and player-access constraints.
4. Broadcast pooled board information so distant deadlocks, target competition, and other box constraints reshape local intentions.
5. Prefer push directions that remain admissible under full multi-box geometry rather than greedy or single-box rules.
6. Rank the immediately relevant box; bind that box to its likely destination.
7. If the destination path is occupied, convert the resulting spatial pressure into a “move the obstacle” priority; allow limited secondary propagation when geometry supports it.
8. Independently relax a local player route to the selected push-access cell.
9. Through a player-centered, manifold-selective gate, read the variable that currently distinguishes the feasible actions.
10. Execute one action, retain a stabilizing memory of the solution, and solve again from the new board.

This is the current best-supported emergent planning algorithm.

## 11. What is actually discrete?

The original task asks for a discrete emergent planning algorithm. The evidence requires a qualified answer. The network's **problem** is discrete: cells are walls or floor; boxes occupy specific coordinates; targets have unit capacity; pushes are legal or illegal; one box is selected before another; and the final policy takes an argmax over discrete actions. Several internal variables are also naturally interpreted in discrete terms, including box identity, immediate priority, destination branch, and push direction.

The **computation connecting those variables**, however, is not well described as discrete symbolic manipulation. Constraint effects vary continuously with dose. Multiple intentions superpose. Symmetry is broken by graded spatial tilts. Fields can be under-formed rather than simply true or false. The read gate is selective but soft, and large off-manifold activity can capture it. Even capacity, a discrete one-box-per-target rule, appears as a continuous repulsive influence on intent.

The most faithful phrase is therefore **continuous relaxation with discrete semantics and serialization**. Calling the entire algorithm discrete would obscure its central mechanism. Calling it purely continuous would ignore the object identities, capacities, branches, and action choices that organize the relaxation. The emergent algorithm is hybrid: continuous dynamics solve a discrete constraint problem one action at a time.

## 12. Confidence map of the scientific claims

| Claim | Best evidence | Status |
|---|---|---|
| A box-indexed push-direction field is a principal planning representation | Strong-board probing, cross-rank transfer, box-specific steering | Established |
| The field encodes multi-box admissibility beyond greedy and single-box deadlock rules | Tickwise convergence, full-solver diagnostics, physical wall edits | Established |
| The recurrent update combines local spatial propagation with board-wide pooled communication | Distance-resolved perturbations and pathway ablation | Established at operator level |
| The pooled path is the unique capacity variable | Conflict-state pooled-output splice | Falsified in this narrow form |
| Cross-step memory is generally required for planning | Full-state resets on long and solver-hard boards | Falsified as a general claim |
| Cross-step memory stabilizes rare ambiguous states | Reset-failure cohorts and tie-breaking studies | Well supported |
| Immediate next-box priority is represented and causally used | Strong baseline plus controlled completion-order steering | Established but modest in effect |
| Priority and destination form a bound object-file | Geometry-matched decoding and shuffled-binding controls | Established for the tested cohort |
| Destination affects action | Solver-verified target relocation across forks | Established conditionally |
| Player route is distinct from the box subgoal | Equal-cost route decoding, near-orthogonal axes, selective steering | Established |
| Route computation is locally scoped while box constraints are global | Matched physical edits and equivalence tests | Established for tested proxies |
| The final read is player-centered and manifold-selective | Spatial transfer, ablation, content controls, solve endpoints | Established phenomenologically |
| The agent executes a deep symbolic queue | Later-priority probing and causal steering | Not supported |
| Spatial capacity conflicts can generate sequential subgoals | Collision interventions with controls | Established for one-step subgoals |
| Capacity tension supports arbitrary-depth sequence planning | Adjacent two-box cascade only; controls degrade at high dimension | Open |
| Natural failures are primarily readout mistakes | Failure decomposition | Strongly disfavored |
| Natural failures reflect an inner-loop relaxation shortfall | Matched cohorts and fresh residual validation | Well supported observationally |

## 13. Limitations and unresolved questions

The synthesis is comprehensive for the available corpus but not universal. All results concern one trained checkpoint and closely related (8	imes8) Sokoban distributions. The discovered algorithm may depend on architecture, training regime, board size, or the four-box limit. A network trained with more recurrent updates or a transformer-style global operator might internalize a different strategy.

Linear probes remain imperfect instruments. Above-baseline decoding establishes accessible information, not a unique representation. A null can reflect nonlinear coding, poor labels, insufficient data, or a wrong locus. The evidence is strongest where probing is paired with manipulation audits and behavior. The later-priority story, for example, should remain conservative: pooled p2 and p3 signals are real but modest, and the causal vector is a coarse approximation to whatever distributed nonlinear state the network actually carries.

Activation addition can leave the natural manifold. Several apparent positive results weakened or disappeared against equal-norm random controls, and large orthogonal perturbations sometimes caused more disruption than semantic ones. Faithful board edits are generally cleaner because they preserve the native sensory pipeline, but they have their own limitations: an encased box is a severe counterfactual; moving a target changes several geometric relations at once; and arbitrary stored boards cannot always be restored in the original environment, requiring a validated local transition emulator.

The read-gate equation is phenomenological. It compactly summarizes locality, manifold selectivity, global architectural support, and magnitude capture, but it is not derived from the weights. Likewise, the local-plus-global relaxation equation does not identify specific ConvLSTM gates or channels. Component-level work remains incomplete. In particular, no study has mapped every layer, recurrent snapshot, hidden and cell state, pooled mean and max component, and gate preactivation on a common capacity endpoint.

The role of the pooled pathway needs refinement. Permanent ablation proves necessity for the trained network and cleanly removes the response beyond local structural reach, but it also sends recurrence off distribution and cannot apportion function among the three layers. The conflict-state splice falsifies one simple uniqueness theory but does not show that pooled communication is semantically unimportant. Acute layer-specific mean-versus-max interventions would provide a sharper causal map.

The object-file account is also incomplete. Priority and destination are selectively bound and jointly predictive of the next push. Priority is causally used in ordinary play; destination is causally used at controlled forks. It remains unknown how often destination is action-binding during natural gameplay because the natural target-relocation cohort had poor decoder registration. It is also unknown whether other attributes—risk, capacity slack, required player side, or expected downstream congestion—join the same object-file.

The route representation is clearly separable and locally scoped under the tested edits, but sequence coherence is unresolved. Independent horizon decoders often yield discontinuous coordinates after a wall edit, which may reflect a genuinely field-like code or simply the weakness of decoding each horizon independently. A sequence-aware decoder or constrained top-(k) reconstruction could distinguish these possibilities without reverting to the unsupported claim of a stored action list.

The deepest open problem is causal rescue of natural failure. Observational residual analysis localizes the deficit to the recurrent update under measured variables, but no intervention has yet taken a naturally failed state, selectively repaired the under-formed admissible field within the native manifold, and restored solving without broad disturbance. Such an experiment would close the loop from representation to failure mechanism more decisively than another decoding study.

Finally, the relationship between continuous relaxation and classical planning deserves careful theoretical work. The DRC is not A*, breadth-first search, or literal value iteration. Yet its learned dynamics implement functions familiar from optimization: warm starts, constraint propagation, repulsive penalties, tie-breaking, coordinate-addressed state, and receding-horizon control. Formalizing which family of continuous algorithms can approximate Sokoban's discrete feasibility structure may be more illuminating than searching for a hidden symbolic program that the evidence repeatedly fails to find.

## 14. Conclusion

The trained DRC agent solves Sokoban through a hybrid algorithm whose internal dynamics are principally spatial and continuous, while its semantics and outputs are discrete. The board encoder establishes physical boundary conditions. Recurrent state supplies a warm start, predictive capacity information, and occasional hysteresis. Local convolutions propagate obstacle-sensitive corrections; pooled board-wide communication makes distant constraints available within a short recurrent horizon. Together they maintain and refine a box-indexed field that favors full multi-box admissibility over greedy or single-box rules.

Within that field, the network selects an immediate box, binds it to a destination, and separately computes a local player route. The selected variables do not all control behavior at all times. A player-centered, manifold-selective read gate admits priority when boxes compete, destination when a geometric fork makes the target binding, and route when navigation is ambiguous. It filters or ignores deep future representations that do not resolve the current action. The output is one discrete move; after the move, the agent solves again.

This account directly answers the central research question. The agent's emergent planner is not a chronological search tree, a latched program, or a clean subgoal queue. It is a **receding-horizon continuous spatial constraint solver with selective object binding, local navigation, global box constraints, and discrete serialization**. Long-horizon competence arises because current fields already encode the consequences of reachability, deadlocks, capacity, and destination structure, and because those fields are recomputed after every action. Memory stabilizes the process but rarely substitutes for it. Natural failures occur when the relaxation does not finish forming an adequate field, not when a correct plan is usually read incorrectly.

The broader interpretability lesson is equally important. Future information is not the same as a future program. A recurrent policy can make distant events linearly predictable because its present constraint solution shapes those events. Discovering the algorithm therefore requires more than reading activations: it requires identifying representational format, testing causal use, mapping spatial and temporal scope, and learning which variables the network admits to action in each regime. When those standards are applied, the apparent symbolic complexity of this agent resolves into a coherent learned dynamics—continuous in computation, discrete in consequence.

## Evidence provenance

The paper-local citations below refer to full archived papers in the supplied corpus. They are listed by scientific title rather than by repository identifiers.

1. *A Continuously-Maintained Spatial Route-Plan Underlies DRC Sokoban Planning.*
2. *The DRC's Plan Is a Box-Indexed Push-Direction Field, Not a Temporal Action Queue.*
3. *The Unordered Spatial Intent: Dynamics of Trajectory Refinement in DRC.*
4. *The Illusion of Sequence: DRC Planning as Spatial Value Diffusion and Reactive Intent Generation.*
5. *The DRC's Inner Loop Maintains a Push-Direction Plan and Refines It Near the Agent, Not a Goal-Seeded Value Iteration.*
6. *Decoded but Not Read: The DRC's Immediate Action Is Controlled by a Global Hidden-State Direction, Not by Its Decodable Cell-State Route Plan.*
7. *The Mechanics of Board-Anchored Value Diffusion: Hybrid Local-Global Updates and Reactive Recomputation.*
8. *The Mechanics of Serialization and Reachability in the DRC's Continuous Spatial Solver.*
9. *The DRC Is Predominantly a Reactive 4-Tick Solver: Falsifying the Necessity of Extended Pondering.*
10. *The DRC's Inner Loop Computes an Admissible, Deadlock-Avoiding Push-Plan (Not a Greedy One), While the Content Is Only Weakly Behaviorally Load-Bearing.*
11. *The Bijection Constraint: Target Capacity in the DRC's Continuous Spatial Solver.*
12. *The Hysteresis Cache: Recurrent Memory Breaks Symmetries in Memoryless Value Diffusion.*
13. *The Limit of Memory: Zeroing Recurrent State on A*-Hard Cohorts Proves Extended Pondering Is Algorithmically Unnecessary.*
14. *The Read Gate: The DRC Reads Its Global Push-Field into Action Through a Player-Local, Near-Readout Spatial Gate.*
15. *The DRC's Push-Plan Exceeds a Complete Single-Box Deadlock-Avoider.*
16. *Active Capacity Re-equilibration: The Error-Correcting Mechanics of the DRC's Hysteresis Cache.*
17. *Structured Observation-Boundary Assimilation of the DRC's Recurrent Push-Plan Field.*
18. *The Breaking Point of the Hysteresis Cache: Cell-State Zeroing Yields Perfect Recovery on A*-Hard Cohorts.*
19. *The Read Gate Is Content-Selective: The DRC Reads Box-Push-Relevant Content Locally, Not Arbitrary Local Content.*
20. *Admissible Push-Content Is Causally Load-Bearing and Read Through a Player-Local, Content-Selective Aperture.*
21. *Signed Causal Interventions Reveal Value/Policy Divergence in the DRC's Continuous Spatial Solver.*
22. *The DRC Sokoban Planner: A Continuous Spatial Relaxation Solver.*
23. *The Read Gate Is a Manifold-Selective Filter.*
24. *DRC Sokoban Failures Are Compute-Dominated Deep-Admissible Field Under-Formation, Not Readout Misfire.*
25. *Completing the Continuous Spatial Solver: Capacity Repulsion and the Temporal Boundary of the Global Broadcast.*
26. *The Environmental Boundary of the Hysteresis Cache: Serialization Collapse on A*-Hard States.*
27. *Tracking the Destination Manifold: Moved-Box Destinations as a Native Variable of the Continuous Spatial Solver.*
28. *Predictive Capacity Caching: The K0 Initialization of the Continuous Spatial Solver.*
29. *Where Geometry Runs Out: The DRC's Long-Horizon Route Signal Is a Choice Representation Localized to Geometrically Ambiguous States.*
30. *The Causal Dynamics of Serialization: Passive Readouts and Tie-Breaking.*
31. *An Immediate, Greedily Recomputed Next-Box Priority in the DRC.*
32. *Point-Aligned but Globally Interconnected: The Structural Evaluation of Distant Constraints in the Continuous Spatial Solver.*
33. *Symmetry Resolution via Causal Interventions.*
34. *Two Orthogonal Choices: The DRC's Player-Route Signal Is Separable from the Box-Push Subgoal.*
35. *Residual Inner-Loop Relaxation Shortfall in Natural Failure Field Formation.*
36. *A Bound Object-File for the Next Box.*
37. *The Architecture of Intent: A Meta-Analytical Integration of the DRC's Continuous Spatial Solver.*
38. *The Quantitative Architecture of the Continuous Spatial Solver.*
39. *Generating Sequential Subgoals from Continuous Capacity Collisions.*
40. *The DRC Computes Its Player Route by an Inner-Loop Obstacle-Admissible Detour Relaxation.*
41. *Priority Is Used, Not Just Decoded.*
42. *Locally Reactive, Globally Decoupled: The DRC's Player-Route Relaxation Is Computed from Local Admissibility, Not the Distant Global Field.*
43. *Deep Sequence Planning via Cascading Spatial Subgoals in a Continuous Solver.*
44. *The Read Gate and the Object-File: A Quantitative Synthesis of What the DRC Encodes versus What It Uses.*
45. *The Macro-Algorithmic Translation of the DRC.*
46. *A Navigation Primitive Beside the Box Solver.*
47. *Physical Counterfactuals Expose the Continuous Spatial Solver.*
48. *Branch-Conditional Causal Use of the Object-File Destination.*
49. *The Illusion of the Queue: Deep Sequence Representation Is Decodable but Causally Filtered by the Continuous Spatial Solver.*

Selected numerical checks were additionally traced to the underlying local experiment reports for pooled-path ablation, hard-cohort recurrent reset, admissible-versus-greedy steering, natural-failure decomposition and replication, next-box priority steering, capacity-collision cascades, matched route-versus-box scope edits, physical route and priority counterfactuals, the pooled-output splice, solver-verified destination relocation, and early-versus-late deep-priority intervention. These checks were used to preserve control qualifications and to avoid inheriting stronger claims than the reported interventions support.
