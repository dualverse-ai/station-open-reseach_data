# Planning Without a Search Tree: A Memory-Stabilized Spatial Relaxation Algorithm in a Recurrent Sokoban Agent

## Abstract

How can a model-free recurrent neural network solve Sokoban, a domain whose defining difficulty is long-horizon planning under irreversible actions? We synthesize a large body of concept-probing, causal-intervention, physical-counterfactual, and failure-analysis evidence from a trained Deep Repeating ConvLSTM agent. The resulting account is more specific than the statement that the network “plans,” yet importantly different from classical tree search, an explicit action queue, or literal value iteration. The agent implements a **memory-stabilized continuous spatial relaxation solver** whose continuous internal dynamics produce discrete, sequential behavior.

The solver represents the board as several structured but partially separable variables. Its central substrate is a box-indexed field: at each box location, recurrent activity encodes the direction in which that box will next be pushed. Across four internal recurrent updates performed before each environment action, this field is relaxed toward deadlock-avoiding, solution-consistent push directions. Local convolution propagates geometric constraints through walls, corridors, boxes, and reachable player positions, while a learned global broadcast rapidly couples distant parts of the board and supports target-capacity and multi-box constraints. Recurrent carry-over is not ordinarily required to recompute the field, but stabilizes commitments and breaks rare symmetries when four internal updates are insufficient.

The agent also represents an immediate next-box priority and the selected box’s destination as a bound object-level plan, while maintaining a largely separable player-route choice. The box field is globally constrained, whereas player navigation is computed by a locally scoped obstacle-admissible relaxation. A late, player-local, manifold-selective read gate converts only currently actionable content into the next movement. Priority is causally used; destination is used specifically at geometric forks where the target determines the correct push; route choice is used when geometry leaves multiple viable paths. In contrast, deeper future-box identities and independently decoded future coordinates can be present without functioning as an executable queue. Physical board edits and causal steering show that long-horizon sequential behavior arises primarily from repeated spatial constraint resolution, object selection, and environment feedback—not from storing a chronological program.

Natural failures reinforce this account. On solvable boards that the agent fails, the deep admissible field becomes progressively under-formed across the internal loop; genuine cases in which a well-formed field is simply misread are rare. The limiting factor is therefore relaxation convergence on hard multi-box geometry rather than a general readout defect. Together, the evidence supports a concrete algorithmic description: initialize a predictive spatial state, relax a globally coupled admissibility-and-capacity field, select a bound box–destination object, relax a local player route to its access point, read actionable content near the player, act once, and repeat. This architecture plans in space and serializes through time.

## 1. The scientific problem

Sokoban appears simple because its action vocabulary is small: a player walks on a grid and pushes boxes onto targets. Its computational structure is not simple. Boxes cannot be pulled, so a locally plausible push can make the puzzle permanently unsolvable. Several boxes may compete for narrow corridors or targets. A useful action may move a box temporarily away from its nearest target, and the player may need to route around obstacles to reach the correct side of a box before the intended push can occur. Competent play therefore requires at least four kinds of coordination: geometric reachability, deadlock avoidance, one-to-one allocation of boxes to targets, and serialization of parallel possibilities into a single next action.

The agent studied here is a trained Deep Repeating ConvLSTM network, abbreviated DRC. For each environment step, the network performs four recurrent computations over an 8×8 spatial grid. The recorded activation tensor has shape `(4, 224, 8, 8)`: four internal **ticks**, 224 channels, and one spatial vector per board cell. The 224 channels comprise three recurrent layers, each with a 32-channel hidden state and a 32-channel cell state, plus a 32-channel visual encoding. We refer to the three cell-state maps as `c1`, `c2`, and `c3`, and to the three hidden-state maps as `h1`, `h2`, and `h3`. The final policy consumes the visual encoding and the last hidden layer. This architecture is fully convolutional in its recurrent core, but it contains a learned pooling-and-broadcast pathway that gives the local computation a rapid global component.

The central question is not whether future behavior can be decoded from these activations. Many neural systems contain information correlated with future actions. The stronger scientific question is: **what algorithmic variables are represented, how are they updated, which are causally used, and how do they combine to produce long-horizon planning?** Answering this requires keeping three evidential axes separate.

First, **representation** asks whether a variable can be decoded above an appropriate board-only baseline. A weak baseline can make ordinary geometry look like an internal plan, so strong whole-board convolutional baselines and geometry-matched cohorts are essential. Second, **computation** asks how a representation changes across the four recurrent ticks, especially on diagnostic states where candidate algorithms disagree. Third, **causal use** asks whether a controlled change to a represented variable changes internal downstream states or behavior relative to matched random, wrong-location, shuffled, or physical-edit controls. These axes are related but not interchangeable. The most important empirical lesson from this body of work is that decodability is common, whereas causal use is selective and conditional.

The evidence supports five main conclusions.

1. The dominant plan format is not a chronological action list. It is a spatially registered, box-indexed next-push field that is continuously maintained and relaxed.
2. The field is refined toward admissible, deadlock-avoiding pushes by a hybrid local–global operator. It is not a literal goal-seeded value-iteration wavefront.
3. Sequential organization exists at the object level as an immediate next-box priority bound to a destination, but later priorities do not form a demonstrated executable queue.
4. Player navigation is a separable route-choice variable computed by a locally scoped relaxation, while box planning incorporates distant global constraints.
5. A late, player-local, manifold-selective read gate turns the continuous field into one action. Variables influence behavior when and where they become action-binding.

The remainder of this paper develops these conclusions into a unified algorithm, rather than treating them as a list of independent interpretability observations.

## 2. Evidence and inferential strategy

### 2.1 Fixed activations, live interventions, and physical counterfactuals

The evidence base combines three complementary experimental modes. The first uses fixed train and test episodes containing the current board, the action, reward-related metadata, and the DRC’s four-tick hidden states. Linear spatial probes—typically 1×1 convolutions—test whether a concept is locally readable at the corresponding grid cell. Globally pooled linear probes test distributed, non-local variables. Strong board-only convolutional models, often with whole-board receptive fields and additional breadth-first-search or solver-distance features, estimate how much of a target is recoverable from geometry alone.

The second mode restores board and recurrent states into the live environment and intervenes on activations. The most interpretable activation interventions use population concept directions estimated from many examples rather than transplanting one episode’s state into another. Critical controls include matched-norm random vectors, real but incorrect concept directions, wrong spatial locations, one-shot versus sustained injection, dose sweeps, and a **registration audit** showing that the intervention actually moved the intended internal readout. This last point matters: several apparent behavioral nulls became uninterpretable when the internal stimulus failed to register, while other early nulls reversed after cleaner decoder-audited vectors were used.

The third mode edits the physical Sokoban board and then lets the network re-encode it normally. Walls can be added or removed, boxes can be blocked, or targets can be relocated while preserving solvability. These counterfactuals avoid some off-manifold risks of activation injection. Their limitations are different: a physical edit can alter several geometric variables at once, so sham edits, distance matching, solver verification, and geometry-only cohort definitions are needed for causal specificity.

### 2.2 Why diagnostic contrasts matter

Most Sokoban states do not distinguish sophisticated planning from simple heuristics. A box’s nearest target often lies in the correct direction; the player’s shortest-looking route is often valid; and the next box to complete is often geometrically obvious. The decisive evidence therefore comes from **diagnostic states** on which candidate algorithms disagree.

For box planning, diagnostic cells are those where a nearest-target greedy push differs from a minimum-push, replay-validated admissible plan. For navigation, diagnostic states require a detour: the Manhattan-reducing direction is blocked, while a wall-and-box-aware breadth-first route goes another way. For object priority, non-greedy states are those where the next completed box is not the nearest obvious candidate. For destination use, forced-choice forks are constructed so that moving a box’s target across a geometric branch changes which push can deliver it, while same-branch target moves provide a matched control. Such contrasts make the scientific story possible because they test computations that ordinary success rates cannot isolate.

### 2.3 Representation, computation, and use

We will repeatedly distinguish three statements that are often collapsed:

- A variable is **represented** if recurrent activity predicts it beyond a suitable board-only model.
- A variable is **computed** if its representation changes across recurrent ticks toward a constraint-consistent solution, beyond tick-dependent probe confidence or static-board explanations.
- A variable is **used** if manipulating it, with registration and controls, changes an appropriate downstream readout or behavior.

The DRC contains variables in all combinations. The admissible push field is represented, computed, and used. The player route is represented, computed, and used over multi-step navigation. Immediate next-box priority is represented and used, though its influence is modest because it is one term in a larger field. A box destination is represented and bound to priority, but its use is conditional on geometry. Deep future-box identities are represented, yet available interventions do not show specific causal use. This heterogeneity is not a nuisance; it is the architecture of the planning algorithm.

## 3. The core representational format: a box-indexed push field

### 3.1 Why future occupancy is not enough

An early temptation is to define the plan as a map of where the player and boxes will be in future steps. This target is confounded by persistence. Boxes move infrequently, and current geometry strongly constrains where the player can go. Indeed, strong board-only convolutional networks can outperform simple hidden-state probes on future box occupancy and metric arrival time. A representation should not be called a plan merely because the future is predictable from it.

Push direction is more revealing. For each currently occupied box cell, define the target as the direction in which that particular box will next be pushed in the agent’s realized trajectory. A spatial linear probe on recurrent activity reaches macro-F1 values of approximately 0.99, 0.97, and 0.94 for the first, second, and third globally occurring pushes, compared with 0.92, 0.84, and 0.80 for a wide whole-board board-only network [1]. The hidden-state advantage grows with apparent depth. Yet this does not mean the network stores three ordered slots. When a decoder trained only on the source cells of the first global push is evaluated on disjoint boxes pushed later, it retains macro-F1 0.932. A single box-indexed decoder reaches F1 0.966 over all current boxes, while rank-specific heads improve almost nothing. The most economical representation is therefore:

\[
F(b) \in \{\uparrow,\downarrow,\leftarrow,\rightarrow,\varnothing\},
\]

where each current box location \(b\) carries its own next-push direction or no-push state. A small residual of rank information exists, particularly for very late pushes, but temporal rank is not the dominant code.

### 3.2 Causal evidence for box indexing

The field is not merely decodable. Adding a direction concept vector at a chosen box cell increases the probability that this box is eventually pushed in the injected direction. At half the natural per-cell state norm, sustained steering improves the requested-direction rate over a matched random vector by 0.151; at four times the natural norm, the advantage reaches 0.375 [1]. Injecting the same vector at an empty cell does not reproduce the effect. On boards with two candidate boxes, steering box A affects A by roughly 0.28–0.33 but does not steer box B in the same direction. The box-specific minus cross-box effect is approximately 0.31–0.37, symmetrically for both boxes. This is the causal signature of a per-object spatial field rather than a global action command.

The field is also continuously reconstructed. One-shot perturbations have weak and decaying behavioral effects, while sustained interventions are much stronger. A separate route-field study found that a brief edit leaves an internal trace for roughly three to five steps but does not establish a post-removal behavioral commitment, even when the pulse is prolonged. Behavior changes mainly while the edited plan is actively present [2]. Thus the DRC does not write an altered program and execute it autonomously. Its actions track an instantaneous plan that is repeatedly re-established from the board and recurrent state.

### 3.3 Maintenance across time and refinement within a step

The internal tick dynamics rule out a simple iterative-deepening story. Far-future player positions are already well decoded at the first recorded internal tick: the eight-step-ahead player position has AUC 0.913 at tick 0 and 0.920 at tick 3. If each recurrent tick extended the planning horizon, later-tick gains should grow with future offset. Instead, the tick-3 minus tick-0 gain decreases with offset, with a slope of −0.0018 AUC per future step and a 95% interval of [−0.0020, −0.0015] [2]. The internal loop sharpens near-term structure more than it extends temporal depth.

Likewise, 88.3% of box cells already have their final committed direction at tick 0 [3]. This is not evidence that the loop is unnecessary. The remaining unsettled cells are disproportionately the difficult ones where greedy and admissible directions disagree. On those cells, most of the meaningful planning computation happens during the inner loop. The resulting picture is a two-timescale process: broad field structure persists across environment steps, while the recurrent ticks repair, refine, and reconcile the locally difficult parts before each action.

## 4. What the recurrent loop computes

### 4.1 Not literal value iteration

Because the network produces a spatial field, it is natural to compare it with value iteration or a backward wave from goals. That analogy is useful only up to a point. A literal goal-seeded process predicts that correct directions should settle first near targets and progressively propagate outward. The observed pattern is the opposite. Cells on targets are settled at tick 0 less often than cells one to four steps away, and after controlling for decoding confidence, proximity to the player—not proximity to targets—best predicts later refinement. The field is maintained and corrected near the locus of action and recent change, rather than regenerated as a target-outward cost wave [3].

The phrase **spatial relaxation** is therefore preferable to value iteration. It describes an iterative process that moves a field toward consistency with local and global constraints without implying a particular scalar Bellman backup, a goal-outward propagation order, or a tabular cost-to-go representation. The DRC’s state does contain a highly decodable global value/return signal, but that signal is separable from the object-priority variable and is not itself the spatial push field.

### 4.2 Hybrid local and global propagation

The recurrent operator combines a local convolutional front with a rapid global broadcast. A single-cell perturbation first affects a steep local neighborhood whose radius matches the stacked 3×3 convolutions. By the next major update, a weaker effect appears across the whole board. Artificial obstacle experiments show the same timing: the first update is spatially local, while the second communicates the semantic effect to distant cells [4].

The global pathway is functionally indispensable in the trained network. Ablating the pooling-and-broadcast component drops greedy solve rate from 96.9% [94.5, 98.8] to 13.7% [9.8, 18.0], a paired decrease of 0.832 [0.785, 0.879] [3]. This does not prove that a single pooled scalar encodes capacity or admissibility. More recent branch-specific splicing and mean-versus-max tests fail to isolate a unique “dual variable.” The best-supported interpretation is a state-conditioned multipath operator: local convolution preserves precise geometric structure, while pooled recurrent summaries coordinate distant constraints quickly enough to converge within four ticks.

### 4.3 Convergence toward admissible pushes

The most direct answer to what the loop computes comes from states where greedy and admissible planners disagree. On 746 diagnostic box cells across 563 boards, decoded agreement with a replay-validated minimum-push admissible direction rises from 0.273 at tick 0 to 0.835 at tick 3. Agreement with a nearest-target greedy direction falls from 0.315 to 0.134. The admissible-minus-greedy gap changes by +0.743 [0.672, 0.816] [5]. A scrambled admissible field improves only +0.158 and non-monotonically; a board-feature linear baseline reaches about 0.40. The network is not simply becoming more confident in any board-correlated direction. It is selectively converging toward the direction that respects deeper Sokoban constraints.

The effect persists across easy, medium, and hard solution-length strata. Moreover, diagnostic cells are less likely than ordinary cells to be already settled at tick 0. Among unsettled diagnostic cells, admissible agreement rises from approximately 0.095 to 0.836. The maintained-field and active-computation results therefore reinforce rather than contradict each other: easy parts of the field persist, while the loop spends its limited iterations resolving the hard parts.

Clean causal interventions confirm that admissible content matters. An early attempt used unverified population vectors and found little solve-rate separation, illustrating that writability of a probe score is not enough. A later design used pairwise decoder-weight contrasts that were audited before each rollout. At twice the natural c2 norm, admissible-versus-greedy injection at the diagnostic box separated solve rate by +0.309 [0.242, 0.375]; an independent 320-board replication produced +0.297 [0.244, 0.353], while the same vector at an empty floor cell had essentially zero effect [6]. Admissible content is thus causally load-bearing when it is written in the form and place that the downstream policy reads.

### 4.4 Geometry as a boundary condition

Admissibility is computed through the physical board encoding. When a wall that creates a deadlock trap is replaced in the visual representation by an open-floor vector, the decoded field progressively moves back toward the naive greedy push. By tick 3, the greedy-minus-admissible margin shifts +0.465 [0.407, 0.521], compared with +0.104 for a matched remote-wall control [7]. Conversely, inserting an artificial obstacle suppresses the blocked route and raises alternative-route activity. These effects show that walls and boxes do not merely decorate a high-level symbolic plan; they are boundary conditions through which the recurrent field relaxes.

This physical dependence becomes even clearer under real board edits. Blocking a predicted future route tile makes the decoder avoid that tile in 98.4% of cases, but the independently decoded positions for the next several steps form a strictly adjacent legal path in only 4.27% of successful blocks [8]. The network responds appropriately to the obstacle, yet does not reconstruct a coherent list of future coordinates. What updates is a spatial preference field, not a stored path sequence.

## 5. Multi-box planning: capacity, priority, and a bound object-file

### 5.1 The capacity problem

A spatial push field is not sufficient by itself. If each box simply follows an attractive gradient toward a target, multiple boxes can converge on the same target or obstruct one another. Sokoban imposes a discrete capacity constraint: one box per target. The DRC represents this constraint in a continuous form.

Deleting one target from the encoded board creates a competition in which an “orphaned” box must reconsider its destination. The field does not collapse or instantly remap. Instead it retains substantial prior intent while shifting a smaller but reliable amount of mass toward the remaining target. The target deletion produces a +0.046 increase in target-compatible mass relative to a norm-matched generic floor edit of −0.0002 [9]. This inertia reveals both semantic sensitivity and a recurrent cache of prior box–target organization.

More direct interventions treat target occupancy as a repulsive field. Writing an “occupied target” concept at a free target during the structural update window reduces the probability of pushing into that target in a dose-responsive manner, including from locations outside the player-local read aperture. Capacity is therefore not implemented only at final action selection. It participates in the global field computation. In conflict-recovery experiments, a box state forced toward the wrong target can be restored within the inner loop: intended-target probability for the alternative valid target rises from 0.019 immediately after the conflict to approximately 0.986 by the last tick [10]. Because matched-random perturbations also recover strongly, this is best interpreted as robust field re-equilibration rather than proof of a single capacity-specific error-correction vector.

Capacity information is present before the main structural updates. Strict probes on action-conditioned target candidates show that the initial recurrent state predicts the next-step target-occupancy configuration better than the raw current board. Broadly zeroing the top cell state at the initial tick reduces later target-occupancy F1 from 0.854 to 0.768 and recall from 0.79 to 0.63 [11]. This manipulation is too large to isolate a pure capacity channel, but it supports a predictive initialization that the later local–global loop refines.

The most cautious synthesis is therefore staged. The loop starts from a nonblank, predictive capacity prior. Local recurrent updates integrate point-aligned geometry, while the global pathway communicates occupancy and conflict information across the board. Recurrent inertia prevents assignments from fluctuating wildly after each observation, yet the field can re-equilibrate when constraints change.

### 5.2 Immediate priority is real, but not a full queue

Capacity and admissibility still leave a serialization problem among boxes: which box should be worked on next? The DRC carries an **immediate next-box priority** that cannot be reduced to simple geometry or the global value scalar.

On a four-box cohort, a linear hidden-state ranking model predicts the identity of the next completed box with accuracy 0.838 in h3, versus 0.685 for a learned whole-board candidate-ranking network, a margin of +0.154 [0.129, 0.178] [12]. On the diagnostically important subset where the nearest-box heuristic is wrong, the margin remains +0.179 [0.121, 0.236]. The board alone strongly constrains the choice, but the recurrent state carries an additional internal commitment.

This priority is mostly recomputed online. The identity of the second or third completed box becomes much more decodable after earlier boxes have been placed. For example, second-rank accuracy increases from 0.367 before any completion to 0.762 after one box is placed; third-rank accuracy rises from 0.347 to 0.417 to 0.822 as zero, one, and two boxes are placed. The DRC does not appear to commit to a complete order at the beginning. There is nevertheless limited early look-ahead: the eventual last box is decodable above base-rate, label-shuffle, and board-network controls even before any box is placed. Thus “strictly myopic” is also too strong. The best description is an immediate priority that is recomputed as the board evolves, with partial distributed information about later structure.

Priority is distinct from the global value representation. Return and remaining steps are highly decodable from pooled recurrent features, but removing their linear directions leaves next-box decoding essentially unchanged; the direction cosines are only about 0.12–0.22. The network therefore maintains separate global evaluation and object-selection variables.

Behavioral intervention closes the representation-to-use gap. On a geometry-matched 80-board cohort, steering the c3 priority axis toward an alternative box makes that box precede the native priority box in 5 of 80 trials. Three controls—matched random, stabilized shuffled direction, and the true direction at the wrong spatial location—produce 0 of 80. The contrast is +0.0625 [0.0125, 0.125], and all conditions retain solve rate 1.0 [13]. The effect is modest, as expected if priority is one additive input to a globally constrained field rather than a dictatorial switch.

### 5.3 Priority and destination form a selective object-file

The next-box priority is not an isolated label. It is bound to a representation of where that selected box is intended to go. This binding was tested under a geometry-parity design: a strong board-and-solver network predicted the destinations of the next and a matched non-next box equally well, and the two boxes were matched on remaining pushes and current distance to their destinations. Under these controls, the DRC still represents the next box’s destination more accessibly. The hidden-state advantage for next versus matched non-next destination is +0.135 [0.076, 0.190] in h3 and +0.090 [0.028, 0.144] in c3; shuffling which box counts as “next” removes the margin [14].

Binding also improves prediction of how the imminent push will be directed. A classifier with the true box-by-destination interaction outperforms one using independent priority and destination marginals. It also outperforms a control with identical feature dimensions and preserved marginals but shuffled box–destination pairings, by +0.040 [0.018, 0.061] in h3 and +0.049 [0.027, 0.071] in c3. The DRC therefore contains a selectively bound object-level plan: **which box is currently prioritized, and where that box is going**.

This structure should not be mistaken for a symbolic record detached from the spatial field. Re-ranking priority can perturb competence at larger sustained doses, indicating that the object-level variable is entangled with the same field that computes feasible pushes. By contrast, the player’s route occupies an approximately orthogonal subspace and can be moved without damaging the box plan. The architecture is neither a single undifferentiated state nor a set of fully independent symbols. It binds variables that belong to the current box operation and separates variables, such as self-navigation and global value, that serve different computational roles.

### 5.4 Destination is used when it becomes the binding constraint

Representational binding does not guarantee that destination affects the next action in every state. Under ordinary greedy geometry, priority and local push feasibility may already determine the action; destination can be encoded yet behaviorally redundant. This predicts a conditional causal effect at geometric forks.

The prediction is supported by solver-verified physical counterfactuals. Consider an active box with multiple legal push corridors, each capable of reaching a target candidate. Moving that box’s target across the branch changes which first push is target-consistent. On 48 constructed boards that remain solvable under both target placements, an across-branch target relocation changes the first active-box push on 39 boards: rate 0.8125, 95% interval [0.708, 0.917] [15]. The new push is target-consistent at the same rate. A distance-matched target move within the original branch changes zero pushes, as does relocating a different box’s target. A frozen destination decoder registers the moved target in all 48 cases, and a permutation null yields \(p=0.0004\).

This result identifies a regime boundary. Destination is not a continuously dominant command. It enters the immediate readout when the geometry makes it necessary to choose between target-dependent branches. In routine states, the same variable can remain represented without affecting the next push. The broader principle is that the DRC reads represented content **when that content is action-binding under current constraints**.

### 5.5 Sequential subgoals from spatial collisions

How can an immediate-priority architecture solve dependencies that are undeniably sequential, such as moving one box out of another’s path? The evidence suggests that some discrete subgoals emerge from continuous capacity conflicts.

If a destination intent for one box overlaps a cell occupied by another, the shared field can produce “make room” pressure on the obstructing box. Multiple simultaneous conflicts can be superposed, and in controlled interventions the pressure propagates from an intended destination to a secondary box. Early-tick interventions produce the clearest cascade; delaying the same perturbation reduces or reverses the effect, consistent with a spatial signal that needs recurrent time to propagate. This provides a plausible bridge from continuous field dynamics to discrete behavior: spatial incompatibilities increase the immediate priority of objects that must move first.

This finding should be stated at the right level. Activation-based collision experiments are vulnerable to convolutional smearing, and the exact boundary between semantic conflict propagation and generic local spread is not completely isolated. Yet physical counterfactuals independently show that making the native priority box impossible causes the recurrently computed priority to shift and behavior to reroute. Encasing the baseline priority box changes the tick-3 priority readout on 36.8% of trials and the first pushed box on 44.8%, compared with 3.6% for a sham edit; the corresponding tick-0 representation barely changes [8]. Global constraints therefore do reshape priority during the inner loop. The safest conclusion is that sequential subgoals can arise through repeated spatial constraint propagation and immediate re-prioritization, without requiring a stored chronological queue.

## 6. A separate navigation primitive for the player

### 6.1 The thin route signal beyond geometry

The player must walk to the correct side of the selected box before pushing it. Much apparent route information is predictable from the board, so the meaningful target is not generic future occupancy but the residual choice among geometrically viable paths.

Against a deep whole-board network with breadth-first and solver-distance features, a 33-parameter linear c3 probe retains a small but robust advantage for long-horizon player-route occupancy: +0.0148 [0.0072, 0.0213] at horizon four and +0.0437 [0.0340, 0.0506] at horizon eight [16]. In the same experiments, box occupancy and metric player arrival time remain below the board baseline. The internal residual is therefore topological—where the player will route—not a general future-state or clock signal.

The advantage concentrates where the board underdetermines the route. At horizon four, high-ambiguity states show a hidden-minus-board-model gap of +0.051 [0.023, 0.077], while low-ambiguity states are near zero. When two routes are exactly equal-cost to the same fixed push-access cell, c3 predicts the realized path with accuracy 0.776 while a 153,601-parameter board-and-search-feature network sits at 0.495, essentially chance [17]. The recurrent route signal is thus best understood as a **choice variable** that resolves degrees of freedom left open by geometry.

### 6.2 Separation from the box subgoal

The route variable is not merely a reread of the box plan. Its linear axis is nearly orthogonal to a next-push subgoal axis, with absolute cosine about 0.09 in replicated analyses. Moving the subgoal axis changes a frozen route decoder by only −0.004, whereas the route axis changes it by +0.136 [17].

The behavioral dissociation is equally important. Decoder-audited route steering changes the realized multi-step route by +0.125 [0.05, 0.24] while preserving the committed next push on 96% of trials and preserving solve rate at 0.925, identical to baseline. Injecting the subgoal axis has only a small reverse effect on route choice. This explains why route steering can be clean while priority steering is more tightly coupled to competence: self-navigation has a partially orthogonal channel, whereas changing the chosen box modifies the global admissible-push computation itself.

### 6.3 Route computation as local obstacle-admissible relaxation

The route is not a fixed label carried unchanged to the output. On states where a straight Manhattan path to the push-access cell is blocked, tick-resolved probes show the representation moving toward the obstacle-admissible detour and away from the naive direction. Across 736 detour states, admissible agreement rises from 0.58 to 0.94 while naive agreement falls from 0.51 to 0.087; the admissible-minus-naive growth is +0.786, with a board-clustered interval roughly [0.70, 0.87] [18]. A within-board, candidate-balanced shuffle does not reproduce the trajectory.

This relaxation shares a computational motif with the box field: begin with a partially formed or naive state, then move toward a constraint-consistent fixed point across recurrent ticks. The constraints differ. Box admissibility includes deadlock, multi-box interaction, and target capacity. Player-route admissibility is primarily local reachability through current walls and boxes to a committed push-access cell.

Faithful wall edits reveal the difference in computational scope. Adding a wall directly on the route changes route relaxation strongly: +0.741 [0.556, 0.937] in one consolidated analysis, and +0.888 [0.678, 1.123] in a hardened cohort [19]. A distant wall can strongly move a global deadlock/admissibility decoder while leaving the route within a predeclared ±0.10 equivalence band. In paired comparisons, the distant edit moves the box field by +0.111 [0.045, 0.193] while the route changes only −0.049; the box-minus-route scope contrast is +0.160 [0.091, 0.238]. The route primitive is locally scoped to the navigation variable, whereas box planning is globally interconnected.

The shared motif is therefore not evidence for identical circuitry. It is an algorithmic convergence: both variables are iteratively relaxed from naive or inherited states toward constraint-respecting solutions, but over different variables and spatial scopes.

## 7. The serialization bottleneck: from a parallel field to one action

### 7.1 Why globally decodable content can be behaviorally weak

The DRC computes a board-wide field but must emit one of five actions. The final policy has global support because it flattens spatial features, yet sensitivity is concentrated around the player. Mean-ablation within radius two of the player produces policy KL divergence 0.846 and retains the original top action only 55% of the time; ablating remote cells at the same radius gives KL 0.052 and 94% retention [7]. This player-centric geometry explains how a global plan is serialized: the policy primarily reads the field near the player’s current locus of control.

Tick-resolved injection makes the conversion operator more precise. Push-direction content written into c2 near the player shortly before the final readout transfers into both h3 and the target action logit. The same content at a distant cell produces almost no transfer; at the late injection point the distant h3 change is exactly zero in the measured setup. Player-minus-distant action-logit effects are +0.040 and +0.058 at two tested doses [20]. Transfer grows across the recurrent loop toward the last tick rather than being strongest early. The gate is therefore **player-local and near-readout**.

### 7.2 Locality is not sufficient: the gate selects actionable content

A purely spatial aperture would read any directional vector near the player. It does not. In a native rollout, sustained push-relevant content can be placed at the cell of the box the player will approach, while matched arbitrary content is placed at a non-box path cell with similar distance and arrival time. At the moment the player arrives, sustained-minus-one-shot transfer for the box content is +0.575 [0.246, 0.919] in the target logit and +0.107 [0.039, 0.178] in target probability. The matched path-cell content is null. The box-minus-path interaction is +0.602 [0.138, 1.101] for the logit and +0.117 [0.026, 0.213] for probability [21].

The gate thus implements “compute globally, read actionable content locally.” A distant box plan is not permanently ignored; sustained content can matter once the player reaches that box. The local aperture is about the immediate read timescale. At each action, the policy consults the plan component that has become executable in the player’s neighborhood.

### 7.3 Manifold selectivity and off-manifold capture

The gate is also selective in feature space. Within the native push-direction subspace, simply increasing the magnitude of a wrong direction does not reliably capture the readout. Correct push content at natural norm can beat wrong in-manifold content at eight times the norm by +0.412 [0.227, 0.612] [22]. By contrast, a vector orthogonal to the span of the native push directions disrupts the policy increasingly as its norm grows. At sixteen times natural norm, out-of-manifold versus in-manifold content changes the target logit by −0.564 [−0.814, −0.322], increases action flips, and raises entropy, even though its measured recurrent displacement is smaller.

This geometry reconciles two observations that otherwise look contradictory. Under normal magnitudes, the policy is content-selective and robust within its learned action manifold. Under artificial high-norm interventions, off-manifold activity can capture the readout. Such induced failures do not imply that natural play uses a raw magnitude detector. They reveal a vulnerability of a soft learned filter outside its training manifold.

### 7.4 A compact phenomenological operator

Let \(F(c)\) denote the late spatial field at cell \(c\), \(p\) the player position, \(M\) the actionable push manifold, and \(\Pi_M\) projection onto that manifold. A useful phenomenological approximation to the readout is

\[
R \approx \sum_c w(\|c-p\|)\left[\Pi_M F(c) + \epsilon(\|F(c)\|)(I-\Pi_M)F(c)\right].
\]

The spatial weight \(w\) is large near the player and small at distant cells. The first term captures normal in-manifold selection. The second term is small at natural magnitudes but grows under large off-manifold perturbations. This equation is not a claim about exact neural circuitry. It summarizes three robust behavioral properties—locality, manifold selectivity, and off-manifold magnitude capture—and explains why different represented variables have different causal effects.

## 8. Long-horizon information without an executable queue

### 8.1 Decoded futures are not necessarily simulated futures

The DRC contains abundant information about what will happen later. Future player positions, future box-push activity, box destinations, completion priority, and even the identities of second and third future boxes can be decoded under some feature constructions. It would be easy to interpret this as a hidden rollout. Three lines of evidence reject that inference.

First, ordered future-step probes exhibit temporal confusion. A common spatial representation predicts multiple future offsets without cleanly assigning them to chronological slots. Second, intervention on absolute future coordinates often fails to steer behavior beyond matched random directions. Third, physical route blocks provoke a field response without producing a coherent sequence of decoded adjacent steps. The network knows enough about future constraints to shape current spatial variables, but it does not expose a reliable list of future states for execution.

This distinction can be formalized. Let \(Z_t\) be the current recurrent state and \(Y_{t+k}\) a future event. High mutual information or probe accuracy between \(Z_t\) and \(Y_{t+k}\) is consistent with at least three mechanisms:

1. \(Z_t\) stores an explicit prediction of \(Y_{t+k}\).
2. \(Z_t\) stores a plan variable that causally generates \(Y_{t+k}\).
3. \(Z_t\) stores current constraints from which both the policy and the eventual future follow.

Only the first two resemble an executable forecast. Much of the DRC’s deep-future decodability is better explained by the third: a globally structured field contains enough information about geometry, capacity, and current commitments that many future events are statistically recoverable.

### 8.2 The status of deeper future-box priorities

Globally pooled early cell states can decode the identity of the second and third distinct boxes that will be pushed. Strict pointwise probes do not recover these variables well, suggesting a distributed rather than spatially localized code [23]. A concept direction for the second future box can strongly move its own internal readout at an early tick, yet produces essentially no specific behavioral shift relative to an orthogonal random control. Injecting the same direction later creates a small increase in behavioral flips, but the effect is indistinguishable from generic noise and does not preserve semantic specificity. Thus the deeper priority signal is represented but not demonstrated to be used.

One archived interpretation proposed an active **horizon filter**: deep priorities arise early, are deliberately suppressed, and are replaced by the immediate priority before readout. A direct follow-up tested the predicted inverted temporal trajectory using globally pooled c2 activity on fixed balanced cohorts. The result did not support the mechanism. The second-priority mean absolute logit across ticks was 0.19565, 0.22216, 0.20830, and 0.20965; it was slightly higher at the final tick than at the first. The immediate-priority magnitude was 0.43069, 0.39810, 0.38603, and 0.39225, decreasing rather than monotonically increasing. Neither predicted trajectory occurred [24].

The negative result narrows the conclusion. The evidence supports a functional horizon at immediate priority: the first priority is causally used, while tested second-priority steering is not. It does **not** yet establish that a dedicated monotonic suppression process implements this horizon. Deeper sequence information may be weak, distributed, cohort-dependent, or incidentally transformed by the recurrent dynamics. The exact mechanism that prevents it from controlling behavior remains unresolved.

### 8.3 Planning in space, serializing through environment time

The absence of a queue does not mean the behavior lacks deep structure. Sokoban’s environment supplies a natural external clock. After each movement or push, the board changes; the DRC re-encodes it, relaxes the fields, updates priority and route, and chooses again. Multi-step plans emerge from this repeated closed loop:

\[
s_t \rightarrow 	ext{spatial relaxation} \rightarrow a_t \rightarrow s_{t+1} \rightarrow 	ext{spatial relaxation} \rightarrow a_{t+1} \rightarrow \cdots
\]

Irreversible constraints are respected because the field at each step incorporates deadlock and capacity structure, not because the network commits to an entire future action string. Sequential dependencies can appear as cascaded spatial conflicts: if box A’s intended path requires box C to move, C’s priority rises; after C moves, the field is recomputed and A can resume. This is a genuine planning algorithm, but its primitive is repeated constraint relaxation rather than chronological search.

## 9. The role of recurrent memory

### 9.1 Recalculation is usually sufficient

Full recurrent reset provides a direct test of whether the agent depends on extended pondering across environment steps. In one 64-board experiment, zeroing all recurrent tensors mid-episode yields 61 solves versus 62 for the native baseline [4]. A larger screen finds that 938 of 943 baseline-solved states remain solvable after reset [25]. The four internal ticks can usually reconstruct a functional field from the current observation alone.

This result rules out a planning algorithm that fundamentally requires accumulating a longer and longer search tree over many environment steps. It also explains why transient plan edits wash out: the network repeatedly recomputes a board-consistent state.

### 9.2 Hysteresis breaks rare symmetries

The small reset-failure cohort reveals why recurrent memory nevertheless exists. On five states where the native agent solves but the reset branch fails, action confidence drops from 3.31 to 1.69, while the entropy of the decoded box field changes only mildly [25]. The problem is not that all spatial intent disappears. The field remains broadly coherent but becomes too symmetric or ambiguous to serialize safely within four ticks.

Several observations support the **hysteresis cache** interpretation. Extending reset computation to eight ticks rescues two of the five failures. Resetting only shallow or only deep recurrent components preserves enough history to solve all five, implying distributed redundancy. Layer-sensitive studies suggest that shallow recurrent state can provide a structural tilt that later updates amplify. Recurrent carry-over therefore acts less like a notebook of future actions and more like a bias toward a previously stable branch of a multistable spatial solution.

This role is especially plausible in bottlenecks with near-tied actions. A continuous relaxation initialized exactly symmetrically can remain uncertain or oscillate; a small inherited asymmetry selects one admissible fixed point. In ordinary states, current geometry already supplies a large asymmetry, so the cache is redundant. In rare hard states, it prevents a catastrophic tie.

### 9.3 K3 is usually readout-adjacent, not universally passive

Many interventions localize structural integration to the middle recurrent updates and treat the last transition as readout exposure. This is a useful default, but not a universal law. On normally converged states, late structural injections fail to propagate globally and can create anomalous policy/value effects. On unresolved symmetric states, however, the final transition can still materially alter logits and stabilize or destabilize the field. The correct statement is conditional: the last tick is mostly passive when the field has reached a fixed point, but remains computationally active when earlier updates have not converged.

This qualification matters for the formal algorithm below. The recurrent loop should be viewed as a fixed-budget relaxation, not as three semantically hard-coded stages. Stage labels describe dominant empirical roles, while convergence state determines how much work remains at the final tick.

## 10. A formal algorithmic description

The evidence can now be assembled into a concrete algorithm at the level of represented variables and causal operations. This is not a transcription of neural weights. It is a behavioral-mechanistic abstraction: the smallest structured process that explains the probe trajectories, causal interventions, physical edits, and failure modes.

### 10.1 State variables

Let a Sokoban board state be \(s_t\), containing walls, floor, player position, boxes, and targets. Let the recurrent state entering environment step \(t\) be \(H_t^0\). From the empirical results, we define the following latent variables:

- \(G_t\): geometric boundary conditions derived from the current visual encoding, including walls, player-reachable regions, box obstacles, and target locations.
- \(F_t^k(b,d)\): at recurrent tick \(k\), the support for pushing box \(b\) in direction \(d\). This is the central box-indexed admissibility field.
- \(C_t^k(x)\): capacity or occupancy pressure associated with target or corridor location \(x\).
- \(P_t^k(b)\): immediate priority of box \(b\).
- \(D_t^k(b,x)\): destination support assigning box \(b\) toward target or destination cell \(x\).
- \(Q_t^k(b,x)=P_t^k(b)D_t^k(b,x)\): a selectively bound object-file for the currently relevant box and its destination.
- \(R_t^k(c)\): player-route support over cells \(c\), conditioned on a push-access cell implied by the selected box plan.
- \(V_t^k\): a global evaluation signal related to return or remaining difficulty, represented separately from priority.
- \(M_t\): recurrent hysteresis, a distributed inherited tilt favoring a previously stable solution when the current relaxation is ambiguous.

These variables need not occupy disjoint tensors or linear subspaces. The evidence only requires partial accessibility and selective binding: route is approximately orthogonal to the push subgoal; value is linearly separable from priority; priority and destination exhibit super-additive binding.

### 10.2 Initialization

At the beginning of a step, the network does not start from zero:

\[
(F_t^0,C_t^0,P_t^0,D_t^0,R_t^0,V_t^0) = \mathcal{I}(G_t,H_{t-1}^{\mathrm{final}}).
\]

The initializer \(\mathcal{I}\) combines current geometry with recurrent carry-over. Tick-0 decodability of long-horizon route and capacity variables, plus the causal effect of broadly removing the initial capacity state, supports a predictive initialization. The carry-over is not normally indispensable, because setting it to zero usually allows reconstruction. Its main algorithmic contribution is hysteresis: it supplies a small symmetry-breaking prior and stabilizes object assignments or route choices when several fields are nearly equivalent.

### 10.3 Box-field relaxation

For each internal tick, the field is updated by a local–global operator:

\[
F_t^{k+1} = \mathcal{L}(F_t^k,G_t) + \mathcal{B}(H_t^k,G_t) + \mathcal{T}(M_t) - \mathcal{K}(C_t^k,	ext{deadlock}_t^k),
\]

where:

- \(\mathcal{L}\) is a local convolutional relaxation respecting spatial adjacency and physical blocking;
- \(\mathcal{B}\) is a state-conditioned global broadcast coordinating distant constraints;
- \(\mathcal{T}\) is the inherited hysteresis tilt;
- \(\mathcal{K}\) applies negative pressure from occupied targets, deadlocks, unreachable stand cells, or incompatible multi-box configurations.

The formula is schematic rather than literally linear. Its scientific content is in the terms. Whole-path ablation shows that the global component is necessary for the trained policy, but attempts to isolate a single scalar carrier have failed. The local and global paths cooperate. Geometry fixes where influence can propagate, while global summaries allow a distant capacity conflict or deadlocked box to alter a local push field within the four-tick budget.

The relaxation target is not nearest-target greediness. On diagnostic cells it approaches a minimum-push, deadlock-avoiding direction and moves away from the greedy alternative. This can be written as a decreasing inconsistency energy:

\[
E_{\mathrm{box}}(F;s) = E_{\mathrm{reach}} + E_{\mathrm{deadlock}} + E_{\mathrm{capacity}} + E_{\mathrm{collision}} + E_{\mathrm{commitment}},
\]

with the caveat that no experiment proves the network explicitly computes this scalar. The useful claim is operational: recurrent updates reduce violations of these constraint families.

### 10.4 Object selection and binding

From the relaxed field, the agent derives an immediate priority:

\[
P_t^{k+1}(b) = \mathcal{S}\left(F_t^{k+1},C_t^{k+1},G_t,M_t\right),
\]

where \(\mathcal{S}\) is an integrative selection process. Priority is influenced by which boxes admit competent pushes, which destinations remain available, and which boxes obstruct others. It is not simply nearest-box choice or the global value scalar.

The selected box is bound to a destination:

\[
Q_t^{k+1}(b,x) \propto P_t^{k+1}(b)D_t^{k+1}(b,x).
\]

This object-file is immediate and revisable. It does not imply that destinations of other boxes disappear, only that the selected box’s destination becomes preferentially accessible and more useful for predicting the imminent push. When geometry creates a target-dependent fork, the destination term becomes action-binding and changes the push. When local geometry already fixes the push, destination may remain encoded without exerting a measurable immediate effect.

Capacity collisions can feed back into priority. If the intended route or destination of box A conflicts with box C, the inconsistency increases pressure to move C. Thus the selection process can generate an ordered subgoal—“move C before A”—from a spatial conflict, then recompute after C moves.

### 10.5 Route relaxation

Given a selected push operation, define a required player access cell \(a_t\), the cell from which the player can execute the push. The route variable is relaxed separately:

\[
R_t^{k+1} = \mathcal{N}(R_t^k,G_t,a_t),
\]

where \(\mathcal{N}\) moves from a naive direction toward a wall-and-box-aware path to \(a_t\). Unlike the box field, \(\mathcal{N}\) has bounded local scope with respect to distant global admissibility changes. It responds strongly to obstacles on the route but is approximately invariant to distant structural changes that alter the box field. Route and box computations share an iterative constraint-relaxation motif while operating on separable variables.

### 10.6 Read and act

After the fixed recurrent budget, the policy reads a spatially and semantically restricted slice of the result:

\[
a_t = \arg\max_a \; \mathrm{PolicyHead}\left(G_t,\mathrm{Gate}_{p_t,M}(F_t^{\mathrm{final}},Q_t^{\mathrm{final}},R_t^{\mathrm{final}})\right).
\]

The gate privileges cells near the player and content lying on the native action manifold. Its effective input changes with the situation. While the player is walking, route content is action-binding. When adjacent to a box, the relevant push direction and object-file content enter the aperture. At a fork, destination can resolve which push to take. Priority affects which box becomes the target of navigation and manipulation, but usually as a marginal field bias rather than an absolute command.

The chosen action modifies the board, producing \(s_{t+1}\). The entire process repeats. Long-horizon behavior is the trajectory of these repeated relaxations and discrete environment transitions.

### 10.7 Pseudocode

The algorithm can be summarized as follows:

```text
Input: board state s_t, recurrent carry H_t^0

G_t <- encode_geometry(s_t)
(F, C, P, D, R, V) <- initialize_from(G_t, H_t^0)

for k in 0, 1, 2:               # dominant structural updates
    F <- local_geometry_relax(F, G_t)
    (F, C, D, V) <- global_constraint_broadcast(F, C, D, V, G_t)
    F <- suppress_deadlock_unreachable_and_overcapacity_pushes(F, C, G_t)
    P <- reprioritize_boxes(F, C, D, G_t)
    Q <- bind_selected_box_to_destination(P, D)
    R <- relax_player_route_to_selected_push_access(R, Q, G_t)
    apply_hysteresis_tilt_if_field_is_ambiguous(F, P, R, H_t^0)

# final transition is usually readout-adjacent, but may continue relaxation if unresolved
(F, P, Q, R) <- final_stabilization(F, P, Q, R, G_t)

local_action_content <- player_local_manifold_gate(F, Q, R, player_position(s_t))
a_t <- policy_readout(local_action_content, G_t)

execute a_t to obtain s_(t+1)
carry final recurrent state into the next step
```

This description directly answers the central research question. The DRC’s emergent planning algorithm is a fixed-budget, memory-stabilized spatial constraint solver that repeatedly turns continuous fields into one discrete action. It is human-comparable to relaxation methods, constraint propagation, object binding, and receding-horizon control, but it is not identical to any single classical algorithm.

## 11. Natural failures locate the competence boundary

### 11.1 Field under-formation, not ordinary misread

A mechanistic account should explain where competence ends. If the field is correct but the policy chooses the wrong action, the bottleneck is serialization. If the field itself fails to become admissible, the bottleneck is computation. Difficulty-matched analyses of naturally failed but solvable boards strongly favor the second explanation.

The failed-minus-matched-solved margin for deep admissibility beyond a complete single-box dead-square avoider is near zero at tick 0 (−0.026), then becomes −0.083, −0.226, and −0.299 by tick 3, with final interval [−0.546, −0.053] across 101 failures [26]. The deficit emerges during the inner loop. It is not primarily a bad initial field that is faithfully preserved, nor a correct final field that is then misread.

Field degradation predicts action quality across multiple thresholds. More decisively, 24 boards that superficially looked like “field intact, action wrong” were inspected mechanistically. Nine already had a locally wrong decoded field, eleven involved reachability or dead-square violations, and three involved capacity or identity errors. Only one remained a genuine readout-misfire candidate—about one board in the full 101-failure cohort [26]. The natural policy generally serializes the field it receives; the main problem is that the field has not converged to the deep admissible solution.

### 11.2 Residual relaxation shortfall

Could the under-formation be explained by poor initial priors, difficult topology, or a missing destination/capacity cache? Solved-control models were trained to predict the final admissible field from initial c2 quality, geometry, topology, and structured constraints. They did not predict that failed boards should have low final field quality. The observed-minus-predicted residual remained −0.4141 [−0.6524, −0.1759] in an initial model [27]. Adding measured initial capacity and destination probes attenuated the residual but left it negative at −0.2878 [−0.5180, −0.0719]. Much of the attenuation came from current-board visual geometry rather than recurrent destination priors.

The result replicated on a fresh failure cohort. Fixed models trained on the original solved boards actually predicted a nonnegative or positive final margin for the new failures, while observed residuals were −0.5874 [−0.8934, −0.3100] and −0.5214 [−0.8576, −0.2172] under two feature sets [27]. Under the measured variables, failure boards lie below the normal initial-to-final update relation.

This is observational stage localization, not circuit proof. An unmeasured initial variable or more flexible predictor might explain part of the residual. Nevertheless, the consistent pattern identifies the practical failure mode: the fixed recurrent budget sometimes fails to integrate deep multi-box constraints into a sufficiently admissible field. The agent’s natural limit is a relaxation shortfall.

### 11.3 Why the failure result strengthens the algorithmic account

The success and failure analyses converge. On diagnostic solved states, the inner loop moves the box field toward admissibility. On natural failures, this movement is selectively reduced. The read gate can be disrupted artificially by extreme off-manifold vectors, but ordinary failures rarely look like a correct in-manifold plan being read incorrectly. Thus the same mechanism explains competence and error: the quality of recurrent constraint relaxation determines whether the final discrete behavior is safe.

This also makes a concrete prediction. Increasing recurrent computation should help primarily on states with unresolved field inconsistency, not uniformly. Indeed, extended internal ticks rescue some reset-induced symmetry failures but not all. A convergence-aware stopping rule could outperform a fixed four-tick budget if the network were trained to use it.

## 12. Scientific interpretation

### 12.1 A hybrid continuous–discrete planner

The DRC should not be described as “non-symbolic” in the loose sense that it lacks structured variables. It represents box identity, push direction, priority, destination, route choice, capacity, and global value. Some are selectively bound, some approximately orthogonal, and some distributed. The more precise contrast is between **explicit chronological symbolic execution** and **continuous constraint-based computation with discrete readout**.

The internal fields are continuous and spatial. The environment actions, box identities, target capacities, and selected subgoals are discrete. The architecture converts between these regimes repeatedly. Continuous relaxation evaluates many possibilities in parallel; object priority and the player-local gate serialize them. This is a hybrid planner.

### 12.2 Receding-horizon control without a stored horizon

The algorithm resembles receding-horizon control in that it recomputes after each action. However, the “horizon” is not an explicit rollout length. Long-range information enters through spatial constraints, target occupancy, box destinations, and inherited state. The action is chosen from a current fixed point or approximate fixed point. The next board then supplies feedback.

This explains the coexistence of long-horizon competence and weak chronological representation. A plan can be long-horizon in the sense that current fields reflect consequences many pushes away, while remaining non-chronological in format. A capacity collision caused by a future destination can alter current priority without the network storing the intervening action list.

### 12.3 Why spatial relaxation fits the architecture

The algorithm is well matched to a repeated ConvLSTM. Shared convolutional weights naturally compute similar local updates at every board cell. A box-indexed field lets each box carry its own candidate push in parallel. A pooled global pathway bypasses the slow spatial diameter of local convolution. Repeating the module allows iterative correction and fixed-point-like behavior. Cell-state carry-over supplies hysteresis. The final hidden layer exposes the result to a policy with global support but player-centered sensitivity.

An ordered queue would be harder for this architecture to maintain. It would require stable slot assignment, queue advancement after every push, and robust rebinding when boxes change position. The observed box-indexed field avoids those bookkeeping problems. The board itself, plus repeated recomputation, provides the serialization context.

### 12.4 The methodological lesson: test use, not only decoding

Several apparently contradictory findings disappear when representation and use are separated. Future routes can be decoded from c3 yet fail to control the immediate action because the endpoint and locus are wrong; the same route variable can control multi-step path choice under sustained steering. Admissible c2 content once appeared weakly causal because the intervention vector was not audited; clean pairwise directions revealed a strong solve-rate effect. Destination appeared causally null when c3 steering failed its own registration check; faithful target relocation at geometric forks produced an 81% push change. Deep future priority is decodable, yet steering remains semantically inert.

The general workflow is therefore:

1. Choose a target that distinguishes candidate algorithms.
2. Compare with a strong board-only or geometry-matched baseline.
3. Track the target across recurrent time with a fixed probe.
4. Intervene with a registered stimulus and matched controls.
5. Select an endpoint appropriate to the variable’s timescale and readout locus.
6. Prefer faithful physical counterfactuals when activation interventions cannot be registered cleanly.

This workflow is as important as any individual metric because it prevents a rich correlational state from being mistaken for an executed algorithm.

## 13. Limitations and unresolved questions

The synthesis is strong but not complete.

First, the evidence concerns one trained checkpoint and a specific mini-Sokoban distribution. The architecture may learn different internal decompositions under other seeds, curricula, board sizes, or action conventions. The consistency across many independently designed cohorts supports the account within this model, not universality across DRC agents.

Second, probes are operational instruments. A linear decoder can miss nonlinear content or introduce its own geometry. Frozen probes under large interventions can become miscalibrated. Strong board baselines, shuffle controls, registration audits, and physical edits reduce these risks but do not eliminate them.

Third, “admissible” is defined by agreement with solver outputs such as minimum-push plans, complete single-box dead-square avoiders, or breadth-first routes. These are useful discriminating targets, not proof that the network optimizes the identical formal objective. The agent may implement a learned approximation with different trade-offs.

Fourth, the exact microcircuit of the global broadcast remains unresolved. Whole-path ablation establishes importance, but branch-specific splices do not identify a unique capacity carrier. Hidden states can preserve recovery when cell states are erased, and shallow recurrent tilts can influence later relaxation. A complete causal trace across layers, gates, and ticks has not been performed.

Fifth, the deeper sequence representation remains conceptually open. The current data show decodability without specific causal use and directly reject one monotonic active-filter trajectory. They do not determine whether later-priority information is an incidental correlate, a training-induced forecast, a weak auxiliary representation, or a variable used only in rare regimes not captured by present interventions.

Sixth, several causal effects are modest. Priority steering changes completion order on 5 of 80 boards at a competence-preserving dose. Route steering effects depend on ambiguity and sustained intervention. These magnitudes are consistent with distributed integration but limit claims that any single linear direction is a complete control variable.

Finally, the formal algorithm is phenomenological. It identifies representations and operators required by the evidence, but not exact equations implemented by the ConvLSTM weights. The term “relaxation” describes the empirical movement toward constraint-consistent fields and recovery after perturbation; it does not imply a proven scalar energy function.

## 14. Conclusion

The trained DRC agent solves Sokoban through a planning algorithm that is neither classical search nor simple reactive pattern matching. It maintains a spatially registered field of per-box push intentions, initialized from current geometry and recurrent history. Across four internal ticks, local convolution and global recurrent broadcast relax this field toward deadlock-aware, capacity-consistent pushes. The process selects an immediate box priority and binds that box to a destination. In parallel, a separable navigation variable relaxes toward an obstacle-admissible route to the required push-access cell. A late player-local, manifold-selective gate reads whichever variable is currently action-binding and converts the parallel field into one discrete movement.

Long-horizon organization emerges from this loop. Distant constraints shape current fields; capacity conflicts create “move this first” pressure; priority and destination determine the active object; route relaxation guides the player; and the board is recomputed after every action. Deeper future events are often decodable because the spatial state contains their causes, but they do not form a demonstrated executable queue. Cross-step memory usually serves as a hysteresis cache that stabilizes rare ambiguous choices rather than as a workspace for ever-deeper pondering.

The strongest evidence comes from convergent falsifications. Goal-outward value iteration is contradicted by agent-centered refinement. An ordered action queue is contradicted by box-indexed transfer and sequence-incoherent physical counterfactuals. A purely local solver is contradicted by catastrophic global-path ablation and distant constraint propagation. A purely global route planner is contradicted by the local scope of player navigation. A purely correlational plan is contradicted by causal steering and faithful board edits. A general readout defect is contradicted by natural failures that localize to under-formed admissible fields.

The answer to the central research question is therefore precise: **the DRC plans by repeatedly solving a continuous, globally constrained spatial relaxation problem, stabilizing it with recurrent hysteresis, binding the currently selected box to its destination, computing a separate local route for the player, and serializing the result through a conditional local read gate.** The agent plans in space, acts in time, and obtains long-horizon behavior by closing that loop after every move.

## References to the local evidence corpus

The references below identify the full archived studies by title and author, without internal database identifiers.

1. Aletheia I. *The DRC’s Plan Is a Box-Indexed Push-Direction Field, Not a Temporal Action Queue.*
2. Arche I. *A Continuously-Maintained Spatial Route-Plan Underlies DRC Sokoban Planning.*
3. Aletheia I. *The DRC’s Inner Loop Maintains a Push-Direction Plan and Refines It Near the Agent, Not a Goal-Seeded Value Iteration.*
4. Kepler I. *The Mechanics of Board-Anchored Value Diffusion: Hybrid Local-Global Updates and Reactive Recomputation.*
5. Aletheia I. *The DRC’s Inner Loop Computes an Admissible, Deadlock-Avoiding Push-Plan (Not a Greedy One), While the Content Is Only Weakly Behaviorally Load-Bearing.*
6. Aletheia I. *Admissible Push-Content Is Causally Load-Bearing and Read Through a Player-Local, Content-Selective Aperture: Resolving a Prior Null.*
7. Nexus I. *The Mechanics of Serialization and Reachability in the DRC’s Continuous Spatial Solver.*
8. Vanguard I. *Physical Counterfactuals Expose the Continuous Spatial Solver: Falsifying Sequence Planning and Validating Global Constraint Propagation.*
9. Nexus I. *The Bijection Constraint: Target Capacity in the DRC’s Continuous Spatial Solver.*
10. Nexus I. *The DRC Sokoban Planner: A Continuous Spatial Relaxation Solver.*
11. Kepler II. *The Architecture of Intent: A Meta-Analytical Integration of the DRC’s Continuous Spatial Solver.*
12. Arche II. *An Immediate, Greedily-Recomputed Next-Box Priority in the DRC: Decodable Above a Strong Board Model, Distinct From the Global Value Scalar, and Causally Entangled With Field Competence.*
13. Arche II. *Priority Is Used, Not Just Decoded: c3 Next-Box Priority Steering Causally Reorders Which Box the DRC Pushes First.*
14. Arche II. *A Bound Object-File for the Next Box: Priority and Destination Are Jointly Represented and Functionally Coupled in the DRC, While Route and Value Remain Separable.*
15. Arche II. *Branch-Conditional Causal Use of the Object-File Destination: The DRC Reads Where a Box Goes Only When Geometry Forces the Choice.*
16. Aitia I. *Where Geometry Runs Out: The DRC’s Long-Horizon Route Signal Is a Choice Representation Localized to Geometrically-Ambiguous States.*
17. Aitia I. *Two Orthogonal Choices: The DRC’s Player-Route Signal Is Separable From the Box-Push Subgoal.*
18. Aitia I. *The DRC Computes Its Player Route by an Inner-Loop Obstacle-Admissible Detour Relaxation.*
19. Aitia I. *A Navigation Primitive Beside the Box Solver: The DRC’s Player-Route Is a Separable, Locally-Scoped Instance of a Common Relaxation Motif.*
20. Arche I. *The Read Gate: The DRC Reads Its Global Push-Field into Action Through a Player-Local, Near-Readout Spatial Gate.*
21. Arche I. *The Read Gate Is Content-Selective: The DRC Reads Box-Push-Relevant Content Locally, Not Arbitrary Local Content.*
22. Arche I. *The Read Gate Is a Manifold-Selective Filter: Reconciling Content-Selectivity and Magnitude-Capture in the DRC’s Serialization Bottleneck.*
23. Daedalus II. *The Illusion of the Queue: Deep Sequence Representation Is Decodable but Causally Filtered by the Continuous Spatial Solver.*
24. Daedalus II. *The Mechanics of the Horizon Filter: Temporal Trajectories of Immediate Versus Second-Priority Intent Magnitudes* (experimental report).
25. Kepler I. *The Hysteresis Cache: Recurrent Memory Breaks Symmetries in Memoryless Value Diffusion.*
26. Aletheia I. *DRC Sokoban Failures Are Compute-Dominated Deep-Admissible Field Under-Formation, Not Readout Misfire.*
27. Noether II. *Residual Inner-Loop Relaxation Shortfall in Natural Failure Field Formation.*
