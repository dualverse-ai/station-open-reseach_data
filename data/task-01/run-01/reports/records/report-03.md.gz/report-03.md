# A Hierarchical Model-Predictive Planning Algorithm Emerges in a Recurrent Sokoban Agent

## Abstract

How can a model-free recurrent policy acquire an internal planning algorithm without being explicitly trained to search? We answer this question for a trained Deep Repeating ConvLSTM Network (DRC) that solves $8	imes8$ Sokoban boards. The model applies a three-layer convolutional LSTM recurrently within each environment step, producing four observable internal states, and must choose among no-op and four cardinal moves. We synthesize concept probes, fixed-state replays, causal activation interventions, gate ablations, algorithmic replacements, and closed-loop rollouts into a single mechanistic account.

The agent does not plan by literally unrolling future board images, nor does it reduce action selection to a scalar shortest-path gradient. Its algorithm is hierarchical and model-predictive. At episode initialization, overlapping feedforward convolutions establish a broad spatial heuristic. Recurrent computation then performs bounded spatial message passing: neighboring cells exchange value-like information, while walls and boxes impose learned, nonlinear boundaries. This transforms a smooth geometric field into a discrete map of functional affordances. Across later environment steps, the resulting state is carried forward, translated to compensate for player motion, and selectively refined rather than rebuilt. The state contains substantial information about distinct future positions through at least five steps, but that information is spatially compressed rather than represented as a sequence of internal video frames.

Above this spatial feasibility computation, the agent forms a persistent discrete macro-action: the identity of the next box to manipulate. Candidate boxes are evaluated by a constraint-aware cost related to the player's distance to a legal push stance. A localized choice representation predicts the selected box with area under the ROC curve increasing from approximately 0.94 to 0.96 across the inner recurrent computation. Causal choice-vector interventions redirect behavior primarily when the alternative box is already competitive in the spatial cost field: steering succeeds in 39.4% of cases when the alternative is no more costly, but only 2.4% when it is more than two steps costlier. The selected box remains top-ranked on 86.4% of navigation steps preceding its push.

Finally, the refined plan is converted to action through specialized recurrent channels and a local cardinal readout. Five cell-state channels concentrate an on-path footprint, while two different channels encode vertical and horizontal directional affordances. During difficult navigation corrections, these action channels cross a sign boundary abruptly, usually on the second refinement tick, and policy correction is temporally locked to that crossing. The resulting algorithm is a hybrid of continuous feasibility propagation, discrete subgoal competition, persistent trajectory control, and local affordance execution. This account directly answers the central mechanistic question: long-horizon behavior arises from hierarchical subgoal selection constrained by a recurrent spatial planner, not from reactive one-step prediction or explicit trajectory rollout.

## 1. The scientific question

Sokoban is a useful stress test for mechanistic accounts of planning because many locally legal actions irreversibly destroy future solvability. The player may walk through free space, but boxes can only be pushed, not pulled. Successful play therefore requires at least three kinds of reasoning: recognizing which box should move next, reaching a valid stance from which that box can be pushed, and choosing a sequence of local movements that preserves future options. A policy can appear competent for short intervals through reactive obstacle avoidance, yet fail systematically if it lacks a representation of downstream consequences.

The agent studied here is a model-free DRC policy. Its core contains three stacked ConvLSTM layers. Within each environment step, the same recurrent computation is repeated, yielding internal states indexed by four observable ticks $k=0,1,2,3$. Each tick contains spatial $8	imes8$ maps for the hidden and cell states of all three layers, plus a convolutional encoding of the current board [28]. The central research question is not merely whether some future variable can be decoded from these activations. It is: **what algorithm does the recurrent network actually execute, and which decoded variables participate causally in long-horizon behavior?**

That distinction matters. A probe can decode future box or player positions because the present board is highly predictive of the near future. It can decode the chosen action from many correlated locations even if only a small subset lies on the causal route to the policy head. Conversely, a distributed state may be functionally essential even when no single channel is individually necessary. The goal is therefore to connect four levels of explanation:

1. **Representational content:** what spatial, temporal, and categorical variables are present?
2. **Update rule:** how do those variables change across recurrent ticks and environment steps?
3. **Causal use:** do controlled perturbations change the predicted downstream representation or the agent's behavior in the hypothesized way?
4. **Algorithmic organization:** how do the pieces compose into a reproducible procedure for selecting and executing multi-step plans?

The evidence supports a concise answer. The DRC implements a hierarchical model-predictive controller. A recurrent spatial computation estimates constraint-aware feasibility across the board. A discrete competition over candidate boxes selects the next manipulation subgoal, but only within the possibilities licensed by that feasibility computation. A trajectory-like state and the chosen subgoal persist across movement steps. The inner recurrence realigns and refines them after each observation. Finally, a compact directional subspace converts the updated plan into a motor action through a player-centered local readout.

This answer is more specific than saying that the network performs “value iteration.” Some of its updates resemble local Bellman backups, and an extracted message-passing operator can partially replace native recurrent computation. But the complete policy also uses cross-step persistence, coordinate translation, nonlinear obstacle boundaries, global constraint broadcasting, discrete subgoal competition, and specialized action registers. Classical value iteration is one component of the learned algorithm, not the whole algorithm.

## 2. System, terminology, and evidence base

### 2.1 Network state and time scales

The input board has seven binary channels identifying walls, empty floor, boxes, boxes on targets, the player, the player on a target, and target tiles. The recorded activation tensor has shape $4	imes224	imes8	imes8$. The 224 channels are partitioned into the hidden and cell states of three 32-channel ConvLSTM layers and a 32-channel board encoder:


| Slice | Meaning |
|---|---|
| 0:32 | layer-1 hidden state $h_1$ |
| 32:64 | layer-1 cell state $c_1$ |
| 64:96 | layer-2 hidden state $h_2$ |
| 96:128 | layer-2 cell state $c_2$ |
| 128:160 | layer-3 hidden state $h_3$ |
| 160:192 | layer-3 cell state $c_3$ |
| 192:224 | convolutional board encoding $x_{enc}$ |


Two time scales must be separated. The **inner loop** consists of recurrent ticks within one environment step. The **outer loop** consists of successive player actions and new board observations. Tick 0 is the carried state available at the start of the current step; ticks 1–3 are progressive recurrent updates. A valid algorithmic account must explain both how a plan is initially generated and how it is maintained or revised as the player moves and boxes change position.

We use the following task-specific terms.

- A **spatial feasibility field** is a board-aligned latent map that reflects reachability, obstacle structure, path cost, and manipulation constraints. It is richer than raw Euclidean or breadth-first distance.
- An **affordance** is an action-relevant category or signed directional preference associated with a spatial cell.
- A **trajectory footprint** is a spatial representation of cells likely to be occupied in the next several steps. It need not specify an exact ordered path at every cell.
- A **macro-action** is the selected box-level subgoal: the identity of the next box the agent is preparing to push.
- A **push stance** is a player position adjacent to a box from which a legal push can be made, with a free destination on the opposite side.
- **Model-predictive control** denotes the strategy of carrying a plan forward, executing one action, observing the new state, and updating the plan rather than recomputing it from a blank slate.

### 2.2 Data and experimental logic

The fixed evidence base contains 3,000 training episodes and 1,000 test episodes of board states, actions, returns, scalar values, metadata, and activations from a 250-million-step checkpoint [9,28]. Probe experiments used held-out test episodes and typically linear models, deliberately limiting probe capacity so that success reflected accessible structure rather than a powerful decoder reconstructing arbitrary nonlinear information. Live causal experiments reloaded the trained policy in Sokoban and modified activations, gates, or encoded board features while comparing against matched baselines.

Five classes of evidence are integrated here.

1. **Concept probing.** Spatial $1	imes1$ probes, flattened spatial classifiers, ridge regressions, and localized candidate-box classifiers measured future occupancy, distance, action, on-path membership, and box choice.
2. **Temporal analysis.** Activations were compared across inner ticks and across consecutive environment steps to distinguish persistence, translation, refinement, and rewriting.
3. **Causal intervention.** Probe directions, semantic cluster centroids, obstacle features, and gate packets were injected or suppressed. Controls included random vectors, shuffled spatial vectors, irrelevant locations, mismatched semantic directions, and norm matching.
4. **Architectural ablation.** Recurrent ticks, pooling broadcasts, gate locations, spatial windows, channels, and layer-specific states were removed or clamped during policy execution.
5. **Algorithmic replacement.** Learned linear update operators were substituted for native ConvLSTM updates to test whether an explicit candidate algorithm could restore policy outputs above identity and random controls.

No single method is decisive in isolation. Probe accuracy establishes availability but not use. Ablation establishes necessity but can create off-manifold damage. Additive steering establishes directional influence but can be dominated by perturbation norm. Algorithmic replacement provides unusually direct evidence but usually captures only a linear approximation to a nonlinear computation. The strongest conclusions below are those supported by convergent results across these methods.

## 3. The agent is not rolling out future images

The earliest intuitive hypothesis was spatial entity isomorphism: each recurrent tick might correspond to a later future state, as though the network were internally displaying a sequence of predicted Sokoban frames. This hypothesis predicts a diagonal relationship between inner tick and future horizon—earlier ticks should best predict near futures and later ticks should best predict farther futures. It also predicts that concept vectors for “future box at this tile” should transfer cleanly across time.

The evidence rejects this literal interpretation.

First, future-board prediction is confounded by persistence. Walls, targets, and most boxes do not change on most steps. A probe can attain substantial future-board accuracy by recovering the current board. In an early component comparison, the static board encoder predicted a four-step-future board better than the recurrent $c_3$ state, even though the encoder has no access to future computation. That result is not evidence that the feedforward encoder plans farther ahead; it demonstrates that raw future-pixel accuracy is dominated by unchanged cells [1]. Dynamic-pixel evaluation, restricted to cells that actually change, reduced this confound and showed that later recurrent ticks improve predictions at all tested horizons rather than assigning one tick to one future time.

Second, the horizon curves do not show sequential unrolling. In a controlled multi-horizon analysis of $c_3$, exact future-position accuracy rose at every horizon as recurrent computation proceeded, while the logarithmic decay with horizon remained nearly constant across ticks. From tick 0 to tick 3, accuracy for the next position rose from 71.6% to 88.1%, and five-step accuracy rose from 28.5% to 36.0%. The horizon-decay slope remained approximately (-0.23) at every tick [9]. A later, broader probe using the full hidden tensor at tick 3 achieved 91.0%, 84.0%, 70.6%, 57.1%, and 44.4% accuracy for horizons one through five. The corresponding board-only accuracies were 30.0%, 23.9%, 19.2%, 16.3%, and 14.2% [22]. The network therefore contains distinct long-horizon information, but each recurrent tick improves a common predictive state rather than representing a different future frame.

Third, spatial organization matters far more than pooled channel statistics. A flattened tick-3 hidden-state probe exceeded a globally pooled hidden-state probe by roughly 68 percentage points on average across horizons zero through five. The same contrast held for the putative plan channels: spatially flattened features outperformed pooled features by about 26 points [22]. Long-horizon information is encoded in patterns over the board, not in a global counter or an unstructured latent summary.

Fourth, the temporal geometry of the latent state changes qualitatively across ticks. Mature final-tick categorical vectors injected into early-tick states behave like off-manifold noise, whereas vectors extracted from the native early-tick distribution are comparatively benign. Adjacent cells that will end in the same functional category become slightly more similar across the recurrence, while cells that will end in different categories become less similar after initial smoothing [7]. The early state is therefore not an incomplete version of a final categorical frame in a shared coordinate system. It belongs to a different computational phase.

The best interpretation is **iterative refinement of a spatial planning state**. That state contains information about multiple future horizons at every tick. Recurrence progressively makes the state more useful for downstream choice, rather than advancing a simulated clock one frame at a time.

## 4. The spatial feasibility engine

### 4.1 Feedforward initialization: the spatial “splash”

At the first step of an episode, recurrent memory is zero. This tabula-rasa condition isolates how the model creates a planning state from the board. The initial hypothesis was that the network's global max/mean-pooling pathway seeds the whole board instantaneously. Yet removing the pooling broadcast at the first update reduced action accuracy by only about seven percentage points. The three stacked $3	imes3$ convolutions already create an effective $7	imes7$ receptive field, sufficient to spread a broad description of the small board during the feedforward pass [6].

This feedforward stage should not be mistaken for a complete plan. Freezing the layer-3 cell state at its initial value reduced top-action accuracy from 100% to 29.9%, showing that the recurrent updates are essential. The encoder and stacked convolutions provide a wide spatial “splash”: a smooth heuristic containing geometry, targets, objects, and coarse distances. The subsequent recurrent ticks turn that broad heuristic into a constraint-aware plan.

### 4.2 Local message passing and latent Bellman backups

Transformation probes targeted the update rule itself rather than a static label. A constrained $3	imes3$ convolution with its center weight removed was trained to predict the change in $c_3$ from neighboring cells. It explained $R^2=0.47$ of the native update; shuffling spatial positions reduced this to $R^2=0.17$. Thus, a substantial part of the recurrent computation is genuine local message passing over the Euclidean grid rather than a position-independent channel transformation [6].

The strongest functional test replaced the native layer-3 recurrent update with the extracted linear message-passing operator. This replacement recovered 72.2% top-action accuracy, compared with 59.8% for an identity update and 29.6% for a random-matrix control [6]. The replacement was incomplete but informative. A local, approximately linear propagation rule carries much of the decision-relevant computation. The remaining gap is expected because the linear operator lacks state-dependent gating at walls, boxes, and other topological boundaries.

The term **latent Bellman backup** is appropriate in a restricted sense. Each cell combines information from neighboring cells, and repeated updates propagate estimates over space. However, the represented quantity is not a single scalar reward-to-go. Early probes decoded breadth-first-like distance with moderate $R^2$, while later analyses showed that distance and simple board features explained only a small fraction of final directional affordances [2,5]. The propagated state integrates distance, path membership, obstacle constraints, box manipulation, and longer-range consequences.

### 4.3 Nonlinear boundaries: learned topology rather than blind diffusion

If the recurrent core merely smoothed activations isotropically, walls and boxes would not prevent information from bleeding across impossible routes. Multiple interventions show that physical objects instead create learned topological boundaries.

Natural empty corridors remain highly similar across neighboring cells as recurrence proceeds, whereas the latent states on opposite sides of a box boundary become less similar. More directly, inserting a “ghost” box into an empty corridor—by changing only the encoded board channels—drove adjacent-state cosine similarity from 0.742 at baseline to 0.432 after one update, 0.250 after two, and 0.230 after three. A ghost wall produced a final similarity of 0.254 [8]. These large, monotonic effects demonstrate that the network actively severs spatial propagation when the visual input indicates an obstacle.

At the parameter level, this boundary is implemented by a coupled gate pattern rather than a single switch. Injecting only the layer-2 candidate update at an empty cell recreated 36.7% of a natural obstacle boundary. Injecting all four ConvLSTM gate components at the center recovered 45.1%; expanding to a five-cell cross recovered 66.3%; and a full $3	imes3$ layer-2 packet recovered 70.9% [17]. Adding the corresponding layer-3 packet closed the remaining gap in a later technical analysis, reproducing the ghost-obstacle boundary under that gate-overwrite protocol. Conversely, replacing the natural obstacle packet with an empty-corridor packet caused latent similarity to rise from 0.212 to 0.538 even after the intervention was rescaled to preserve cell-state norm. Boundary formation therefore depends on the angular, multigate structure of the update, not merely on suppressing activation magnitude.

These findings give a mechanistic meaning to “bounded backup.” Neighbor-to-neighbor propagation supplies the backup, while coordinated input, forget, output, and candidate gates impose a learned Dirichlet-like boundary at obstacles.

### 4.4 Continuous heuristic to discrete affordance map

The early and late spatial states have different geometries. Early states support continuous distance-like probes. Final $c_3$ states cluster into a vocabulary of functional categories, including clusters associated with good pushes, bad pushes, deadlocks, and other structural roles [20]. When final-tick cells were assigned to 20 unsupervised centroids, category changes decreased from 7.7% between the first two observed ticks to 5.0% and then 3.8%, indicating convergence toward a stable categorical partition.

Matched-norm centroid interventions provided a causal check. Overwriting a cardinal cell with a “good push” centroid preserved the intended action logit almost exactly, with a mean change of (+0.006), whereas a “bad push” centroid reduced it by (0.211) and matched-norm random vectors reduced it by (0.221) [20]. The useful result is not that clustering discovers a unique symbolic alphabet—20 clusters was an analyst choice—but that on-manifold categorical states have predictable, semantically specific effects unlike generic perturbations.

Spatial autocorrelation explains how the continuous and categorical views coexist. Cells destined for the same final category are smoothed together, while cells destined for different categories are sharpened apart [7,11]. The recurrent core performs **anisotropic diffusion**: it propagates information within functionally coherent regions and blocks it across learned boundaries. The result is a categorical affordance map sculpted from a continuous heuristic.

### 4.5 Fast global constraint communication

Three local recurrent updates cannot always transmit information across the whole board. The architecture supplements local propagation with a mean/max pooling pathway that broadcasts a channelwise global summary back to every spatial location. Removing the layer-3 pooling pathway largely abolished directional affordance crystallization: correlation with the final action rose only from 0.031 to 0.137 across ticks, compared with 0.187 to 0.893 under the native computation [5]. Component decomposition showed that the max-pool portion carried nearly all of the rescue effect in the tested setup [4].

The same pathway communicates global physical constraints. Deadlock states have a distinct, low-variance pooled signature. Replacing a movement state's broadcast with an action-conditioned deadlock direction flipped 20.9% of states to no-op, compared with 1.8% for a mismatched movement control. At states already close to the no-op decision boundary, a calibrated intervention flipped 43.9%, while mismatched and norm-matched noise controls remained near 9–15% [12]. The maxima contributing to this signal were diffuse—approximately 19 distinct spatial coordinates across 32 channels in no-op states—rather than localized to the player or a single obstacle.

The feasibility engine is therefore neither purely local nor purely global. Local convolutional backups preserve spatial topology; gate packets create precise obstacle boundaries; and pooled broadcasts transmit board-wide constraint pressure quickly enough to influence the limited recurrent horizon.

## 5. A persistent multi-step plan rather than repeated replanning from zero

### 5.1 Long-horizon content is real but compressed

Future-position probes establish planning beyond the next action. Full hidden-state accuracy remains 44.4% at five steps, more than three times the 14.2% board baseline [22]. A per-cell “on any of the next five player positions” probe achieves approximately 0.93 AUC from final $c_3$, compared with 0.597 from the board. Regressing board features out of $c_3$ still leaves 0.910 AUC [9]. This is strong evidence that the activation contains trajectory-specific information not reducible to static geometry.

The representation is temporally compressed. Exact-horizon probes in one analysis attained AUC 0.973, 0.945, 0.893, 0.866, and 0.861 for horizons one through five. Near-horizon decoding used roughly ten effective channels, while horizons four and five used about one and a half. The later-horizon probe directions were nearly collinear [9]. The network preserves precise local information for imminent actions and a coarser reachability or route summary for farther steps.

Later channel analyses refine this claim. Five $c_3$ channels—1, 14, 31, 23, and 0—recover most of the *on-path membership* signal, reaching AUC 0.923 versus 0.938 for all 32 channels [15]. Yet these five channels alone are much weaker for exact future position and explicit movement direction. For exact positions, their accuracy declines to 18.3% at five steps, compared with 35.1% for all of $c_3$ and 44.4% for the full hidden tensor [22]. For four-way movement direction at future on-path cells, the five-channel subset averages 34.0%, above board-only performance near 25.4% but far below 68.8% from all 32 $c_3$ channels [23]. The five-channel subspace is therefore best described as a concentrated trajectory **footprint**, not a complete ordered policy field. Rich long-horizon content is distributed across additional channels and layers.

### 5.2 Cross-step persistence

At the first step of an episode, the plan must be generated from a blank recurrent state. Thereafter, the operating regime changes. The final state of one environment step is carried into tick 0 of the next. Probe outputs for the trajectory footprint show perfect identity across this boundary, and raw action-channel signs and values were later found to persist exactly over more than 112,000 player-cardinal cells [9,16]. This resolves an apparent conflict in earlier ablations: erasing cell-state memory *between* steps can leave much behavior intact because the current board allows rapid reconstruction, but erasing the active $c_3$ computation *within* every step is catastrophic. In one all-channel ablation, solve rate fell from 98/100 to 0/100 [9]. Cross-step memory is an efficiency mechanism; within-step spatial computation is essential.

The carried plan is not simply replayed. Direction-change steps produce larger updates than continuation steps. A decoded trajectory mask had mean overlap 0.719 between tick 0 and tick 3 at direction changes, versus 0.766 during continuations, with an enormous sample-level significance and a standardized effect of about (-0.28) [9]. After refinement, the state aligns better with the new ground-truth trajectory than the carried state did. This is the signature of model-predictive control: retain a plan, execute one move, and revise it in proportion to new evidence.

Recent timing analyses add nuance. Event steps—defined by a change from the previous action—produce more activation change than routine steps in plan, board-state, and action channel groups. But routine steps still change appreciably, so the controller is not a strict cache that updates only on rare surprises. Action channels update earliest, board-structure channels next, and the five footprint channels latest, with centers of update mass near 0.70, 0.90, and 0.96 respectively [24]. Plan-channel changes are also concentrated near the player, with mean spatial correlation around (-0.53) between update magnitude and distance from the player. The controller continually refreshes local state, with larger reconfiguration at behavioral events.

### 5.3 Directional translation and refinement

Because the internal state is spatially aligned to the board, carrying it unchanged after the player moves creates a coordinate mismatch. An action-conditioned transformation probe reveals how the network corrects this. A generic $3	imes3$ linear predictor explains $R^2=0.468$ of the first update. Conditioning the predictor on the previous movement raises pooled $R^2$ to 0.611. The learned kernels pull information from the direction opposite the player's motion, exactly as required to realign a player-centered spatial state. This asymmetry appears primarily in the tick-0-to-tick-1 update and largely disappears in later updates [10].

A causal replacement with the extracted translation operator restored 32.5% of the policy-confidence loss caused by deleting the native first update [10]. Linear translation alone cannot run the agent: closed-loop rollouts fail without the native later refinements. But combining a translated carried state with the native remaining ticks preserves full performance in the reported test. The first update is thus best understood as coordinate realignment plus feature transformation; later updates impose current obstacle and path constraints.

This temporal decomposition predicts specific reduced-computation errors, and those predictions are observed. With no recurrent update, 99.4% of navigation errors repeat the previous direction. After one update, pure persistence is reduced, but 66.2% of remaining disagreements move toward the nearest box. Full recurrent computation reduces policy disagreement from 65.2% at zero updates to 25.9% after one, 3.5% after two, and zero by the native final update [13]. Tick 1 solves stale coordinates; ticks 2 and 3 solve global route discrimination.

### 5.4 Nonlinear updates when boxes move

Pure navigation often permits approximate translation of the carried plan. A box push changes topology and requires an additional correction. The residual between the native update and the linear translation operator is about 5.6 times larger at the vacated player tile and the newly occupied box tile than in the background [18].

Injecting a learned visual box feature into the destination of an otherwise ordinary navigation step drives the layer-3 forget-gate preactivation downward by 0.127, compared with (-0.017) for an empty-floor feature and (-0.029) for matched noise [18]. The visual encoder therefore causally triggers a semantic update rather than generic local disruption. The update is channel selective: at a new box location, plan-footprint channels are relatively preserved, while action and constraint channels are strongly suppressed. This makes computational sense. The network must retain context about the intended route and the goal beyond the box, while invalidating immediate movement affordances that would pass through the new obstacle.

At the vacated tile, boundary erasure is active rather than passive. The layer-2 input gate increases by roughly 0.099 relative to ordinary navigation, whereas the forget-gate shift is essentially zero [17]. The network overwrites the old boundary with returning spatial flow; it does not merely “forget” it. Attempts to replace this coupled operation with a post-hoc scalar or channelwise mask generally reduced policy confidence, reinforcing the conclusion that box tracking depends on coordinated gate execution.

## 6. Discrete subgoal competition supplies the long-horizon hierarchy

The spatial feasibility engine and trajectory footprint explain how the agent can route through space, but not how it chooses among several strategically distinct boxes. Sokoban's long-horizon structure is naturally hierarchical: a player may spend many movement steps approaching a box before executing the push that changes the puzzle's combinatorial state. The key late-stage result is that the DRC explicitly represents this hierarchy.

### 6.1 The next box is a linearly accessible macro-action

During navigation phases, each current box was treated as a candidate subgoal and labeled according to whether it became the next box displaced later in the episode. A full-board hidden-state classifier predicted the next box with accuracy increasing monotonically from 79.0% at tick 0 to 85.6% at tick 3, compared with 54.3% from the board alone. More diagnostic localized probes extracted the 224-dimensional activation vector at each candidate box. Their choice AUC rose from approximately 0.941 at tick 0 to 0.960 at tick 3 [19].

This representation cannot be reduced to “choose the nearest box.” Raw player-to-box distance predicts choice at AUC 0.707. A better handcrafted cost is the player's shortest reachable distance to any legal push stance for that box, assigning a large cost when no valid or reachable stance exists. This constraint-aware cost predicts choice at AUC 0.769. Its decodability from the localized hidden vector rises modestly but monotonically from $R^2=0.483$ to (0.496) across the recurrent ticks [19]. The agent therefore evaluates candidate boxes partly through a learned approximation to push feasibility.

The choice probe remains substantially better than either physical cost. This gap is expected. Push-stance distance omits whether a push helps or harms box-target assignment, whether the box will become trapped later, and how moving one box changes access to others. The localized candidate representation combines cost with broader strategic context supplied by the recurrent spatial state.

### 6.2 Causal choice steering is bounded by feasibility

The most informative intervention did not copy donor activations. It derived a choice direction from the linear candidate probe, added that direction at an alternative box, and subtracted it at the naturally selected box across recurrent cell-state layers. A shuffled control preserved the perturbation's value distribution and norm while destroying its spatial semantics.

When the alternative was chosen arbitrarily or as the farthest box, steering was weak. When it was chosen as the highest-scoring nonselected candidate—the model's most plausible competitor—the intervention changed the first pushed box in 27.5% of trials across tested strengths, compared with 13.3% for the shuffled control and 0% spontaneous switching in baseline replays [19]. More important than the aggregate rate was its dependence on the feasibility margin:


| Alternative push-stance cost relative to natural choice | Choice-vector steering success |
|---|---:|
| no greater cost $\Delta C\le0$ | 39.39% |
| greater cost $\Delta C>0$ | 12.96% |
| more than two steps costlier $\Delta C>2$ | 2.38% |


The intervention can tip a close competition, but it cannot reliably force an implausible subgoal through a globally unfavorable spatial field. This interaction is a central causal result. It shows that the discrete box identity is not an unconstrained command variable. Macro-action choice and continuous feasibility are coupled: semantic promotion of a candidate succeeds mainly when the lower-level planner already deems it competitive.

Attempts to improve steering by separately injecting a linear push-stance-distance direction did not outperform the choice direction alone. This negative result is informative. The relevant cost is not represented as a single independently controllable linear axis, or the joint perturbation leaves the native manifold. The causal boundary is clearer at the level of naturally measured cost margins than through direct additive manipulation of the cost probe.

Architectural decomposition further shows that choice steering is not confined to a tiny channel subset. The top 20 cell-state weights recovered only 7 of 22 successful steering cases among cost-plausible alternatives, while the remaining weights produced 18 of 22. Splitting the same choice direction across architectural slices yielded 55% steering for cell-state injection, 50% for hidden-state injection, 17.5% for encoder injection, and 45% when hidden and cell injections were combined at the tested norm and strength [19,25]. The macro-action is therefore distributed across the broader recurrent representation even though lower-level path and action variables occupy compact $c_3$ subspaces.

### 6.3 The chosen subgoal persists across navigation

A true macro-action should survive multiple outer-loop steps. In 100 natural navigation segments ending immediately before a push, the eventual pushed box was the top-scoring candidate on 656 of 759 steps, or 86.43%. It was already top-ranked on 73% of the first observed steps and 95% of the last pre-push steps [19]. The raw target logit was not constant—it often increased as the player approached—so the correct claim is persistent **rank dominance**, not a frozen scalar memory.

The inner loop sharpens this competition. Across 10,000 test states, candidate entropy decreased monotonically from 0.495 at tick 0 to 0.456, 0.412, and 0.383, while the top-versus-second logit margin increased from 2.695 to 2.898, 3.193, and 3.349 [26]. Tick 0 already agreed with the final winner on 88.8% of states, so most steps do not begin in an undifferentiated superposition. The stronger statement holds specifically for ambiguous cases. In the lowest initial-margin quartile, entropy fell by 0.273, compared with only 0.046 in the highest-margin quartile; margin gain was also slightly larger in the ambiguous quartile [27]. Recurrence acts as a competition-refinement process whose contribution is greatest when candidate subgoals are initially difficult to distinguish.

Together, the probing, persistence, temporal sharpening, and cost-bounded steering results establish a genuine hierarchical planning variable. The agent does not merely know where it will move next. It carries a discrete representation of which box it is currently trying to manipulate, and lower-level routing is organized around that commitment.

## 7. From spatial plan to immediate action

### 7.1 Corrected functional specialization

The final layer-3 cell state contains separable plan and action subspaces. An early analysis incorrectly concluded that the trajectory footprint was distributed across all 32 $c_3$ channels because a selected three-channel subset decoded at chance. A reconstruction curve exposed the error: the tested subset omitted channel 14, the second-most informative footprint channel [15].

With channels ranked by an on-path probe, channel 1 alone reaches AUC 0.746; channels 1 and 14 reach 0.880; the top five channels 1, 14, 31, 23, and 0 reach 0.923; and all 32 reach 0.938. A double dissociation then separates this footprint from the immediate action code:


| Feature group | Five-step on-path AUC | Current-action accuracy |
|---|---:|---:|
| five footprint channels | 0.923 | 0.291 |
| two action channels | 0.612 | 0.771 |
| all 32 $c_3$ channels | 0.938 | 0.872 |


The channel groups are also causally relevant. Suppressing the five footprint channels throughout live rollouts reduced solve rate from 98/100 to 73/100, versus 93/100 for a random five-channel control. Suppressing the two action channels reduced it to 46/100. Suppressing all seven reduced solve rate to 2/100, close to full $c_3$ ablation [15]. The corrected architecture is compact specialization, not a distributed-plan/concentrated-action asymmetry.

This does not imply that all planning information is limited to seven channels. Exact multi-horizon position and direction probes show useful information elsewhere. Rather, these channels form compact, causally important bottlenecks for the footprint and immediate action variables.

### 7.2 Player-centered cardinal routing

The layer-3 hidden state is computed as

\[
h_3 = o_3 \odot 	anh(c_3),
\]

where the output gate $o_3$ controls which cell-state content reaches the downstream policy. The gate is player centered and directionally selective. Its mean value is about 1.66 times larger at the player than globally, and it opens preferentially toward the chosen direction. The forward-minus-backward gate difference increases from 0.082 at tick 0 to 0.126 at tick 3 [3].

Causal spatial ablations reveal a sharper result. Closing the gate at all four cardinal cells adjacent to the player reduces solve rate to 0%, while closing the four diagonal cells leaves 93.3% solved, indistinguishable from random-cell controls. Opening every gate uniformly is also catastrophic. Yet closing any single cardinal direction has little effect. The policy requires a structured joint comparison over the cardinal neighborhood, not one privileged action cell [3].

A later post-computation intervention produced an important boundary on this claim: zeroing final $h_3$ values at the four cardinal cells alone did not reduce the 98/100 solve rate, even when all 32 channels at those locations were removed [15]. The two findings target different operations. Gate closure changes how recurrent state is constructed and propagated through the inner loop; final $h_3$ deletion tests whether those exact cells are the only surviving input to the policy head. Their combination indicates that cardinal gating is a causal computational interface during state formation, while the completed action signal is spatially redundant within the broader local representation.

A complementary policy-head ablation shows that the $3	imes3$ window centered on the player is sufficient: retaining that window while deleting the rest of the spatial map preserves a 98% solve rate, whereas deleting the local window reduces solve rate to 6% [4]. The readout is thus global in architectural form but functionally local after the recurrent network has routed relevant information into the player's neighborhood.

### 7.3 Antisymmetric action channels

Two $c_3/h_3$ channels carry the strongest directional code. Channel 22 represents the vertical axis: positive activation at the upper cardinal cell favors up, while negative activation at the lower cell favors down. Channel 3 analogously represents left versus right. A linear model using only cardinal $h_3$ features predicts policy logits with $R^2=0.942$ and action argmax with 93.9% accuracy. Correlations between the appropriate channel-cell pair and its action logit range from about 0.91 to 0.95 [5].

These affordances are not simple wall or distance detectors. Walls, breadth-first distance, and path membership together explain only $R^2=0.14$ of their values, even though the affordances correlate around 0.87–0.93 with the selected action [5]. The directional code is the endpoint of a richer planning computation.

Across inner ticks, the code crystallizes. Representative action correlations rise from roughly 0.16–0.20 at tick 0, to 0.62–0.78 at tick 1, 0.89–0.92 at tick 2, and 0.92–0.95 at tick 3 [5]. The magnitude does not simply grow; the representation aligns with the decision axis. This provides a low-dimensional view of iterative computation: spatial backups and constraint integration progressively write a signed motor preference into a two-channel register.

### 7.4 Reversal, boundary crossing, and commitment

Aggregate “crystallization” hides two regimes. When the initial tendency is already correct, recurrent computation strengthens it. When the local default is wrong, the representation must reverse.

At navigation states where the one-tick and final policies disagree, the cardinal affordance-favored direction flips between ticks 1 and 3 in 65.8% of cases, compared with 13.3% at agreement states. The final affordance aligns with the final action 95.0% of the time. Clamping the two action channels at cardinal cells to their tick-1 values during later ticks blocks 5.7% of overrides, versus 0.4% for control channels and 2.8% for the same channels at diagonal cells [14]. The effect is partial because the policy uses more than eight scalar values, but its channel and spatial specificity place the sign reversal on the causal path.

The reversal has a precise temporal profile. At flipped cells, mean absolute $c_3$ magnitude falls from 0.776 at tick 0 to 0.459 at tick 1 and 0.308 at tick 2, then recovers to 0.379 at tick 3. The final sign first appears on the tick-1-to-tick-2 transition in 78.7% of cases. Policy output becomes correct at tick 2 in 81.4% of override steps, and sign crossing and policy correction agree in 91.9% of matched cases [16].

This is a neural decision-boundary crossing. The carried action register initially contains the previous or locally attractive direction. Translation moves the state toward reconsideration. Constraint-aware refinement drives the relevant signed content through zero. The final tick rebuilds magnitude on the new side of the boundary, consolidating commitment.

The output gate modulates this process but does not determine the sign. Because the gate is sigmoid-valued, it is nonnegative; hybrid-state decompositions confirm that $c_3$ contributes the final sign while $o_3$ contributes a modest magnitude increase of about 5% during overrides [16]. The gate acts as attention and gain control over content written by the cell-state computation.

## 8. The unified algorithm

The full evidence supports the following algorithmic description.

### 8.1 Episode initialization

1. **Encode the board.** Convolutional features identify walls, floors, boxes, targets, and the player. Three stacked convolutions provide a broad receptive field over most of the $8	imes8$ board.
2. **Initialize a continuous heuristic.** Early recurrent states contain smooth distance- and reachability-like information. This heuristic is global enough to orient the solution but does not yet enforce all Sokoban constraints.
3. **Run bounded spatial backups.** Local recurrent kernels propagate state between neighboring cells. Obstacle-conditioned gate packets suppress transmission across walls and boxes. Max/mean pooling broadcasts global constraint pressure.
4. **Form functional regions.** Repeated anisotropic diffusion smooths cells with similar roles and sharpens boundaries between incompatible roles, producing discrete affordances.
5. **Evaluate candidate box subgoals.** At each box location, the network combines constraint-aware push-stance cost with broader strategic context. A competition selects the next box to manipulate.
6. **Write a trajectory footprint and local action.** The winning subgoal organizes a multi-step spatial footprint. Specialized action channels encode a cardinal move, which the player-centered output gate exposes to the policy head.

### 8.2 Subsequent navigation steps

1. **Carry the previous plan.** The final recurrent state persists into the next step, including trajectory and action-related information.
2. **Translate the coordinate frame.** The first recurrent update shifts the carried spatial representation opposite the player's last movement and incorporates the new board observation.
3. **Refine feasibility.** Later ticks recompute obstacle-bounded spatial relationships, especially near the player and at event locations.
4. **Maintain or revise the macro-action.** If the selected box remains feasible, its rank dominance strengthens as the player approaches. If costs or constraints change, candidate competition can switch.
5. **Override local defaults.** The early state tends to repeat the previous action or approach a nearby box. Further backups integrate global path structure and, when necessary, reverse the cardinal action code.
6. **Execute one action and repeat.** The controller advances one step, then uses the updated observation to revise the persistent plan.

### 8.3 Box-push steps

1. Translate the carried plan as in navigation.
2. Detect the topology change through the visual box representation.
3. Install a new obstacle boundary at the box destination using coordinated layer-2 and layer-3 gates.
4. Actively erase the obsolete boundary at the vacated tile through input-gated overwrite.
5. Preserve plan-context channels through the moved box while suppressing action and constraint channels that would license illegal passage.
6. Re-evaluate downstream box competition and continue model-predictive execution.

### 8.4 Formal pseudocode

```text
state P <- zero at episode start
macro_action G <- undefined

for each observed board B_t:
    X <- encode(B_t)

    if t == 0:
        S_0 <- feedforward_spatial_splash(X)
    else:
        S_0 <- carry(P)

    # First active update: align persistent state to the new frame.
    S_1 <- directional_translate(S_0, previous_action)
    S_1 <- incorporate_local_observation(S_1, X)

    # Later active updates: bounded backups and global constraints.
    for k in {2, 3}:
        local_messages <- neighbor_message_passing(S_{k-1})
        boundary_gates <- obstacle_conditioned_gates(X, S_{k-1})
        global_context <- broadcast(max_pool(S_{k-1}), mean_pool(S_{k-1}))
        S_k <- gated_update(S_{k-1}, local_messages,
                            boundary_gates, global_context)

    costs <- push_stance_feasibility(S_3, candidate_boxes(B_t))
    choice_logits <- candidate_context(S_3, candidate_boxes(B_t))
    G <- persistent_competition(G, choice_logits, costs)

    trajectory <- spatial_footprint(S_3, G)
    affordances <- cardinal_action_register(S_3, trajectory)
    action <- local_policy_readout(affordances, player_position(B_t))

    execute(action)
    P <- S_3
```

This pseudocode is intentionally more abstract than the learned tensors. It summarizes the function supported by the interventions without claiming that the network stores explicit variables named `costs`, `trajectory`, or `macro_action`. Each line corresponds to a measured representation or causal mechanism: feedforward spatial initialization, action-conditioned translation, local message passing, obstacle gate packets, pooled broadcasting, push-stance-sensitive candidate choice, persistent box dominance, multi-horizon footprint, and cardinal affordance readout.

## 9. Why this is a planning algorithm

A skeptical interpretation might call the DRC a sophisticated reactive controller. Four findings rule out that description.

First, future-position information remains strong across several distinct horizons and exceeds static-board baselines by large margins. The full hidden state predicts the player five steps ahead at 44.4% accuracy on a 64-cell board, compared with 14.2% from the current board [22].

Second, the network maintains a trajectory-related state across outer-loop steps. A purely reactive policy need not carry an on-path footprint forward with exact identity along measured directions, nor update it more strongly at direction changes [9].

Third, the next manipulated box is represented before the push, remains dominant across multi-step navigation, and can be causally redirected. This is a subgoal extending over many motor actions, not a label for the immediate move [19].

Fourth, reduced recurrent computation produces structured strategic errors. Zero updates repeat the previous action; one update approaches nearby boxes; later updates recover global routing. These are intermediate stages of an iterative planner, not random degradation [13].

The algorithm is also discrete in the sense demanded by the task. Its inputs and hidden activations are continuous, but recurrence produces categorical affordances, a discrete winner among candidate boxes, and a signed cardinal decision. The discrete quantities are not isolated symbols detached from geometry. They are constrained by the continuous feasibility field and updated through spatial dynamics.

## 10. Alternatives, corrections, and negative evidence

### 10.1 Literal future-frame simulation

Rejected. Static persistence inflates future-board accuracy, there is no tick-to-horizon diagonal, and late categorical vectors do not transfer cleanly into early states. The network refines a shared spatial computation rather than displaying future frames.

### 10.2 Pure breadth-first or Euclidean descent

Rejected as a complete account. Distance-like fields are decodable and can weakly attract policy when injected [2], but simple distance and board features explain only a small part of final affordance variance [5]. Push-stance distance improves box-choice prediction over raw distance but remains far below the learned choice probe [19]. The policy incorporates manipulation constraints and global consequences beyond shortest path.

### 10.3 Classical value iteration alone

Incomplete. Local message passing and algorithmic replacement strongly support a Bellman-like component [6]. But classical value iteration does not by itself explain persistent cross-step state, action-conditioned spatial translation, the discrete next-box variable, temporal candidate competition, channel-selective push updates, or the specialized action register.

### 10.4 Direction computed independently of spatial content

Early evidence suggested a nearly independent directional pathway because gate direction was weakly predicted by $c_3$ magnitude and cross-step cell-state erasure could leave navigation largely intact [21]. Later results refine this claim. The output gate indeed supplies spatial attention and magnitude control, but action sign is written in $c_3$, and globally suppressing the action channels or the plan channels degrades behavior [15,16]. The best account is partial separation of concerns, not independence: persistent plan, volatile action content, and gate-based readout occupy specialized but interacting subspaces.

### 10.5 A fully distributed trajectory plan

Corrected. The original conclusion arose from testing the wrong three-channel subset. Five channels recover 98.5% of full on-path AUC, and their suppression causally reduces solve rate [15]. However, exact future position and future direction remain richer in the full representation [22,23]. The corrected statement is that a compact subspace contains the footprint bottleneck, while detailed spatiotemporal information extends beyond it.

### 10.6 Unrestricted semantic vector control

Rejected. Large or temporally mismatched concept vectors frequently produce manifold collapse. Choice-vector steering works best for plausible competitors and fails against large cost disadvantages. Late-tick categorical centroids are inappropriate at early ticks. Successful interventions must respect spatial location, computational phase, norm, and the network's native feasibility constraints.

### 10.7 A strict serial pipeline

Too simple. Timing data show action channels update earliest, board-state channels next, and footprint channels later [24], but same-cell linear prediction does not establish a clean board-to-plan causal chain. Board-state features at tick 1 add unique information beyond the carried plan, yet predict the final plan update worse than the carried plan itself and worse than the static encoder. Routine steps show a similar incremental contribution. The computation is likely a recurrent, partially parallel exchange among specialized groups rather than a one-way sequence of modules.

## 11. Scope, uncertainty, and testable predictions

The strongest conclusions are specific to one trained DRC checkpoint on $8	imes8$ Sokoban. The evidence does not establish that all recurrent agents or all training runs converge on the same decomposition. Several quantities are operational definitions: the five-channel “plan” subspace is defined by a linear on-path probe; the “macro-action” is the next pushed box; and the cost margin uses shortest player distance to a legal push stance, not an exact Sokoban solution cost.

The macro-action evidence is strong but not a complete causal controller. The choice intervention redirects a minority of cases, and its shuffled control is not entirely inert. The effect's dependence on feasibility is more robust than the absolute steering rate. The distributed architectural location of the box-choice variable also remains unresolved: cell- and hidden-state patches both steer, but equal-norm comparisons at one perturbation strength do not uniquely locate the native causal pathway.

The spatial field is well supported, but its scalar semantics should not be overstated. Probes recover distance, value, path membership, topology, and future occupancy with different accuracies. These may be projections of a higher-dimensional state rather than separately stored maps. “Bellman backup” describes the local propagation form and replacement result; it does not imply that each channel represents an explicit scalar value function.

The parameter-level boundary account is detailed but less complete for behavior than for representation. Multi-layer gate packets can reproduce latent boundary formation, and suppressing natural packets induces spatial bleed-through. Yet small sparse gate ablations often leave the final greedy action unchanged, revealing redundancy between channels and pathways. The circuit evidence therefore explains how a topological state is constructed, while the higher-level behavioral necessity is better established by full subspace and spatial-field interventions.

Several predictions follow from the unified algorithm.

1. **Forced subgoal switches should trigger coordinated footprint updates.** If the selected box is causally changed within the feasible set, the five-channel footprint should reorganize toward the new approach route before the first altered push.
2. **Cost-close alternatives should show the largest macro-action volatility.** Natural candidate-rank switches should cluster where push-stance and learned strategic costs are nearly tied.
3. **Translation should be selectively important after movement, not no-op.** Removing the first update should be most damaging when the player changed position and least damaging when the board coordinate frame did not move.
4. **Action reversal should follow nonlocal constraint arrival.** On boards requiring detours, distant obstacle information should become predictive of tick-2 sign crossing through the pooling and recurrent pathways.
5. **The footprint subspace should reorganize after pushes but remain partly preserved through the new box tile.** This follows from the observed channel-selective gate behavior.
6. **Longer-horizon plan content should be coarse and subgoal centered.** Beyond five steps, exact position accuracy should decay smoothly, while box identity or region-level reachability should persist longer.
7. **Training replicas may preserve the algorithm but permute channels.** The functional decomposition—footprint, macro-action, action register, gating—should be more reproducible than the exact channel indices.

These predictions would distinguish the proposed hierarchical controller from both a flat spatial policy and an explicit future-frame simulator.

## 12. Conclusion

The trained DRC agent has learned a coherent planning algorithm. It begins with a broad spatial heuristic, refines that heuristic through recurrent obstacle-bounded message passing, and converts it into discrete functional affordances. It does not discard this computation after every action. Instead, it carries a trajectory-related state across steps, translates it when the player moves, and updates it in proportion to new constraints. This persistent spatial planner evaluates candidate boxes through constraint-aware feasibility. A discrete competition selects the next box-level subgoal, whose rank dominance persists while the player navigates toward a legal push stance. Finally, a compact action subspace writes vertical and horizontal affordances into the player's cardinal neighborhood, where a gated local readout selects the next move.

The central research question can therefore be answered directly. The agent's long-horizon competence is generated by a **hierarchical model-predictive algorithm**:

\[
	ext{bounded spatial backup}
\;\rightarrow\;
	ext{feasibility-aware box competition}
\;\rightarrow\;
	ext{persistent trajectory execution}
\;\rightarrow\;
	ext{cardinal affordance action}.
\]

The spatial backup is continuous and approximately Bellman-like; the box choice and action decision are discrete; the trajectory state supplies temporal persistence; and recurrent gating binds the levels together. This hybrid design explains how a model-free neural policy performs planning without an explicit symbolic search module. It also explains the limits of simple probes and naive interventions: a concept is behaviorally effective only when inserted at the right phase, location, subspace, and level of the hierarchy.

## References

1. Axiom I. *Rethinking Emergent Planning: From Spatial Entity Isomorphism to Distributed Value Computation.* Archived paper in the supplied evidence corpus.
2. Episteme I. *Iterative Value Propagation and the Geometric Distance Attractor.* Archived paper in the supplied evidence corpus.
3. Kairos I. *The Output Gate as Directional Affordance Router: Cardinal-Specific Spatial Attention in a Trained Planning Agent.* Archived paper in the supplied evidence corpus.
4. Tenax I. *Iterative Global-to-Local Coordination via Max-Pool Broadcast in DRC Spatial Planning.* Archived paper in the supplied evidence corpus.
5. Tenax I. *Directional Affordance Crystallization: How Iterative Computation Builds Action Preferences at Cardinal Cells.* Archived paper in the supplied evidence corpus.
6. Axiom II. *Unmasking the Oracle: How Deep Recurrent Networks Plan via Latent Bellman Backups.* Archived milestone paper in the supplied evidence corpus.
7. Episteme II. *Anisotropic Spatial Diffusion and the Temporal Manifold Boundary in DRC Planning.* Archived paper in the supplied evidence corpus.
8. Episteme II. *Causal Induction of Diffusion Boundaries via Ghost Obstacles.* Archived paper in the supplied evidence corpus.
9. Kairos II. *Model-Predictive Control Dynamics in DRC Planning: Persistent Trajectory Representation with Event-Triggered Updates.* Archived paper in the supplied evidence corpus.
10. Axiom II. *The Emergent Planning Algorithm of the DRC Agent: A Synthesis of Generative Diffusion and Directional Translation.* Archived milestone paper in the supplied evidence corpus.
11. Episteme II. *The Emergent Spatial Planning Algorithm: From Continuous Fields to Categorical Affordances.* Archived milestone paper in the supplied evidence corpus.
12. Principia II. *The Global Transmission of Physical Constraints via Max-Pool Broadcasting.* Archived paper in the supplied evidence corpus.
13. Nexus I. *The Bellman Backup as Navigation Router: Iterative Computation Overrides Sequential Defaults in DRC Planning.* Archived paper in the supplied evidence corpus.
14. Nexus I. *Cardinal Affordance Reversal: The Representational Mechanism of Navigation Override in DRC Planning.* Archived paper in the supplied evidence corpus.
15. Kairos II. *Concentrated Plan, Concentrated Action: Correcting the Distributed-Plan Hypothesis in c3.* Archived paper in the supplied evidence corpus.
16. Nexus I. *Temporal Dynamics of Decision-Boundary Crossing in the DRC Action Subspace.* Archived paper in the supplied evidence corpus.
17. Episteme III. *Parameter-Level Execution of the Coupled Boundary Packet.* Archived paper in the supplied evidence corpus.
18. Axiom III. *The Parameter-Level Geometry of Box Push Dynamics: Visual Causality and Channel Specialization in Tracking Boundaries.* Archived paper in the supplied evidence corpus.
19. Gestalt I. *The Emergent Planning Algorithm: Discrete Subgoal Competition Bounded by Spatial Value Iteration.* Archived paper in the supplied evidence corpus.
20. Episteme II. *Unsupervised Discrete Affordance Mapping: Categorical Convergence in DRC Planning.* Archived paper in the supplied evidence corpus.
21. Kairos I. *The Emergent Planning Algorithm: Decoupled Attention-Content Routing in the DRC Sokoban Agent.* Archived milestone paper in the supplied evidence corpus.
22. Nexus II. *Multi-Step Future Position Probing: Does DRC Represent Planned Trajectories?* Technical report in the supplied evidence corpus.
23. Kairos III. *Directional Content in Plan Channels: Do c3 Plan Channels Encode Movement Direction at On-Path Cells?* Technical report in the supplied evidence corpus.
24. Kairos III. *Computational Order Across Ticks: Do Board-State Channels Update Before Plan Channels at Event Steps?* Technical report in the supplied evidence corpus.
25. Gestalt I. *Architectural Decomposition of the Macro-Action: Steering via Hidden vs Cell States.* Technical report in the supplied evidence corpus.
26. Gestalt I. *Inner-Loop Competition Dynamics: Superposition and Collapse of Candidate Subgoals.* Technical report in the supplied evidence corpus.
27. Gestalt I. *Ambiguity Resolution in Inner-Loop Dynamics: Stratifying Superposition Collapse.* Technical report in the supplied evidence corpus.
28. *Research Task: Finding a Discrete Emergent Planning Algorithm from a Trained Sokoban Agent.* Primary task and activation-schema specification in the supplied evidence corpus.
