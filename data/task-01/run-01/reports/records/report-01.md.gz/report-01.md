# A Hierarchical Receding-Horizon Algorithm Emerges in a Recurrent Sokoban Agent

## Discrete box-level subgoal competition, obstacle-gated spatial value propagation, persistent route tracking, and volatile action writing

### Abstract

How does a model-free recurrent neural policy solve Sokoban, a domain in which a locally legal move can irreversibly destroy a solution many steps later? We synthesize a large body of concept-probing, causal-intervention, ablation, algorithm-replacement, and temporal-dynamics evidence from one trained Deep Repeating ConvLSTM agent on 8×8 Sokoban boards. The central conclusion is that the agent does not plan by literally unrolling future video frames, nor by applying a single homogeneous value-iteration rule. It implements a hierarchical, receding-horizon algorithm with two coupled levels. At the higher level, boxes are treated as discrete candidate subgoals. The latent state assigns each candidate a constraint-aware feasibility cost related to the player’s distance to a legal push stance, ranks plausible boxes, and maintains the winning box across the navigation phase. At the lower level, a compact spatial route field is carried between environment steps, translated after the player moves, and refined by recurrent, obstacle-gated local message passing. Physical walls and boxes create nonlinear boundaries in this field; box pushes trigger channel-selective boundary updates. The refined field is converted into action through a small specialized subspace: approximately five cell-state channels carry most linearly decodable trajectory information, whereas two different volatile channels encode vertical and horizontal affordances. When the agent must reverse an initially attractive but globally wrong move, those action channels approach zero, cross sign primarily during the second recurrent update, and then rebuild magnitude in the new direction. Causal evidence closes the loop. A learned neighbor-to-neighbor transition partially replaces the native recurrent update; hallucinated obstacles sever latent spatial continuity; localized box-choice interventions redirect which box is pushed, but only when the alternative is competitive in the feasibility field. Steering succeeds in 39.39% of cases when the alternative box is no more costly than the natural target, falls to 12.96% when it is costlier, and to 2.38% when its push-stance disadvantage exceeds two steps. The resulting mechanistic description is: discrete subgoal competition bounded by a dynamically maintained topological cost field, followed by model-predictive route execution and discrete affordance readout. This account explains long-horizon behavior, recurrent computation depth, apparent conflicts between decodability and causal necessity, and the characteristic progression from action persistence to box attraction to globally appropriate navigation.

**Keywords:** mechanistic interpretability; planning; reinforcement learning; Sokoban; ConvLSTM; causal intervention; concept probing; value iteration; model-predictive control; hierarchical control

## 1. The question is not whether the policy contains plans, but what kind of plan it computes

Sokoban is deceptively small. A board contains walls, floor, targets, movable boxes, and a player. The player can walk through free floor and can push, but not pull, a box. This asymmetry makes the task fundamentally prospective. A box pushed into a corner or against the wrong wall can render the puzzle unsolvable even if the move appears locally productive. Competent play therefore requires more than collision avoidance or one-step action prediction. It requires selecting which box to manipulate, reaching a valid side of that box, preserving future access, and revising the route as the board changes.

The agent studied here is a Deep Repeating ConvLSTM network, abbreviated DRC. Its input is a seven-channel 8×8 board tensor. Its recurrent core contains three convolutional LSTM layers with 32 hidden channels and 32 cell-state channels per layer. Within each environment step, the same recurrent machinery is applied repeatedly, producing four recorded internal states: an incoming state and three successive updates. The complete recorded activation at each internal stage has 224 channels: hidden and cell states for the three layers, followed by a 32-channel visual encoding. The architecture therefore exposes two timescales. The outer timescale is the sequence of moves in the environment. The inner timescale is repeated computation while the board is held fixed.

That design invites a strong hypothesis: perhaps each inner update corresponds to one imagined future step. On this view, the network would function like a compact video simulator, with the first recurrent update predicting the next board, the second predicting the board after that, and so forth. Early experiments made this proposal plausible because future player and box locations were linearly decodable and because adding a learned “box” direction to an empty tile could deter movement toward it. Yet the accumulated evidence rejects literal frame-by-frame unrolling. Later inner states improve predictions for many future horizons simultaneously, not diagonally. The network represents where a route goes much more clearly than when each cell will be visited. Static board persistence also makes future-pixel prediction deceptively easy: the visual encoder alone predicts much of a future board because most walls, targets, and boxes do not move on most steps.

The central research question must therefore be sharpened. What abstract algorithm is implemented by the recurrent computation? A satisfactory answer must connect four levels that are often studied separately:

1. **Long-horizon intent:** what future object or configuration is the agent trying to reach?
2. **Spatial computation:** how does it determine whether and how that intent is physically feasible?
3. **Temporal maintenance:** how is the plan preserved and updated from one environment step to the next?
4. **Action readout:** how does a distributed spatial computation become one of five discrete actions?

The evidence supports one integrated answer. The DRC is a hierarchical receding-horizon controller. It converts the board into a set of candidate box-level macro-actions; evaluates those candidates using a constraint-aware spatial cost field; preserves the winner during approach; maintains and repairs a spatial route as the state changes; and writes the immediate action into a compact, volatile affordance subspace. The terms in this description are used precisely:

- A **macro-action** is the selection of the next box to be pushed, not a complete fixed sequence of primitive moves.
- A **push stance** is a player location adjacent to a box from which a legal push can be executed into an unoccupied non-wall destination.
- A **spatial field** is an 8×8 map represented across recurrent channels whose local values encode reachability, route membership, constraints, or action affordances.
- A **Bellman-like backup** is local neighbor-to-neighbor propagation that improves a spatial decision field through repeated updates. The term is functional: the learned update resembles bounded dynamic programming, not an exact hand-coded Bellman equation.
- **Model-predictive control** means carrying a plan forward, executing one action, observing the new board, and refining the plan rather than committing to an immutable open-loop sequence.

The remainder of the paper develops this algorithm from the evidence rather than recounting studies chronologically. The most important pattern is that every level constrains the next. Box identity can be causally manipulated only inside the feasible cost manifold. The route field can be linearly approximated only until nonlinear obstacle boundaries matter. The action subspace can carry stale momentum only until recurrent refinement reverses it. Planning emerges from these constrained interfaces, not from a single all-purpose representation.

## 2. Evidence strategy: probing generates hypotheses; interventions decide which hypotheses survive

The analysis uses a fixed activation corpus containing 3,000 training episodes with 106,990 transitions and 1,000 test episodes with 36,697 transitions. Each transition includes the board tensor, the four-stage 224-channel activation tensor, the chosen action, value estimate, return, reward, board index, and position within the episode. Live causal studies replayed the trained policy in the corresponding Sokoban environment with frozen parameters. No claim in this synthesis depends on external literature or newly generated experimental results.

The evidence falls into five complementary classes.

### 2.1 Linear concept probes

Spatial probes used 1×1 convolutions or per-cell linear models so that prediction at a board coordinate depended on the latent vector at that same coordinate. Global probes used spatial pooling or flattening followed by a linear classifier. Targets included future player location, future-path membership, dynamic box destination, geometric distance, distance to a legal push stance, next pushed box, immediate action, and later push direction. Linear probes were deliberately weak. High performance indicates that a variable is explicitly readable, but not that it is causally used.

This distinction became essential. Future-path membership can be decoded from the third-layer cell state with area under the ROC curve near 0.97, yet projecting out a path-probe direction did not produce a specific behavioral deficit, and resetting all cell states between environment steps preserved most solves. Conversely, hidden-state perturbations with only modest probe-level interpretation could strongly affect action because hidden states lie directly on the policy-readout path. Throughout this paper, decodability is treated as a map of candidate mechanisms, never as proof by itself.

### 2.2 Causal activation interventions

Interventions added, subtracted, suppressed, or replaced activation directions at chosen spatial coordinates. Strong controls included same-norm random vectors, spatially shuffled versions of the same patch, semantically irrelevant coordinates, sign reversals, and alternative concept directions. The most informative interventions preserved as much of the original activation geometry as possible. Large arbitrary perturbations often changed behavior by destroying the latent manifold rather than by writing a meaningful concept.

The decisive causal tests in the final account are not donor–recipient substitutions. They either manipulate a learned semantic direction within the same state, change the board input in a controlled way, clamp a gate or state component, or replace a recurrent transition with an extracted mathematical operator.

### 2.3 Structural ablations

Ablations tested which architectural pathways matter: removing recurrent updates, resetting hidden or cell memory, suppressing global pooling broadcasts, opening or closing output gates, and retaining only selected spatial windows or channel groups. These studies establish necessity at the component level. They also reveal redundancy. A representation can be naturally persistent and behaviorally important without any single channel, spatial cell, or memory pathway being individually necessary.

### 2.4 Transformation probes and algorithm replacement

Static probes ask what a state contains. Transformation probes ask what function maps one state to the next. A particularly important model constrained a 3×3 convolution to have a zero center weight, forcing it to predict the next cell-state change using neighboring hidden states only. This neighbor-only operator explained substantially more of the true update than spatially shuffled controls. Replacing native recurrent updates with the learned operator recovered policy accuracy above frozen-state and random-operator baselines. This is stronger than decoding because it tests whether an explicit candidate algorithm can substitute for part of the network computation.

### 2.5 Temporal counterfactuals

The four recorded inner states permit counterfactual policy readout at different computational depths. Reading the policy before any new inner update, after one update, after two, and after all three exposes a computational sequence. These comparisons do not merely measure “more compute is better.” They reveal qualitatively different default policies at each stage: first repeat the previous direction, then approach a salient box, then incorporate global path constraints.

Together these methods support a hierarchy of confidence. Repeated probe results establish that a variable is available. Matched causal interventions establish semantic leverage. Ablation establishes necessity or redundancy. Algorithm replacement establishes partial functional equivalence. Temporal analysis establishes order. The proposed algorithm relies most heavily on claims supported by at least two of these forms.

## 3. The first major rejection: inner ticks do not enumerate future frames

A literal rollout model makes a clear prediction. If inner computation stage (k) represents environment time (t+k), probe accuracy should form a temporal diagonal: early inner states should best predict near futures, later inner states should best predict farther futures. This pattern is absent.

When linear probes predict future boards or future player positions, the final inner state is generally best at all horizons. In one controlled sweep, explicit future-position top-1 accuracy fell from 0.674 at one step ahead to 0.178 at four steps ahead, but the final inner state remained best throughout. For trajectory-position decoding from the third-layer cell state, accuracy improved across inner computation at every tested horizon: at one step ahead it rose from 71.6% to 88.1%; at five steps ahead it rose from 28.5% to 36.0%. The logarithmic decay with horizon remained almost constant across ticks, about (-0.23). Recurrent updates therefore refine a shared spatial object rather than advance a simulation clock.

The representation is better characterized as an aggregated footprint or route field. A per-cell probe trained to classify whether a cell will be visited within the next several steps achieves high AUC, reaching about 0.93 for a five-step horizon and remaining above 0.90 after removing the small component predictable from current-board features. Future-path maps remain strongly decodable at horizons up to ten steps. Yet regression on time until visit is weak, with correlation near 0.11 in an early analysis. The state says “this region belongs to the intended route” much more clearly than “this cell will be occupied exactly three moves from now.”

Dynamic object evidence reaches the same conclusion. A target restricted to empty cells that a box will enter within four future steps becomes increasingly decodable across recurrent computation, with intersection-over-union rising from 0.267 to approximately 0.435. Suppressing the corresponding representation at an intended box destination reduces the immediate push probability. Thus the network represents future consequences of manipulation, but it combines them into spatial footprints rather than a sequence of complete future boards.

This distinction matters algorithmically. A literal rollout must preserve entity identity and temporal order across hypothetical frames. An aggregated route field can instead support a form of dynamic programming: mark regions that lead toward a goal, sharpen them around obstacles, and repeatedly read the best local direction. The latter is cheaper, more robust, and consistent with all later causal evidence.

## 4. The high-level plan is a discrete competition among boxes

Route fields explain how to reach a target, but Sokoban also requires deciding which target to pursue. On boards with several boxes, “move along the current path” is underspecified until one box has been selected as the next object of manipulation. The strongest late evidence identifies this missing hierarchical variable.

### 4.1 The next pushed box is explicitly represented well before the push

Navigation-phase states were defined by looking ahead to the first future transition in which a box moved and excluding immediate pushes. A linear classifier predicted the source coordinate of that future push from the full hidden tensor. The current board alone achieved 54.29% accuracy, showing that geometry already constrains box order. Hidden activations were much more informative: accuracy increased monotonically from 79.01% in the incoming recurrent state to 85.62% after the final inner update. The gain over the board baseline was 31.34 percentage points.

The representation is spatially localized. If the 224-dimensional latent vector is sampled at each box coordinate and classified as chosen versus unchosen, ROC-AUC rises from 0.940 at the incoming state to about 0.960 at the final state. This is not merely a global board classifier whose information happens to be recoverable everywhere. Each candidate box location carries a locally readable choice score.

Static geometry explains part, but not all, of the choice. Ranking boxes by raw player-to-box distance produces AUC 0.707. The localized latent choice score reaches about 0.960. Moreover, the simple distance representation does not sharpen across inner computation: linear decoding of player-to-box distance stays near R² = 0.56–0.57. Choice, by contrast, sharpens steadily. The recurrent process is not just estimating proximity; it is transforming geometry into a task-specific candidate ranking.

### 4.2 The relevant cost is access to a valid push stance

Raw distance to a box ignores Sokoban’s central asymmetry. The player cannot pull a box and cannot push it from an arbitrary adjacent tile. For each candidate box, a more faithful feasibility cost is the shortest path from the player to any adjacent stance from which the box can be pushed into a legal destination. This push-stance distance folds walls, other boxes, approach direction, and immediate push legality into one scalar.

The localized box vector linearly encodes this cost with held-out R² increasing from 0.483 at the incoming state to 0.496 after the final recurrent update. The numerical increase is modest, but the target is meaningfully more predictive of choice than raw distance: push-stance distance ranks the chosen box with AUC 0.769, compared with 0.707 for player-to-box distance. The choice probe still performs much better, near 0.960, implying that feasibility cost is a major input to the competition rather than the entire decision rule.

This is the first discrete layer of the emergent algorithm. The controller partitions the continuous board into a finite set of box candidates, associates each candidate with a physically grounded cost, and produces a categorical winner. The winner is a macro-action because it remains meaningful across many primitive walking steps.

### 4.3 Choice is persistent dominance, not a frozen scalar

A true macro-action should remain stable while the player approaches the chosen box. Across 100 natural navigation segments comprising 759 steps, the eventual pushed box had the highest choice logit on 86.43% of all steps. It was already top-ranked on 73% of first segment states and reached 95% immediately before the push.

The raw choice logit was not numerically constant. Its within-trajectory variance, 3.72 on average, exceeded the variance of the strongest alternative, 0.89. Example traces show why: the target logit often rises as the player approaches. The correct interpretation is therefore persistent **rank dominance with increasing commitment**, not memory of an invariant scalar. The macro-action is maintained while its evidence is continuously updated.

### 4.4 Causal steering reveals that identity is subordinate to feasibility

Decoding a chosen box does not prove the representation controls behavior. Causal tests localized a learned choice direction at box coordinates: add the direction at an alternative box, subtract it at the natural target, and inject the resulting patch into recurrent cell updates during the first 20 steps of rollout. A spatially shuffled patch preserved the same values and norm but destroyed their semantic coordinate assignment.

With delayed-push boards and arbitrary alternatives, targeted patches redirected the first pushed box in 7 of 40 runs, whereas shuffled controls succeeded in none. The effect was real but modest. A follow-up using the farthest alternative tested a stronger “identity plus lower cost” patch. The combined patch did not beat identity alone: 5 of 60 versus 6 of 60 successes. This negative result is important. The feasibility computation is not a scalar knob that can be cleanly overwritten by adding a linear distance vector.

The decisive experiment selected the alternative box with the highest natural non-winning choice score—an internally plausible competitor—and stratified outcomes by its push-stance cost relative to the natural target. Across 40 boards and three intervention strengths, the targeted identity patch redirected the first push in 33 of 120 runs, compared with 16 of 120 for a shuffled control. More importantly, success depended sharply on cost margin:

| Alternative-box cost relative to natural target | Targeted steering success |
|---|---:|
| Equal or cheaper push-stance cost | 39.39% |
| Any positive cost disadvantage | 12.96% |
| More than two steps costlier | 2.38% |

The identity intervention therefore has causal leverage, but only inside a manifold licensed by the global feasibility computation. Local categorical evidence can break a near tie; it cannot ordinarily force the policy to pursue a geometrically implausible box. This asymmetric relationship—cost bounds identity rather than identity freely overriding cost—is the clearest answer to how discrete choice and continuous spatial computation interact.

The macro-action representation also differs from the compact route and action subspaces described below. Selecting the 20 largest choice-probe weights within the cell-state channels recovered only 7 of 22 full-patch successes on equal-or-cheaper competitors. The remaining channels achieved 18 of 22, even exceeding the full patch in that sample. Thus the causally effective choice direction is distributed at the tested intervention site. High-level identity is a population-level pattern, while lower-level route and action variables are more concentrated.

## 5. The low-level planner is bounded spatial message passing

Once a box-level subgoal is selected, the agent must compute how to approach it. Three results identify the core operation: local transformation probes, algorithm replacement, and causal boundary induction.

### 5.1 A neighbor-only operator predicts the recurrent update

On the first step of an episode, recurrent memory begins from zero. This tabula-rasa regime isolates plan generation from cross-step persistence. The initial feedforward stack produces a broad spatial seed: ablating the global pooling broadcast at the first update reduces accuracy only modestly, and stacked 3×3 convolutions already provide a wide receptive field. Yet the seed is not sufficient. Freezing the third-layer cell state before recurrent refinement reduces action match from 100% to 29.9% in a fixed-state replay, demonstrating that the plan is constructed through the inner updates.

A transformation probe was constrained to predict the change in the third-layer cell state from neighboring third-layer hidden vectors using a 3×3 convolution whose center weight was fixed to zero. It reached R² = 0.47. Spatially shuffling the grid reduced R² to 0.17, showing that the predictive power depends on true board topology rather than generic channel mixing.

The learned transition was then inserted into the network. The first recurrent update remained native, but the next two third-layer cell updates were replaced by

`c3[k+1] = c3[k] + Conv2D_neighbor(h3[k]; W_nbr)`

Here `W_nbr` is the learned zero-center convolution, and the native output gate still produced `h3[k+1] = o3[k+1] ⊙ tanh(c3[k+1])`. The replacement recovered 72.2% top-1 action match. A frozen-state control reached 59.8%; a matched random neighbor operator reached 29.6%; the native network reached 100%. The explicit operator therefore captures functionally relevant local message passing, but not the entire computation.

Calling this operation a latent Bellman backup is justified in a limited, mechanistic sense. Each spatial cell receives information from neighboring cells, repeated application propagates reachability or route evidence, and policy quality improves as the propagation proceeds. It is not an exact scalar value iteration because the state is vector-valued, the updates are gated and anisotropic, and categorical subgoal information interacts with the field.

### 5.2 Obstacles provide nonlinear boundary conditions

The linear replacement’s 27.8-point gap to the native policy is not noise. A fixed convolution indiscriminately spreads information and therefore “bleeds” through walls and boxes. The native ConvLSTM gates impose the missing topological boundaries.

Natural empty corridors show high similarity between adjacent latent cell vectors, whereas boundaries involving a box are sharply less similar. A causal input intervention makes this contrast decisive. Turning an empty corridor cell into a hallucinated box while holding the incoming recurrent state fixed leaves the baseline initial cosine similarity unchanged at 0.742, then drives it to 0.433 after one update, 0.250 after two, and 0.230 after three. The corresponding unmodified corridor ends near 0.747. A hallucinated wall produces a comparable final severing. The network therefore reads physical geometry and actively cuts message-passing edges at obstacles.

Gate-level interventions identify a distributed boundary packet in the second ConvLSTM layer. Overwriting only the central candidate-update gate reproduces 36.7% of the boundary effect. Overwriting all four gate components at the center yields 45.1%; extending the packet to a five-cell cross yields 66.3%; extending it over the full 3×3 footprint yields 70.85%. Conversely, replacing a natural box’s 3×3 packet with an empty-corridor packet—while rescaling the state to preserve its norm—raises cross-boundary similarity from 0.211 to 0.538. The boundary depends on the angular pattern of the coupled gates, not merely reduced activation magnitude.

These findings refine the Bellman-backup description. The recurrent core performs anisotropic, obstacle-gated message passing. Empty regions smooth and propagate a continuous heuristic; walls and boxes instantiate learned boundary conditions that split the field into distinct topological regions. This is the mechanism by which Euclidean-looking early gradients become legal Sokoban affordances.

### 5.3 Global broadcasting accelerates a locally implemented algorithm

Three recurrent updates with 3×3 kernels cannot communicate arbitrarily across an 8×8 board by local propagation alone. The architecture supplements convolution with a broadcast derived from spatial mean and maximum hidden activations. Removing that broadcast at any single inner update is usually benign, but removing it from all updates collapses solve rate from 98% to 14%. Two recurrent updates with broadcast retain 98% solves; two updates without broadcast retain only 18%. The third layer is the critical site: removing its broadcast lowers solve rate to 32%, whereas removing the first or second layer’s broadcast alone is much less harmful.

The maximum component carries nearly all of the effect. Retaining only the third-layer maximum rescues 99.8% of the lost return; retaining only the mean rescues 5.4%. A matched random broadcast is worse than no broadcast, demonstrating semantic interpretation rather than generic excitation. Although third-layer maxima are not simply a one-hot pointer to the player, they are player enriched: 8.5% of channel maxima occur at the player compared with the player’s much lower board prevalence, and activation magnitude at the player is 2.16 times that at other cells on average.

Later evidence expands the role of this mechanism. In states where the policy chooses no operation because movement is constrained, the broadcast has a distinctive, low-variance signature. Adding the difference between the no-operation and movement broadcasts to boundary states flips the policy toward no-operation in 43.9% of cases near the manifold-optimal intervention scale, while mismatched movement and norm-matched noise controls remain far weaker. The maxima arise from roughly 19 spatial coordinates per state, not one obstacle or player location. Global broadcasting therefore carries a distributed summary of topological pressure. It allows local gates to condition their updates on board-wide constraints within a small number of recurrent iterations.

The low-level planner is consequently neither purely local nor globally dense. Its computational primitive is local message passing, but each local update receives a global summary. This hybrid design explains how the network can produce board-wide effects quickly while preserving spatially precise obstacle boundaries.

## 6. Planning after the first move: carry, translate, and repair

The tabula-rasa analysis describes how a plan is generated at the start of an episode. Most decisions occur later, when the recurrent state already contains the previous step’s computation. In that tracking regime, the agent behaves like a receding-horizon controller.

### 6.1 Natural persistence is exact along important readout directions

The incoming third-layer cell state at a new environment step is the final state from the previous step. Under trajectory-probe readout, the predicted mask transfers with intersection-over-union and logit cosine both equal to 1.000. In the two specialized action channels, raw cross-step sign and Pearson correlation are also exactly 1.000 over 112,951 cardinal-cell comparisons. The controller therefore begins each step with a carried plan and carried action tendency.

Persistence does not mean immobility. Within the next environment step, 44.8% of cardinal action-channel signs change. Trajectory masks update more at direction changes than during continuation: decoded overlap falls to 0.719 at changes versus 0.766 during continuations, a highly reliable difference. After the update, the state better matches the new future route than the carried state does. The controller preserves what remains useful and spends computation where the observation demands revision.

This is model-predictive control in a concrete representational sense. The agent maintains a plan, executes one primitive action, carries the plan to the next state, then refines it using the new board. At the start of an episode the same recurrent machinery builds a field from near-zero state; thereafter it updates a warm start.

### 6.2 The first update translates the carried coordinate frame

Movement changes the player’s position relative to the board. A carried player-centered plan is therefore spatially stale even if its strategic content remains valid. Transformation probes conditioned on the previous action reveal an explicit translation signature in the first update. An unconditioned 3×3 model explains about 46.8% of the update variance; conditioning on whether the player previously moved up, down, left, or right raises explained variance to 61.1%. The learned kernels draw most strongly from the direction opposite the movement, precisely what is required to realign a spatial field after the player advances. This directional asymmetry is present in the first update and largely disappears in subsequent updates.

Ablating the first third-layer update reduces the mean probability of the natural action by 0.0227 with a paired (z)-score of 11.75. Inserting the extracted translation operator restores 0.00740 probability points, or 32.5% of the loss at its best scale. This is meaningful partial recovery, not exact replacement. The native update simultaneously translates, transforms features, and interacts with nonlinear gates. The evidence supports translation as a real component of the first update, but not as a complete description of it.

### 6.3 Later updates repair topology and resolve global routing

After translation, the map must be reconciled with the current board, especially if a box moved. The second and third updates reapply obstacle-gated message passing and global constraint broadcasts. Purely linear translation across a full rollout fails, whereas restoring native later refinement returns solve rate to baseline in the tested setting. The tracking algorithm is therefore:

1. carry the previous latent plan;
2. shift it into the new coordinate frame;
3. rebuild boundaries and local route values where the board changed;
4. emit the next action;
5. carry the refined result onward.

Box pushes reveal why nonlinear repair is essential. Translation alone would move a previously traversable representation into the newly occupied destination of the box. The visual encoding of a newly pushed box causally lowers the third-layer forget-gate preactivation at that tile by 0.127, far more than empty-floor or matched-noise features. The update is channel selective: at the new box tile, the forget gate preserves plan-related channels at mean activation 0.374, strongly erases the two action channels at mean 0.098, and nearly zeros a separate set of constraint channels. The network does not erase all information at an obstacle. It preserves context about the route and target while suppressing signals that would authorize an illegal immediate move.

At the vacated box origin, boundary removal is active rather than passive. The forget gate barely changes; instead, the input gate increases by about 0.098 during the first update, overwriting the old boundary with the returning continuous field. This is an elegant implementation of dynamic topology: create a boundary at the new box location, flood the old location with updated reachability, and retain higher-level route context across both.

## 7. The recurrent depth is a sequence of increasingly informed defaults

The temporal counterfactuals make the algorithm behaviorally legible. The policy can be read before the current step’s recurrent updates, after one update, after two, and after all three. At states where these policies disagree, each depth has a characteristic error mode.

### 7.1 Before updating: continue the previous action

At zero-update navigation disagreements, 99.4% of errors repeat the previous movement direction. The correct final action is usually orthogonal to the previous action, indicating that these are turn-requiring states. This is exactly what cross-step persistence predicts: the incoming action channels still encode the prior step’s affordance. Without computation, the policy simply continues.

### 7.2 After translation: approach the nearest salient box

One recurrent update largely resolves stale coordinates, reducing the navigation disagreement rate from 65.2% to 25.9%. The remaining errors are no longer pure persistence. Among them, 66.2% move toward the nearest box, whereas the final policy moves toward that box in only 27.4%. At these disagreement states, 55.5% of one-update actions attempt a push, compared with 5.8% at agreement states. The bias is strongest when a box is one tile away and declines with distance.

This box-attraction default is not arbitrary. After translation, the policy has current local geometry and sees the objects it is trained to manipulate, but the global route field has not yet fully incorporated approach-side constraints and detours. Moving toward a box is often useful and provides a sensible cheap heuristic. Sokoban’s difficulty lies in the exceptions: the player may need to walk away from the box, circle around it, or approach a different box first.

### 7.3 After refinement: select the globally appropriate route

With two updates, disagreement falls to 3.5%; after all three it reaches zero by definition relative to the full policy. The recurrent computation therefore overrides two defaults in sequence:

`continue prior direction → approach salient box → follow globally feasible route`

Live reduced-compute rollouts confirm behavioral importance. Three updates solve all 50 boards in one study. Two updates solve 94%; one update solves 56%. Push actions themselves are surprisingly robust: under a one-update counterfactual they match the full policy 84.1% of the time, compared with 74.1% for navigation actions. Yet push-heavy episodes fail disproportionately when computation is reduced because navigation mistakes place the player on the wrong side of boxes and accumulate into irreversible configurations.

The inner loop is thus not primarily deciding whether to push once the player is already correctly positioned. Local geometry often makes that action obvious. Its distinctive contribution is navigation discrimination and future push coordination: deciding how to position the player so that a later push is possible and useful.

## 8. A compact route subspace and a separate volatile action subspace

The third-layer cell state is not a homogeneous “planning tensor.” Channel-level reconstruction reveals a compact functional organization that corrects an earlier interpretation.

### 8.1 Most trajectory information is concentrated in five channels

A linear per-cell classifier for five-step future-path membership reaches AUC 0.938 using all 32 third-layer cell channels. Ranking channels by the absolute weight of that probe and retraining on subsets yields a steep reconstruction curve:

| Number of best-ranked channels | On-path AUC |
|---:|---:|
| 1 | 0.746 |
| 2 | 0.880 |
| 3 | 0.889 |
| 5 | 0.923 |
| 8 | 0.930 |
| 32 | 0.938 |

Five channels therefore recover 98.5% of full-probe AUC. The earlier claim that the plan required all channels arose from testing a subset chosen by an overly strict temporal-stability threshold; that subset omitted the second-most informative channel. The corrected result is concentrated encoding with a long tail, not uniform distribution.

This concentration is representational rather than a proof that those five channels alone are necessary. Suppressing small channel groups often leaves behavior intact, likely because weaker channels, lower layers, hidden states, and recurrent reconstruction provide redundancy. Nevertheless, the linear information geometry is clear: route membership is dominated by a small stable-like subspace.

### 8.2 Immediate action occupies two different channels

Two other cell-state channels, one vertical and one horizontal, decode action far better than the plan channels. The five plan channels achieve 29.1% five-way action accuracy; the two action channels achieve 77.1%. The direction reverses for trajectory decoding: plan channels reach AUC 0.923; action channels reach 0.612. Confidence intervals do not overlap. All 32 channels reach 87.2% action accuracy and AUC 0.938 for trajectory, so the specialized subsets capture most but not all of their respective signals.

The action channels are volatile across environment steps, whereas the leading plan channels are comparatively stable. This creates a useful division of labor. A route can persist with small corrections while the immediate action is rapidly rewritten. The same cell-state workspace supports both functions through non-overlapping subspaces.

Action information remains spatially redundant downstream. Removing the two action channels from all hidden-state positions reduces solves from 98 to 84 out of 100, but removing them only at the four cardinal neighbors has no detectable effect; even removing all hidden channels only at those cardinal positions can be compensated in that final-readout intervention. This does not erase the strong evidence that cardinal neighborhoods are important during **generation** through recurrent gating. It means that by the time the final hidden state reaches the dense policy readout, action evidence has spread to a broader spatial support. Causal site and decodable readout site are not identical.

### 8.3 Route horizon is compressed rather than enumerated

The route subspace also compresses time. Exact future-position probes use roughly 9.6 effective channels at one step ahead but only 1.5 at five steps ahead. A five-horizon weight matrix has effective rank around three. Near-future route information is detailed and high dimensional; farther-future information collapses into coarse reachability directions. This matches receding-horizon control: precise immediate geometry is needed for the next action, while distant future structure can remain abstract until the agent approaches it.

## 9. How the action is written: directional gates and sign reversal

The final stage converts the refined spatial plan into one discrete action. The relevant mechanism is not a simple global average of the cell state. The third-layer output gate controls which cell content enters the hidden state:

`h3 = o3 ⊙ tanh(c3)`

Opening this gate uniformly is catastrophic, reducing solve rate to zero in one intervention series; replacing its spatial pattern with a uniform mean yields only 5% solves. Closing the neighborhood around the player is likewise catastrophic, whereas closing the player cell alone is mild. More precise interventions show that closing the four cardinal neighbors destroys performance while closing the four diagonals leaves 93.3% solves. The gate pattern is aligned with the action space.

Gate magnitude is also direction selective. At the final internal state, the forward cardinal cell exceeds the backward cell by 0.126 on average, with a paired standardized effect of 1.48. Yet closing any single cardinal direction is benign. The computation is comparative: all four directions jointly form an action landscape, and redundancy allows loss of one sample.

Global max-pool broadcasting helps localize this gate around the player, but does not determine which direction wins. Removing or shuffling the broadcast preserves nearly all directional asymmetry. The primary symmetry breaker is the previous third-layer hidden state. Zeroing it leaves only 43.2% of directional asymmetry; spatially shuffling it leaves 36.9%. Static visual features act mainly as constraints, and the lower layer supplies a smaller contribution. Direction is therefore progressively inherited and revised through recurrent feedback, not freshly chosen by a one-shot visual template.

The two action channels make this process discrete. Because output gates are nonnegative, the sign of a hidden action-channel value is inherited from the corresponding cell-state content; the gate modulates magnitude. During navigation overrides—states where an early policy differs from the final policy—the action channels show a characteristic decision-boundary trajectory. At the incoming state, only 7.0% of relevant cells already have the final sign. After the first translated state, none do. After the second update, 85.5% do; after the final update, all do by construction. Among cells that flip, 78.7% cross between the first and second updates, while 14.3% cross during the final update.

Magnitude exposes the boundary crossing. Mean absolute cell value declines from 0.776 in the carried state to 0.459 after translation and 0.308 at the main flip stage, then recovers to 0.379. Policy correction is temporally locked to this event: 91.9% of cells that flip during the second update occur in steps whose policy is already correct at that same stage. The output gate opens by roughly 5% during override, but hidden magnitude still falls because the cell content passes near zero. Content chooses the sign; the gate adjusts confidence and spatial routing.

This microscopic pattern explains the macroscopic default sequence. The old action sign is carried across steps. Translation moves the state toward a new decision boundary while revealing the box-attraction heuristic. Obstacle-gated refinement pushes the two-dimensional affordance register across zero when global routing contradicts the heuristic. The final update consolidates the new sign.

## 10. The emergent algorithm

The evidence can now be stated as a unified procedure. The description separates episode initialization from normal tracking because the same recurrent machinery is used differently in those regimes.

### 10.1 State variables

At an abstract level, the controller maintains:

- (q_i): a choice score for each candidate box (i);
- (d_i): a feasibility estimate related to distance from the player to a legal push stance for box (i);
- `b*`: the currently preferred box-level macro-action;
- (P(x,y)): a compact route or reachability field over board cells;
- (C(x,y)): obstacle and manipulation constraints that gate spatial propagation;
- (a_v, a_h): vertical and horizontal action-affordance registers encoded primarily by two volatile channels.

These are functional variables, not claims that a single neuron stores each scalar. Box choice is distributed at the tested causal site; the route and action variables are concentrated but still embedded in a larger nonlinear state.

### 10.2 Initialization

At the first environment step:

1. Encode walls, floor, boxes, player, and targets into a spatial feature map.
2. Use stacked convolutions and global broadcast to create a broad heuristic seed.
3. Treat current boxes as candidate subgoals.
4. Repeatedly propagate vector-valued route evidence between neighboring cells.
5. Use obstacle-conditioned gate packets to block propagation through walls and boxes and to sharpen topological regions.
6. Estimate access to legal push stances and combine feasibility with learned strategic features to rank candidate boxes.
7. Select a winning box (b^*) and form a route field toward an appropriate stance.
8. Convert the local route comparison into vertical and horizontal affordance signs, then read out the primitive action.

### 10.3 Tracking and control

At later environment steps:

1. Carry the previous route field and affordance state forward.
2. Translate the carried field opposite the player’s last movement to realign coordinates.
3. Update box-choice evidence; preserve the winning macro-action unless new feasibility or strategic evidence changes the ranking.
4. Reapply obstacle-gated message passing, using global broadcast to communicate constraint pressure.
5. If a box moved, create a new boundary at its destination, actively erase the old boundary at its origin, preserve route context, and suppress illegal action channels.
6. Compare the refined field around the player.
7. Rewrite the two action-affordance signs if the globally supported route differs from the carried or box-attraction default.
8. Execute one action and repeat.

The following pseudocode captures the scientific content without pretending to reproduce the neural implementation exactly:

```text
function DRC_PLAN(board, recurrent_state):
    features = encode(board)
    boxes = candidate_boxes(board)

    if recurrent_state is empty:
        plan_field = broad_spatial_seed(features, global_broadcast(features))
        action_register = neutral
    else:
        plan_field = translate(recurrent_state.plan_field,
                               opposite(recurrent_state.previous_action))
        action_register = recurrent_state.action_register

    for each candidate box i:
        stance_cost[i] = estimate_legal_push_stance_cost(plan_field,
                                                         features,
                                                         box=i)
        choice_score[i] = candidate_evidence(plan_field,
                                             features,
                                             box=i,
                                             stance_cost=stance_cost[i])

    chosen_box = argmax_feasible(choice_score, stance_cost)

    for recurrent_update in {1, 2, 3}:
        global_context = max_pool_broadcast(plan_field, action_register)
        plan_field = local_message_pass(plan_field,
                                        features,
                                        chosen_box,
                                        global_context)
        plan_field = impose_obstacle_boundaries(plan_field, board)
        action_register = update_cardinal_affordances(plan_field,
                                                      action_register)

    action = policy_readout(action_register, features)
    return action, persistent(plan_field, chosen_box, action_register)
```

The phrase **argmax feasible** is crucial. Choice is not a free categorical switch. The intervention results imply a constrained competition in which semantic evidence can change the winner among plausible candidates but rarely override a large physical disadvantage. Likewise, **local message pass** includes global context and nonlinear gates; it is not a bare convolution.

### 10.4 What kind of human-designed algorithm is this closest to?

The DRC combines motifs from several classical families without exactly matching any one of them.

- It resembles **value iteration** because repeated local updates propagate route quality through space, and an extracted neighbor operator partially substitutes for the native computation.
- It resembles **wavefront or distance-transform planning** because early fields are continuous and geometric, then sharpen at obstacles.
- It resembles **hierarchical planning** because a discrete box-level subgoal persists across many primitive actions.
- It resembles **model-predictive control** because the plan is carried forward, one action is executed, and the field is repaired after each observation.
- It resembles an **attractor decision system** because directional evidence is carried, amplified, or reversed by recurrent dynamics.

The best compact description is therefore not “the network learned value iteration.” It learned a hierarchical receding-horizon planner whose low-level routing primitive is bounded spatial value propagation.

## 11. Resolving the apparent contradictions in the evidence

A mature mechanistic account should explain why several earlier conclusions appeared mutually inconsistent. These were not merely disagreements in wording. They exposed real redundancies and scale-dependent descriptions of the same system.

### 11.1 Future entities versus abstract reachability

Future player and box locations are strongly decodable, and semantic box injections can alter behavior. It was therefore reasonable to describe the network as a forward spatial simulator. Yet future-board probes are confounded by static persistence, inner stages do not align with future time steps, and path timing is weakly represented. The resolution is that the network simulates **task-relevant spatial consequences**, not complete future frames. A route field can predict future occupancy because the future player follows the route. A dynamic box footprint can predict a push destination because object manipulation is embedded in the plan. These variables are genuine, but they are projections of a shared planning field rather than separate imagined scenes.

### 11.2 Value field versus trajectory field

Global return and geometric distance are linearly decodable from recurrent states. At the same time, controlled comparisons show that final third-layer cell vectors predict future-path membership better than scalar distance: on-path AUC is 0.929, whereas per-cell distance R² is about 0.263 under matched conditions. This does not mean distance findings were spurious. Early and intermediate states contain continuous geometric gradients; recurrent boundary sharpening and subgoal conditioning transform those gradients into a route-specific field. “Value,” “distance,” “reachability,” and “trajectory” describe different readouts or phases of a vector-valued computation. The final state is closest to a selected route, while the update rule retains the propagation logic of a value backup.

### 11.3 Cell-state dispensability versus cell-state planning

Resetting all cell states at every environment step preserves 92% solve rate versus 94% in the baseline, whereas resetting all recurrent states leaves only 32%. This led to the strong claim that cell states are dispensable and hidden states are the true planning substrate. Later work found exact natural persistence of trajectory and action features in the cell state, catastrophic effects from full within-step third-layer cell ablation, and compact plan/action channel structure.

The conflict disappears when three operations are separated:

1. **Natural storage:** under normal execution, cell states carry plan content across steps.
2. **Within-step computation:** cell updates are necessary components of the recurrent transformation, and hidden states are generated from gated cell content.
3. **Exclusive cross-step dependence:** the policy does not rely uniquely on cell-state memory because hidden states, board input, lower layers, global broadcast, and rapid recurrent reconstruction provide alternate routes.

The cell state is a preferred carrier and computational workspace, not a single point of failure. Hidden-state interventions often have larger immediate effects because hidden states directly feed subsequent layers and the policy, whereas cell perturbations are filtered through gates. Causal proximity to output should not be confused with sole ownership of the plan.

### 11.4 Independent direction versus value-derived direction

Early gate decomposition found weak linear dependence between gate opening and cell-state magnitude, with the previous hidden state accounting for much of directional asymmetry. This supported a model in which direction crystallized largely independently of spatial content and then attended to that content. Later action-channel analysis gives a more precise statement. Output-gate values are nonnegative; the sign of the directional hidden signal is therefore determined by cell-state sign. During overrides, the two action channels visibly cross zero, and policy correction is locked to that crossing. The gate modulates where and how strongly the content is expressed, but the content determines the binary direction.

Direction is consequently neither read from a scalar value field in a single operation nor independent of the field. It is a recurrently maintained affordance state whose sign is rewritten by spatial refinement. Prior hidden state supplies inertia; global and local geometry determine whether that inertia survives.

### 11.5 Distributed plan versus concentrated plan

An early channel analysis reported that no small “stable” subset decoded trajectory above chance and concluded that the plan was distributed across all 32 channels. A later reconstruction curve showed that the tested subset was poorly chosen. The five channels selected by actual probe contribution reach AUC 0.923 compared with 0.938 for all channels. This is a direct correction, not a matter of interpretation.

The remaining nuance is causal redundancy. Concentrated linear decodability does not imply that removing those channels must destroy behavior. Other channels contain weaker correlated signal, and recurrence can reconstruct damaged state. The correct claim is that most linearly readable trajectory information is concentrated in a small subspace, while functional robustness is distributed across pathways.

### 11.6 Cardinal bottleneck versus spatially redundant action information

Closing the third-layer output gate at all four cardinal neighbors is catastrophic, strongly implicating that neighborhood in generating action-aligned hidden content. Yet suppressing final hidden-state channels only at those cells can be behaviorally benign. The interventions act at different points. Gate closure disrupts recurrent computation and prevents the correct pattern from being generated and propagated. Final-state spatial suppression occurs after action information has become readable at many positions and can be compensated by the dense readout. A mechanistic pathway can be spatially specific at its generative bottleneck and spatially redundant at its endpoint.

These resolutions yield a general methodological lesson: apparent contradictions often arise from changing the level of analysis—representation versus transformation, natural use versus exclusive necessity, or generation versus readout. The final algorithm was recoverable only by keeping those distinctions explicit.

## 12. Strength of evidence for each part of the algorithm

The central claims are not equally supported. The following table separates what is established from what remains interpretive.

| Algorithmic component | Strongest evidence | Assessment |
|---|---|---|
| Aggregated long-horizon route rather than frame-by-frame rollout | No tick-to-horizon diagonal; high path AUC with weak temporal ordering; constant horizon-decay slope | Strongly established |
| Local spatial message passing | Neighbor-only transformation probe; spatial-shuffle control; explicit replacement beating frozen and random controls | Strong partial equivalence |
| Nonlinear obstacle boundaries | Ghost-box and ghost-wall causal severing; norm-preserving gate-packet suppression | Strongly established |
| Cross-step carry and event-triggered refinement | Exact probe/sign persistence; larger updates at direction changes | Strongly established for measured subspaces |
| Directional translation after movement | Action-conditioned kernels; temporal localization; partial causal restoration | Supported, but incomplete as a replacement model |
| Compact plan and action subspaces | Reconstruction curve and double dissociation | Strong representational evidence; causal necessity remains partly redundant |
| Action rewriting by sign crossing | Temporal sign trajectory and policy-lock analysis | Strong temporal/mechanistic evidence; direct prevention experiment remains absent |
| Discrete next-box macro-action | High localized choice AUC, long-horizon coordinate decoding, persistent rank dominance | Strong representational evidence |
| Feasibility-bounded macro-action competition | Push-stance cost decoding and cost-stratified identity steering | Strong causal evidence for a boundary, not a full choice equation |
| Exact optimal Sokoban search | Not demonstrated | Unsupported and not required by the data |

Two results deserve particular emphasis because they move beyond correlation. First, the explicit neighbor operator improves action match by 12.4 percentage points over the frozen-state floor and by 42.6 points over a matched random operator. The native gap remains substantial, but the extracted algorithm performs real computational work. Second, box-identity steering changes behavior in a cost-dependent manner. A generic disruptive account cannot easily explain why the same semantic patch succeeds about sixteen times more often when the alternative is no more costly than when it is more than two stance steps costlier.

## 13. Scientific implications

### 13.1 A learned policy can discover symbolic hierarchy without symbolic state variables

The network was trained as a model-free policy, yet its behavior is best described using discrete candidates, feasibility costs, route maintenance, and event-triggered control. The “symbols” are not hand-coded tokens. Candidate identity is a distributed localized pattern at each box, and the route is a continuous spatial field. Nevertheless, their interaction is algorithmically symbolic: choose one member of a finite set, retain it as a macro-action, and invoke a lower-level controller until the associated push occurs.

This is a concrete example of a continuous neural system producing a hybrid computation. Continuous fields handle geometry and uncertainty; discrete competition handles commitment. The causal boundary between them is informative: categorical intervention can alter a near-tie but cannot normally violate the spatial feasibility manifold.

### 13.2 Recurrent depth implements qualitative phases, not merely extra capacity

The inner loop is often described as “thinking longer.” Here each update has a distinct role even though weights are shared. The incoming state supplies continuity. The first update realigns coordinates and exposes a local box-oriented heuristic. The second is the primary decision-boundary crossing stage. The third resolves residual cases and consolidates magnitude. Shared weights therefore produce phase-like computation because their inputs occupy different regions of state space at successive iterations.

This observation helps explain why two updates can be nearly sufficient while one is inadequate. The first iteration does not perform a weaker version of the final computation; it produces an intermediate with a characteristic, useful, but systematically biased policy.

### 13.3 Robustness comes from redundancy across representations and pathways

Several apparently paradoxical ablations are signatures of redundancy. Cell-state memory can be reset with limited behavioral loss even though cell states naturally carry plans. Small channel groups can be removed without catastrophe even though those channels dominate linear decoding. Single cardinal gate sites can be closed without effect even though all four together are essential. The architecture distributes recoverability more broadly than it distributes information.

This suggests a useful distinction for neural algorithms: **where a variable is most legible** need not be **where it is uniquely stored**, and **where an intervention has immediate leverage** need not be **where the variable is computed**. Mechanistic claims should specify which of these meanings is intended.

### 13.4 The policy uses a topological cost, not naive proximity

The higher-level choice results directly illuminate competent Sokoban play. Raw distance to a box is predictive because nearby boxes are often natural targets. But distance to a legal push stance is better, and the full latent choice score is better still. The controller appears to evaluate not merely “which box is close?” but “which box can I get behind in a way that supports a legal manipulation, given the board’s current topology and learned strategic context?”

That is exactly the abstraction needed to avoid the one-update box-attraction failure. A purely reactive agent approaches boxes. The recurrent planner evaluates approach sides, obstacles, and route consequences before committing.

## 14. Scope, limitations, and falsifiable next questions

This synthesis supports a detailed algorithm, but its scope is bounded.

First, all results concern one trained 250-million-step checkpoint on 8×8 Sokoban. The algorithm may reflect both the architecture and this training run. Replication across random seeds, board sizes, and recurrent depths is needed before treating the mechanism as a universal property of DRC agents.

Second, many targets are defined from the agent’s own future behavior. “Chosen box,” “future route,” and “next push” summarize what the policy later does; they do not independently establish optimality. The evidence explains the agent’s planning algorithm, not a proof that every internal plan is globally optimal.

Third, push-stance distance is still a simplified cost. It captures access to an immediately legal side of a box but not whether the resulting push creates a later deadlock, preserves access to all targets, or belongs to a complete solution. The remaining gap between cost AUC 0.769 and choice AUC near 0.960 likely contains precisely these strategic factors, along with correlations specific to the training distribution.

Fourth, linear probes reveal only linearly readable variables. This is appropriate for testing simple mechanistic interfaces, but nonlinear information may exist in the remaining channels. Conversely, high linear accuracy can arise for variables that are downstream consequences rather than causes. The paper therefore gives priority to results with causal controls.

Fifth, intervention strength remains delicate. Large semantic vectors can leave the natural activation manifold. Random controls sometimes flip actions by destroying the original logit rather than increasing the target logit. The cleanest claims use matched controls, spatial shuffles, cost stratification, or norm-preserving suppression. Even then, successful causal steering is incomplete.

Sixth, the explicit operators are approximations. The neighbor-only transition reaches 72.2% action match, not native performance. The translation operator restores only 32.5% of the probability lost by ablating the first update. Coupled gates, lower-layer interactions, tick-specific transforms, and global broadcasts account for the residual.

Seventh, the macro-action result identifies the next box, not the intended push direction, target square, or full sequence of box manipulations. Some evidence shows that next-push direction and location become more decodable during push states, but a complete hierarchy above “next box” remains unresolved.

These limitations lead to discriminating predictions that follow from the proposed algorithm:

1. Preventing the second-update sign crossing in the two action channels should selectively preserve box-attraction errors at navigation-override states.
2. A nonlinear intervention that changes a candidate’s complete push-stance feasibility field, while keeping identity fixed, should shift choice more reliably than adding a single distance vector.
3. Perturbing the five route channels should have larger effects when recurrent repair and hidden-state compensation are simultaneously blocked.
4. The chosen-box representation should switch abruptly when a push changes the feasibility ordering among candidates, but should otherwise remain rank stable.
5. Replicated agents with different recurrent depths should retain the hierarchy but may allocate translation, boundary refinement, and sign consolidation across different numbers of updates.

These are tests of the integrated account, not requests to decorate an already complete story. Failure of the first two would challenge the proposed causal linkage between spatial refinement, feasibility, and discrete action or subgoal choice.

## 15. Evidence provenance within the local research record

The synthesis draws primarily on the full archived papers listed below, supplemented by their associated experiment reports and raw logs where numerical verification was needed. Titles are given without internal database handles.

### Milestone syntheses read in full

- *The Emergent Planning Algorithm: Decoupled Attention-Content Routing in the DRC Sokoban Agent*
- *Unmasking the Oracle: How Deep Recurrent Networks Plan via Latent Bellman Backups*
- *The Emergent Planning Algorithm of the DRC Agent: A Synthesis of Generative Diffusion and Directional Translation*
- *The Emergent Spatial Planning Algorithm: From Continuous Fields to Categorical Affordances*
- *Asymmetric Functional Architecture of c3: Distributed Plan, Concentrated Action*

### Corrective and capstone evidence read in full

- *Concentrated Plan, Concentrated Action: Correcting the Distributed-Plan Hypothesis in c3*
- *Temporal Dynamics of Decision-Boundary Crossing in the DRC Action Subspace*
- *Parameter-Level Execution of the Coupled Boundary Packet*
- *The Parameter-Level Geometry of Box Push Dynamics: Visual Causality and Channel Specialization in Tracking Boundaries*
- *The Emergent Planning Algorithm: Discrete Subgoal Competition Bounded by Spatial Value Iteration*

### Principal supporting papers

- *Rethinking Emergent Planning: From Spatial Entity Isomorphism to Distributed Value Computation*
- *Dissociation Between Representation Decodability and Causal Importance in a Trained Planning Agent*
- *Iterative Path Footprint Routing: Resolving Spatial and Abstract Planning*
- *Selected Push-Route Representations Beyond Shortest Paths*
- *Cross-Step Cell-State Dispensability and Hidden-State Mediation in DRC Spatial Planning*
- *Iterative Value Propagation and the Geometric Distance Attractor*
- *Output Gate Masking: Bridging the Distributed Reachability Graph and Local Policy Readout*
- *The Output Gate as Directional Affordance Router*
- *Iterative Global-to-Local Coordination via Max-Pool Broadcast in DRC Spatial Planning*
- *The Distance Gradient Readout: Bridging Global Value Iteration and Local Policy Routing*
- *Causal Induction of Diffusion Boundaries via Ghost Obstacles*
- *Model-Predictive Control Dynamics in DRC Planning*
- *The Bellman Backup as Navigation Router: Iterative Computation Overrides Sequential Defaults in DRC Planning*
- *Cardinal Affordance Reversal: The Representational Mechanism of Navigation Override in DRC Planning*

This list is not intended as a sequence of mini-summaries. It identifies the local primary record from which the integrated claims and numerical values were derived.

## 16. Conclusion

The trained DRC agent has learned a recognizable planning algorithm, but not a literal copy of any single textbook procedure. Its solution is hierarchical and hybrid.

At the top level, the controller turns boxes into discrete candidate macro-actions. It estimates how feasible each candidate is by evaluating access to legal push stances through the current board topology. A learned choice signal ranks the candidates, and the winning box remains dominant while the player navigates toward it. Causal interventions can change this winner, but mainly when the alternative is already competitive in the spatial cost field. The continuous geometry therefore constrains the discrete decision.

At the lower level, the controller maintains a compact spatial plan. On the first step, recurrent neighbor-to-neighbor updates build the field from a broad visual seed. On later steps, the previous field is carried forward, translated to compensate for movement, and repaired by obstacle-gated diffusion. Walls and boxes create learned nonlinear boundary conditions; pushes move those boundaries through channel-selective gate updates. Global max-pool broadcasting communicates constraint pressure quickly across the board while local convolutions preserve spatial precision.

The resulting route is converted into action through specialized state variables. Roughly five channels contain nearly all linearly decodable trajectory information, while two different volatile channels form vertical and horizontal affordance registers. The old action is carried into the next step. One recurrent update removes coordinate staleness but leaves a box-attraction heuristic. Further refinement can drive the affordance registers through zero and reverse their signs, producing the globally appropriate navigation action. The output gate shapes the spatial and magnitude profile presented to the policy.

The complete scientific answer is therefore:

> **The DRC solves Sokoban by discrete competition among box-level subgoals, bounded by a dynamically computed push-feasibility field; it executes the selected subgoal with a persistent, translated, obstacle-gated route representation and rewrites a compact directional affordance register at each step.**

This account directly connects concept probes to causal interventions and culminates in a formal algorithmic description. It explains why future paths are decodable without literal future-frame simulation, why cell-state plans can be naturally persistent yet behaviorally redundant, why one recurrent update approaches boxes while later updates choose detours, and why semantic box-choice steering succeeds only inside the geometry of feasible plans. The emergent computation is best understood as hierarchical model-predictive control built from bounded spatial value propagation—not a monolithic rollout, not a reflex, and not unconstrained symbolic search.
